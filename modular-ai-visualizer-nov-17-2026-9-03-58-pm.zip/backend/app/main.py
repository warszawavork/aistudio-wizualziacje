from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api.router import api_router
from app.core.config import get_settings
from app.db.database import Base, SessionLocal, engine, ensure_sqlite_schema_migrations
from app.db.seed import seed_initial_data
from app.services.storage_service import ensure_storage_directories


@asynccontextmanager
async def lifespan(_app: FastAPI):
    settings = get_settings()
    ensure_storage_directories(settings)
    Base.metadata.create_all(bind=engine)
    ensure_sqlite_schema_migrations(engine)
    db = SessionLocal()
    try:
        seed_initial_data(db)
    finally:
        db.close()
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    ensure_storage_directories(settings)

    application = FastAPI(
        title=settings.app_name,
        version="0.1.0",
        description="Stage 1 foundation API for Modular AI Visualizer.",
        lifespan=lifespan,
    )

    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    application.include_router(api_router, prefix=settings.api_prefix)
    application.mount(
        "/storage",
        StaticFiles(directory=str(settings.storage_path)),
        name="storage",
    )
    return application


app = create_app()
