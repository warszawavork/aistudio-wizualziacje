import hashlib
import os
import re
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile, status

from app.core.config import Settings

ALLOWED_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".svg"}
ALLOWED_SUBFOLDERS = {"uploads", "sketches", "renders"}
MAX_UPLOAD_BYTES = 15 * 1024 * 1024  # 15 MB


def ensure_storage_directories(settings: Settings) -> Path:
    base = settings.storage_path.resolve()
    for folder in ALLOWED_SUBFOLDERS:
        (base / folder).mkdir(parents=True, exist_ok=True)
    return base


def _sanitize_stem(filename: str) -> str:
    stem = Path(filename).stem.lower()
    cleaned = re.sub(r"[^a-z0-9_-]+", "_", stem).strip("_")
    return cleaned[:40] or "file"


def _validate_safe_target_dir(base: Path, subfolder: str) -> Path:
    clean_subfolder = (subfolder or "").strip().strip("/")
    if clean_subfolder not in ALLOWED_SUBFOLDERS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Niedozwolony katalog docelowy magazynu ({subfolder}).",
        )
    target_dir = (base / clean_subfolder).resolve()
    if not target_dir.is_relative_to(base.resolve()):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Wykryto niedozwoloną ścieżkę zapisu pliku.",
        )
    target_dir.mkdir(parents=True, exist_ok=True)
    return target_dir


def _validate_uploaded_file_bytes(contents: bytes, ext: str) -> None:
    if ext == ".png":
        if not contents.startswith(b"\x89PNG\r\n\x1a\n"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Plik .png ma nieprawidłową sygnaturę binarną (uszkodzony lub niezgodny format obrazu).",
            )
        return

    if ext in {".jpg", ".jpeg"}:
        if not contents.startswith(b"\xff\xd8\xff"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Plik JPEG ma nieprawidłową sygnaturę binarną (uszkodzony lub niezgodny format obrazu).",
            )
        return

    if ext == ".webp":
        if not (len(contents) >= 12 and contents[:4] == b"RIFF" and contents[8:12] == b"WEBP"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Plik WEBP ma nieprawidłową sygnaturę binarną (uszkodzony lub niezgodny format obrazu).",
            )
        return

    if ext == ".svg":
        try:
            text_content = contents.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Plik SVG nie jest poprawnym dokumentem tekstowym UTF-8.",
            ) from exc
        lowered = text_content.lower()
        if "<svg" not in lowered:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Plik SVG nie zawiera znacznika <svg>.",
            )
        if "<script" in lowered or "javascript:" in lowered or "onerror=" in lowered or "onload=" in lowered:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Plik SVG zawiera niedozwolone skrypty aktywne i został odrzucony ze względów bezpieczeństwa.",
            )


def _atomic_write_deduplicated(
    target_dir: Path,
    base: Path,
    subfolder: str,
    stem: str,
    ext: str,
    contents: bytes,
) -> str:
    content_hash = hashlib.sha256(contents).hexdigest()[:16]
    suffix_pattern = f"_{content_hash}{ext}"

    # Check if an identical file (by SHA-256 content hash) is already stored in this subfolder
    for existing in target_dir.glob(f"*{suffix_pattern}"):
        if existing.is_file() and existing.stat().st_size == len(contents):
            return f"/storage/{subfolder}/{existing.name}"

    unique_name = f"{stem}_{content_hash}{ext}"
    target_path = (target_dir / unique_name).resolve()
    if not target_path.is_relative_to(base.resolve()):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nieprawidłowa ścieżka docelowa pliku.",
        )

    tmp_path = target_dir / f".tmp_{uuid.uuid4().hex}{ext}"
    try:
        tmp_path.write_bytes(contents)
        os.replace(tmp_path, target_path)
    except Exception:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass
        raise

    return f"/storage/{subfolder}/{unique_name}"


def save_generated_render_bytes(
    image_bytes: bytes,
    mime_type: str,
    settings: Settings,
    prefix: str = "render",
) -> str:
    from app.providers.image_providers import validate_image_magic_bytes

    detected_mime = validate_image_magic_bytes(image_bytes)
    ext_map = {
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/webp": ".webp",
    }
    ext = ext_map.get(detected_mime or mime_type, ".png")
    base = ensure_storage_directories(settings)
    renders_dir = _validate_safe_target_dir(base, "renders")
    return _atomic_write_deduplicated(
        target_dir=renders_dir,
        base=base,
        subfolder="renders",
        stem=_sanitize_stem(prefix),
        ext=ext,
        contents=image_bytes,
    )


async def save_uploaded_image(
    file: UploadFile,
    settings: Settings,
    subfolder: str = "uploads",
) -> str:
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Brak nazwy przesłanego pliku.",
        )

    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Nieobsługiwany format pliku ({ext}). Dozwolone: PNG, JPG, WEBP, SVG.",
        )

    contents = await file.read()
    if not contents:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Przesłany plik jest pusty.",
        )
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="Plik przekracza maksymalny rozmiar 15 MB.",
        )

    _validate_uploaded_file_bytes(contents, ext)

    base = ensure_storage_directories(settings)
    target_dir = _validate_safe_target_dir(base, subfolder)
    return _atomic_write_deduplicated(
        target_dir=target_dir,
        base=base,
        subfolder=subfolder.strip("/"),
        stem=_sanitize_stem(file.filename),
        ext=ext,
        contents=contents,
    )
