import json
from datetime import datetime, timezone
from typing import Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.project import Project
from app.models.reference import ReferenceItem
from app.schemas.reference import (
    ReferenceContextItem,
    ReferenceContextPreview,
    ReferenceCreate,
    ReferenceRead,
    ReferenceUpdate,
    get_reference_category_label,
    get_reference_role_for_ai,
    parse_tags_list,
)


class ReferenceInUseError(Exception):
    """Raised when attempting to delete a reference that is actively assigned to a project."""

    def __init__(self, reference_id: int, title: str, project_titles: List[str]):
        self.reference_id = reference_id
        self.title = title
        self.project_titles = project_titles
        joined = ", ".join(project_titles)
        super().__init__(
            f"Referencja „{title}” (ID {reference_id}) jest aktualnie wykorzystywana przez "
            f"projekt(y): {joined}. Aby chronić spójność projektu i plików referencyjnych, "
            f"najpierw odłącz referencję w szczegółach projektu lub potwierdź bezpieczne "
            f"odłączenie i usunięcie wpisu."
        )


def _extract_project_ref_ids(project: Project) -> List[int]:
    try:
        raw = json.loads(project.reference_ids_json or "[]")
        if not isinstance(raw, list):
            return []
        return [int(x) for x in raw if isinstance(x, (int, str)) and str(x).isdigit()]
    except json.JSONDecodeError:
        return []


def _load_projects_map(db: Session) -> Dict[int, Project]:
    rows = db.scalars(select(Project).order_by(Project.id.asc())).all()
    return {row.id: row for row in rows}


def _to_reference_read(
    item: ReferenceItem,
    projects_by_id: Dict[int, Project],
) -> ReferenceRead:
    linked_ids: List[int] = []
    if item.project_id is not None and item.project_id in projects_by_id:
        linked_ids.append(item.project_id)

    for pid, proj in projects_by_id.items():
        ref_ids = _extract_project_ref_ids(proj)
        if item.id in ref_ids and pid not in linked_ids:
            linked_ids.append(pid)

    linked_titles = [projects_by_id[pid].title for pid in linked_ids if pid in projects_by_id]
    tags = parse_tags_list(item.style_tags)
    original_path = item.image_url or item.paired_sketch_url
    primary_project_id = (
        item.project_id
        if (item.project_id is not None and item.project_id in projects_by_id)
        else (linked_ids[0] if linked_ids else None)
    )

    return ReferenceRead(
        id=item.id,
        title=item.title,
        category=item.category,
        category_label=get_reference_category_label(item.category),
        role=get_reference_role_for_ai(item.category),
        description=item.description,
        materials_note=item.materials_note,
        lighting_note=item.lighting_note,
        style_tags=item.style_tags,
        tags=tags,
        image_url=item.image_url,
        paired_sketch_url=item.paired_sketch_url,
        original_file_path=original_path,
        project_id=primary_project_id,
        linked_project_ids=linked_ids,
        linked_project_titles=linked_titles,
        is_in_use=len(linked_ids) > 0,
        created_at=item.created_at,
        updated_at=getattr(item, "updated_at", None) or item.created_at,
    )


def _normalize_style_tags(style_tags: Optional[str], tags: Optional[List[str]]) -> str:
    if tags is not None:
        cleaned = [t.strip().lstrip("#").strip() for t in tags if t and t.strip()]
        return ", ".join(dict.fromkeys(cleaned))
    if style_tags is not None:
        return ", ".join(parse_tags_list(style_tags))
    return ""


def _add_ref_to_project(project: Project, reference_id: int) -> None:
    current = _extract_project_ref_ids(project)
    if reference_id not in current:
        current.append(reference_id)
        project.reference_ids_json = json.dumps(current)


def _remove_ref_from_project(project: Project, reference_id: int) -> None:
    current = _extract_project_ref_ids(project)
    if reference_id in current:
        current = [rid for rid in current if rid != reference_id]
        project.reference_ids_json = json.dumps(current)


def list_references(
    db: Session,
    category: Optional[str] = None,
    search: Optional[str] = None,
    project_id: Optional[int] = None,
    tag: Optional[str] = None,
    limit: Optional[int] = None,
    offset: int = 0,
) -> List[ReferenceRead]:
    stmt = select(ReferenceItem).order_by(ReferenceItem.created_at.desc(), ReferenceItem.id.desc())
    if category:
        if category in {"sketch_pair", "sketch_plan"}:
            stmt = stmt.where(ReferenceItem.category.in_(["sketch_pair", "sketch_plan"]))
        else:
            stmt = stmt.where(ReferenceItem.category == category)
    if search and search.strip():
        pattern = f"%{search.strip()}%"
        stmt = stmt.where(
            ReferenceItem.title.ilike(pattern)
            | ReferenceItem.description.ilike(pattern)
            | ReferenceItem.materials_note.ilike(pattern)
            | ReferenceItem.lighting_note.ilike(pattern)
            | ReferenceItem.style_tags.ilike(pattern)
            | ReferenceItem.category.ilike(pattern)
        )
    rows = db.scalars(stmt).all()
    projects_by_id = _load_projects_map(db)
    results = [_to_reference_read(row, projects_by_id) for row in rows]

    if tag and tag.strip():
        target_tag = tag.strip().lstrip("#").lower()
        results = [
            r
            for r in results
            if any(t.lower() == target_tag or target_tag in t.lower() for t in r.tags)
        ]

    if project_id is not None:
        results = [
            r
            for r in results
            if r.project_id == project_id or project_id in r.linked_project_ids
        ]

    if offset > 0:
        results = results[offset:]
    if limit is not None and limit >= 0:
        results = results[:limit]

    return results


def get_reference(db: Session, reference_id: int) -> Optional[ReferenceRead]:
    item = db.get(ReferenceItem, reference_id)
    if item is None:
        return None
    projects_by_id = _load_projects_map(db)
    return _to_reference_read(item, projects_by_id)


def create_reference(db: Session, payload: ReferenceCreate) -> ReferenceRead:
    normalized_tags = _normalize_style_tags(payload.style_tags, payload.tags)
    projects_by_id = _load_projects_map(db)

    desired_project_ids: List[int] = []
    if payload.project_id is not None and int(payload.project_id) in projects_by_id:
        desired_project_ids.append(int(payload.project_id))
    if payload.linked_project_ids:
        for pid in payload.linked_project_ids:
            if int(pid) in projects_by_id and int(pid) not in desired_project_ids:
                desired_project_ids.append(int(pid))

    valid_project_id: Optional[int] = desired_project_ids[0] if desired_project_ids else None

    item = ReferenceItem(
        title=payload.title.strip(),
        category=payload.category,
        description=payload.description.strip(),
        materials_note=payload.materials_note.strip(),
        lighting_note=payload.lighting_note.strip(),
        style_tags=normalized_tags,
        image_url=payload.image_url,
        paired_sketch_url=payload.paired_sketch_url,
        project_id=valid_project_id,
    )
    db.add(item)
    db.flush()

    for pid in desired_project_ids:
        target_project = projects_by_id.get(pid)
        if target_project is not None:
            _add_ref_to_project(target_project, item.id)

    db.commit()
    db.refresh(item)
    return _to_reference_read(item, projects_by_id)


def update_reference(
    db: Session,
    reference_id: int,
    payload: ReferenceUpdate,
) -> Optional[ReferenceRead]:
    item = db.get(ReferenceItem, reference_id)
    if item is None:
        return None

    data = payload.model_dump(exclude_unset=True)
    projects_by_id = _load_projects_map(db)

    if "title" in data and data["title"] is not None:
        item.title = data["title"].strip()
    if "category" in data and data["category"] is not None:
        item.category = data["category"]
    if "description" in data and data["description"] is not None:
        item.description = data["description"].strip()
    if "materials_note" in data and data["materials_note"] is not None:
        item.materials_note = data["materials_note"].strip()
    if "lighting_note" in data and data["lighting_note"] is not None:
        item.lighting_note = data["lighting_note"].strip()
    if "style_tags" in data or "tags" in data:
        item.style_tags = _normalize_style_tags(
            data.get("style_tags", item.style_tags),
            data.get("tags"),
        )
    if "image_url" in data:
        item.image_url = data["image_url"]
    if "paired_sketch_url" in data:
        item.paired_sketch_url = data["paired_sketch_url"]

    if "linked_project_ids" in data and data["linked_project_ids"] is not None:
        desired_ids = [
            int(pid)
            for pid in data["linked_project_ids"]
            if int(pid) in projects_by_id
        ]
        for pid, proj in projects_by_id.items():
            if pid in desired_ids:
                _add_ref_to_project(proj, item.id)
            else:
                _remove_ref_from_project(proj, item.id)
        item.project_id = desired_ids[0] if desired_ids else None
    elif "project_id" in data:
        new_pid = data["project_id"]
        if new_pid is None:
            if item.project_id is not None and item.project_id in projects_by_id:
                _remove_ref_from_project(projects_by_id[item.project_id], item.id)
            item.project_id = None
        elif int(new_pid) in projects_by_id:
            item.project_id = int(new_pid)
            _add_ref_to_project(projects_by_id[int(new_pid)], item.id)

    item.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(item)
    return _to_reference_read(item, projects_by_id)


def delete_reference(
    db: Session,
    reference_id: int,
    *,
    force: bool = False,
) -> bool:
    item = db.get(ReferenceItem, reference_id)
    if item is None:
        return False

    projects_by_id = _load_projects_map(db)
    read_model = _to_reference_read(item, projects_by_id)

    if read_model.linked_project_ids and not force:
        raise ReferenceInUseError(
            reference_id=item.id,
            title=item.title,
            project_titles=read_model.linked_project_titles,
        )

    if read_model.linked_project_ids and force:
        for pid in read_model.linked_project_ids:
            proj = projects_by_id.get(pid)
            if proj is not None:
                _remove_ref_from_project(proj, item.id)

    # Note: Underlying image files on disk are intentionally preserved if any project
    # or reference uses them, preventing broken image links in historical projects.
    db.delete(item)
    db.commit()
    return True


def build_reference_context_preview(
    db: Session,
    reference_ids: List[int],
    *,
    project_id: Optional[int] = None,
    project_title: Optional[str] = None,
) -> ReferenceContextPreview:
    clean_ids: List[int] = []
    for raw_id in reference_ids:
        try:
            rid = int(raw_id)
            if rid not in clean_ids:
                clean_ids.append(rid)
        except (TypeError, ValueError):
            continue

    if not clean_ids:
        return ReferenceContextPreview(
            project_id=project_id,
            project_title=project_title,
            total_references=0,
            formatted_prompt_context="Brak przypisanych referencji z biblioteki pracowni.",
            items=[],
        )

    rows = db.scalars(select(ReferenceItem).where(ReferenceItem.id.in_(clean_ids))).all()
    rows_by_id = {r.id: r for r in rows}
    ordered_rows = [rows_by_id[rid] for rid in clean_ids if rid in rows_by_id]

    if not ordered_rows:
        return ReferenceContextPreview(
            project_id=project_id,
            project_title=project_title,
            total_references=0,
            formatted_prompt_context="Brak przypisanych referencji z biblioteki pracowni.",
            items=[],
        )

    projects_by_id = _load_projects_map(db)
    context_items: List[ReferenceContextItem] = []
    prompt_lines: List[str] = [
        "UPORZĄDKOWANY KONTEKST REFERENCYJNY Z BIBLIOTEKI PRACOWNI "
        "(TRWAŁY KONTEKST PROJEKTOWY — NIE TRENING MODELU):"
    ]

    for idx, ref in enumerate(ordered_rows, start=1):
        read_ref = _to_reference_read(ref, projects_by_id)
        if project_id is not None and project_title:
            relation = f"Przypisana do analizowanego projektu „{project_title}” (ID {project_id})"
        elif read_ref.linked_project_titles:
            relation = (
                "Powiązana w bibliotece z projektem: "
                + ", ".join(read_ref.linked_project_titles)
            )
        else:
            relation = "Wybrana z biblioteki pracowni jako materiał odniesienia dla bieżącej analizy"

        img_path = ref.image_url or ref.paired_sketch_url or "brak przypisanego pliku obrazu"
        item_obj = ReferenceContextItem(
            reference_id=ref.id,
            title=ref.title,
            category=ref.category,
            category_label=read_ref.category_label,
            role=read_ref.role,
            description=ref.description,
            tags=read_ref.tags,
            materials_note=ref.materials_note,
            lighting_note=ref.lighting_note,
            image_path=img_path,
            paired_sketch_path=ref.paired_sketch_url,
            project_relation=relation,
        )
        context_items.append(item_obj)

        details: List[str] = [
            f"{idx}. [Rola: {read_ref.role}] {ref.title} (kategoria: {read_ref.category_label} / {ref.category})"
        ]
        if ref.description:
            details.append(f"   - Opis: {ref.description}")
        if ref.materials_note:
            details.append(f"   - Materiały i kolory: {ref.materials_note}")
        if ref.lighting_note:
            details.append(f"   - Oświetlenie: {ref.lighting_note}")
        if read_ref.tags:
            details.append(f"   - Tagi: {', '.join('#' + t for t in read_ref.tags)}")
        details.append(f"   - Ścieżka do obrazu: {img_path}")
        if ref.paired_sketch_url and ref.paired_sketch_url != ref.image_url:
            details.append(f"   - Ścieżka do powiązanego szkicu: {ref.paired_sketch_url}")
        details.append(f"   - Relacja z projektem: {relation}")
        prompt_lines.append("\n".join(details))

    return ReferenceContextPreview(
        project_id=project_id,
        project_title=project_title,
        total_references=len(context_items),
        formatted_prompt_context="\n".join(prompt_lines),
        items=context_items,
    )

