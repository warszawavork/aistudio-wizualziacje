import json
from datetime import datetime, timezone
from typing import Dict, List, Optional

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.models.analysis import ProjectAnalysis
from app.models.project import Project
from app.models.reference import ReferenceItem
from app.schemas.analysis import ProjectAnalysisRead, extract_structured_payload_dict
from app.schemas.project import DashboardSummary, ProjectCreate, ProjectRead, ProjectUpdate


def _get_analyses_history_map(
    db: Session,
    project_ids: List[int],
) -> Dict[int, List[ProjectAnalysisRead]]:
    if not project_ids:
        return {}
    rows = db.scalars(
        select(ProjectAnalysis)
        .where(ProjectAnalysis.project_id.in_(project_ids))
        .order_by(ProjectAnalysis.created_at.desc(), ProjectAnalysis.id.desc())
    ).all()
    history: Dict[int, List[ProjectAnalysisRead]] = {}
    for row in rows:
        history.setdefault(row.project_id, []).append(ProjectAnalysisRead.model_validate(row))
    return history


def _normalize_ref_ids(raw_ids: Optional[List[int]]) -> List[int]:
    if not raw_ids:
        return []
    clean: List[int] = []
    for item in raw_ids:
        if isinstance(item, (int, str)) and str(item).isdigit():
            val = int(item)
            if val not in clean:
                clean.append(val)
    return clean


def _filter_existing_ref_ids(db: Session, ref_ids: List[int]) -> List[int]:
    if not ref_ids:
        return []
    existing = set(
        db.scalars(select(ReferenceItem.id).where(ReferenceItem.id.in_(ref_ids))).all()
    )
    return [rid for rid in ref_ids if rid in existing]


def _find_fallback_project_for_ref(
    db: Session,
    reference_id: int,
    exclude_project_id: int,
) -> Optional[int]:
    other_projects = db.scalars(
        select(Project).where(Project.id != exclude_project_id).order_by(Project.id.asc())
    ).all()
    for other in other_projects:
        try:
            other_refs = json.loads(other.reference_ids_json or "[]")
            if isinstance(other_refs, list) and reference_id in _normalize_ref_ids(other_refs):
                return other.id
        except json.JSONDecodeError:
            continue
    return None


def _sync_reference_primary_project(
    db: Session,
    project_id: int,
    new_ref_ids: List[int],
) -> None:
    previously_linked = db.scalars(
        select(ReferenceItem).where(ReferenceItem.project_id == project_id)
    ).all()
    for ref in previously_linked:
        if ref.id not in new_ref_ids:
            ref.project_id = _find_fallback_project_for_ref(db, ref.id, project_id)

    if new_ref_ids:
        refs = db.scalars(select(ReferenceItem).where(ReferenceItem.id.in_(new_ref_ids))).all()
        for ref in refs:
            if ref.project_id is None:
                ref.project_id = project_id


def _to_project_read(
    project: Project,
    analyses_list: Optional[List[ProjectAnalysisRead]] = None,
) -> ProjectRead:
    try:
        ref_ids = json.loads(project.reference_ids_json or "[]")
        if not isinstance(ref_ids, list):
            ref_ids = []
    except json.JSONDecodeError:
        ref_ids = []

    history = analyses_list or []
    latest_analysis = history[0] if history else None

    return ProjectRead(
        id=project.id,
        title=project.title,
        mode=project.mode,
        status=project.status,
        building_type=project.building_type,
        area_sqm=project.area_sqm,
        modules_count=project.modules_count,
        style_preset=project.style_preset,
        preserve_geometry=project.preserve_geometry,
        prompt_brief=project.prompt_brief,
        geometry_notes=project.geometry_notes,
        sketch_image_url=project.sketch_image_url,
        preview_image_url=project.preview_image_url,
        reference_ids=_normalize_ref_ids(ref_ids),
        latest_analysis=latest_analysis,
        analyses_count=len(history),
        analysis_history=history,
        created_at=project.created_at,
        updated_at=project.updated_at,
    )


def list_projects(
    db: Session,
    mode: Optional[str] = None,
    status_filter: Optional[str] = None,
    search: Optional[str] = None,
    sort_by: Optional[str] = None,
    limit: Optional[int] = None,
    offset: int = 0,
) -> List[ProjectRead]:
    stmt = select(Project).order_by(Project.created_at.desc(), Project.id.desc())
    if mode:
        stmt = stmt.where(Project.mode == mode)
    if status_filter:
        stmt = stmt.where(Project.status == status_filter)
    if search and search.strip():
        pattern = f"%{search.strip()}%"
        stmt = stmt.where(
            Project.title.ilike(pattern)
            | Project.prompt_brief.ilike(pattern)
            | Project.geometry_notes.ilike(pattern)
            | Project.building_type.ilike(pattern)
            | Project.style_preset.ilike(pattern)
        )

    rows = list(db.scalars(stmt).all())
    if sort_by == "date_asc":
        rows.sort(key=lambda r: (r.updated_at or r.created_at, r.id))
    elif sort_by == "date_desc":
        rows.sort(key=lambda r: (r.updated_at or r.created_at, r.id), reverse=True)
    elif sort_by == "name_asc":
        rows.sort(key=lambda r: (r.title.lower(), r.id))
    elif sort_by == "name_desc":
        rows.sort(key=lambda r: (r.title.lower(), r.id), reverse=True)
    elif sort_by == "area_desc":
        rows.sort(key=lambda r: (r.area_sqm is not None, r.area_sqm or 0.0), reverse=True)
    elif sort_by == "area_asc":
        rows.sort(key=lambda r: (r.area_sqm is None, r.area_sqm or 0.0))

    if offset > 0:
        rows = rows[offset:]
    if limit is not None and limit >= 0:
        rows = rows[:limit]

    analyses_map = _get_analyses_history_map(db, [row.id for row in rows])
    return [_to_project_read(row, analyses_map.get(row.id, [])) for row in rows]


def get_project(db: Session, project_id: int) -> Optional[ProjectRead]:
    project = db.get(Project, project_id)
    if project is None:
        return None
    analyses_map = _get_analyses_history_map(db, [project.id])
    return _to_project_read(project, analyses_map.get(project.id, []))


def create_project(db: Session, payload: ProjectCreate) -> ProjectRead:
    clean_ref_ids = _filter_existing_ref_ids(db, _normalize_ref_ids(payload.reference_ids))
    project = Project(
        title=payload.title.strip(),
        mode=payload.mode,
        status=payload.status,
        building_type=payload.building_type.strip(),
        area_sqm=payload.area_sqm,
        modules_count=payload.modules_count,
        style_preset=payload.style_preset.strip(),
        preserve_geometry=payload.preserve_geometry,
        prompt_brief=payload.prompt_brief.strip(),
        geometry_notes=payload.geometry_notes.strip(),
        sketch_image_url=payload.sketch_image_url,
        preview_image_url=payload.preview_image_url,
        reference_ids_json=json.dumps(clean_ref_ids),
    )
    db.add(project)
    db.flush()

    _sync_reference_primary_project(db, project.id, clean_ref_ids)

    saved_analyses: List[ProjectAnalysisRead] = []
    if payload.initial_analysis is not None:
        draft = payload.initial_analysis
        structured_json = json.dumps(extract_structured_payload_dict(draft), ensure_ascii=False)
        analysis_row = ProjectAnalysis(
            project_id=project.id,
            mode=draft.mode,
            provider=draft.provider.strip(),
            model=draft.model.strip(),
            is_free_tier=draft.is_free_tier,
            summary=draft.summary.strip(),
            spatial_layout=draft.spatial_layout.strip(),
            materials_proposal=draft.materials_proposal.strip(),
            lighting_proposal=draft.lighting_proposal.strip(),
            geometry_preservation_note=draft.geometry_preservation_note.strip(),
            visualization_prompt=draft.visualization_prompt.strip(),
            structured_payload_json=structured_json,
            response_time_ms=draft.response_time_ms,
            schema_version=draft.schema_version or "3.5",
            raw_response_text=draft.raw_response_text.strip(),
        )
        db.add(analysis_row)
        db.flush()
        saved_analyses.append(ProjectAnalysisRead.model_validate(analysis_row))

    db.commit()
    db.refresh(project)
    return _to_project_read(project, saved_analyses)


def update_project(db: Session, project_id: int, payload: ProjectUpdate) -> Optional[ProjectRead]:
    project = db.get(Project, project_id)
    if project is None:
        return None

    data = payload.model_dump(exclude_unset=True)
    if "reference_ids" in data:
        clean_ref_ids = _filter_existing_ref_ids(
            db, _normalize_ref_ids(data.pop("reference_ids") or [])
        )
        project.reference_ids_json = json.dumps(clean_ref_ids)
        _sync_reference_primary_project(db, project.id, clean_ref_ids)

    for field, value in data.items():
        if isinstance(value, str):
            value = value.strip()
        setattr(project, field, value)

    project.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(project)
    analyses_map = _get_analyses_history_map(db, [project.id])
    return _to_project_read(project, analyses_map.get(project.id, []))


def delete_project(db: Session, project_id: int) -> bool:
    project = db.get(Project, project_id)
    if project is None:
        return False

    # Detach references whose primary project_id pointed to this project (keep references in library)
    linked_refs = db.scalars(
        select(ReferenceItem).where(ReferenceItem.project_id == project_id)
    ).all()
    for ref in linked_refs:
        ref.project_id = _find_fallback_project_for_ref(db, ref.id, project_id)

    # Remove child analyses explicitly before deleting the project row
    db.execute(delete(ProjectAnalysis).where(ProjectAnalysis.project_id == project_id))
    db.delete(project)
    db.commit()
    return True


def get_dashboard_summary(db: Session) -> DashboardSummary:
    total_projects = db.scalar(select(func.count(Project.id))) or 0
    sketch_mode_count = (
        db.scalar(select(func.count(Project.id)).where(Project.mode == "sketch_to_render")) or 0
    )
    idea_mode_count = (
        db.scalar(select(func.count(Project.id)).where(Project.mode == "idea_to_project")) or 0
    )
    total_references = db.scalar(select(func.count(ReferenceItem.id))) or 0

    recent_rows = db.scalars(
        select(Project).order_by(Project.updated_at.desc(), Project.id.desc()).limit(6)
    ).all()
    recent_analyses = _get_analyses_history_map(db, [row.id for row in recent_rows])

    return DashboardSummary(
        total_projects=total_projects,
        sketch_mode_count=sketch_mode_count,
        idea_mode_count=idea_mode_count,
        total_references=total_references,
        recent_projects=[
            _to_project_read(row, recent_analyses.get(row.id, [])) for row in recent_rows
        ],
    )

