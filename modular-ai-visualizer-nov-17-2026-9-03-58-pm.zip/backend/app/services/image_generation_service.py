import base64
from typing import Optional

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.cost_guard import (
    CostGuard,
    CostPolicyViolation,
    ProviderQuotaExceededError,
)
from app.providers.image_providers import resolve_dimensions_for_aspect_ratio
from app.schemas.image_generation import (
    AnalysisLifecycleState,
    GenerateDraftImageRequest,
    GenerateImageRequest,
    ImageGenerationResponse,
    ImageProvidersOverviewRead,
    ImageProviderStatusRead,
)
from app.schemas.project import ProjectRead, ProjectUpdate
from app.services import project_service
from app.services.analysis_service import (
    ensure_geometry_lock_in_prompt,
    load_sketch_image_for_vision,
)
from app.services.provider_router import ImageProviderRouter
from app.services.storage_service import save_generated_render_bytes


def _build_project_render_prompt(
    project: ProjectRead,
    custom_prompt_override: Optional[str] = None,
) -> str:
    latest = project.latest_analysis
    base_prompt = (custom_prompt_override or "").strip()

    if not base_prompt and latest and latest.visualization_prompt.strip():
        base_prompt = latest.visualization_prompt.strip()

    if not base_prompt:
        parts = [
            f"Obiekt: {project.building_type}",
            f"Styl: {project.style_preset}",
            f"Założenia: {project.prompt_brief}",
        ]
        if project.geometry_notes:
            parts.append(f"Geometria i stolarka: {project.geometry_notes}")
        if latest and latest.materials_proposal:
            parts.append(f"Materiały: {latest.materials_proposal}")
        if latest and latest.lighting_proposal:
            parts.append(f"Oświetlenie: {latest.lighting_proposal}")
        base_prompt = " | ".join(p for p in parts if p)

    if project.mode == "sketch_to_render":
        extra_context = []
        if latest:
            if latest.geometry and latest.geometry.building_footprint:
                extra_context.append(f"Obrys bryły z analizy: {latest.geometry.building_footprint}")
            if latest.rooms:
                room_names = ", ".join(r.name for r in latest.rooms[:8] if r.name)
                if room_names:
                    extra_context.append(f"Rozpoznane pomieszczenia: {room_names}")
            if latest.openings:
                openings_desc = "; ".join(
                    f"{o.opening_id or o.category} ({o.location})" for o in latest.openings[:8]
                )
                if openings_desc:
                    extra_context.append(f"Otwory okienne i drzwiowe: {openings_desc}")
        if extra_context:
            base_prompt = f"{base_prompt}\n" + "\n".join(extra_context)

        return ensure_geometry_lock_in_prompt(
            base_prompt,
            mode="sketch_to_render",
            preserve_geometry=project.preserve_geometry,
        )

    # Mode B (idea_to_project) — explicitly mark as conceptual architectural image
    conceptual_prefix = (
        "[TRYB B — WIZUALIZACJA KONCEPCYJNA DOMU MODUŁOWEGO / WNĘTRZA NA PODSTAWIE OPISU] "
    )
    if not base_prompt.startswith("[TRYB B"):
        base_prompt = f"{conceptual_prefix}{base_prompt}"
    return base_prompt


async def get_image_providers_overview(
    db: Session,
    settings: Settings,
    router: Optional[ImageProviderRouter] = None,
) -> ImageProvidersOverviewRead:
    cost_guard = CostGuard(settings)
    active_router = router or ImageProviderRouter(settings, cost_guard)
    statuses = await active_router.list_providers_status(db)
    db.commit()

    read_items = [
        ImageProviderStatusRead(
            key=st.key,
            name=st.name,
            role=st.role,
            model=st.model,
            plan_type=st.plan_type,
            available=st.available,
            availability_status=st.availability_status,
            is_truly_free=st.is_truly_free,
            is_paid_endpoint=st.is_paid_endpoint,
            is_verified=st.is_verified,
            verification_status=st.verification_status,
            blocked_by_cost_policy=st.blocked_by_cost_policy,
            api_key_configured=st.api_key_configured,
            known_limits=st.known_limits,
            cooldown_until=st.cooldown_until,
            supported_resolutions=st.supported_resolutions,
            supports_image_to_image=st.supports_image_to_image,
            supports_geometry_preservation=st.supports_geometry_preservation,
            hardware_requirements=st.hardware_requirements,
            unavailability_reason=st.unavailability_reason,
            local_calls_today=st.local_calls_today,
            local_calls_total=st.local_calls_total,
            last_error=st.last_error,
        )
        for st in statuses
    ]

    free_online = [
        item
        for item in read_items
        if item.available
        and item.is_truly_free
        and item.is_verified
        and not item.is_paid_endpoint
        and not item.blocked_by_cost_policy
    ]

    if free_online:
        first = free_online[0]
        summary_msg = (
            f"Dostępny zweryfikowany darmowy silnik generowania obrazów: {first.name} "
            f"(model: {first.model}, image-to-image: {'TAK' if first.supports_image_to_image else 'NIE'})."
        )
        return ImageProvidersOverviewRead(
            any_free_engine_available=True,
            active_free_engine_key=first.key,
            active_free_engine_name=first.name,
            summary_message=summary_msg,
            providers=read_items,
        )

    summary_msg = (
        "Brak aktywnego darmowego silnika generowania obrazów w bieżącym środowisku. "
        "Lokalne silniki Open-Source (Stable Diffusion WebUI :7860, ComfyUI :8188) nie są "
        "uruchomione (brak GPU/VRAM w kontenerze), natomiast chmurowe API obrazów (Google Imagen 3, "
        "OpenAI gpt-image-1, Hugging Face micro-credits oraz niezweryfikowane zewnętrzne przekaźniki) "
        "są zablokowane przez CostGuard w ramach polityki Zero Kosztów (0 zł)."
    )
    return ImageProvidersOverviewRead(
        any_free_engine_available=False,
        active_free_engine_key=None,
        active_free_engine_name=None,
        summary_message=summary_msg,
        providers=read_items,
    )


async def generate_image_for_project(
    db: Session,
    settings: Settings,
    project_id: int,
    payload: Optional[GenerateImageRequest] = None,
    router: Optional[ImageProviderRouter] = None,
) -> ImageGenerationResponse:
    req = payload or GenerateImageRequest()
    project = project_service.get_project(db, project_id)
    if project is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Projekt nie został znaleziony.",
        )

    analysis_status: AnalysisLifecycleState = (
        "completed" if project.latest_analysis is not None else "not_started"
    )

    if project.mode == "sketch_to_render" and not project.sketch_image_url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tryb A (Szkic → Wizualizacja) wymaga przypisanego szkicu wejściowego przed generowaniem obrazu.",
        )

    cost_guard = CostGuard(settings)
    active_router = router or ImageProviderRouter(settings, cost_guard)
    strict_preferred = bool(req.preferred_provider and req.preferred_provider != "auto")

    selected = await active_router.select_image_provider(
        db,
        preferred_key=req.preferred_provider,
        strict_preferred=strict_preferred,
        prefer_image_to_image=(project.mode == "sketch_to_render"),
    )

    prompt_to_use = _build_project_render_prompt(project, req.custom_prompt_override)

    if selected.provider is None:
        if selected.decision.blocked_by_cost_policy:
            raise CostPolicyViolation(selected.decision.reason)
        if selected.decision.availability_status in {"cooldown", "local_limit_reached"}:
            raise ProviderQuotaExceededError(selected.decision.reason)

        return ImageGenerationResponse(
            project_id=project.id,
            mode=project.mode,
            analysis_status=analysis_status,
            render_status="unavailable_free",
            generated_image_url=project.preview_image_url,
            provider_key=None,
            provider_name=None,
            model=None,
            used_image_to_image=False,
            geometry_preserved=project.preserve_geometry,
            is_conceptual=(project.mode == "idea_to_project"),
            conceptual_label=(
                "Obraz koncepcyjny (Tryb B)" if project.mode == "idea_to_project" else None
            ),
            prompt_used=prompt_to_use,
            response_time_ms=None,
            message=(
                f"{selected.decision.reason} Status analizy AI ({analysis_status}) oraz "
                "zapisany prompt z blokadą geometrii pozostają nienaruszone w bazie SQLite."
            ),
            project=project,
        )

    provider = selected.provider
    caps = provider.get_capabilities()
    width, height = resolve_dimensions_for_aspect_ratio(req.aspect_ratio)

    if (
        project.mode == "sketch_to_render"
        and caps.supports_image_to_image
        and project.sketch_image_url
    ):
        sketch_b64, sketch_mime = load_sketch_image_for_vision(project.sketch_image_url, settings)
        sketch_bytes = base64.b64decode(sketch_b64)
        gen_result = await provider.image_to_image(
            prompt_to_use,
            sketch_bytes,
            sketch_mime,
            mode=project.mode,
            aspect_ratio=req.aspect_ratio,
            preserve_geometry=project.preserve_geometry,
            width=width,
            height=height,
        )
    else:
        gen_result = await provider.generate(
            prompt_to_use,
            mode=project.mode,
            aspect_ratio=req.aspect_ratio,
            preserve_geometry=project.preserve_geometry,
            width=width,
            height=height,
        )

    saved_url = save_generated_render_bytes(
        gen_result.image_bytes,
        gen_result.mime_type,
        settings,
        prefix=f"render_project_{project.id}_{project.mode}",
    )

    updated_project = project_service.update_project(
        db,
        project.id,
        ProjectUpdate(preview_image_url=saved_url),
    )

    is_conceptual = project.mode == "idea_to_project"
    conceptual_label = (
        "Wizualizacja koncepcyjna (Tryb B — wygenerowana na podstawie opisu i analizy koncepcyjnej)"
        if is_conceptual
        else None
    )

    return ImageGenerationResponse(
        project_id=project.id,
        mode=project.mode,
        analysis_status=analysis_status,
        render_status="completed",
        generated_image_url=saved_url,
        provider_key=gen_result.provider_key,
        provider_name=gen_result.provider_name,
        model=gen_result.model,
        used_image_to_image=gen_result.used_image_to_image,
        geometry_preserved=gen_result.geometry_preserved,
        is_conceptual=is_conceptual,
        conceptual_label=conceptual_label,
        prompt_used=gen_result.prompt_used,
        response_time_ms=gen_result.response_time_ms,
        message=(
            f"Wygenerowano i zweryfikowano obraz w darmowym silniku {gen_result.provider_name} "
            f"({'image-to-image z zachowaniem geometrii szkicu' if gen_result.used_image_to_image else 'wizualizacja koncepcyjna'})."
        ),
        project=updated_project,
    )


async def generate_image_for_draft(
    db: Session,
    settings: Settings,
    payload: GenerateDraftImageRequest,
    router: Optional[ImageProviderRouter] = None,
) -> ImageGenerationResponse:
    if payload.mode == "sketch_to_render" and not payload.sketch_image_url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tryb A (Szkic → Wizualizacja) wymaga przesłanego szkicu wejściowego.",
        )

    cost_guard = CostGuard(settings)
    active_router = router or ImageProviderRouter(settings, cost_guard)
    strict_preferred = bool(
        payload.preferred_provider and payload.preferred_provider != "auto"
    )

    selected = await active_router.select_image_provider(
        db,
        preferred_key=payload.preferred_provider,
        strict_preferred=strict_preferred,
        prefer_image_to_image=(payload.mode == "sketch_to_render"),
    )

    raw_prompt = payload.prompt.strip() or f"{payload.building_type}, styl {payload.style_preset}"
    if payload.mode == "sketch_to_render":
        prompt_to_use = ensure_geometry_lock_in_prompt(
            raw_prompt,
            mode="sketch_to_render",
            preserve_geometry=payload.preserve_geometry,
        )
    else:
        prompt_to_use = (
            raw_prompt
            if raw_prompt.startswith("[TRYB B")
            else f"[TRYB B — WIZUALIZACJA KONCEPCYJNA DOMU MODUŁOWEGO / WNĘTRZA] {raw_prompt}"
        )

    if selected.provider is None:
        if selected.decision.blocked_by_cost_policy:
            raise CostPolicyViolation(selected.decision.reason)
        if selected.decision.availability_status in {"cooldown", "local_limit_reached"}:
            raise ProviderQuotaExceededError(selected.decision.reason)

        return ImageGenerationResponse(
            project_id=None,
            mode=payload.mode,
            analysis_status="not_started",
            render_status="unavailable_free",
            generated_image_url=None,
            provider_key=None,
            provider_name=None,
            model=None,
            used_image_to_image=False,
            geometry_preserved=payload.preserve_geometry,
            is_conceptual=(payload.mode == "idea_to_project"),
            conceptual_label=(
                "Obraz koncepcyjny (Tryb B)" if payload.mode == "idea_to_project" else None
            ),
            prompt_used=prompt_to_use,
            response_time_ms=None,
            message=selected.decision.reason,
            project=None,
        )

    provider = selected.provider
    caps = provider.get_capabilities()
    width, height = resolve_dimensions_for_aspect_ratio(payload.aspect_ratio)

    if (
        payload.mode == "sketch_to_render"
        and caps.supports_image_to_image
        and payload.sketch_image_url
    ):
        sketch_b64, sketch_mime = load_sketch_image_for_vision(payload.sketch_image_url, settings)
        sketch_bytes = base64.b64decode(sketch_b64)
        gen_result = await provider.image_to_image(
            prompt_to_use,
            sketch_bytes,
            sketch_mime,
            mode=payload.mode,
            aspect_ratio=payload.aspect_ratio,
            preserve_geometry=payload.preserve_geometry,
            width=width,
            height=height,
        )
    else:
        gen_result = await provider.generate(
            prompt_to_use,
            mode=payload.mode,
            aspect_ratio=payload.aspect_ratio,
            preserve_geometry=payload.preserve_geometry,
            width=width,
            height=height,
        )

    saved_url = save_generated_render_bytes(
        gen_result.image_bytes,
        gen_result.mime_type,
        settings,
        prefix=f"render_draft_{payload.mode}",
    )

    is_conceptual = payload.mode == "idea_to_project"
    return ImageGenerationResponse(
        project_id=None,
        mode=payload.mode,
        analysis_status="not_started",
        render_status="completed",
        generated_image_url=saved_url,
        provider_key=gen_result.provider_key,
        provider_name=gen_result.provider_name,
        model=gen_result.model,
        used_image_to_image=gen_result.used_image_to_image,
        geometry_preserved=gen_result.geometry_preserved,
        is_conceptual=is_conceptual,
        conceptual_label=(
            "Wizualizacja koncepcyjna (Tryb B — wygenerowana na podstawie opisu)"
            if is_conceptual
            else None
        ),
        prompt_used=gen_result.prompt_used,
        response_time_ms=gen_result.response_time_ms,
        message=f"Wygenerowano obraz w darmowym silniku {gen_result.provider_name}.",
        project=None,
    )
