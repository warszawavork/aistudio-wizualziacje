from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.cost_guard import CostGuard
from app.models.settings import StudioSettings
from app.providers import (
    FreeImageGeneratorProvider,
    GeminiProvider,
    GroqProvider,
    HuggingFaceImageProvider,
    OpenAIImageProvider,
    TelegramBotProvider,
)
from app.schemas.settings import (
    CostPolicyOverview,
    ImageGeneratorStatusRead,
    ProviderStatusItem,
    ProvidersOverview,
    StudioSettingsRead,
    StudioSettingsUpdate,
)

LOCAL_COUNTER_DISCLAIMER = (
    "Licznik lokalny zlicza wyłącznie zapytania wysłane przez tę aplikację. "
    "Dostawcy nie udostępniają oficjalnego API salda limitów."
)


def get_or_create_studio_settings(db: Session) -> StudioSettingsRead:
    record = db.get(StudioSettings, 1)
    if record is None:
        record = StudioSettings(id=1)
        db.add(record)
        db.commit()
        db.refresh(record)
    return StudioSettingsRead.model_validate(record)


def update_studio_settings(db: Session, payload: StudioSettingsUpdate) -> StudioSettingsRead:
    record = db.get(StudioSettings, 1)
    if record is None:
        record = StudioSettings(id=1)
        db.add(record)
        db.flush()

    for field, value in payload.model_dump(exclude_unset=True).items():
        if isinstance(value, str):
            value = value.strip()
        setattr(record, field, value)

    db.commit()
    db.refresh(record)
    return StudioSettingsRead.model_validate(record)


def get_providers_overview(db: Session, settings: Settings) -> ProvidersOverview:
    cost_guard = CostGuard(settings)

    adapters = [
        GeminiProvider(settings, cost_guard, db=db),
        GroqProvider(settings, cost_guard, db=db),
        HuggingFaceImageProvider(settings, cost_guard, db=db),
        OpenAIImageProvider(settings, cost_guard, db=db),
        TelegramBotProvider(settings),
    ]

    provider_items: list[ProviderStatusItem] = []
    for adapter in adapters:
        descriptor = adapter.get_descriptor()
        key_configured = adapter.is_key_configured()
        usage = cost_guard.get_or_create_usage(db, descriptor.key)
        decision = cost_guard.evaluate_provider(descriptor, key_configured, usage=usage)

        provider_items.append(
            ProviderStatusItem(
                key=descriptor.key,
                name=descriptor.name,
                role=descriptor.role,
                model=descriptor.model,
                plan_type=descriptor.plan_type,
                api_key_configured=key_configured,
                available=decision.allowed,
                availability_status=decision.availability_status,
                is_paid_endpoint=descriptor.is_paid_endpoint,
                blocked_by_cost_policy=decision.blocked_by_cost_policy,
                configured_limits=descriptor.configured_limits_note,
                local_calls_today=usage.calls_today,
                local_calls_total=usage.calls_total,
                last_error=usage.last_error or "",
                cooldown_until=usage.cooldown_until,
                local_counter_disclaimer=LOCAL_COUNTER_DISCLAIMER,
                notes=decision.reason,
            )
        )

    db.commit()

    free_gen = FreeImageGeneratorProvider()
    gen_descriptor = free_gen.get_descriptor()

    import asyncio
    from app.services.image_generation_service import get_image_providers_overview

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is None:
        img_overview = asyncio.run(get_image_providers_overview(db, settings))
    else:
        # Fallback synchronous construction when called inside an active event loop
        from app.providers.image_providers import build_default_image_providers
        from app.schemas.image_generation import (
            ImageProvidersOverviewRead,
            ImageProviderStatusRead,
        )

        img_adapters = build_default_image_providers(settings, cost_guard, db=db)
        read_items = []
        for img_adapter in img_adapters:
            desc = img_adapter.get_descriptor()
            caps = img_adapter.get_capabilities()
            usage = cost_guard.get_or_create_usage(db, desc.key)
            is_healthy = False if desc.is_local_engine else True
            dec = cost_guard.evaluate_provider(
                desc,
                api_key_configured=img_adapter.is_key_configured(),
                usage=usage,
                local_service_reachable=is_healthy,
            )
            reason = dec.reason
            if desc.is_local_engine and not is_healthy:
                reason = (
                    f"Brak uruchomionego lokalnego serwera {desc.name} oraz brak GPU/VRAM w środowisku kontenera."
                )
            read_items.append(
                ImageProviderStatusRead(
                    key=desc.key,
                    name=desc.name,
                    role=desc.role,
                    model=desc.model,
                    plan_type=desc.plan_type,
                    available=dec.allowed,
                    availability_status=dec.availability_status,
                    is_truly_free=caps.is_truly_free,
                    is_paid_endpoint=desc.is_paid_endpoint,
                    is_verified=desc.is_verified,
                    verification_status=caps.verification_status,
                    blocked_by_cost_policy=dec.blocked_by_cost_policy,
                    api_key_configured=img_adapter.is_key_configured(),
                    known_limits=caps.known_limits,
                    cooldown_until=usage.cooldown_until,
                    supported_resolutions=list(caps.supported_resolutions),
                    supports_image_to_image=caps.supports_image_to_image,
                    supports_geometry_preservation=caps.supports_geometry_preservation,
                    hardware_requirements=caps.hardware_requirements,
                    unavailability_reason="" if dec.allowed else reason,
                    local_calls_today=usage.calls_today,
                    local_calls_total=usage.calls_total,
                    last_error=usage.last_error or "",
                )
            )
        img_overview = ImageProvidersOverviewRead(
            any_free_engine_available=False,
            active_free_engine_key=None,
            active_free_engine_name=None,
            summary_message=(
                "Brak aktywnego darmowego silnika generowania obrazów w bieżącym środowisku. "
                "Lokalne silniki Open-Source (Stable Diffusion WebUI :7860, ComfyUI :8188) nie są "
                "uruchomione (brak GPU/VRAM w kontenerze), natomiast chmurowe API obrazów są zablokowane przez CostGuard (0 zł)."
            ),
            providers=read_items,
        )

    return ProvidersOverview(
        stage=settings.app_stage,
        cost_policy=CostPolicyOverview(
            free_only=settings.free_only,
            allow_paid_apis=settings.allow_paid_apis,
            monthly_budget=settings.monthly_budget,
            allow_hf_micro_free_credits=settings.allow_hf_micro_free_credits,
            paid_services_blocked=cost_guard.paid_apis_blocked,
        ),
        image_generator=ImageGeneratorStatusRead(
            status=(
                "available_free"
                if img_overview.any_free_engine_available
                else free_gen.get_generation_status()
            ),
            provider_name=(
                img_overview.active_free_engine_name or gen_descriptor.name
            ),
            message=img_overview.summary_message,
            preserves_project_artifacts=True,
        ),
        image_providers_overview=img_overview,
        providers=provider_items,
    )

