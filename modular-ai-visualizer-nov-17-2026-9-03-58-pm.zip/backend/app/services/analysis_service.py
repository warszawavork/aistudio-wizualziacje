import base64
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import ROOT_DIR, Settings
from app.core.cost_guard import (
    CostGuard,
    CostPolicyViolation,
    ProviderKeyMissingError,
    ProviderQuotaExceededError,
    ProviderRequestError,
)
from app.models.analysis import ProjectAnalysis
from app.models.project import Project
from app.models.reference import ReferenceItem
from app.schemas.analysis import (
    AnalysisContentFields,
    AnalysisPreviewResponse,
    AnalyzeDraftRequest,
    ConfidenceLevel,
    DEFAULT_ARCHITECTURAL_DISCLAIMER,
    DimensionCheckItem,
    DimensionObservationItem,
    DimensionSourceType,
    GeometryAnalysis,
    GeometryProtectionRules,
    OpeningAnalysisItem,
    ProjectAnalysisRead,
    ProjectAnalysisUpdate,
    ProviderPreference,
    RoomAnalysisItem,
    UncertaintyItem,
    extract_structured_payload_dict,
)
from app.services import project_service, settings_service
from app.services.provider_router import ProviderRouter

ALLOWED_VISION_MIME_BY_EXT = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
}

CANONICAL_CONFIDENCE_LEVELS = (
    "wysoka pewność",
    "średnia pewność",
    "niska pewność",
    "niemożliwe do ustalenia na podstawie materiału",
)


def normalize_confidence_level(value: Any) -> ConfidenceLevel:
    text = str(value or "").strip().lower()
    if not text:
        return "niemożliwe do ustalenia na podstawie materiału"
    if "niemożliwe" in text or "nie można" in text or "nieczytel" in text or "unknown" in text or "brak" in text:
        return "niemożliwe do ustalenia na podstawie materiału"
    if "wysok" in text or "high" in text or "pewn" in text and "nie" not in text:
        return "wysoka pewność"
    if "nisk" in text or "low" in text or "słab" in text:
        return "niska pewność"
    if "średn" in text or "sredn" in text or "medium" in text or "umiark" in text:
        return "średnia pewność"
    return "niska pewność"


def _coerce_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        lines = [_coerce_text(item) for item in value]
        return "\n".join(f"- {line}" for line in lines if line)
    if isinstance(value, dict):
        lines = [f"{k}: {_coerce_text(v)}" for k, v in value.items()]
        return "\n".join(line for line in lines if line)
    return str(value).strip()


def _coerce_string_list(value: Any, max_items: int = 20) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        raw_lines = [line.strip(" -•\t") for line in value.splitlines()]
        return [line for line in raw_lines if line][:max_items]
    if isinstance(value, list):
        items: List[str] = []
        for entry in value:
            text = _coerce_text(entry).lstrip("- ").strip()
            if text:
                items.append(text)
            if len(items) >= max_items:
                break
        return items
    text = _coerce_text(value)
    return [text] if text else []


def _extract_json_block(raw_text: str) -> Optional[Dict[str, Any]]:
    cleaned = raw_text.strip()
    if not cleaned:
        return None

    fence_match = re.search(
        r"```(?:json)?\s*(\{.*?\})\s*```",
        cleaned,
        flags=re.DOTALL | re.IGNORECASE,
    )
    candidate = fence_match.group(1) if fence_match else cleaned

    if not candidate.startswith("{"):
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start != -1 and end > start:
            candidate = candidate[start : end + 1]

    try:
        parsed = json.loads(candidate)
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        return None


def _parse_geometry(raw_geo: Any) -> Optional[GeometryAnalysis]:
    if not isinstance(raw_geo, dict):
        return None
    return GeometryAnalysis(
        building_footprint=_coerce_text(raw_geo.get("building_footprint")),
        floors_count=_coerce_text(raw_geo.get("floors_count"))
        or "niemożliwe do ustalenia na podstawie materiału",
        structural_vs_partition_walls=_coerce_text(raw_geo.get("structural_vs_partition_walls")),
        circulation=_coerce_text(raw_geo.get("circulation")),
        proportions_and_scale=_coerce_text(raw_geo.get("proportions_and_scale")),
        confidence=normalize_confidence_level(raw_geo.get("confidence")),
    )


def _parse_rooms(raw_rooms: Any) -> List[RoomAnalysisItem]:
    if not isinstance(raw_rooms, list):
        return []
    rooms: List[RoomAnalysisItem] = []
    for item in raw_rooms[:24]:
        if isinstance(item, dict):
            name = _coerce_text(item.get("name"))
            if not name:
                continue
            rooms.append(
                RoomAnalysisItem(
                    name=name[:200],
                    zone=_coerce_text(item.get("zone")) or "nieustalone",
                    approximate_area=_coerce_text(item.get("approximate_area"))
                    or "brak wymiarów na materiale",
                    spatial_relations=_coerce_text(item.get("spatial_relations")),
                    confidence=normalize_confidence_level(item.get("confidence")),
                )
            )
        elif isinstance(item, str) and item.strip():
            rooms.append(
                RoomAnalysisItem(
                    name=item.strip()[:200],
                    zone="nieustalone",
                    approximate_area="brak wymiarów na materiale",
                    spatial_relations="",
                    confidence="niska pewność",
                )
            )
    return rooms


def _parse_bool_optional(value: Any) -> Optional[bool]:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in {"true", "tak", "yes", "1", "widoczny", "present"}:
        return True
    if text in {"false", "nie", "no", "0", "brak", "absent"}:
        return False
    return None


def _parse_dimension_source_type(value: Any) -> DimensionSourceType:
    text = str(value or "").strip().lower()
    if text in {"a", "direct"} or "bezpośrednio" in text or "odczyt" in text:
        return "direct"
    if text in {"b", "calculated"} or "oblicz" in text or "sum" in text:
        return "calculated"
    if text in {"c", "estimated"} or "szacunk" in text or "przybliż" in text:
        return "estimated"
    return "indeterminable"


def _parse_openings(
    raw_openings: Any,
    uncertainties: List[UncertaintyItem],
) -> List[OpeningAnalysisItem]:
    if not isinstance(raw_openings, list):
        return []
    openings: List[OpeningAnalysisItem] = []
    seen_ids: set[str] = set()
    for idx, item in enumerate(raw_openings[:40], start=1):
        if isinstance(item, dict):
            category = _coerce_text(item.get("category") or item.get("type"))
            if not category:
                continue
            raw_id = _coerce_text(item.get("opening_id") or item.get("id"))
            if not raw_id:
                cat_low = category.lower()
                prefix = "D" if ("drzwi" in cat_low or "hs" in cat_low) else ("O" if "okn" in cat_low else "OT")
                raw_id = f"{prefix}-{idx:02d}"
            unique_id = raw_id[:64]
            if unique_id in seen_ids:
                unique_id = f"{raw_id[:56]}-{idx:02d}"
            seen_ids.add(unique_id)

            has_swing_arc = _parse_bool_optional(item.get("has_swing_arc"))
            opening_direction = (
                _coerce_text(item.get("opening_direction"))
                or "niemożliwe do ustalenia na podstawie materiału"
            )
            notes = _coerce_text(item.get("notes"))
            completeness_note = _coerce_text(item.get("opening_completeness_note"))
            confidence = normalize_confidence_level(item.get("confidence"))

            cat_lower = category.lower()
            is_hinged_door = (
                "drzwi" in cat_lower
                and "przesuw" not in cat_lower
                and "hs" not in cat_lower
            )
            dir_lower = opening_direction.lower()
            claims_specific_swing = (
                "niemożliwe" not in dir_lower
                and "niepewn" not in dir_lower
                and "brak" not in dir_lower
                and any(tok in dir_lower for tok in ("wewnątrz", "zewnątrz", "lew", "praw", "do ", "na "))
            )
            notes_indicate_missing_arc = "brak łuk" in notes.lower() or "bez łuk" in notes.lower()
            if has_swing_arc is False or (is_hinged_door and notes_indicate_missing_arc):
                if has_swing_arc is None:
                    has_swing_arc = False
                if claims_specific_swing:
                    opening_direction = "niemożliwe do ustalenia na podstawie materiału (brak łuku otwierania)"
                    confidence = "niska pewność"
                elif confidence == "wysoka pewność" and "niemożliwe" not in dir_lower:
                    confidence = "średnia pewność"
                if not completeness_note:
                    completeness_note = "Brak widocznego łuku otwierania — kierunek otwierania niepewny."
                uncertainties.append(
                    UncertaintyItem(
                        element=f"Kierunek otwierania ({unique_id}: {category})",
                        confidence="niska pewność",
                        reason="Brak wyraźnego łuku otwierania na szkicu mimo widocznego otworu drzwiowego.",
                    )
                )

            openings.append(
                OpeningAnalysisItem(
                    opening_id=unique_id,
                    category=category[:120],
                    location=_coerce_text(item.get("location")),
                    opening_direction=opening_direction,
                    has_swing_arc=has_swing_arc,
                    opening_completeness_note=completeness_note[:300],
                    notes=notes,
                    confidence=confidence,
                )
            )
        elif isinstance(item, str) and item.strip():
            openings.append(
                OpeningAnalysisItem(
                    opening_id=f"OT-{idx:02d}",
                    category="otwór / stolarka",
                    location=item.strip()[:400],
                    opening_direction="niemożliwe do ustalenia na podstawie materiału",
                    has_swing_arc=None,
                    opening_completeness_note="",
                    notes="",
                    confidence="niska pewność",
                )
            )
    return openings


def _parse_dimension_observations(raw_obs: Any) -> List[DimensionObservationItem]:
    if not isinstance(raw_obs, list):
        return []
    items: List[DimensionObservationItem] = []
    for item in raw_obs[:40]:
        if isinstance(item, dict):
            label = _coerce_text(item.get("label"))
            if not label:
                continue
            source_type = _parse_dimension_source_type(item.get("source_type"))
            value = _coerce_text(item.get("value")) or "niemożliwe do ustalenia na podstawie materiału"
            confidence = normalize_confidence_level(item.get("confidence"))
            if source_type == "estimated" and confidence == "wysoka pewność":
                confidence = "niska pewność"
            if source_type == "indeterminable":
                confidence = "niemożliwe do ustalenia na podstawie materiału"
            items.append(
                DimensionObservationItem(
                    label=label[:200],
                    value=value[:160],
                    source_type=source_type,
                    unit=_coerce_text(item.get("unit"))[:24],
                    location=_coerce_text(item.get("location"))[:300],
                    confidence=confidence,
                )
            )
    return items


def _parse_dimension_checks(raw_checks: Any) -> List[DimensionCheckItem]:
    if not isinstance(raw_checks, list):
        return []
    items: List[DimensionCheckItem] = []
    for item in raw_checks[:20]:
        if isinstance(item, dict):
            desc = _coerce_text(item.get("description"))
            if not desc:
                continue
            raw_status = str(item.get("status") or "").strip().lower()
            if raw_status in {"consistent", "spójne", "zgodne"}:
                status_val = "consistent"
            elif raw_status in {"conflict", "sprzeczność", "konflikt", "niezgodne"}:
                status_val = "conflict"
            else:
                status_val = "indeterminable"
            items.append(
                DimensionCheckItem(
                    description=desc[:400],
                    overall_dimension=_coerce_text(item.get("overall_dimension"))[:120],
                    segment_sum=_coerce_text(item.get("segment_sum"))[:120],
                    status=status_val,  # type: ignore[arg-type]
                    difference=_coerce_text(item.get("difference"))[:120],
                )
            )
    return items


def _extract_meters_value(text: str) -> Optional[float]:
    if not text:
        return None
    match = re.search(r"(\d+(?:[.,]\d+)?)\s*(mm|cm|m)?\b", text.strip(), flags=re.IGNORECASE)
    if not match:
        return None
    try:
        val = float(match.group(1).replace(",", "."))
    except ValueError:
        return None
    unit = (match.group(2) or "m").lower()
    if unit == "cm":
        return val / 100.0
    if unit == "mm":
        return val / 1000.0
    return val


def verify_dimensional_consistency(
    dimension_observations: List[DimensionObservationItem],
    dimension_checks: List[DimensionCheckItem],
    raw_conflicts: List[str],
    geometry: Optional[GeometryAnalysis],
    uncertainties: List[UncertaintyItem],
    initial_confidence: ConfidenceLevel,
) -> Tuple[List[str], ConfidenceLevel]:
    conflicts = list(dict.fromkeys(c.strip() for c in raw_conflicts if c and c.strip()))

    for chk in dimension_checks:
        overall_m = _extract_meters_value(chk.overall_dimension)
        segment_m = _extract_meters_value(chk.segment_sum)
        if overall_m is not None and segment_m is not None:
            diff = round(abs(overall_m - segment_m), 3)
            if diff > 0.02:
                chk.status = "conflict"
                if not chk.difference:
                    chk.difference = f"{diff:g} m"
                msg = (
                    f"Sprzeczność wymiarowa ({chk.description}): wymiar całkowity {overall_m:g} m "
                    f"nie zgadza się z sumą odcinków {segment_m:g} m (różnica {diff:g} m)."
                )
                if msg not in conflicts:
                    conflicts.append(msg)
            elif chk.status == "indeterminable":
                chk.status = "consistent"
        elif chk.status == "conflict":
            msg = f"Sprzeczność wymiarowa: {chk.description}" + (
                f" (różnica {chk.difference})" if chk.difference else ""
            )
            if msg not in conflicts:
                conflicts.append(msg)

    # Check if direct overall vs direct segment observations exist without check item
    has_direct_or_calc = any(
        obs.source_type in {"direct", "calculated"} for obs in dimension_observations
    )

    confidence = initial_confidence
    if conflicts:
        confidence = "niska pewność"
        if geometry and geometry.proportions_and_scale:
            prop_low = geometry.proportions_and_scale.lower()
            if "spójn" in prop_low and "sprzecznoś" not in prop_low and "nie można" not in prop_low:
                geometry.proportions_and_scale = (
                    f"{geometry.proportions_and_scale} "
                    "[KOREKTA WALIDACJI: wykryto sprzeczność wymiarową — nie można uznać wymiarów za spójne]"
                )
        for conflict_msg in conflicts:
            if not any(conflict_msg[:40] in u.element or conflict_msg[:40] in u.reason for u in uncertainties):
                uncertainties.append(
                    UncertaintyItem(
                        element="Sprzeczność wymiarowa na rysunku",
                        confidence="niska pewność",
                        reason=conflict_msg,
                    )
                )
    elif has_direct_or_calc and confidence == "niemożliwe do ustalenia na podstawie materiału":
        confidence = "średnia pewność"

    return conflicts, confidence


CARDINAL_DIRECTION_RE = re.compile(
    r"\b(północn\w*|północ\w*|południow\w*|południe\w*|wschodni\w*|wschód|zachodni\w*|zachód|"
    r"north(?:ern|east|west)?|south(?:ern|east|west)?|east(?:ern)?|west(?:ern)?)\b",
    flags=re.IGNORECASE,
)


def input_justifies_cardinal_directions(user_context_text: str, observed_facts: List[str]) -> bool:
    if CARDINAL_DIRECTION_RE.search(user_context_text or ""):
        return True
    compass_markers = (
        "róża wiatrów",
        "strzałka północy",
        "oznaczenie północy",
        "north arrow",
        "compass",
    )
    facts_joined = "\n".join(observed_facts).lower()
    return any(marker in facts_joined for marker in compass_markers)


def detect_unjustified_cardinal_directions(
    *,
    summary: str,
    spatial_layout: str,
    rooms: List[RoomAnalysisItem],
    openings: List[OpeningAnalysisItem],
    observed_facts: List[str],
    visualization_prompt: str,
    user_context_text: str,
) -> List[str]:
    if input_justifies_cardinal_directions(user_context_text, observed_facts):
        return []

    findings: List[str] = []
    seen: set[str] = set()

    def _scan(label: str, text: str) -> None:
        if not text:
            return
        for match in CARDINAL_DIRECTION_RE.finditer(text):
            token = match.group(0)
            entry = f"{token} ({label})"
            key = entry.lower()
            if key not in seen:
                seen.add(key)
                findings.append(entry)

    _scan("podsumowanie", summary)
    _scan("układ przestrzenny", spatial_layout)
    for room in rooms:
        _scan(f"pomieszczenie: {room.name}", room.spatial_relations)
    for opening in openings:
        _scan(f"otwór: {opening.opening_id or opening.category}", opening.location)
    _scan("prompt wizualizacyjny", visualization_prompt)
    return findings


CANONICAL_GEOMETRY_LOCK_CLAUSE = (
    "GEOMETRY LOCK (MANDATORY — STRICT SKETCH FIDELITY): "
    "Preserve exact building footprint, room count and positions, all interior and exterior wall alignments, "
    "window placement, all entrance/interior/sliding/terrace door positions, openings and glazing, and all spatial relations. "
    "FORBIDDEN: Do not add new rooms, do not remove existing rooms, do not add floors, do not move walls, "
    "and do not alter proportions, opening sizes, or window/door locations."
)


def has_complete_geometry_lock(prompt: str) -> bool:
    text = (prompt or "").lower()
    if not text.strip():
        return False
    checks = [
        any(k in text for k in ("footprint", "obrys", "silhouette")),
        any(k in text for k in ("wall", "ścian")),
        any(k in text for k in ("window", "okien", "okna")),
        any(k in text for k in ("door", "drzwi")),
        any(k in text for k in ("room", "pomieszczeń", "pomieszczenia", "layout", "układ")),
        any(
            k in text
            for k in (
                "do not add",
                "do not remove",
                "do not move",
                "forbidden",
                "nie dodawaj",
                "nie usuwaj",
                "nie przesuwaj",
                "geometry lock",
            )
        ),
    ]
    return all(checks)


def ensure_geometry_lock_in_prompt(
    prompt: str,
    *,
    mode: str,
    preserve_geometry: bool,
) -> str:
    cleaned = prompt.strip()
    if not cleaned or mode != "sketch_to_render" or not preserve_geometry:
        return cleaned
    if has_complete_geometry_lock(cleaned):
        return cleaned
    return f"{cleaned}\n\n{CANONICAL_GEOMETRY_LOCK_CLAUSE}"


def _parse_geometry_protection(
    raw_protection: Any,
    fallback_note: str,
    preserve_geometry: bool,
) -> GeometryProtectionRules:
    if isinstance(raw_protection, dict):
        must_preserve = _coerce_string_list(raw_protection.get("must_preserve"))
        can_change = _coerce_string_list(raw_protection.get("can_change"))
        forbidden_changes = _coerce_string_list(raw_protection.get("forbidden_changes"))
        if must_preserve or can_change or forbidden_changes:
            return GeometryProtectionRules(
                must_preserve=must_preserve,
                can_change=can_change,
                forbidden_changes=forbidden_changes,
            )

    if preserve_geometry:
        return GeometryProtectionRules(
            must_preserve=[
                fallback_note
                or "Dokładny obrys budynku, liczba i położenie pomieszczeń, przebieg wszystkich ścian, rozmieszczenie okien, wszystkich drzwi i przeszkleń oraz relacje przestrzenne."
            ],
            can_change=[
                "Okładziny elewacyjne i wykończeniowe, kolorystyka, oprawy oświetleniowe, zieleń i pora dnia."
            ],
            forbidden_changes=[
                "Dodawanie lub usuwanie pomieszczeń, przesuwanie ścian, zmiana liczby kondygnacji, przesuwanie lub usuwanie okien, drzwi i przeszkleń oraz zmiana proporcji."
            ],
        )

    return GeometryProtectionRules(
        must_preserve=["Skala i logika funkcjonalna modułów."],
        can_change=["Korekta detali elewacji, wykończeń, stolarki i aranżacji otoczenia."],
        forbidden_changes=["Zniekształcanie deklarowanego metrażu lub liczby modułów."],
    )


def _parse_uncertainties(raw_uncertainties: Any) -> List[UncertaintyItem]:
    if not isinstance(raw_uncertainties, list):
        return []
    items: List[UncertaintyItem] = []
    for item in raw_uncertainties[:24]:
        if isinstance(item, dict):
            element = _coerce_text(item.get("element"))
            if not element:
                continue
            reason = _coerce_text(item.get("reason"))
            confidence = normalize_confidence_level(item.get("confidence"))
            combined_low = f"{element} {reason}".lower()
            if confidence == "wysoka pewność" and any(
                kw in combined_low for kw in ("łuk", "kierun", "otwier", "orientacyjn", "brak", "niepewn")
            ):
                confidence = "niska pewność"
            items.append(
                UncertaintyItem(
                    element=element[:240],
                    confidence=confidence,
                    reason=reason,
                )
            )
        elif isinstance(item, str) and item.strip():
            items.append(
                UncertaintyItem(
                    element=item.strip()[:240],
                    confidence="niska pewność",
                    reason="Wymaga doprecyzowania na podstawie czytelniejszego materiału.",
                )
            )
    return items


def _format_protection_summary(rules: GeometryProtectionRules) -> str:
    parts: List[str] = []
    if rules.must_preserve:
        parts.append("Musi pozostać niezmienione: " + "; ".join(rules.must_preserve))
    if rules.can_change:
        parts.append("Można zmienić: " + "; ".join(rules.can_change))
    if rules.forbidden_changes:
        parts.append("Zakazane zmiany: " + "; ".join(rules.forbidden_changes))
    return "\n".join(parts)


def parse_ai_analysis_response(
    raw_text: str,
    mode: str,
    preserve_geometry: bool = True,
    user_context_text: str = "",
) -> AnalysisContentFields:
    parsed = _extract_json_block(raw_text)
    if parsed:
        summary = _coerce_text(parsed.get("summary"))
        spatial_layout = _coerce_text(parsed.get("spatial_layout"))
        materials_proposal = _coerce_text(parsed.get("materials_proposal"))
        lighting_proposal = _coerce_text(parsed.get("lighting_proposal"))
        geometry_note = _coerce_text(parsed.get("geometry_preservation_note"))
        raw_vis_prompt = _coerce_text(parsed.get("visualization_prompt"))
        visualization_prompt = ensure_geometry_lock_in_prompt(
            raw_vis_prompt,
            mode=mode,
            preserve_geometry=preserve_geometry,
        )

        uncertainties = _parse_uncertainties(parsed.get("uncertainties"))
        geometry = _parse_geometry(parsed.get("geometry"))
        rooms = _parse_rooms(parsed.get("rooms"))
        openings = _parse_openings(parsed.get("openings"), uncertainties)
        openings_completeness_check = _coerce_text(parsed.get("openings_completeness_check"))
        orientation_source = _coerce_text(parsed.get("orientation_source"))
        dimension_observations = _parse_dimension_observations(parsed.get("dimension_observations"))
        dimension_checks = _parse_dimension_checks(parsed.get("dimension_checks"))
        raw_dimension_conflicts = _coerce_string_list(parsed.get("dimension_conflicts"))
        raw_dim_confidence = normalize_confidence_level(parsed.get("dimension_confidence"))

        geometry_protection = _parse_geometry_protection(
            parsed.get("geometry_protection"),
            geometry_note,
            preserve_geometry,
        )
        user_requirements = _coerce_string_list(parsed.get("user_requirements"))
        ai_suggestions = _coerce_string_list(parsed.get("ai_suggestions"))
        observed_facts = _coerce_string_list(parsed.get("observed_facts"))
        model_interpretations = _coerce_string_list(parsed.get("model_interpretations"))
        indeterminable_elements = _coerce_string_list(parsed.get("indeterminable_elements"))
        clarification_questions = _coerce_string_list(parsed.get("clarification_questions"))
        disclaimer = _coerce_text(parsed.get("disclaimer")) or DEFAULT_ARCHITECTURAL_DISCLAIMER

        dimension_conflicts, dimension_confidence = verify_dimensional_consistency(
            dimension_observations=dimension_observations,
            dimension_checks=dimension_checks,
            raw_conflicts=raw_dimension_conflicts,
            geometry=geometry,
            uncertainties=uncertainties,
            initial_confidence=raw_dim_confidence,
        )

        unjustified_directions = detect_unjustified_cardinal_directions(
            summary=summary,
            spatial_layout=spatial_layout,
            rooms=rooms,
            openings=openings,
            observed_facts=observed_facts,
            visualization_prompt=visualization_prompt,
            user_context_text=user_context_text,
        )
        if not orientation_source:
            if input_justifies_cardinal_directions(user_context_text, observed_facts):
                orientation_source = "podano w materiale wejściowym lub oznaczeniu północy na szkicu"
            else:
                orientation_source = "niemożliwe do ustalenia na podstawie materiału (brak róży wiatrów / strzałki północy)"

        if unjustified_directions:
            uncertainties.append(
                UncertaintyItem(
                    element="Nieuzasadnione przypisanie stron świata",
                    confidence="niska pewność",
                    reason=(
                        "Brak róży wiatrów lub oznaczenia północy na materiale — wykryto kierunki: "
                        + ", ".join(unjustified_directions[:6])
                    ),
                )
            )
            if not any("stron" in item.lower() or "północ" in item.lower() for item in indeterminable_elements):
                indeterminable_elements.append(
                    "Orientacja geograficzna względem stron świata (brak róży wiatrów / oznaczenia północy)"
                )

        if not observed_facts and user_requirements:
            observed_facts = list(user_requirements)
        if not model_interpretations and (geometry or rooms):
            interp: List[str] = []
            if geometry and geometry.building_footprint:
                interp.append(f"Obrys i układ: {geometry.building_footprint}")
            if geometry and geometry.structural_vs_partition_walls:
                interp.append(f"Ściany: {geometry.structural_vs_partition_walls}")
            if rooms:
                interp.append(
                    "Rozpoznane lub proponowane strefy: "
                    + ", ".join(f"{r.name} ({r.confidence})" for r in rooms[:6])
                )
            model_interpretations = interp
        if not indeterminable_elements and uncertainties:
            indeterminable_elements = [
                f"{u.element} ({u.confidence})"
                for u in uncertainties
                if u.confidence in {"niemożliwe do ustalenia na podstawie materiału", "niska pewność"}
            ]

        if not spatial_layout and (geometry or rooms):
            layout_lines: List[str] = []
            if geometry and geometry.building_footprint:
                layout_lines.append(f"Obrys: {geometry.building_footprint}")
            if geometry and geometry.circulation:
                layout_lines.append(f"Komunikacja: {geometry.circulation}")
            for room in rooms:
                layout_lines.append(
                    f"- {room.name} ({room.zone}, {room.approximate_area}) — {room.confidence}"
                )
            spatial_layout = "\n".join(layout_lines)

        if not geometry_note:
            geometry_note = _format_protection_summary(geometry_protection)

        if any(
            [
                summary,
                spatial_layout,
                materials_proposal,
                lighting_proposal,
                geometry_note,
                visualization_prompt,
                rooms,
                openings,
                geometry,
            ]
        ):
            return AnalysisContentFields(
                summary=summary or raw_text.strip()[:1200],
                spatial_layout=spatial_layout,
                rooms=rooms,
                geometry=geometry,
                openings=openings,
                openings_completeness_check=openings_completeness_check,
                orientation_source=orientation_source,
                unjustified_directions_detected=unjustified_directions,
                dimension_observations=dimension_observations,
                dimension_checks=dimension_checks,
                dimension_conflicts=dimension_conflicts,
                dimension_confidence=dimension_confidence,
                materials_proposal=materials_proposal,
                lighting_proposal=lighting_proposal,
                geometry_preservation_note=geometry_note,
                geometry_protection=geometry_protection,
                visualization_prompt=visualization_prompt,
                uncertainties=uncertainties,
                user_requirements=user_requirements,
                ai_suggestions=ai_suggestions,
                observed_facts=observed_facts,
                model_interpretations=model_interpretations,
                indeterminable_elements=indeterminable_elements,
                clarification_questions=clarification_questions,
                disclaimer=disclaimer,
                analysis_source="live",
            )

    fallback_text = raw_text.strip() or "Dostawca AI zwrócił pustą odpowiedź tekstową."
    default_geo_rules = _parse_geometry_protection(None, "", preserve_geometry)
    default_geo_note = _format_protection_summary(default_geo_rules)
    return AnalysisContentFields(
        summary=fallback_text,
        spatial_layout="",
        rooms=[],
        geometry=None,
        openings=[],
        openings_completeness_check="",
        orientation_source="niemożliwe do ustalenia na podstawie materiału",
        unjustified_directions_detected=[],
        dimension_observations=[],
        dimension_checks=[],
        dimension_conflicts=[],
        dimension_confidence="niemożliwe do ustalenia na podstawie materiału",
        materials_proposal="",
        lighting_proposal="",
        geometry_preservation_note=default_geo_note,
        geometry_protection=default_geo_rules,
        visualization_prompt="",
        uncertainties=[
            UncertaintyItem(
                element="Struktura odpowiedzi modelu",
                confidence="niska pewność",
                reason="Model nie zwrócił pełnego formatu JSON — wyświetlono odpowiedź opisową (tryb fallback).",
            )
        ],
        user_requirements=[],
        ai_suggestions=[],
        observed_facts=[],
        model_interpretations=[],
        indeterminable_elements=["Pełna struktura JSON odpowiedzi modelu"],
        clarification_questions=[],
        disclaimer=DEFAULT_ARCHITECTURAL_DISCLAIMER,
        analysis_source="fallback",
    )


def detect_image_mime_from_bytes(raw_bytes: bytes) -> Optional[str]:
    if raw_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if raw_bytes.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if len(raw_bytes) >= 12 and raw_bytes[:4] == b"RIFF" and raw_bytes[8:12] == b"WEBP":
        return "image/webp"
    head_text = raw_bytes[:256].lstrip().lower()
    if head_text.startswith(b"<svg") or b"<svg" in head_text:
        return "image/svg+xml"
    return None


def load_sketch_image_for_vision(sketch_url: str, settings: Settings) -> Tuple[str, str]:
    normalized = sketch_url.strip()
    if not normalized:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Brak ścieżki do szkicu wejściowego.",
        )

    target_path: Optional[Path] = None
    allowed_root: Optional[Path] = None

    if normalized.startswith("/storage/"):
        rel = normalized[len("/storage/") :]
        allowed_root = settings.storage_path.resolve()
        target_path = (allowed_root / rel).resolve()
    elif normalized.startswith("/src/assets/"):
        rel = normalized[len("/src/assets/") :]
        allowed_root = (ROOT_DIR / "src" / "assets").resolve()
        target_path = (allowed_root / rel).resolve()
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nieprawidłowa ścieżka szkicu. Prześlij plik przez formularz pracowni lub użyj wzoru demonstracyjnego.",
        )

    if not target_path.is_relative_to(allowed_root):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Niedozwolona ścieżka pliku szkicu.",
        )

    if not target_path.is_file():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Plik szkicu nie został odnaleziony na serwerze.",
        )

    ext = target_path.suffix.lower()
    if ext == ".svg":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Format SVG nie jest obsługiwany przez darmowe modele wizyjne — prześlij plik PNG, JPG lub WEBP albo użyj wzoru demonstracyjnego.",
        )

    ext_mime = ALLOWED_VISION_MIME_BY_EXT.get(ext)
    if not ext_mime:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Nieobsługiwany format obrazu ({ext}) dla analizy AI. Użyj PNG, JPG lub WEBP.",
        )

    raw_bytes = target_path.read_bytes()
    if not raw_bytes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Plik szkicu jest pusty.",
        )

    detected_mime = detect_image_mime_from_bytes(raw_bytes)
    if detected_mime == "image/svg+xml":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Wykryto treść SVG w pliku szkicu — darmowe modele wizyjne wymagają rastra PNG, JPG lub WEBP.",
        )
    if detected_mime is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Zawartość pliku szkicu nie odpowiada prawidłowemu nagłówkowi obrazu PNG, JPG ani WEBP.",
        )

    return base64.b64encode(raw_bytes).decode("ascii"), detected_mime


def _load_reference_context(
    db: Session,
    reference_ids: List[int],
    *,
    project_id: Optional[int] = None,
    project_title: Optional[str] = None,
) -> str:
    if not reference_ids:
        return "Brak przypisanych referencji z biblioteki pracowni."

    from app.services import reference_service

    preview = reference_service.build_reference_context_preview(
        db,
        reference_ids,
        project_id=project_id,
        project_title=project_title,
    )
    return preview.formatted_prompt_context



def build_analysis_prompts(
    *,
    mode: str,
    title: str,
    building_type: str,
    area_sqm: Optional[float],
    modules_count: int,
    style_preset: str,
    preserve_geometry: bool,
    prompt_brief: str,
    geometry_notes: str,
    reference_context: str,
) -> Tuple[str, str]:
    system_instruction = (
        "Jesteś starszym architektem specjalizującym się w budownictwie modułowym i architekturze wnętrz "
        "w aplikacji Modular AI Visualizer (polityka Zero Kosztów).\n"
        "ZASADA NACZELNA: Poprawność architektoniczna, weryfikacja matematyczna wymiarów oraz uczciwe informowanie o niepewności "
        "są ważniejsze niż efektowny, ale zmyślony opis.\n"
        "ZAKAZY BEZWZGLĘDNE:\n"
        "1. Nie wymyślaj wymiarów, powierzchni pomieszczeń ani kątów, których nie widać jednoznacznie na rysunku lub nie podano w opisie.\n"
        "2. ZAKAZ WYMYŚLANIA STRON ŚWIATA: Nie przypisuj kierunków geograficznych (północ, południe, wschód, zachód, north, south, east, west), "
        "jeśli na szkicu nie ma róży wiatrów / strzałki północy lub użytkownik nie podał ich wprost. Zamiast tego używaj określeń: "
        "'górna część rzutu', 'dolna część rzutu', 'lewa strona rzutu', 'prawa strona rzutu', 'centralna część', 'część wejściowa', "
        "'część ogrodowa' (wyłącznie jeśli wynika z materiału).\n"
        "3. Nie deklaruj zgodności wymiarowej, jeśli suma odcinków przeczy wymiarowi całkowitemu; nie poprawiaj samodzielnie wymiarów.\n"
        "4. Nie deklaruj zgodności konstrukcyjnej, nośności ani zgodności z przepisami budowlanymi.\n"
        "5. Nie twierdź, że wygenerowano gotowy obraz lub fotorealistyczny render.\n"
        "6. W Trybie A obowiązuje GEOMETRY LOCK — nie zmieniaj obrysu, liczby i położenia pomieszczeń, ścian, okien ani żadnych drzwi.\n"
        "7. Każdy istotny element oznaczaj WYŁĄCZNIE jednym z czterech poziomów pewności:\n"
        "   - \"wysoka pewność\"\n"
        "   - \"średnia pewność\"\n"
        "   - \"niska pewność\"\n"
        "   - \"niemożliwe do ustalenia na podstawie materiału\"\n\n"
        "Odpowiadaj WYŁĄCZNIE poprawnym obiektem JSON (bez komentarzy poza JSON) zgodnym ze schematem:\n"
        "{\n"
        '  "summary": "string",\n'
        '  "spatial_layout": "string",\n'
        '  "orientation_source": "string (skąd pochodzi orientacja lub że jest niemożliwa do ustalenia)",\n'
        '  "geometry": {\n'
        '    "building_footprint": "string",\n'
        '    "floors_count": "string",\n'
        '    "structural_vs_partition_walls": "string",\n'
        '    "circulation": "string",\n'
        '    "proportions_and_scale": "string",\n'
        '    "confidence": "wysoka pewność | średnia pewność | niska pewność | niemożliwe do ustalenia na podstawie materiału"\n'
        "  },\n"
        '  "rooms": [{"name": "string", "zone": "string", "approximate_area": "string", "spatial_relations": "string", "confidence": "..."}],\n'
        '  "openings": [{\n'
        '    "opening_id": "np. D-01, DW-01, HS-01, O-01",\n'
        '    "category": "drzwi wejściowe | drzwi wewnętrzne | drzwi przesuwne | drzwi tarasowe | przeszklenia HS | okno | inne",\n'
        '    "location": "lokalizacja opisana względem pomieszczeń i stron rzutu (bez zmyślonych stron świata)",\n'
        '    "opening_direction": "string (lub niemożliwe do ustalenia na podstawie materiału)",\n'
        '    "has_swing_arc": true | false | null,\n'
        '    "opening_completeness_note": "string",\n'
        '    "notes": "string",\n'
        '    "confidence": "..."\n'
        "  }],\n"
        '  "openings_completeness_check": "string (podsumowanie końcowej kontroli liczby drzwi/otworów i ewentualnych niepewności)",\n'
        '  "dimension_observations": [{\n'
        '    "label": "string",\n'
        '    "value": "string",\n'
        '    "source_type": "direct | calculated | estimated | indeterminable",\n'
        '    "unit": "m | cm | mm | m2 | brak",\n'
        '    "location": "string",\n'
        '    "confidence": "..."\n'
        "  }],\n"
        '  "dimension_checks": [{\n'
        '    "description": "string",\n'
        '    "overall_dimension": "string",\n'
        '    "segment_sum": "string",\n'
        '    "status": "consistent | conflict | indeterminable",\n'
        '    "difference": "string"\n'
        "  }],\n"
        '  "dimension_conflicts": ["string"],\n'
        '  "dimension_confidence": "wysoka pewność | średnia pewność | niska pewność | niemożliwe do ustalenia na podstawie materiału",\n'
        '  "materials_proposal": "string",\n'
        '  "lighting_proposal": "string",\n'
        '  "geometry_protection": {\n'
        '    "must_preserve": ["string"],\n'
        '    "can_change": ["string"],\n'
        '    "forbidden_changes": ["string"]\n'
        "  },\n"
        '  "geometry_preservation_note": "string",\n'
        '  "visualization_prompt": "string",\n'
        '  "uncertainties": [{"element": "string", "confidence": "niska pewność | niemożliwe do ustalenia na podstawie materiału", "reason": "string"}],\n'
        '  "user_requirements": ["string"],\n'
        '  "ai_suggestions": ["string"],\n'
        '  "observed_facts": ["A. Informacje jednoznacznie odczytane ze szkicu lub podane wprost przez użytkownika"],\n'
        '  "model_interpretations": ["B. Ostrożne interpretacje architektoniczne modelu wymagające weryfikacji"],\n'
        '  "indeterminable_elements": ["D. Informacje niemożliwe do ustalenia na podstawie materiału"],\n'
        '  "clarification_questions": ["string"],\n'
        '  "disclaimer": "string"\n'
        "}"
    )

    area_str = f"{area_sqm} m²" if area_sqm is not None else "nie podano w formularzu"

    if mode == "sketch_to_render":
        user_prompt = (
            "TRYB A — PRECYZYJNA ANALIZA SZKICU ARCHITEKTONICZNEGO Z BLOKADĄ GEOMETRII (GEOMETRY LOCK).\n"
            f"Projekt: {title}\n"
            f"Typ obiektu: {building_type} | Metraż z formularza: {area_str} | Liczba modułów: {modules_count} | Styl docelowy: {style_preset}\n"
            f"Blokada geometrii szkicu: {'TAK — BEZWZGLĘDNY GEOMETRY LOCK' if preserve_geometry else 'Elastycznie w detalu'}\n"
            f"Wymagania użytkownika: {prompt_brief or 'Brak dodatkowych uwag'}\n"
            f"Uwagi wymiarowe i stolarka: {geometry_notes or 'Brak dodatkowych uwag'}\n"
            f"Referencje pracowni:\n{reference_context}\n\n"
            "WYMAGANIA SZCZEGÓŁOWE TRYBU A:\n"
            "1. ORIENTACJA I GEOMETRIA:\n"
            "- ZAKAZ WYMYŚLANIA STRON ŚWIATA: Nie używaj słów północ/południe/wschód/zachód (ani north/south/east/west), chyba że na szkicu jest jednoznaczna róża wiatrów / strzałka północy lub użytkownik podał kierunek wprost. Stosuj wyłącznie: górna część rzutu, dolna część rzutu, lewa strona rzutu, prawa strona rzutu, centralna część, część wejściowa, część ogrodowa (gdy wynika z materiału).\n"
            "- Opisz obrys, liczbę kondygnacji, rozmieszczenie pomieszczeń, komunikację oraz rozróżnienie ścian konstrukcyjnych/działowych (jeśli brak różnicy grubości/oznaczeń, wpisz 'niemożliwe do ustalenia na podstawie materiału').\n\n"
            "2. PEŁNE ROZPOZNAWANIE DRZWI I OTWORÓW:\n"
            "- Osobno przeanalizuj i wypisz w `openings`: drzwi wejściowe, drzwi wewnętrzne, drzwi przesuwne, drzwi tarasowe, przeszklenia HS, okna oraz inne widoczne otwory.\n"
            "- Każde drzwi i otwór muszą mieć unikalny `opening_id` (np. D-01, DW-01, HS-01, O-01), lokalizację względem pomieszczeń, typ (`category`), `has_swing_arc` (true/false/null), `opening_direction` oraz `confidence`.\n"
            "- WAŻNE: Brak łuku otwierania NIE oznacza, że drzwi nie istnieją! Jeśli otwór drzwiowy jest widoczny bez łuku, opisz go w `openings`, ustaw `has_swing_arc: false`, wpisz kierunek otwierania jako niepewny i NIE deklaruj wysokiej pewności kierunku otwierania.\n"
            "- KOŃCOWA KONTROLA KOMPLETNOŚCI OTWORÓW (`openings_completeness_check`):\n"
            "  (1) Ponownie przeanalizuj cały obrys budynku;\n"
            "  (2) Przejdź przez wszystkie granice pomieszczeń;\n"
            "  (3) Policz widoczne otwory drzwiowe;\n"
            "  (4) Porównaj liczbę rozpoznanych otworów drzwiowych z liczbą pozycji w `openings`;\n"
            "  (5) Jeśli liczby nie da się pewnie ustalić, zgłoś niepewność zamiast zgadywać.\n\n"
            "3. KONTROLA SPÓJNOŚCI WYMIAROWEJ (`dimension_observations`, `dimension_checks`, `dimension_conflicts`, `dimension_confidence`):\n"
            "- Zbierz wszystkie widoczne wymiary całkowite i odcinkowe; porównaj sumy odcinków z wymiarami całkowitymi; sprawdź jednostki.\n"
            "- Każdą obserwację oznacz jako `source_type`: 'direct' (A. bezpośrednio odczytany), 'calculated' (B. obliczony z innych oznaczeń), 'estimated' (C. szacunkowy — nigdy jako fakt!) lub 'indeterminable' (D. niemożliwy do ustalenia).\n"
            "- Jeśli suma odcinków nie zgadza się z wymiarem całkowitym (np. 4,0 + 3,5 + 2,1 = 9,6 m vs 7,5 m -> sprzeczność 2,1 m), wpisz `status: \"conflict\"`, zgłoś dokładną różnicę w `dimension_conflicts` i NIE deklaruj spójności wymiarowej ani nie poprawiaj samowolnie liczb.\n\n"
            "4. MATERIAŁY, OŚWIETLENIE I NIEPEWNOŚCI:\n"
            "- W `materials_proposal` i `lighting_proposal` zaproponuj spójne materiały i światło dzienne/sztuczne.\n"
            "- Rozróżnij jawnie listy: `observed_facts`, `model_interpretations`, `ai_suggestions`, `indeterminable_elements` oraz `uncertainties` + `clarification_questions`.\n\n"
            "5. GEOMETRY LOCK W `visualization_prompt` (OBOWIĄZKOWE):\n"
            "- Każdy `visualization_prompt` Trybu A MUSI zawierać wyraźną sekcję `GEOMETRY LOCK (MANDATORY):` nakazującą zachować: dokładny obrys budynku, liczbę i położenie pomieszczeń, przebieg wszystkich ścian, rozmieszczenie okien, rozmieszczenie wszystkich drzwi, otwory i przeszklenia oraz relacje przestrzenne; oraz ZAKAZUJĄCĄ: dodawania nowych pomieszczeń, usuwania istniejących pomieszczeń, dokładania kondygnacji, przesuwania ścian i zmiany proporcji lub położenia otworów."
        )
    else:
        user_prompt = (
            "TRYB B — PROFESJONALNA KONCEPCJA ARCHITEKTONICZNA Z OPISU POMYSŁU.\n"
            f"Nazwa koncepcji: {title}\n"
            f"Typ obiektu: {building_type} | Metraż z formularza: {area_str} | Liczba modułów: {modules_count} | Styl bazowy: {style_preset}\n"
            f"Opis pomysłu użytkownika: {prompt_brief}\n"
            f"Parametry konstrukcyjne i stolarka: {geometry_notes or 'Brak dodatkowych uwag'}\n"
            f"Referencje pracowni:\n{reference_context}\n\n"
            "Przygotuj profesjonalną koncepcję w JSON:\n"
            "1. summary + geometry: charakterystyka budynku modułowego lub wnętrza, obrys koncepcyjny, liczba kondygnacji, komunikacja i założenia modułowe.\n"
            "2. spatial_layout + rooms: proponowany układ funkcjonalny z wyraźnym podziałem na strefy dzienne i nocne oraz relacje między pomieszczeniami.\n"
            "3. openings + openings_completeness_check: proponowane drzwi wejściowe, wewnętrzne, tarasowe/HS i okna wraz z `opening_id` (bez wymyślania stron świata, jeśli brak ich w briefie).\n"
            "4. dimension_observations + dimension_checks: rozróżnij parametry podane przez użytkownika ('direct'), obliczone ('calculated') i wstępne założenia ('estimated').\n"
            "5. materials_proposal + lighting_proposal: materiały zewnętrzne/wewnętrzne, spójna paleta kolorystyki, oświetlenie naturalne i sztuczne.\n"
            "6. Rozróżnij jawnie 4 listy (`observed_facts`/`user_requirements`, `model_interpretations`, `ai_suggestions`, `indeterminable_elements`), `uncertainties`, `clarification_questions`, `disclaimer` oraz `geometry_protection` + `visualization_prompt`."
        )

    return system_instruction, user_prompt


async def execute_free_ai_analysis(
    db: Session,
    settings: Settings,
    *,
    mode: str,
    title: str,
    building_type: str,
    area_sqm: Optional[float],
    modules_count: int,
    style_preset: str,
    preserve_geometry: bool,
    prompt_brief: str,
    geometry_notes: str,
    sketch_image_url: Optional[str],
    reference_ids: List[int],
    preferred_provider: ProviderPreference = "auto",
    router: Optional[ProviderRouter] = None,
) -> AnalysisPreviewResponse:
    image_base64: Optional[str] = None
    image_mime_type = "image/jpeg"

    if mode == "sketch_to_render":
        if not sketch_image_url or not sketch_image_url.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="W Trybie A (Szkic → Wizualizacja) prześlij najpierw plik szkicu lub załaduj wzór demonstracyjny.",
            )
        image_base64, image_mime_type = load_sketch_image_for_vision(sketch_image_url, settings)
    else:
        if len(prompt_brief.strip()) < 10:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="W Trybie B (Pomysł → Projekt) wpisz opis koncepcji o długości co najmniej 10 znaków.",
            )

    studio_settings = settings_service.get_or_create_studio_settings(db)
    active_router = router or ProviderRouter(settings, CostGuard(settings))

    if preferred_provider in {"gemini", "groq"}:
        selection = active_router.select_vision_provider(
            db,
            preferred_key=preferred_provider,
            strict_preferred=True,
        )
    else:
        selection = active_router.select_vision_provider(
            db,
            preferred_key=studio_settings.preferred_vision_provider,
            strict_preferred=False,
        )

    if selection.provider is None:
        decision = selection.decision
        if decision.blocked_by_cost_policy:
            raise CostPolicyViolation(decision.reason)
        if decision.availability_status in {"cooldown", "local_limit_reached"}:
            raise ProviderQuotaExceededError(decision.reason)
        if decision.availability_status == "missing_api_key":
            raise ProviderKeyMissingError(
                "Brak skonfigurowanego darmowego klucza API (GEMINI_API_KEY lub GROQ_API_KEY) "
                "w zmiennych środowiskowych backendu. Nie wykonano żadnego wywołania zewnętrznego."
            )
        raise CostPolicyViolation(decision.reason)

    reference_context = _load_reference_context(db, reference_ids)
    system_instruction, user_prompt = build_analysis_prompts(
        mode=mode,
        title=title,
        building_type=building_type,
        area_sqm=area_sqm,
        modules_count=modules_count,
        style_preset=style_preset,
        preserve_geometry=preserve_geometry,
        prompt_brief=prompt_brief,
        geometry_notes=geometry_notes,
        reference_context=reference_context,
    )

    result = await selection.provider.analyze_sketch(
        prompt=user_prompt,
        image_base64=image_base64,
        preserve_geometry=preserve_geometry,
        image_mime_type=image_mime_type,
        system_instruction=system_instruction,
        response_mime_type="application/json",
    )

    raw_text = str(result.get("text") or "").strip()
    if not raw_text:
        raise ProviderRequestError("Dostawca AI nie zwrócił treści tekstowej analizy.")

    structured = parse_ai_analysis_response(
        raw_text,
        mode=mode,
        preserve_geometry=preserve_geometry,
        user_context_text=f"{prompt_brief}\n{geometry_notes}",
    )

    image_gen = active_router.select_image_generator()
    image_gen_result = await image_gen.generate_visualization(
        prompt=structured.visualization_prompt or structured.summary,
        reference_image_paths=[],
        aspect_ratio=studio_settings.preferred_aspect_ratio,
    )

    raw_latency = result.get("response_time_ms")
    response_time_ms = int(raw_latency) if isinstance(raw_latency, (int, float)) else None

    return AnalysisPreviewResponse(
        mode=mode,  # type: ignore[arg-type]
        provider=str(result["provider"]),
        model=str(result["model"]),
        is_free_tier=True,
        response_time_ms=response_time_ms,
        schema_version="3.5",
        summary=structured.summary,
        spatial_layout=structured.spatial_layout,
        rooms=structured.rooms,
        geometry=structured.geometry,
        openings=structured.openings,
        openings_completeness_check=structured.openings_completeness_check,
        orientation_source=structured.orientation_source,
        unjustified_directions_detected=structured.unjustified_directions_detected,
        dimension_observations=structured.dimension_observations,
        dimension_checks=structured.dimension_checks,
        dimension_conflicts=structured.dimension_conflicts,
        dimension_confidence=structured.dimension_confidence,
        materials_proposal=structured.materials_proposal,
        lighting_proposal=structured.lighting_proposal,
        geometry_preservation_note=structured.geometry_preservation_note,
        geometry_protection=structured.geometry_protection,
        visualization_prompt=structured.visualization_prompt,
        uncertainties=structured.uncertainties,
        user_requirements=structured.user_requirements,
        ai_suggestions=structured.ai_suggestions,
        observed_facts=structured.observed_facts,
        model_interpretations=structured.model_interpretations,
        indeterminable_elements=structured.indeterminable_elements,
        clarification_questions=structured.clarification_questions,
        disclaimer=structured.disclaimer,
        analysis_source=structured.analysis_source,
        raw_response_text=raw_text,
        image_generation_available=False,
        image_generation_note=str(image_gen_result.get("message") or ""),
    )


async def analyze_draft(
    db: Session,
    settings: Settings,
    payload: AnalyzeDraftRequest,
    router: Optional[ProviderRouter] = None,
) -> AnalysisPreviewResponse:
    return await execute_free_ai_analysis(
        db,
        settings,
        mode=payload.mode,
        title=payload.title,
        building_type=payload.building_type,
        area_sqm=payload.area_sqm,
        modules_count=payload.modules_count,
        style_preset=payload.style_preset,
        preserve_geometry=payload.preserve_geometry,
        prompt_brief=payload.prompt_brief,
        geometry_notes=payload.geometry_notes,
        sketch_image_url=payload.sketch_image_url,
        reference_ids=payload.reference_ids,
        preferred_provider=payload.preferred_provider,
        router=router,
    )


async def analyze_and_save_for_project(
    db: Session,
    settings: Settings,
    project_id: int,
    preferred_provider: ProviderPreference = "auto",
    router: Optional[ProviderRouter] = None,
) -> Optional[project_service.ProjectRead]:
    project = db.get(Project, project_id)
    if project is None:
        return None

    try:
        ref_ids = json.loads(project.reference_ids_json or "[]")
        if not isinstance(ref_ids, list):
            ref_ids = []
    except json.JSONDecodeError:
        ref_ids = []

    preview = await execute_free_ai_analysis(
        db,
        settings,
        mode=project.mode,
        title=project.title,
        building_type=project.building_type,
        area_sqm=project.area_sqm,
        modules_count=project.modules_count,
        style_preset=project.style_preset,
        preserve_geometry=project.preserve_geometry,
        prompt_brief=project.prompt_brief,
        geometry_notes=project.geometry_notes,
        sketch_image_url=project.sketch_image_url,
        reference_ids=[int(x) for x in ref_ids if isinstance(x, (int, str)) and str(x).isdigit()],
        preferred_provider=preferred_provider,
        router=router,
    )

    structured_json = json.dumps(extract_structured_payload_dict(preview), ensure_ascii=False)
    record = ProjectAnalysis(
        project_id=project.id,
        mode=preview.mode,
        provider=preview.provider,
        model=preview.model,
        is_free_tier=preview.is_free_tier,
        summary=preview.summary,
        spatial_layout=preview.spatial_layout,
        materials_proposal=preview.materials_proposal,
        lighting_proposal=preview.lighting_proposal,
        geometry_preservation_note=preview.geometry_preservation_note,
        visualization_prompt=preview.visualization_prompt,
        structured_payload_json=structured_json,
        response_time_ms=preview.response_time_ms,
        schema_version=preview.schema_version,
        raw_response_text=preview.raw_response_text,
    )
    db.add(record)
    db.commit()
    return project_service.get_project(db, project.id)


def update_latest_analysis_for_project(
    db: Session,
    project_id: int,
    payload: ProjectAnalysisUpdate,
) -> Optional[project_service.ProjectRead]:
    project = db.get(Project, project_id)
    if project is None:
        return None

    latest = db.scalars(
        select(ProjectAnalysis)
        .where(ProjectAnalysis.project_id == project_id)
        .order_by(ProjectAnalysis.updated_at.desc(), ProjectAnalysis.id.desc())
        .limit(1)
    ).first()
    if latest is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ten projekt nie ma jeszcze zapisanej analizy AI do edycji.",
        )

    text_fields = (
        "summary",
        "spatial_layout",
        "materials_proposal",
        "lighting_proposal",
        "geometry_preservation_note",
        "visualization_prompt",
    )
    data = payload.model_dump(exclude_unset=True)
    for field in text_fields:
        if field in data and isinstance(data[field], str):
            setattr(latest, field, data[field].strip())

    structured_keys = (
        "rooms",
        "geometry",
        "openings",
        "openings_completeness_check",
        "orientation_source",
        "unjustified_directions_detected",
        "dimension_observations",
        "dimension_checks",
        "dimension_conflicts",
        "dimension_confidence",
        "geometry_protection",
        "uncertainties",
        "user_requirements",
        "ai_suggestions",
        "observed_facts",
        "model_interpretations",
        "indeterminable_elements",
        "clarification_questions",
        "disclaimer",
    )
    if any(k in data for k in structured_keys):
        existing_structured: Dict[str, Any] = {}
        if latest.structured_payload_json:
            try:
                loaded = json.loads(latest.structured_payload_json)
                if isinstance(loaded, dict):
                    existing_structured = loaded
            except json.JSONDecodeError:
                existing_structured = {}

        for key in structured_keys:
            if key in data:
                existing_structured[key] = data[key]

        if "disclaimer" not in existing_structured or not existing_structured["disclaimer"]:
            existing_structured["disclaimer"] = DEFAULT_ARCHITECTURAL_DISCLAIMER

        latest.structured_payload_json = json.dumps(existing_structured, ensure_ascii=False)
        latest.schema_version = "3.5"

    db.commit()
    return project_service.get_project(db, project_id)

