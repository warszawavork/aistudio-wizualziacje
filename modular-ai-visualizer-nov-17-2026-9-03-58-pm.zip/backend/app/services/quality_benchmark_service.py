import re
import struct
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Literal, Optional, Sequence

from sqlalchemy.orm import Session

from app.core.config import ROOT_DIR, Settings
from app.core.cost_guard import CostGuard, CostPolicyViolation, ProviderKeyMissingError, ProviderQuotaExceededError
from app.schemas.analysis import AnalysisContentFields, AnalysisPreviewResponse
from app.services import analysis_service
from app.services.provider_router import ProviderRouter

CANONICAL_CONFIDENCE_SET = {
    "wysoka pewność",
    "średnia pewność",
    "niska pewność",
    "niemożliwe do ustalenia na podstawie materiału",
}


@dataclass(frozen=True)
class ArchitecturalBenchmarkCase:
    case_id: str
    title: str
    mode: Literal["sketch_to_render", "idea_to_project"]
    building_type: str
    area_sqm: Optional[float]
    modules_count: int
    style_preset: str
    preserve_geometry: bool
    prompt_brief: str
    geometry_notes: str
    sketch_image_url: Optional[str]
    required_terms: List[str]
    expects_caution_on_missing_dims: bool = False
    expects_ambiguity_handling: bool = False
    expected_dimension_conflict: bool = False
    allows_cardinal_directions: bool = False
    allowed_numeric_tokens: List[str] = field(default_factory=list)


@dataclass
class QualityEvaluationReport:
    case_id: str
    provider: str
    model: str
    response_time_ms: Optional[int]
    completeness_score: int
    interpretation_score: int
    caution_score: int
    requirements_score: int
    prompt_consistency_score: int
    overall_score: int
    passed: bool
    defects: List[str]


@dataclass
class ProviderAggregateMetrics:
    provider: str
    cases_evaluated: int
    passed_cases: int
    avg_completeness: float
    avg_interpretation: float
    avg_caution: float
    avg_requirements: float
    avg_prompt_quality: float
    avg_overall: float
    avg_response_time_ms: Optional[float]


@dataclass
class ProviderComparisonReport:
    shared_case_ids: List[str]
    ranking_allowed: bool
    notice: str
    providers: List[ProviderAggregateMetrics]
    winner_by_dimension: Dict[str, str]


def build_minimal_png_bytes(width: int = 32, height: int = 32) -> bytes:
    """Creates a valid minimal RGBA PNG without external image dependencies for local fixture tests."""
    raw_rows = []
    for y in range(height):
        row = bytearray([0])
        for x in range(width):
            is_border = x in (4, width - 5) and 4 <= y <= height - 5 or y in (4, height - 5) and 4 <= x <= width - 5
            val = 30 if is_border else 245
            row.extend((val, val, val, 255))
        raw_rows.append(bytes(row))
    compressed = zlib.compress(b"".join(raw_rows))

    def chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack("!I", len(data)) + tag + data + struct.pack("!I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    ihdr = struct.pack("!IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", compressed) + chunk(b"IEND", b"")


def get_default_benchmark_cases(mode: Optional[Literal["sketch_to_render", "idea_to_project"]] = None) -> List[ArchitecturalBenchmarkCase]:
    demo_sketch = "/src/assets/images/architectural_hand_sketch_1794908154196.jpg"
    has_demo_sketch = (ROOT_DIR / "src" / "assets" / "images" / "architectural_hand_sketch_1794908154196.jpg").is_file()

    cases: List[ArchitecturalBenchmarkCase] = [
        # --- TRYB A (6 reprezentatywnych szkiców z Etapu 3.4 §4) ---
        ArchitecturalBenchmarkCase(
            case_id="simple_modular_plan",
            title="1. Prosty rzut domu modułowego z czytelnym podziałem pomieszczeń",
            mode="sketch_to_render",
            building_type="Dom modułowy parterowy",
            area_sqm=48.0,
            modules_count=1,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief="Prosty prostokątny rzut jednego modułu mieszkalnego z wejściem od frontu i wyraźnym podziałem na salon, aneks oraz łazienkę.",
            geometry_notes="Zachować układ wejścia i proporcje bryły.",
            sketch_image_url=demo_sketch if has_demo_sketch else None,
            required_terms=["moduł", "wejści", "nordic graphite"],
            expects_caution_on_missing_dims=False,
            allowed_numeric_tokens=["48", "1", "2700"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="multi_room_modular_plan",
            title="2. Rzut z kilkoma pomieszczeniami i korytarzem",
            mode="sketch_to_render",
            building_type="Pawilon dwumodułowy",
            area_sqm=76.0,
            modules_count=2,
            style_preset="Raw Steel & Cedar",
            preserve_geometry=True,
            prompt_brief="Dwa połączone moduły: strefa dzienna z kuchnią, korytarz osiowy, dwie sypialnie i łazienka.",
            geometry_notes="Wyraźna oś korytarza między modułem dziennym a nocnym.",
            sketch_image_url=demo_sketch if has_demo_sketch else None,
            required_terms=["korytarz", "sypialni", "łazienk", "cedr"],
            expects_caution_on_missing_dims=False,
            allowed_numeric_tokens=["76", "2"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="large_glazing_plan",
            title="3. Rzut z dużymi przeszkleniami",
            mode="sketch_to_render",
            building_type="Dom modułowy parterowy",
            area_sqm=68.0,
            modules_count=2,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief="Duże przeszklenia tarasowe HS od strony południowej z podcieniem na taras.",
            geometry_notes="Przeszklenie HS bez słupków pośrednich na osi salonu.",
            sketch_image_url=demo_sketch if has_demo_sketch else None,
            required_terms=["przeszklen", "hs", "taras"],
            expects_caution_on_missing_dims=False,
            allowed_numeric_tokens=["68", "2"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="illegible_incomplete_dimensions",
            title="4. Szkic z niepełnymi wymiarami",
            mode="sketch_to_render",
            building_type="Dom modułowy",
            area_sqm=None,
            modules_count=2,
            style_preset="Shou Sugi Ban Minimal",
            preserve_geometry=True,
            prompt_brief="Szkic odręczny z niepełnymi wymiarami ścian i bez metrażu pomieszczeń.",
            geometry_notes="Brak zwymiarowania długości przegród i szerokości otworów.",
            sketch_image_url=demo_sketch if has_demo_sketch else None,
            required_terms=["niemożliwe do ustalenia"],
            expects_caution_on_missing_dims=True,
            expects_ambiguity_handling=True,
            allowed_numeric_tokens=["2", "2700", "3000"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="ambiguous_doors_windows_sketch",
            title="5. Szkic z niejednoznacznymi oznaczeniami drzwi i okien",
            mode="sketch_to_render",
            building_type="Dom modułowy",
            area_sqm=62.0,
            modules_count=2,
            style_preset="Birch & Microcement",
            preserve_geometry=True,
            prompt_brief="Szkic koncepcyjny bez łuków otwierania drzwi i bez rozróżnienia, które przerwy w ścianach to okna narożne, a które wyjście tarasowe.",
            geometry_notes="Brak symboli kierunków otwierania skrzydeł i brak opisów stolarki.",
            sketch_image_url=demo_sketch if has_demo_sketch else None,
            required_terms=["niemożliwe do ustalenia", "otw"],
            expects_caution_on_missing_dims=False,
            expects_ambiguity_handling=True,
            allowed_numeric_tokens=["62", "2"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="structural_vs_partition_walls_sketch",
            title="6. Szkic z wyraźnymi ścianami konstrukcyjnymi i działowymi",
            mode="sketch_to_render",
            building_type="Pawilon dwumodułowy",
            area_sqm=80.0,
            modules_count=2,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief="Rzut architektoniczny z grubymi ścianami obwodowymi/konstrukcyjnymi modułów i cienkimi ściankami działowymi wewnątrz strefy nocnej.",
            geometry_notes="Zaznaczyć różnicę między ścianą konstrukcyjną a działową wyłącznie tam, gdzie grubość linii na rysunku jest wyraźna.",
            sketch_image_url=demo_sketch if has_demo_sketch else None,
            required_terms=["konstrukcyjn", "działow"],
            expects_caution_on_missing_dims=False,
            allowed_numeric_tokens=["80", "2"],
        ),
        # --- TRYB B (4 opisy pomysłów z Etapu 3.4 §5) ---
        ArchitecturalBenchmarkCase(
            case_id="tryb_b_small_two_person_house",
            title="7. Mały dom modułowy dla dwóch osób",
            mode="idea_to_project",
            building_type="Dom modułowy parterowy",
            area_sqm=46.0,
            modules_count=1,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief=(
                "Kompaktowy całoroczny dom jednomodułowy 46 m² dla dwóch osób: jasna strefa dzienna z aneksem, "
                "wydzielona sypialnia dwuosobowa, łazienka i mały taras drewniany pod zadaszeniem."
            ),
            geometry_notes="Moduł transportowy 3.45 x 13.5 m, dach jednospadowy.",
            sketch_image_url=None,
            required_terms=["46", "taras", "sypialni", "nordic graphite"],
            expects_caution_on_missing_dims=False,
            allowed_numeric_tokens=["46", "1", "3.45", "13.5"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="tryb_b_family_day_night_zones",
            title="8. Dom rodzinny z wyraźnym podziałem na strefę dzienną i nocną",
            mode="idea_to_project",
            building_type="Pawilon dwumodułowy",
            area_sqm=96.0,
            modules_count=3,
            style_preset="Raw Steel & Cedar",
            preserve_geometry=True,
            prompt_brief=(
                "Dom rodzinny 96 m² z trzech modułów dla rodziny 2+2: wyraźne oddzielenie głośnej strefy dziennej z jadalnią "
                "od cichej strefy nocnej z trzema sypialniami i dwiema łazienkami połączonej przeszklonym łącznikiem."
            ),
            geometry_notes="Szerokość każdego modułu do 3.5 m.",
            sketch_image_url=None,
            required_terms=["stref", "dzienn", "nocn", "96"],
            expects_caution_on_missing_dims=False,
            allowed_numeric_tokens=["96", "3", "2", "3.5"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="tryb_b_modern_glazed_interior",
            title="9. Nowoczesne wnętrze z dużymi przeszkleniami",
            mode="idea_to_project",
            building_type="Wnętrze dzienne",
            area_sqm=42.0,
            modules_count=1,
            style_preset="Birch & Microcement",
            preserve_geometry=True,
            prompt_brief=(
                "Nowoczesne wnętrze dzienne 42 m² otwarte na las trzema wysokimi przeszkleniami od podłogi do sufitu w czarnych ramach. "
                "Sufit ze sklejki brzozowej, posadzka z mikrocementu i wyspa kuchenna w osi okna."
            ),
            geometry_notes="Wysokość pomieszczenia w świetle 2.95 m.",
            sketch_image_url=None,
            required_terms=["przeszklen", "mikrocement", "sklejk", "42"],
            expects_caution_on_missing_dims=False,
            allowed_numeric_tokens=["42", "1", "2.95"],
        ),
        ArchitecturalBenchmarkCase(
            case_id="tryb_b_incomplete_requirements",
            title="10. Koncepcja z niepełnymi wymaganiami użytkownika",
            mode="idea_to_project",
            building_type="Dom modułowy",
            area_sqm=None,
            modules_count=2,
            style_preset="Shou Sugi Ban Minimal",
            preserve_geometry=True,
            prompt_brief="Chcę nieduży czarny dom modułowy w lesie z tarasem, bez określonego metrażu, stron świata ani liczby sypialni.",
            geometry_notes="",
            sketch_image_url=None,
            required_terms=["niemożliwe do ustalenia", "taras"],
            expects_caution_on_missing_dims=True,
            expects_ambiguity_handling=True,
            allowed_numeric_tokens=["2"],
        ),
    ]

    if mode:
        return [c for c in cases if c.mode == mode]
    return cases


def _extract_unallowed_dimension_mentions(text: str, allowed_tokens: Sequence[str]) -> List[str]:
    """Detects specific dimensional claims (e.g. '12.4 m', '24 m²', '340 cm') not present in input."""
    pattern = re.compile(r"\b(\d+(?:[.,]\d+)?)\s*(?:m²|m2|mkw|cm|mm|m)\b", flags=re.IGNORECASE)
    allowed_norm = {tok.replace(",", ".") for tok in allowed_tokens}
    suspicious: List[str] = []
    for match in pattern.finditer(text):
        num = match.group(1).replace(",", ".")
        if num not in allowed_norm:
            suspicious.append(match.group(0))
    return suspicious


def evaluate_analysis_quality(
    case: ArchitecturalBenchmarkCase,
    analysis: AnalysisContentFields,
    *,
    provider: str = "unknown",
    model: str = "unknown",
    response_time_ms: Optional[int] = None,
) -> QualityEvaluationReport:
    defects: List[str] = []

    # 1. Structure completeness (0-100)
    completeness = 0
    if analysis.summary.strip():
        completeness += 15
    else:
        defects.append("Brak podsumowania (summary).")

    if analysis.spatial_layout.strip():
        completeness += 10
    else:
        defects.append("Brak opisu układu przestrzennego (spatial_layout).")

    if analysis.geometry is not None and analysis.geometry.building_footprint.strip():
        completeness += 15
    else:
        defects.append("Brak ustrukturyzowanej sekcji geometrii (geometry).")

    if len(analysis.rooms) >= 1:
        completeness += 10
    else:
        defects.append("Brak rozpoznanych lub zaproponowanych pomieszczeń (rooms).")

    if len(analysis.openings) >= 1:
        completeness += 10
    else:
        defects.append("Brak informacji o stolarce i otworach (openings).")

    if analysis.materials_proposal.strip() and analysis.lighting_proposal.strip():
        completeness += 10
    else:
        defects.append("Niekompletna propozycja materiałów lub oświetlenia.")

    if (
        analysis.geometry_protection is not None
        and analysis.geometry_protection.must_preserve
        and analysis.geometry_protection.forbidden_changes
    ):
        completeness += 15
    else:
        defects.append("Brak pełnego podziału zasad ochrony geometrii (must_preserve / forbidden_changes).")

    if analysis.visualization_prompt.strip():
        completeness += 10
    else:
        defects.append("Brak promptu do przyszłej wizualizacji (visualization_prompt).")

    if analysis.observed_facts or analysis.model_interpretations or analysis.user_requirements or analysis.ai_suggestions:
        completeness += 5
    else:
        defects.append("Brak rozdzielenia faktów odczytanych, interpretacji i sugestii AI.")

    # 2. Interpretation accuracy & canonical confidence labels (0-100)
    interpretation = 100
    all_confidences: List[str] = []
    if analysis.geometry:
        all_confidences.append(analysis.geometry.confidence)
    all_confidences.extend(r.confidence for r in analysis.rooms)
    all_confidences.extend(o.confidence for o in analysis.openings)
    all_confidences.extend(u.confidence for u in analysis.uncertainties)

    if not all_confidences:
        interpretation -= 40
        defects.append("Brak przypisanych poziomów pewności przy elementach analizy.")
    elif any(c not in CANONICAL_CONFIDENCE_SET for c in all_confidences):
        interpretation -= 25
        defects.append("Wykryto niestandardowy poziom pewności spoza kanonicznych czterech poziomów.")

    if not (analysis.observed_facts or analysis.user_requirements):
        interpretation -= 10
        defects.append("Brak wyodrębnionych informacji odczytanych wprost (observed_facts / user_requirements).")

    if case.mode == "idea_to_project":
        if not analysis.user_requirements or not analysis.ai_suggestions:
            interpretation -= 30
            defects.append("Tryb B musi wyraźnie oddzielać user_requirements od ai_suggestions.")
        if "nie stanowi" not in analysis.disclaimer.lower() and "nie jest" not in analysis.disclaimer.lower():
            interpretation -= 20
            defects.append("Brak zastrzeżenia, że koncepcja nie jest zatwierdzonym projektem budowlanym.")

    # Etap 3.5: Check unjustified cardinal directions unless explicitly provided in input
    user_context = f"{case.prompt_brief}\n{case.geometry_notes}"
    effective_allows_cardinal = case.allows_cardinal_directions or analysis_service.input_justifies_cardinal_directions(
        user_context, analysis.observed_facts
    )
    if not effective_allows_cardinal:
        detected_dirs = list(analysis.unjustified_directions_detected)
        if not detected_dirs:
            detected_dirs = analysis_service.detect_unjustified_cardinal_directions(
                summary=analysis.summary,
                spatial_layout=analysis.spatial_layout,
                rooms=analysis.rooms,
                openings=analysis.openings,
                observed_facts=analysis.observed_facts,
                visualization_prompt=analysis.visualization_prompt,
                user_context_text=user_context,
            )
        if detected_dirs:
            interpretation -= 25
            defects.append(
                "Przypisano nieuzasadnione kierunki geograficzne (północ/południe/wschód/zachód) "
                f"bez róży wiatrów na materiale: {', '.join(detected_dirs[:4])}."
            )

    # Etap 3.5: Check hinged doors missing swing arc must not claim high confidence
    for op in analysis.openings:
        if op.has_swing_arc is False and op.confidence == "wysoka pewność":
            interpretation -= 15
            defects.append(
                f"Otwór {op.opening_id or op.category} ma brak łuku otwierania (has_swing_arc=false), "
                "a mimo to deklaruje wysoką pewność."
            )
    for unc in analysis.uncertainties:
        if unc.confidence == "wysoka pewność" and any(
            kw in f"{unc.element} {unc.reason}".lower() for kw in ("łuk", "kierun", "otwier", "orientacyjn")
        ):
            interpretation -= 15
            defects.append(
                f"Niepewność '{unc.element}' ma sprzecznie przypisaną wysoką pewność."
            )

    # 3. Caution on illegible / missing dimensions & anti-hallucination (0-100)
    caution = 100
    combined_corpus = "\n".join(
        [
            analysis.summary,
            analysis.spatial_layout,
            analysis.geometry.proportions_and_scale if analysis.geometry else "",
            " ".join(f"{r.name} {r.approximate_area}" for r in analysis.rooms),
        ]
    )

    if case.expects_caution_on_missing_dims:
        unallowed_dims = _extract_unallowed_dimension_mentions(
            combined_corpus,
            case.allowed_numeric_tokens,
        )
        if unallowed_dims:
            caution -= 50
            defects.append(
                f"Wymyślono konkretne wymiary nieobecne na nieczytelnym materiale: {', '.join(unallowed_dims)}."
            )
        has_honest_uncertainty = bool(analysis.uncertainties) or bool(analysis.indeterminable_elements) or any(
            c in {"niska pewność", "niemożliwe do ustalenia na podstawie materiału"}
            for c in all_confidences
        )
        if not has_honest_uncertainty:
            caution -= 40
            defects.append("Nie oznaczono niepewności mimo nieczytelnych/niekompletnych danych.")
    elif case.expects_ambiguity_handling:
        has_ambiguity_flag = bool(analysis.uncertainties) or bool(analysis.indeterminable_elements) or any(
            c in {"niska pewność", "niemożliwe do ustalenia na podstawie materiału"}
            for c in all_confidences
        )
        if not has_ambiguity_flag:
            caution -= 35
            defects.append("Nie oznaczono niejednoznaczności otworów lub wymagań wymagających potwierdzenia.")
    else:
        if not analysis.uncertainties and not analysis.clarification_questions:
            caution -= 15

    # Etap 3.5: Dimensional conflict verification
    has_conflict_check = any(chk.status == "conflict" for chk in analysis.dimension_checks)
    if case.expected_dimension_conflict:
        if not analysis.dimension_conflicts and not has_conflict_check:
            caution -= 45
            defects.append("Nie wykryto ani nie zgłoszono sprzeczności wymiarowej obecnej na rysunku.")
    if analysis.dimension_conflicts or has_conflict_check:
        prop_text = (analysis.geometry.proportions_and_scale if analysis.geometry else "").lower()
        if "spójn" in prop_text and "nie można" not in prop_text and "sprzecznoś" not in prop_text:
            caution -= 35
            defects.append("Zadeklarowano spójność wymiarową mimo istnienia wykrytej sprzeczności wymiarów.")

    # Check false claims about structural compliance
    compliance_claims = re.search(
        r"(zgodn[ey] z warunkami technicznymi|spełnia normy konstrukcyjne|zatwierdzony projekt budowlany)",
        combined_corpus,
        flags=re.IGNORECASE,
    )
    if compliance_claims:
        caution -= 40
        defects.append("Nieuprawniona deklaracja zgodności konstrukcyjnej lub z przepisami budowlanymi.")

    # 4. Requirements compliance (0-100)
    requirements_score = 100
    full_text_lower = "\n".join(
        [
            analysis.summary,
            analysis.spatial_layout,
            analysis.materials_proposal,
            analysis.lighting_proposal,
            analysis.geometry_preservation_note,
            analysis.visualization_prompt,
            analysis.openings_completeness_check,
            analysis.orientation_source,
            " ".join(analysis.dimension_conflicts),
            " ".join(analysis.user_requirements),
            " ".join(analysis.ai_suggestions),
            " ".join(analysis.observed_facts),
            " ".join(analysis.model_interpretations),
            " ".join(analysis.indeterminable_elements),
            " ".join(u.reason + " " + u.element for u in analysis.uncertainties),
            " ".join(r.name + " " + r.zone for r in analysis.rooms),
            " ".join(
                f"{o.opening_id} {o.category} {o.location} {o.opening_direction} {o.notes}"
                for o in analysis.openings
            ),
        ]
    ).lower()

    missing_terms = [term for term in case.required_terms if term.lower() not in full_text_lower]
    if missing_terms:
        penalty = min(80, len(missing_terms) * 25)
        requirements_score -= penalty
        defects.append(f"Pominięto wymagane elementy z danych wejściowych: {', '.join(missing_terms)}.")

    # 5. Visualization prompt consistency & Geometry Lock (0-100)
    prompt_score = 100
    prompt_lower = analysis.visualization_prompt.lower()
    if not prompt_lower.strip():
        prompt_score = 0
    else:
        if re.search(r"(wygenerowano obraz|render gotowy|załączony render)", prompt_lower):
            prompt_score -= 40
            defects.append("Prompt wizualizacyjny fałszywie sugeruje wygenerowanie obrazu.")
        if case.mode == "sketch_to_render" and case.preserve_geometry:
            if re.search(
                r"\b(add second floor|add upper floor|move windows|rearrange walls|change layout|dodaj piętro|przesuń okna|zmień układ ścian)\b",
                prompt_lower,
            ):
                prompt_score -= 50
                defects.append("Prompt wizualizacyjny próbuje zmieniać geometrię wejściową szkicu.")
            if not analysis_service.has_complete_geometry_lock(analysis.visualization_prompt):
                prompt_score -= 35
                defects.append(
                    "Prompt w Trybie A nie zawiera pełnej sekcji GEOMETRY LOCK "
                    "(ochrona obrysu, ścian, okien, drzwi, pomieszczeń i wyraźny zakaz zmian)."
                )
        style_tokens = [tok.lower() for tok in re.split(r"[\s&]+", case.style_preset) if len(tok) >= 3]
        if style_tokens and not any(tok in prompt_lower for tok in style_tokens):
            prompt_score -= 25
            defects.append(f"Prompt wizualizacyjny nie odzwierciedla wybranego stylu ({case.style_preset}).")

    completeness = max(0, completeness)
    interpretation = max(0, interpretation)
    caution = max(0, caution)
    requirements_score = max(0, requirements_score)
    prompt_score = max(0, prompt_score)

    overall = round(
        0.25 * completeness
        + 0.20 * interpretation
        + 0.25 * caution
        + 0.15 * requirements_score
        + 0.15 * prompt_score
    )
    passed = overall >= 75 and caution >= 70 and completeness >= 75

    return QualityEvaluationReport(
        case_id=case.case_id,
        provider=provider,
        model=model,
        response_time_ms=response_time_ms,
        completeness_score=completeness,
        interpretation_score=interpretation,
        caution_score=caution,
        requirements_score=requirements_score,
        prompt_consistency_score=prompt_score,
        overall_score=overall,
        passed=passed,
        defects=defects,
    )


def compare_providers_across_suite(
    reports_by_provider: Dict[str, List[QualityEvaluationReport]],
) -> ProviderComparisonReport:
    """
    Compares multiple providers across shared benchmark cases.
    Never produces a ranking when fewer than 2 shared test cases are evaluated.
    """
    provider_keys = sorted(reports_by_provider.keys())
    if len(provider_keys) < 2:
        return ProviderComparisonReport(
            shared_case_ids=[],
            ranking_allowed=False,
            notice="Do porównania potrzebni są co najmniej dwaj dostawcy (Gemini i Groq).",
            providers=[],
            winner_by_dimension={},
        )

    case_sets = [
        {r.case_id: r for r in reports_by_provider[p]}
        for p in provider_keys
    ]
    shared_ids = sorted(set.intersection(*(set(cs.keys()) for cs in case_sets)))
    ranking_allowed = len(shared_ids) >= 2

    aggregates: List[ProviderAggregateMetrics] = []
    for idx, pkey in enumerate(provider_keys):
        matched = [case_sets[idx][cid] for cid in shared_ids]
        count = len(matched)
        if count == 0:
            aggregates.append(
                ProviderAggregateMetrics(
                    provider=pkey,
                    cases_evaluated=0,
                    passed_cases=0,
                    avg_completeness=0.0,
                    avg_interpretation=0.0,
                    avg_caution=0.0,
                    avg_requirements=0.0,
                    avg_prompt_quality=0.0,
                    avg_overall=0.0,
                    avg_response_time_ms=None,
                )
            )
            continue

        latencies = [r.response_time_ms for r in matched if r.response_time_ms is not None]
        aggregates.append(
            ProviderAggregateMetrics(
                provider=pkey,
                cases_evaluated=count,
                passed_cases=sum(1 for r in matched if r.passed),
                avg_completeness=round(sum(r.completeness_score for r in matched) / count, 1),
                avg_interpretation=round(sum(r.interpretation_score for r in matched) / count, 1),
                avg_caution=round(sum(r.caution_score for r in matched) / count, 1),
                avg_requirements=round(sum(r.requirements_score for r in matched) / count, 1),
                avg_prompt_quality=round(sum(r.prompt_consistency_score for r in matched) / count, 1),
                avg_overall=round(sum(r.overall_score for r in matched) / count, 1),
                avg_response_time_ms=round(sum(latencies) / len(latencies), 1) if latencies else None,
            )
        )

    winners: Dict[str, str] = {}
    if ranking_allowed:
        dimensions = {
            "kompletność": lambda a: a.avg_completeness,
            "poprawność_interpretacji": lambda a: a.avg_interpretation,
            "ostrożność_nieczytelne_dane": lambda a: a.avg_caution,
            "zgodność_z_wymaganiami": lambda a: a.avg_requirements,
            "jakość_promptu": lambda a: a.avg_prompt_quality,
            "ogólna_jakość": lambda a: a.avg_overall,
        }
        for dim_name, getter in dimensions.items():
            best_val = max(getter(a) for a in aggregates)
            tied = [a.provider for a in aggregates if getter(a) == best_val]
            winners[dim_name] = tied[0] if len(tied) == 1 else "remis: " + ", ".join(tied)

        timed = [a for a in aggregates if a.avg_response_time_ms is not None]
        if len(timed) == len(aggregates) and timed:
            fastest = min(a.avg_response_time_ms or 0.0 for a in timed)
            tied_fast = [a.provider for a in timed if a.avg_response_time_ms == fastest]
            winners["czas_odpowiedzi"] = (
                tied_fast[0] if len(tied_fast) == 1 else "remis: " + ", ".join(tied_fast)
            )
        notice = (
            f"Porównanie wykonano na {len(shared_ids)} wspólnych przypadkach testowych "
            "bez przekraczania polityki Zero Kosztów."
        )
    else:
        notice = (
            "Zbyt mała liczba wspólnych testów (< 2) — zgodnie z zasadą jakości nie tworzy się "
            "rankingu na podstawie pojedynczego testu."
        )

    return ProviderComparisonReport(
        shared_case_ids=shared_ids,
        ranking_allowed=ranking_allowed,
        notice=notice,
        providers=aggregates,
        winner_by_dimension=winners,
    )


async def run_safe_provider_comparison(
    db: Session,
    settings: Settings,
    cases: Sequence[ArchitecturalBenchmarkCase],
    *,
    router: Optional[ProviderRouter] = None,
    max_cases: int = 3,
    execution_mode: Literal["live", "mocked"] = "live",
) -> Dict[str, object]:
    """
    Runs at most `max_cases` shared cases per provider (gemini & groq) strictly under CostGuard.
    Stops immediately on 429 cooldown or missing key without retry loops.
    """
    selected_cases = list(cases)[: max(1, min(max_cases, 10))]
    reports: Dict[str, List[QualityEvaluationReport]] = {"gemini": [], "groq": []}
    errors: Dict[str, str] = {}

    for provider_key in ("gemini", "groq"):
        for case in selected_cases:
            try:
                preview: AnalysisPreviewResponse = await analysis_service.execute_free_ai_analysis(
                    db,
                    settings,
                    mode=case.mode,
                    title=case.title,
                    building_type=case.building_type,
                    area_sqm=case.area_sqm,
                    modules_count=case.modules_count,
                    style_preset=case.style_preset,
                    preserve_geometry=case.preserve_geometry,
                    prompt_brief=case.prompt_brief,
                    geometry_notes=case.geometry_notes,
                    sketch_image_url=case.sketch_image_url,
                    reference_ids=[],
                    preferred_provider=provider_key,  # type: ignore[arg-type]
                    router=router,
                )
                reports[provider_key].append(
                    evaluate_analysis_quality(
                        case,
                        preview,
                        provider=preview.provider,
                        model=preview.model,
                        response_time_ms=preview.response_time_ms,
                    )
                )
            except (ProviderQuotaExceededError, ProviderKeyMissingError, CostPolicyViolation) as exc:
                errors[provider_key] = str(exc)
                break
            except Exception as exc:
                errors[provider_key] = str(exc)
                break

    comparison = compare_providers_across_suite(reports)
    return {
        "execution_mode": execution_mode,
        "comparison": comparison,
        "reports": reports,
        "errors": errors,
    }
