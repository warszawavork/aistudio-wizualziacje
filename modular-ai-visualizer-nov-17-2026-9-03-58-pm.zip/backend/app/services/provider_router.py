from dataclasses import dataclass
from typing import List, Optional

from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.cost_guard import CostCheckDecision, CostGuard
from app.providers import (
    FreeImageGeneratorProvider,
    GeminiProvider,
    GroqProvider,
    ImageGenerationProvider,
    ImageGeneratorProvider,
    ImageProviderStatusInfo,
    VisionAnalyzerProvider,
)


@dataclass(frozen=True)
class SelectedVisionProvider:
    provider: Optional[VisionAnalyzerProvider]
    decision: CostCheckDecision
    checked_providers: List[str]


class ProviderRouter:
    """
    Selects the best available verified free-tier provider for a given task.
    Never switches to paid providers and waits for quota reset on 429 cooldowns.
    """

    def __init__(self, settings: Settings, cost_guard: CostGuard) -> None:
        self._settings = settings
        self._cost_guard = cost_guard

    def select_vision_provider(
        self,
        db: Session,
        preferred_key: Optional[str] = None,
        strict_preferred: bool = False,
    ) -> SelectedVisionProvider:
        candidates: List[VisionAnalyzerProvider] = [
            GeminiProvider(self._settings, self._cost_guard, db=db),
            GroqProvider(self._settings, self._cost_guard, db=db),
        ]

        if preferred_key:
            if strict_preferred:
                candidates = [p for p in candidates if p.get_descriptor().key == preferred_key]
            else:
                candidates.sort(key=lambda p: 0 if p.get_descriptor().key == preferred_key else 1)

        checked: List[str] = []
        decisions: List[CostCheckDecision] = []

        for candidate in candidates:
            descriptor = candidate.get_descriptor()
            checked.append(descriptor.key)
            usage = self._cost_guard.get_or_create_usage(db, descriptor.key)
            decision = self._cost_guard.evaluate_provider(
                descriptor,
                api_key_configured=candidate.is_key_configured(),
                usage=usage,
            )
            decisions.append(decision)
            if decision.allowed:
                return SelectedVisionProvider(
                    provider=candidate,
                    decision=decision,
                    checked_providers=checked,
                )

        priority_order = {
            "cooldown": 0,
            "local_limit_reached": 1,
            "disabled_by_cost_policy": 2,
            "unavailable_free": 3,
            "missing_api_key": 4,
        }
        best_decision = (
            min(decisions, key=lambda d: priority_order.get(d.availability_status, 99))
            if decisions
            else CostCheckDecision(
                allowed=False,
                availability_status="unavailable_free",
                blocked_by_cost_policy=False,
                reason="Brak dostępnych darmowych dostawców analizy obrazów. Oczekiwanie na konfigurację lub odnowienie limitu.",
            )
        )
        return SelectedVisionProvider(
            provider=None,
            decision=best_decision,
            checked_providers=checked,
        )

    def select_image_generator(self) -> ImageGeneratorProvider:
        # Strictly zero-cost: returns honest unavailable_free boundary until a verified free image generator exists.
        return FreeImageGeneratorProvider()


@dataclass(frozen=True)
class SelectedImageProvider:
    provider: Optional[ImageGenerationProvider]
    status: Optional[ImageProviderStatusInfo]
    decision: CostCheckDecision
    checked_providers: List[str]
    all_statuses: List[ImageProviderStatusInfo]


class ImageProviderRouter:
    """
    Multi-engine router for architectural image generation.
    Selects ONLY verified, truly free, and currently healthy engines.
    Strictly blocks paid, micro-credit, and unverified providers via CostGuard.
    """

    def __init__(
        self,
        settings: Settings,
        cost_guard: CostGuard,
        candidates: Optional[List[ImageGenerationProvider]] = None,
    ) -> None:
        self._settings = settings
        self._cost_guard = cost_guard
        self._custom_candidates = candidates

    def _get_candidates(self, db: Session) -> List[ImageGenerationProvider]:
        if self._custom_candidates is not None:
            return list(self._custom_candidates)
        from app.providers.image_providers import build_default_image_providers

        return build_default_image_providers(self._settings, self._cost_guard, db=db)

    async def list_providers_status(self, db: Session) -> List[ImageProviderStatusInfo]:
        candidates = self._get_candidates(db)
        statuses: List[ImageProviderStatusInfo] = []
        for candidate in candidates:
            statuses.append(await candidate.get_status(db))
        return statuses

    async def select_image_provider(
        self,
        db: Session,
        preferred_key: Optional[str] = None,
        strict_preferred: bool = False,
        prefer_image_to_image: bool = False,
    ) -> SelectedImageProvider:
        candidates = self._get_candidates(db)
        all_statuses: List[ImageProviderStatusInfo] = []
        by_key = {}
        for candidate in candidates:
            st = await candidate.get_status(db)
            all_statuses.append(st)
            by_key[st.key] = (candidate, st)

        ordered_candidates = list(candidates)
        if preferred_key and preferred_key != "auto":
            if strict_preferred:
                ordered_candidates = [
                    c for c in ordered_candidates if c.get_descriptor().key == preferred_key
                ]
            else:
                ordered_candidates.sort(
                    key=lambda c: 0 if c.get_descriptor().key == preferred_key else 1
                )
        elif prefer_image_to_image:
            ordered_candidates.sort(
                key=lambda c: 0 if c.get_capabilities().supports_image_to_image else 1
            )

        checked: List[str] = []
        decisions: List[CostCheckDecision] = []

        for candidate in ordered_candidates:
            descriptor = candidate.get_descriptor()
            checked.append(descriptor.key)
            _, st = by_key[descriptor.key]
            decision = CostCheckDecision(
                allowed=(
                    st.available
                    and st.is_truly_free
                    and st.is_verified
                    and not st.is_paid_endpoint
                    and not st.blocked_by_cost_policy
                ),
                availability_status=st.availability_status,
                blocked_by_cost_policy=st.blocked_by_cost_policy,
                reason=st.unavailability_reason or f"Silnik {st.name} gotowy (0 zł).",
                cooldown_until=st.cooldown_until,
            )
            decisions.append(decision)
            if decision.allowed:
                return SelectedImageProvider(
                    provider=candidate,
                    status=st,
                    decision=decision,
                    checked_providers=checked,
                    all_statuses=all_statuses,
                )

        if strict_preferred and preferred_key and preferred_key in by_key:
            _, st = by_key[preferred_key]
            return SelectedImageProvider(
                provider=None,
                status=st,
                decision=CostCheckDecision(
                    allowed=False,
                    availability_status=st.availability_status,
                    blocked_by_cost_policy=st.blocked_by_cost_policy,
                    reason=st.unavailability_reason,
                    cooldown_until=st.cooldown_until,
                ),
                checked_providers=checked,
                all_statuses=all_statuses,
            )

        priority_order = {
            "cooldown": 0,
            "local_limit_reached": 1,
            "unavailable_free": 2,
            "disabled_by_cost_policy": 3,
            "unverified_blocked": 4,
            "missing_api_key": 5,
        }
        best_decision = (
            min(decisions, key=lambda d: priority_order.get(d.availability_status, 99))
            if decisions
            else CostCheckDecision(
                allowed=False,
                availability_status="unavailable_free",
                blocked_by_cost_policy=False,
                reason=(
                    "Brak aktywnego, zweryfikowanego darmowego silnika generowania obrazów "
                    "(lokalne serwery ComfyUI / SD WebUI są wyłączone, a chmurowe API obrazów "
                    "wymagają płatności lub nie posiadają weryfikacji 0 zł)."
                ),
            )
        )
        return SelectedImageProvider(
            provider=None,
            status=None,
            decision=best_decision,
            checked_providers=checked,
            all_statuses=all_statuses,
        )

