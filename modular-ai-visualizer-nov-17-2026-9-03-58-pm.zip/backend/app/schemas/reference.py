from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


ReferenceCategory = Literal[
    "sketch_pair",
    "sketch_plan",
    "visualization",
    "realization",
    "material",
    "color",
    "lighting",
    "style",
    "interior",
]

CATEGORY_LABELS_PL: dict[str, str] = {
    "sketch_pair": "Szkice i rzuty",
    "sketch_plan": "Szkice i rzuty",
    "visualization": "Wizualizacje",
    "realization": "Zdjęcia ukończonych realizacji",
    "material": "Materiały i faktury",
    "color": "Kolory",
    "lighting": "Oświetlenie",
    "style": "Style architektoniczne",
    "interior": "Aranżacje wnętrz",
}

CATEGORY_AI_ROLES_PL: dict[str, str] = {
    "sketch_pair": "szkic i rzut odniesienia",
    "sketch_plan": "szkic i rzut odniesienia",
    "visualization": "wizualizacja referencyjna",
    "realization": "przykład ukończonej realizacji",
    "material": "materiał i faktura wykończeniowa",
    "color": "paleta kolorystyczna",
    "lighting": "scenariusz oświetlenia",
    "style": "styl architektoniczny",
    "interior": "aranżacja wnętrza i wyposażenia",
}


def get_reference_category_label(category: str) -> str:
    return CATEGORY_LABELS_PL.get(category, category)


def get_reference_role_for_ai(category: str) -> str:
    return CATEGORY_AI_ROLES_PL.get(category, "materiał referencyjny")


def parse_tags_list(style_tags: str) -> List[str]:
    if not style_tags:
        return []
    seen: set[str] = set()
    tags: List[str] = []
    for raw in style_tags.split(","):
        cleaned = raw.strip().lstrip("#").strip()
        if cleaned and cleaned.lower() not in seen:
            seen.add(cleaned.lower())
            tags.append(cleaned)
    return tags


def _validate_ref_title(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    cleaned = value.strip()
    if len(cleaned) < 2:
        raise ValueError("Nazwa referencji musi zawierać co najmniej 2 niepuste znaki.")
    return cleaned


def _validate_ref_url(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    cleaned = value.strip()
    if not cleaned:
        return None
    if ".." in cleaned or "\x00" in cleaned or "\\" in cleaned:
        raise ValueError("Niedozwolona ścieżka pliku referencyjnego.")
    return cleaned


class ReferenceCreate(BaseModel):
    title: str = Field(..., min_length=2, max_length=160)
    category: ReferenceCategory
    description: str = Field(default="", max_length=2000)
    materials_note: str = Field(default="", max_length=255)
    lighting_note: str = Field(default="", max_length=255)
    style_tags: str = Field(default="", max_length=255)
    tags: Optional[List[str]] = Field(default=None)
    image_url: Optional[str] = Field(default=None, max_length=500)
    paired_sketch_url: Optional[str] = Field(default=None, max_length=500)
    project_id: Optional[int] = Field(default=None)
    linked_project_ids: Optional[List[int]] = Field(default=None)

    @field_validator("title")
    @classmethod
    def check_title(cls, v: str) -> str:
        res = _validate_ref_title(v)
        assert res is not None
        return res

    @field_validator("image_url", "paired_sketch_url")
    @classmethod
    def check_urls(cls, v: Optional[str]) -> Optional[str]:
        return _validate_ref_url(v)


class ReferenceUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=2, max_length=160)
    category: Optional[ReferenceCategory] = None
    description: Optional[str] = Field(default=None, max_length=2000)
    materials_note: Optional[str] = Field(default=None, max_length=255)
    lighting_note: Optional[str] = Field(default=None, max_length=255)
    style_tags: Optional[str] = Field(default=None, max_length=255)
    tags: Optional[List[str]] = Field(default=None)
    image_url: Optional[str] = Field(default=None, max_length=500)
    paired_sketch_url: Optional[str] = Field(default=None, max_length=500)
    project_id: Optional[int] = Field(default=None)
    linked_project_ids: Optional[List[int]] = Field(default=None)

    @field_validator("title")
    @classmethod
    def check_title(cls, v: Optional[str]) -> Optional[str]:
        return _validate_ref_title(v)

    @field_validator("image_url", "paired_sketch_url")
    @classmethod
    def check_urls(cls, v: Optional[str]) -> Optional[str]:
        return _validate_ref_url(v)


class ReferenceRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    category: str
    category_label: str = ""
    role: str = ""
    description: str
    materials_note: str
    lighting_note: str
    style_tags: str
    tags: List[str] = Field(default_factory=list)
    image_url: Optional[str]
    paired_sketch_url: Optional[str]
    original_file_path: Optional[str] = None
    project_id: Optional[int] = None
    linked_project_ids: List[int] = Field(default_factory=list)
    linked_project_titles: List[str] = Field(default_factory=list)
    is_in_use: bool = False
    created_at: datetime
    updated_at: Optional[datetime] = None


class ReferenceContextItem(BaseModel):
    reference_id: int
    title: str
    category: str
    category_label: str
    role: str
    description: str
    tags: List[str] = Field(default_factory=list)
    materials_note: str = ""
    lighting_note: str = ""
    image_path: str = ""
    paired_sketch_path: Optional[str] = None
    project_relation: str


class ReferenceContextPreview(BaseModel):
    project_id: Optional[int] = None
    project_title: Optional[str] = None
    total_references: int
    context_note: str = (
        "Biblioteka referencji stanowi trwały kontekst projektowy przekazywany do analizy AI "
        "wyłącznie dla wybranych materiałów i po weryfikacji CostGuard (nie jest to trening modelu)."
    )
    formatted_prompt_context: str
    items: List[ReferenceContextItem] = Field(default_factory=list)

