from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.schemas.analysis import ProjectAnalysisDraft, ProjectAnalysisRead

ProjectMode = Literal["sketch_to_render", "idea_to_project"]
ProjectStatus = Literal["draft", "awaiting_ai_pipeline", "archived"]
ProjectSortOption = Literal[
    "date_desc",
    "date_asc",
    "name_asc",
    "name_desc",
    "area_desc",
    "area_asc",
]


def _validate_clean_title(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    cleaned = value.strip()
    if len(cleaned) < 2:
        raise ValueError("Nazwa projektu musi zawierać co najmniej 2 niepuste znaki.")
    return cleaned


def _validate_safe_asset_url(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    cleaned = value.strip()
    if not cleaned:
        return None
    if ".." in cleaned or "\x00" in cleaned or "\\" in cleaned:
        raise ValueError("Niedozwolona ścieżka pliku obrazu.")
    return cleaned


class ProjectBase(BaseModel):
    title: str = Field(..., min_length=2, max_length=160)
    mode: ProjectMode
    building_type: str = Field(default="Dom modułowy", min_length=2, max_length=80)
    area_sqm: Optional[float] = Field(default=None, gt=0, le=5000)
    modules_count: int = Field(default=1, ge=1, le=24)
    style_preset: str = Field(default="Nordic Graphite", max_length=80)
    preserve_geometry: bool = True
    prompt_brief: str = Field(default="", max_length=4000)
    geometry_notes: str = Field(default="", max_length=2000)
    sketch_image_url: Optional[str] = Field(default=None, max_length=500)
    preview_image_url: Optional[str] = Field(default=None, max_length=500)
    reference_ids: List[int] = Field(default_factory=list)

    @field_validator("title")
    @classmethod
    def check_title(cls, v: str) -> str:
        res = _validate_clean_title(v)
        assert res is not None
        return res

    @field_validator("sketch_image_url", "preview_image_url")
    @classmethod
    def check_urls(cls, v: Optional[str]) -> Optional[str]:
        return _validate_safe_asset_url(v)


class ProjectCreate(ProjectBase):
    status: ProjectStatus = "awaiting_ai_pipeline"
    initial_analysis: Optional[ProjectAnalysisDraft] = None


class ProjectUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=2, max_length=160)
    status: Optional[ProjectStatus] = None
    building_type: Optional[str] = Field(default=None, min_length=2, max_length=80)
    area_sqm: Optional[float] = Field(default=None, gt=0, le=5000)
    modules_count: Optional[int] = Field(default=None, ge=1, le=24)
    style_preset: Optional[str] = Field(default=None, max_length=80)
    preserve_geometry: Optional[bool] = None
    prompt_brief: Optional[str] = Field(default=None, max_length=4000)
    geometry_notes: Optional[str] = Field(default=None, max_length=2000)
    sketch_image_url: Optional[str] = Field(default=None, max_length=500)
    preview_image_url: Optional[str] = Field(default=None, max_length=500)
    reference_ids: Optional[List[int]] = None

    @field_validator("title")
    @classmethod
    def check_title(cls, v: Optional[str]) -> Optional[str]:
        return _validate_clean_title(v)

    @field_validator("sketch_image_url", "preview_image_url")
    @classmethod
    def check_urls(cls, v: Optional[str]) -> Optional[str]:
        return _validate_safe_asset_url(v)


class ProjectRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    mode: str
    status: str
    building_type: str
    area_sqm: Optional[float]
    modules_count: int
    style_preset: str
    preserve_geometry: bool
    prompt_brief: str
    geometry_notes: str
    sketch_image_url: Optional[str]
    preview_image_url: Optional[str]
    reference_ids: List[int]
    latest_analysis: Optional[ProjectAnalysisRead] = None
    analyses_count: int = 0
    analysis_history: List[ProjectAnalysisRead] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime



class DashboardSummary(BaseModel):
    total_projects: int
    sketch_mode_count: int
    idea_mode_count: int
    total_references: int
    recent_projects: List[ProjectRead]
