from datetime import datetime
from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str
    app_name: str
    stage: str
    database_connected: bool
    storage_ready: bool
    timestamp: datetime
