from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, Field

from app.schemas.project import ProjectRead

RenderLifecycleState = Literal[
    "not_requested",
    "queued",
    "generating",
    "completed",
    "unavailable_free",
    "disabled_by_cost_policy",
    "unverified_blocked",
    "cooldown",
    "error",
]

AnalysisLifecycleState = Literal["not_started", "completed"]


class ImageProviderStatusRead(BaseModel):
    key: str
    name: str
    role: str
    model: str
    plan_type: str
    available: bool
    availability_status: str
    is_truly_free: bool
    is_paid_endpoint: bool
    is_verified: bool
    verification_status: str
    blocked_by_cost_policy: bool
    api_key_configured: bool
    known_limits: str
    cooldown_until: Optional[datetime] = None
    supported_resolutions: List[str] = Field(default_factory=list)
    supports_image_to_image: bool = False
    supports_geometry_preservation: bool = False
    hardware_requirements: str = ""
    unavailability_reason: str = ""
    local_calls_today: int = 0
    local_calls_total: int = 0
    last_error: str = ""


class ImageProvidersOverviewRead(BaseModel):
    any_free_engine_available: bool
    active_free_engine_key: Optional[str] = None
    active_free_engine_name: Optional[str] = None
    summary_message: str
    providers: List[ImageProviderStatusRead] = Field(default_factory=list)


class GenerateImageRequest(BaseModel):
    preferred_provider: str = Field(default="auto", max_length=60)
    aspect_ratio: str = Field(default="16:9", max_length=20)
    custom_prompt_override: Optional[str] = Field(default=None, max_length=4000)


class GenerateDraftImageRequest(BaseModel):
    mode: Literal["sketch_to_render", "idea_to_project"]
    title: str = Field(default="Wizualizacja robocza", max_length=160)
    building_type: str = Field(default="Dom modułowy", max_length=80)
    style_preset: str = Field(default="Nordic Graphite", max_length=80)
    preserve_geometry: bool = True
    prompt: str = Field(default="", max_length=4000)
    sketch_image_url: Optional[str] = Field(default=None, max_length=500)
    preferred_provider: str = Field(default="auto", max_length=60)
    aspect_ratio: str = Field(default="16:9", max_length=20)


class ImageGenerationResponse(BaseModel):
    project_id: Optional[int] = None
    mode: str
    analysis_status: AnalysisLifecycleState
    render_status: RenderLifecycleState
    generated_image_url: Optional[str] = None
    provider_key: Optional[str] = None
    provider_name: Optional[str] = None
    model: Optional[str] = None
    used_image_to_image: bool = False
    geometry_preserved: bool = False
    is_conceptual: bool = False
    conceptual_label: Optional[str] = None
    prompt_used: str = ""
    response_time_ms: Optional[int] = None
    message: str
    project: Optional[ProjectRead] = None
