import json
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

AnalysisMode = Literal["sketch_to_render", "idea_to_project"]
ProviderPreference = Literal["auto", "gemini", "groq"]

ConfidenceLevel = Literal[
    "wysoka pewność",
    "średnia pewność",
    "niska pewność",
    "niemożliwe do ustalenia na podstawie materiału",
]

DimensionSourceType = Literal[
    "direct",
    "calculated",
    "estimated",
    "indeterminable",
]

DEFAULT_ARCHITECTURAL_DISCLAIMER = (
    "Analiza i koncepcja mają charakter pomocniczy i koncepcyjny — "
    "nie stanowią zatwierdzonego projektu budowlanego, dokumentacji wykonawczej ani weryfikacji konstrukcyjnej."
)


class GeometryAnalysis(BaseModel):
    building_footprint: str = Field(default="", max_length=1500)
    floors_count: str = Field(default="niemożliwe do ustalenia na podstawie materiału", max_length=300)
    structural_vs_partition_walls: str = Field(default="", max_length=1500)
    circulation: str = Field(default="", max_length=1500)
    proportions_and_scale: str = Field(default="", max_length=1500)
    confidence: ConfidenceLevel = "średnia pewność"


class RoomAnalysisItem(BaseModel):
    name: str = Field(..., max_length=200)
    zone: str = Field(default="nieustalone", max_length=120)
    approximate_area: str = Field(default="brak wymiarów na materiale", max_length=160)
    spatial_relations: str = Field(default="", max_length=600)
    confidence: ConfidenceLevel = "średnia pewność"


class OpeningAnalysisItem(BaseModel):
    opening_id: str = Field(default="", max_length=64)
    category: str = Field(..., max_length=120)
    location: str = Field(default="", max_length=400)
    opening_direction: str = Field(
        default="niemożliwe do ustalenia na podstawie materiału", max_length=200
    )
    has_swing_arc: Optional[bool] = Field(default=None)
    opening_completeness_note: str = Field(default="", max_length=300)
    notes: str = Field(default="", max_length=500)
    confidence: ConfidenceLevel = "średnia pewność"


class DimensionObservationItem(BaseModel):
    label: str = Field(..., max_length=200)
    value: str = Field(default="niemożliwe do ustalenia na podstawie materiału", max_length=160)
    source_type: DimensionSourceType = "indeterminable"
    unit: str = Field(default="", max_length=24)
    location: str = Field(default="", max_length=300)
    confidence: ConfidenceLevel = "średnia pewność"


class DimensionCheckItem(BaseModel):
    description: str = Field(..., max_length=400)
    overall_dimension: str = Field(default="", max_length=120)
    segment_sum: str = Field(default="", max_length=120)
    status: Literal["consistent", "conflict", "indeterminable"] = "indeterminable"
    difference: str = Field(default="", max_length=120)


class GeometryProtectionRules(BaseModel):
    must_preserve: List[str] = Field(default_factory=list)
    can_change: List[str] = Field(default_factory=list)
    forbidden_changes: List[str] = Field(default_factory=list)


class UncertaintyItem(BaseModel):
    element: str = Field(..., max_length=240)
    confidence: ConfidenceLevel = "niska pewność"
    reason: str = Field(default="", max_length=600)


class StructuredAnalysisSections(BaseModel):
    rooms: List[RoomAnalysisItem] = Field(default_factory=list)
    geometry: Optional[GeometryAnalysis] = None
    openings: List[OpeningAnalysisItem] = Field(default_factory=list)
    openings_completeness_check: str = Field(default="", max_length=1000)
    orientation_source: str = Field(default="", max_length=300)
    unjustified_directions_detected: List[str] = Field(default_factory=list)
    dimension_observations: List[DimensionObservationItem] = Field(default_factory=list)
    dimension_checks: List[DimensionCheckItem] = Field(default_factory=list)
    dimension_conflicts: List[str] = Field(default_factory=list)
    dimension_confidence: ConfidenceLevel = "niemożliwe do ustalenia na podstawie materiału"
    geometry_protection: Optional[GeometryProtectionRules] = None
    uncertainties: List[UncertaintyItem] = Field(default_factory=list)
    user_requirements: List[str] = Field(default_factory=list)
    ai_suggestions: List[str] = Field(default_factory=list)
    observed_facts: List[str] = Field(default_factory=list)
    model_interpretations: List[str] = Field(default_factory=list)
    indeterminable_elements: List[str] = Field(default_factory=list)
    clarification_questions: List[str] = Field(default_factory=list)
    disclaimer: str = Field(default=DEFAULT_ARCHITECTURAL_DISCLAIMER, max_length=1000)


class AnalysisContentFields(StructuredAnalysisSections):
    summary: str = Field(default="", max_length=6000)
    spatial_layout: str = Field(default="", max_length=6000)
    materials_proposal: str = Field(default="", max_length=4000)
    lighting_proposal: str = Field(default="", max_length=4000)
    geometry_preservation_note: str = Field(default="", max_length=4000)
    visualization_prompt: str = Field(default="", max_length=6000)
    analysis_source: Literal["live", "mock", "legacy", "fallback"] = "live"


def extract_structured_payload_dict(fields: StructuredAnalysisSections) -> Dict[str, Any]:
    return {
        "rooms": [item.model_dump() for item in fields.rooms],
        "geometry": fields.geometry.model_dump() if fields.geometry else None,
        "openings": [item.model_dump() for item in fields.openings],
        "openings_completeness_check": fields.openings_completeness_check,
        "orientation_source": fields.orientation_source,
        "unjustified_directions_detected": fields.unjustified_directions_detected,
        "dimension_observations": [item.model_dump() for item in fields.dimension_observations],
        "dimension_checks": [item.model_dump() for item in fields.dimension_checks],
        "dimension_conflicts": fields.dimension_conflicts,
        "dimension_confidence": fields.dimension_confidence,
        "geometry_protection": (
            fields.geometry_protection.model_dump() if fields.geometry_protection else None
        ),
        "uncertainties": [item.model_dump() for item in fields.uncertainties],
        "user_requirements": fields.user_requirements,
        "ai_suggestions": fields.ai_suggestions,
        "observed_facts": fields.observed_facts,
        "model_interpretations": fields.model_interpretations,
        "indeterminable_elements": fields.indeterminable_elements,
        "clarification_questions": fields.clarification_questions,
        "disclaimer": fields.disclaimer or DEFAULT_ARCHITECTURAL_DISCLAIMER,
        "analysis_source": getattr(fields, "analysis_source", "live"),
    }


class ProjectAnalysisDraft(AnalysisContentFields):
    mode: AnalysisMode
    provider: str = Field(..., min_length=2, max_length=40)
    model: str = Field(..., min_length=2, max_length=120)
    is_free_tier: bool = True
    response_time_ms: Optional[int] = Field(default=None, ge=0)
    schema_version: str = Field(default="3.5", max_length=24)
    raw_response_text: str = Field(default="", max_length=24000)


class ProjectAnalysisRead(AnalysisContentFields):
    model_config = ConfigDict(from_attributes=True)

    id: int
    project_id: int
    mode: str
    provider: str
    model: str
    is_free_tier: bool
    response_time_ms: Optional[int] = None
    schema_version: str = "3.5"
    is_legacy_format: bool = False
    analysis_source: Literal["live", "mock", "legacy", "fallback"] = "live"
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="before")
    @classmethod
    def _hydrate_structured_json(cls, data: Any) -> Any:
        if isinstance(data, dict):
            raw_json = data.get("structured_payload_json") or ""
            schema_ver = data.get("schema_version") or "3.5"
            payload_dict: Dict[str, Any] = dict(data)
        else:
            raw_json = getattr(data, "structured_payload_json", "") or ""
            schema_ver = getattr(data, "schema_version", "") or (
                "3.3" if raw_json else "3.2_legacy"
            )
            payload_dict = {
                "id": getattr(data, "id"),
                "project_id": getattr(data, "project_id"),
                "mode": getattr(data, "mode"),
                "provider": getattr(data, "provider"),
                "model": getattr(data, "model"),
                "is_free_tier": getattr(data, "is_free_tier"),
                "summary": getattr(data, "summary", "") or "",
                "spatial_layout": getattr(data, "spatial_layout", "") or "",
                "materials_proposal": getattr(data, "materials_proposal", "") or "",
                "lighting_proposal": getattr(data, "lighting_proposal", "") or "",
                "geometry_preservation_note": getattr(data, "geometry_preservation_note", "") or "",
                "visualization_prompt": getattr(data, "visualization_prompt", "") or "",
                "response_time_ms": getattr(data, "response_time_ms", None),
                "schema_version": schema_ver,
                "created_at": getattr(data, "created_at"),
                "updated_at": getattr(data, "updated_at"),
            }

        if raw_json:
            try:
                parsed = json.loads(raw_json)
                if isinstance(parsed, dict):
                    for key in (
                        "rooms",
                        "geometry",
                        "openings",
                        "openings_completeness_check",
                        "orientation_source",
                        "unjustified_directions_detected",
                        "dimension_observations",
                        "dimension_checks",
                        "dimension_conflicts",
                        "dimension_confidence",
                        "geometry_protection",
                        "uncertainties",
                        "user_requirements",
                        "ai_suggestions",
                        "observed_facts",
                        "model_interpretations",
                        "indeterminable_elements",
                        "clarification_questions",
                        "disclaimer",
                        "analysis_source",
                    ):
                        if key in parsed and parsed[key] is not None:
                            payload_dict[key] = parsed[key]
                    payload_dict["is_legacy_format"] = False
            except json.JSONDecodeError:
                payload_dict["is_legacy_format"] = True
                payload_dict["analysis_source"] = "legacy"
        else:
            if not schema_ver or schema_ver == "3.2_legacy":
                payload_dict["schema_version"] = "3.2_legacy"
                payload_dict["is_legacy_format"] = True
                payload_dict["analysis_source"] = "legacy"

        if not payload_dict.get("disclaimer"):
            payload_dict["disclaimer"] = DEFAULT_ARCHITECTURAL_DISCLAIMER

        return payload_dict


class ProjectAnalysisUpdate(BaseModel):
    summary: Optional[str] = Field(default=None, max_length=6000)
    spatial_layout: Optional[str] = Field(default=None, max_length=6000)
    materials_proposal: Optional[str] = Field(default=None, max_length=4000)
    lighting_proposal: Optional[str] = Field(default=None, max_length=4000)
    geometry_preservation_note: Optional[str] = Field(default=None, max_length=4000)
    visualization_prompt: Optional[str] = Field(default=None, max_length=6000)
    rooms: Optional[List[RoomAnalysisItem]] = None
    geometry: Optional[GeometryAnalysis] = None
    openings: Optional[List[OpeningAnalysisItem]] = None
    openings_completeness_check: Optional[str] = Field(default=None, max_length=1000)
    orientation_source: Optional[str] = Field(default=None, max_length=300)
    unjustified_directions_detected: Optional[List[str]] = None
    dimension_observations: Optional[List[DimensionObservationItem]] = None
    dimension_checks: Optional[List[DimensionCheckItem]] = None
    dimension_conflicts: Optional[List[str]] = None
    dimension_confidence: Optional[ConfidenceLevel] = None
    geometry_protection: Optional[GeometryProtectionRules] = None
    uncertainties: Optional[List[UncertaintyItem]] = None
    user_requirements: Optional[List[str]] = None
    ai_suggestions: Optional[List[str]] = None
    observed_facts: Optional[List[str]] = None
    model_interpretations: Optional[List[str]] = None
    indeterminable_elements: Optional[List[str]] = None
    clarification_questions: Optional[List[str]] = None
    disclaimer: Optional[str] = Field(default=None, max_length=1000)


class AnalyzeDraftRequest(BaseModel):
    mode: AnalysisMode
    title: str = Field(default="Projekt koncepcyjny", max_length=160)
    building_type: str = Field(default="Dom modułowy", max_length=80)
    area_sqm: Optional[float] = Field(default=None, gt=0, le=5000)
    modules_count: int = Field(default=1, ge=1, le=24)
    style_preset: str = Field(default="Nordic Graphite", max_length=80)
    preserve_geometry: bool = True
    prompt_brief: str = Field(default="", max_length=4000)
    geometry_notes: str = Field(default="", max_length=2000)
    sketch_image_url: Optional[str] = Field(default=None, max_length=500)
    reference_ids: List[int] = Field(default_factory=list)
    preferred_provider: ProviderPreference = "auto"


class AnalyzeProjectRequest(BaseModel):
    preferred_provider: ProviderPreference = "auto"


class AnalysisPreviewResponse(AnalysisContentFields):
    mode: AnalysisMode
    provider: str
    model: str
    is_free_tier: bool
    response_time_ms: Optional[int] = None
    schema_version: str = "3.5"
    raw_response_text: str = ""
    image_generation_available: bool = False
    image_generation_note: str
