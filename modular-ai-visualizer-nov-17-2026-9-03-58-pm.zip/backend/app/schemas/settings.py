from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from app.providers.base import ImageGeneratorStatus


class StudioSettingsUpdate(BaseModel):
    studio_name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    default_style: Optional[str] = Field(default=None, min_length=2, max_length=80)
    default_preserve_geometry: Optional[bool] = None
    preferred_aspect_ratio: Optional[str] = Field(default=None, max_length=20)
    preferred_vision_provider: Optional[str] = Field(default=None, max_length=40)
    preferred_image_provider: Optional[str] = Field(default=None, max_length=40)


class StudioSettingsRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    studio_name: str
    default_style: str
    default_preserve_geometry: bool
    preferred_aspect_ratio: str
    preferred_vision_provider: str
    preferred_image_provider: str
    updated_at: datetime


class CostPolicyOverview(BaseModel):
    free_only: bool
    allow_paid_apis: bool
    monthly_budget: float
    allow_hf_micro_free_credits: bool
    paid_services_blocked: bool


class ImageGeneratorStatusRead(BaseModel):
    status: ImageGeneratorStatus
    provider_name: str
    message: str
    preserves_project_artifacts: bool


class ProviderStatusItem(BaseModel):
    key: str
    name: str
    role: str
    model: str
    plan_type: str
    api_key_configured: bool
    available: bool
    availability_status: str
    is_paid_endpoint: bool
    blocked_by_cost_policy: bool
    configured_limits: str
    local_calls_today: int
    local_calls_total: int
    last_error: str
    cooldown_until: Optional[datetime] = None
    local_counter_disclaimer: str
    notes: str


from app.schemas.image_generation import ImageProvidersOverviewRead


class ProvidersOverview(BaseModel):
    stage: str
    cost_policy: CostPolicyOverview
    image_generator: ImageGeneratorStatusRead
    image_providers_overview: Optional[ImageProvidersOverviewRead] = None
    providers: List[ProviderStatusItem]

