from datetime import datetime, timezone

from sqlalchemy import DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ProviderUsageState(Base):
    """Local application counter and rate-limit cooldown state (never stores API keys)."""

    __tablename__ = "provider_usage_state"

    provider_key: Mapped[str] = mapped_column(String(40), primary_key=True)
    calls_total: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    calls_today: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    usage_date: Mapped[str] = mapped_column(String(10), nullable=False, default="")
    last_error: Mapped[str] = mapped_column(Text, nullable=False, default="")
    last_error_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cooldown_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_called_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )
