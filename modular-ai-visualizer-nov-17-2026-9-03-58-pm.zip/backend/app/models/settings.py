from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class StudioSettings(Base):
    __tablename__ = "studio_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    studio_name: Mapped[str] = mapped_column(String(120), nullable=False, default="Pracownia Modułowa")
    default_style: Mapped[str] = mapped_column(String(80), nullable=False, default="Nordic Graphite")
    default_preserve_geometry: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    preferred_aspect_ratio: Mapped[str] = mapped_column(String(20), nullable=False, default="16:9")
    preferred_vision_provider: Mapped[str] = mapped_column(String(40), nullable=False, default="gemini")
    preferred_image_provider: Mapped[str] = mapped_column(String(40), nullable=False, default="openai")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )
