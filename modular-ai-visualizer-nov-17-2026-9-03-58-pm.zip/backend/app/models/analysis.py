from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ProjectAnalysis(Base):
    __tablename__ = "project_analyses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    project_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    mode: Mapped[str] = mapped_column(String(32), nullable=False)
    provider: Mapped[str] = mapped_column(String(40), nullable=False)
    model: Mapped[str] = mapped_column(String(120), nullable=False)
    is_free_tier: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    summary: Mapped[str] = mapped_column(Text, nullable=False, default="")
    spatial_layout: Mapped[str] = mapped_column(Text, nullable=False, default="")
    materials_proposal: Mapped[str] = mapped_column(Text, nullable=False, default="")
    lighting_proposal: Mapped[str] = mapped_column(Text, nullable=False, default="")
    geometry_preservation_note: Mapped[str] = mapped_column(Text, nullable=False, default="")
    visualization_prompt: Mapped[str] = mapped_column(Text, nullable=False, default="")
    structured_payload_json: Mapped[str] = mapped_column(Text, nullable=False, default="")
    response_time_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, default=None)
    schema_version: Mapped[str] = mapped_column(String(24), nullable=False, default="3.3")
    raw_response_text: Mapped[str] = mapped_column(Text, nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )
