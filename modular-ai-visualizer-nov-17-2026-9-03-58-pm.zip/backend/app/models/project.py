from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    title: Mapped[str] = mapped_column(String(160), nullable=False, index=True)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="draft", index=True)
    building_type: Mapped[str] = mapped_column(String(80), nullable=False, default="Dom modułowy")
    area_sqm: Mapped[float | None] = mapped_column(Float, nullable=True, index=True)
    modules_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    style_preset: Mapped[str] = mapped_column(String(80), nullable=False, default="Nordic Graphite")
    preserve_geometry: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    prompt_brief: Mapped[str] = mapped_column(Text, nullable=False, default="")
    geometry_notes: Mapped[str] = mapped_column(Text, nullable=False, default="")
    sketch_image_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    preview_image_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    reference_ids_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False, index=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False, index=True
    )
