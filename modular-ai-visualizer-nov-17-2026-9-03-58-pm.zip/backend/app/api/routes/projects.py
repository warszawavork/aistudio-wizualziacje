from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy.orm import Session

from app.api.routes.ai import map_ai_exception_to_http
from app.core.config import Settings, get_settings
from app.db.database import get_db
from app.schemas.analysis import AnalyzeProjectRequest, ProjectAnalysisUpdate
from app.schemas.image_generation import GenerateImageRequest, ImageGenerationResponse
from app.schemas.project import DashboardSummary, ProjectCreate, ProjectRead, ProjectUpdate
from app.services import analysis_service, image_generation_service, project_service
from app.services.storage_service import save_uploaded_image

router = APIRouter(prefix="/projects", tags=["projects"])


@router.get("/summary", response_model=DashboardSummary)
def read_dashboard_summary(db: Session = Depends(get_db)):
    return project_service.get_dashboard_summary(db)


@router.get("", response_model=List[ProjectRead])
def read_projects(
    mode: Optional[str] = Query(default=None),
    status_filter: Optional[str] = Query(default=None, alias="status"),
    search: Optional[str] = Query(default=None),
    sort_by: Optional[str] = Query(default=None),
    limit: Optional[int] = Query(default=None, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    return project_service.list_projects(
        db,
        mode=mode,
        status_filter=status_filter,
        search=search,
        sort_by=sort_by,
        limit=limit,
        offset=offset,
    )


@router.post("", response_model=ProjectRead, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreate, db: Session = Depends(get_db)):
    return project_service.create_project(db, payload)


@router.post("/upload-sketch")
async def upload_sketch(
    file: UploadFile = File(...),
    settings: Settings = Depends(get_settings),
):
    url = await save_uploaded_image(file, settings, subfolder="sketches")
    return {"url": url, "filename": file.filename}


@router.get("/{project_id}", response_model=ProjectRead)
def read_project(project_id: int, db: Session = Depends(get_db)):
    project = project_service.get_project(db, project_id)
    if project is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Projekt nie został znaleziony.")
    return project


@router.get("/{project_id}/reference-context")
def read_project_reference_context(project_id: int, db: Session = Depends(get_db)):
    from app.services import reference_service

    project = project_service.get_project(db, project_id)
    if project is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Projekt nie został znaleziony.")
    return reference_service.build_reference_context_preview(
        db,
        project.reference_ids,
        project_id=project.id,
        project_title=project.title,
    )


@router.patch("/{project_id}", response_model=ProjectRead)
def update_project(project_id: int, payload: ProjectUpdate, db: Session = Depends(get_db)):
    project = project_service.update_project(db, project_id, payload)
    if project is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Projekt nie został znaleziony.")
    return project



@router.post("/{project_id}/analyze", response_model=ProjectRead)
async def analyze_project(
    project_id: int,
    payload: Optional[AnalyzeProjectRequest] = None,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    preferred = payload.preferred_provider if payload else "auto"
    try:
        project = await analysis_service.analyze_and_save_for_project(
            db,
            settings,
            project_id=project_id,
            preferred_provider=preferred,
        )
    except Exception as exc:
        raise map_ai_exception_to_http(exc) from exc

    if project is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Projekt nie został znaleziony.")
    return project


@router.post("/{project_id}/generate-image", response_model=ImageGenerationResponse)
async def generate_project_image(
    project_id: int,
    payload: Optional[GenerateImageRequest] = None,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    try:
        return await image_generation_service.generate_image_for_project(
            db,
            settings,
            project_id=project_id,
            payload=payload,
        )
    except Exception as exc:
        raise map_ai_exception_to_http(exc) from exc


@router.patch("/{project_id}/analysis", response_model=ProjectRead)
def update_project_analysis(
    project_id: int,
    payload: ProjectAnalysisUpdate,
    db: Session = Depends(get_db),
):
    project = analysis_service.update_latest_analysis_for_project(db, project_id, payload)
    if project is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Projekt nie został znaleziony.")
    return project


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(project_id: int, db: Session = Depends(get_db)):
    deleted = project_service.delete_project(db, project_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Projekt nie został znaleziony.")

