from datetime import datetime, timezone

from fastapi import APIRouter, Depends, status
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.database import get_db
from app.schemas.health import HealthResponse
from app.services.storage_service import ensure_storage_directories

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse)
def health_check(
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    database_connected = False
    storage_ready = False

    try:
        db.execute(text("SELECT 1"))
        database_connected = True
    except Exception:
        database_connected = False

    try:
        storage_path = ensure_storage_directories(settings)
        storage_ready = storage_path.exists() and storage_path.is_dir()
    except Exception:
        storage_ready = False

    healthy = database_connected and storage_ready
    payload = HealthResponse(
        status="ok" if healthy else "degraded",
        app_name=settings.app_name,
        stage=settings.app_stage,
        database_connected=database_connected,
        storage_ready=storage_ready,
        timestamp=datetime.now(timezone.utc),
    )
    if not healthy:
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content=payload.model_dump(mode="json"),
        )
    return payload
