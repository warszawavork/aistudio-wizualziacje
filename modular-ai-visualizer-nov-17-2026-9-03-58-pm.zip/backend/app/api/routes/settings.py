from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.database import get_db
from app.schemas.settings import ProvidersOverview, StudioSettingsRead, StudioSettingsUpdate
from app.services import settings_service

router = APIRouter(tags=["settings"])


@router.get("/settings", response_model=StudioSettingsRead)
def read_settings(db: Session = Depends(get_db)):
    return settings_service.get_or_create_studio_settings(db)


@router.put("/settings", response_model=StudioSettingsRead)
def update_settings(payload: StudioSettingsUpdate, db: Session = Depends(get_db)):
    return settings_service.update_studio_settings(db, payload)


@router.get("/providers/status", response_model=ProvidersOverview)
def read_providers_status(
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    return settings_service.get_providers_overview(db, settings)
