from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.core.cost_guard import (
    CostPolicyViolation,
    ProviderKeyMissingError,
    ProviderQuotaExceededError,
    ProviderRequestError,
    ProviderTimeoutError,
)
from app.db.database import get_db
from app.schemas.analysis import AnalysisPreviewResponse, AnalyzeDraftRequest
from app.schemas.image_generation import (
    GenerateDraftImageRequest,
    ImageGenerationResponse,
    ImageProvidersOverviewRead,
)
from app.services import analysis_service, image_generation_service

router = APIRouter(prefix="/ai", tags=["ai"])


def map_ai_exception_to_http(exc: Exception) -> HTTPException:
    if isinstance(exc, HTTPException):
        return exc
    if isinstance(exc, CostPolicyViolation):
        return HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc))
    if isinstance(exc, ProviderKeyMissingError):
        return HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc))
    if isinstance(exc, ProviderQuotaExceededError):
        return HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=str(exc))
    if isinstance(exc, ProviderTimeoutError):
        return HTTPException(status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail=str(exc))
    if isinstance(exc, ProviderRequestError):
        return HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))
    return HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))


@router.post("/analyze", response_model=AnalysisPreviewResponse)
async def analyze_draft_with_free_ai(
    payload: AnalyzeDraftRequest,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    try:
        return await analysis_service.analyze_draft(db, settings, payload)
    except Exception as exc:
        raise map_ai_exception_to_http(exc) from exc


@router.get("/image-providers", response_model=ImageProvidersOverviewRead)
async def read_image_providers_status(
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    return await image_generation_service.get_image_providers_overview(db, settings)


@router.post("/generate-image", response_model=ImageGenerationResponse)
async def generate_draft_image_with_free_engine(
    payload: GenerateDraftImageRequest,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
):
    try:
        return await image_generation_service.generate_image_for_draft(db, settings, payload)
    except Exception as exc:
        raise map_ai_exception_to_http(exc) from exc

