from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.database import get_db
from app.schemas.reference import (
    ReferenceContextPreview,
    ReferenceCreate,
    ReferenceRead,
    ReferenceUpdate,
)
from app.services import reference_service
from app.services.reference_service import ReferenceInUseError
from app.services.storage_service import save_uploaded_image

router = APIRouter(prefix="/references", tags=["references"])


class ReferenceContextRequest(BaseModel):
    reference_ids: List[int] = Field(default_factory=list)
    project_id: Optional[int] = None
    project_title: Optional[str] = None


@router.get("", response_model=List[ReferenceRead])
def read_references(
    category: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None),
    project_id: Optional[int] = Query(default=None),
    tag: Optional[str] = Query(default=None),
    limit: Optional[int] = Query(default=None, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    return reference_service.list_references(
        db,
        category=category,
        search=search,
        project_id=project_id,
        tag=tag,
        limit=limit,
        offset=offset,
    )


@router.post("/context-preview", response_model=ReferenceContextPreview)
def preview_reference_context(
    payload: ReferenceContextRequest,
    db: Session = Depends(get_db),
):
    return reference_service.build_reference_context_preview(
        db,
        payload.reference_ids,
        project_id=payload.project_id,
        project_title=payload.project_title,
    )


@router.get("/{reference_id}", response_model=ReferenceRead)
def read_reference(reference_id: int, db: Session = Depends(get_db)):
    item = reference_service.get_reference(db, reference_id)
    if item is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Referencja nie została znaleziona.",
        )
    return item


@router.post("", response_model=ReferenceRead, status_code=status.HTTP_201_CREATED)
def create_reference(payload: ReferenceCreate, db: Session = Depends(get_db)):
    return reference_service.create_reference(db, payload)


@router.patch("/{reference_id}", response_model=ReferenceRead)
@router.put("/{reference_id}", response_model=ReferenceRead)
def update_reference(
    reference_id: int,
    payload: ReferenceUpdate,
    db: Session = Depends(get_db),
):
    updated = reference_service.update_reference(db, reference_id, payload)
    if updated is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Referencja nie została znaleziona.",
        )
    return updated


@router.post("/upload-image")
async def upload_reference_image(
    file: UploadFile = File(...),
    settings: Settings = Depends(get_settings),
):
    url = await save_uploaded_image(file, settings, subfolder="uploads")
    return {"url": url, "filename": file.filename}


@router.delete("/{reference_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_reference(
    reference_id: int,
    force: bool = Query(default=False),
    db: Session = Depends(get_db),
):
    try:
        deleted = reference_service.delete_reference(db, reference_id, force=force)
    except ReferenceInUseError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Referencja nie została znaleziona.",
        )

