"""FastAPI API routing package."""
