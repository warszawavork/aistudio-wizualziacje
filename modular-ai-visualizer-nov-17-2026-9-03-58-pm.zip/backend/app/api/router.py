from fastapi import APIRouter

from app.api.routes import ai, health, projects, references, settings

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(projects.router)
api_router.include_router(references.router)
api_router.include_router(settings.router)
api_router.include_router(ai.router)
