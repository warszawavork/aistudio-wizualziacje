import json
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.analysis import ProjectAnalysis
from app.models.project import Project
from app.models.reference import ReferenceItem
from app.models.settings import StudioSettings


def seed_initial_data(db: Session) -> None:
    """Populate initial architectural examples on first run if tables are empty."""
    existing_settings = db.get(StudioSettings, 1)
    if existing_settings is None:
        db.add(
            StudioSettings(
                id=1,
                studio_name="Modular AI Visualizer Studio",
                default_style="Nordic Graphite",
                default_preserve_geometry=True,
                preferred_aspect_ratio="16:9",
                preferred_vision_provider="gemini",
                preferred_image_provider="openai",
            )
        )

    has_references = db.execute(select(ReferenceItem.id).limit(1)).first() is not None
    created_ref_ids: list[int] = []
    if not has_references:
        refs = [
            ReferenceItem(
                title="Moduł Leśny — Szkic i Elewacja Północna",
                category="sketch_pair",
                description="Referencyjna para: odręczny rzut z tarasem zadaszonym i odpowiadający mu układ bryły jednokondygnacyjnej.",
                materials_note="Blacha na rąbek grafit RAL 7016, modrzew syberyjski naturalny",
                lighting_note="Rozproszone światło dzienne, miękki cień pod okapem",
                style_tags="nordic, szkielet, dach dwuspadowy, taras",
                image_url="/src/assets/images/modular_cabin_exterior_1794908155648.jpg",
                paired_sketch_url="/src/assets/images/architectural_hand_sketch_1794908154196.jpg",
            ),
            ReferenceItem(
                title="Paleta Materiałowa: Opalany Modrzew i Anoda",
                category="material",
                description="Zestawienie podstawowych tekstur dla elewacji i stolarki okiennej pracowni.",
                materials_note="Drewno opalane Shou Sugi Ban, aluminium anodowane czarne, dąb szczotkowany, mikrocement",
                lighting_note="Kierunkowe światło studyjne podkreślające fakturę słojów",
                style_tags="materiały, elewacja, stolarka, beton",
                image_url="/src/assets/images/material_charred_larch_1794908156119.jpg",
            ),
            ReferenceItem(
                title="Strefa Dzienna — Szkło + Sklejka Brzozowa",
                category="realization",
                description="Ukończona realizacja wnętrza domu 72 m² z pełnymi przeszkleniami od podłogi do sufitu.",
                materials_note="Sklejka brzozowa olejowana, posadzka z mikrocementu, wełniana sofa grafitowa",
                lighting_note="Poranne światło wschodnie, liniowe oprawy szynowe 3000K",
                style_tags="wnętrze, salon, przeszklenia, minimalizm",
                image_url="/src/assets/images/modular_interior_living_1794908152101.jpg",
            ),
            ReferenceItem(
                title="Pawilon Dwumodułowy — Oświetlenie Zmierzchowe",
                category="lighting",
                description="Przykład oświetlenia podbitki dachowej LED i ciepłej poświaty wnętrza o niebieskiej godzinie.",
                materials_note="Stal malowana proszkowo mat, podbitka cedrowa, żwir bazaltowy",
                lighting_note="Blue hour, podświetlenie liniowe okapu 2700K, słupki ogrodowe",
                style_tags="oświetlenie, zmierzch, dach płaski, stal",
                image_url="/src/assets/images/modular_pavilion_concept_1794908154441.jpg",
            ),
            ReferenceItem(
                title="Wizualizacja Koncepcyjna: Bryła Leśna z Tarasem",
                category="visualization",
                description="Wzorcowa wizualizacja zewnętrzna parterowego domu modułowego w otoczeniu sosnowego starodrzewu.",
                materials_note="Blacha na rąbek stojący antracyt, deska modrzewiowa pionowa, szkło niskoemisyjne",
                lighting_note="Miękkie światło popołudniowe, odbicia lasu w przeszkleniach",
                style_tags="wizualizacja, bryła, las, taras, elewacja",
                image_url="/src/assets/images/modular_cabin_exterior_1794908155648.jpg",
            ),
            ReferenceItem(
                title="Paleta Kolorystyczna: Grafit, Ciepły Cedr i Piaskowy Mikrocement",
                category="color",
                description="Zestawienie barwne dla elewacji i wnętrz: kontrast matowej czerni stolarki z miodowym odcieniem drewna.",
                materials_note="RAL 7016 Anthracite Grey, RAL 9005 Jet Black, naturalny cedr czerwony, ciepły beż NCS S 2005-Y20R",
                lighting_note="Neutralne światło dzienne 4500K dla wiernego oddania barw",
                style_tags="kolory, paleta, grafit, cedr, kontrast",
                image_url="/src/assets/images/material_charred_larch_1794908156119.jpg",
            ),
            ReferenceItem(
                title="Kierunek Stylistyczny: Nordic Graphite & Raw Timber",
                category="style",
                description="Wzorzec stylu architektonicznego pracowni łączący minimalistyczną geometrię modułów ze szlachetnym drewnem.",
                materials_note="Stal kortenowska / grafitowa, modrzew syberyjski, wielkoformatowe ramy aluminiowe",
                lighting_note="Światło boczne podkreślające rytm podziałów elewacyjnych",
                style_tags="styl, nordic, minimalizm, architektura modułowa",
                image_url="/src/assets/images/modular_pavilion_concept_1794908154441.jpg",
            ),
            ReferenceItem(
                title="Aranżacja Wnętrza: Strefa Dzienna z Jadalnią i Panoramą",
                category="interior",
                description="Referencyjny układ mebli, zabudowy stolarskiej i strefowania otwartego salonu w module o szerokości 3,45 m.",
                materials_note="Fornir brzozowy, mikrocement jasnoszary, tkaniny lniane i wełniane w odcieniach ziemi",
                lighting_note="Szynoprzewody magnetyczne 3000K + światło naturalne z przeszklenia HS",
                style_tags="aranżacje wnętrz, salon, jadalnia, ergonomia, sklejka",
                image_url="/src/assets/images/modular_interior_living_1794908152101.jpg",
            ),
        ]
        db.add_all(refs)
        db.flush()
        created_ref_ids = [r.id for r in refs]
    else:
        existing_categories = {
            row[0] for row in db.execute(select(ReferenceItem.category)).all()
        }
        extra_refs: list[ReferenceItem] = []
        if "visualization" not in existing_categories:
            extra_refs.append(
                ReferenceItem(
                    title="Wizualizacja Koncepcyjna: Bryła Leśna z Tarasem",
                    category="visualization",
                    description="Wzorcowa wizualizacja zewnętrzna parterowego domu modułowego w otoczeniu sosnowego starodrzewu.",
                    materials_note="Blacha na rąbek stojący antracyt, deska modrzewiowa pionowa, szkło niskoemisyjne",
                    lighting_note="Miękkie światło popołudniowe, odbicia lasu w przeszkleniach",
                    style_tags="wizualizacja, bryła, las, taras, elewacja",
                    image_url="/src/assets/images/modular_cabin_exterior_1794908155648.jpg",
                )
            )
        if "color" not in existing_categories:
            extra_refs.append(
                ReferenceItem(
                    title="Paleta Kolorystyczna: Grafit, Ciepły Cedr i Piaskowy Mikrocement",
                    category="color",
                    description="Zestawienie barwne dla elewacji i wnętrz: kontrast matowej czerni stolarki z miodowym odcieniem drewna.",
                    materials_note="RAL 7016 Anthracite Grey, RAL 9005 Jet Black, naturalny cedr czerwony, ciepły beż NCS S 2005-Y20R",
                    lighting_note="Neutralne światło dzienne 4500K dla wiernego oddania barw",
                    style_tags="kolory, paleta, grafit, cedr, kontrast",
                    image_url="/src/assets/images/material_charred_larch_1794908156119.jpg",
                )
            )
        if "style" not in existing_categories:
            extra_refs.append(
                ReferenceItem(
                    title="Kierunek Stylistyczny: Nordic Graphite & Raw Timber",
                    category="style",
                    description="Wzorzec stylu architektonicznego pracowni łączący minimalistyczną geometrię modułów ze szlachetnym drewnem.",
                    materials_note="Stal kortenowska / grafitowa, modrzew syberyjski, wielkoformatowe ramy aluminiowe",
                    lighting_note="Światło boczne podkreślające rytm podziałów elewacyjnych",
                    style_tags="styl, nordic, minimalizm, architektura modułowa",
                    image_url="/src/assets/images/modular_pavilion_concept_1794908154441.jpg",
                )
            )
        if "interior" not in existing_categories:
            extra_refs.append(
                ReferenceItem(
                    title="Aranżacja Wnętrza: Strefa Dzienna z Jadalnią i Panoramą",
                    category="interior",
                    description="Referencyjny układ mebli, zabudowy stolarskiej i strefowania otwartego salonu w module o szerokości 3,45 m.",
                    materials_note="Fornir brzozowy, mikrocement jasnoszary, tkaniny lniane i wełniane w odcieniach ziemi",
                    lighting_note="Szynoprzewody magnetyczne 3000K + światło naturalne z przeszklenia HS",
                    style_tags="aranżacje wnętrz, salon, jadalnia, ergonomia, sklejka",
                    image_url="/src/assets/images/modular_interior_living_1794908152101.jpg",
                )
            )
        if extra_refs:
            db.add_all(extra_refs)
            db.flush()

    has_projects = db.execute(select(Project.id).limit(1)).first() is not None
    if not has_projects:
        ref_slice = created_ref_ids[:2] if created_ref_ids else []

        projects = [
            Project(
                title="Dom Modułowy Sosnowy 68 m²",
                mode="sketch_to_render",
                status="awaiting_ai_pipeline",
                building_type="Dom modułowy parterowy",
                area_sqm=68.5,
                modules_count=2,
                style_preset="Nordic Graphite",
                preserve_geometry=True,
                prompt_brief="Zachować dokładny układ ścian nośnych i trzyczęściowe przeszklenie frontowe na taras. Elewacja z grafitowej blachy na rąbek i naturalnego modrzewia.",
                geometry_notes="Stosunek osi okien 1:1.4, taras frontowy szerokości 2.6 m, wejście od strony zachodniej.",
                sketch_image_url="/src/assets/images/architectural_hand_sketch_1794908154196.jpg",
                preview_image_url="/src/assets/images/modular_cabin_exterior_1794908155648.jpg",
                reference_ids_json=json.dumps(ref_slice),
            ),
            Project(
                title="Pawilon Ogrodowy Atrium 96 m²",
                mode="idea_to_project",
                status="draft",
                building_type="Pawilon dwumodułowy",
                area_sqm=96.0,
                modules_count=3,
                style_preset="Raw Steel & Cedar",
                preserve_geometry=True,
                prompt_brief="Dwa przesunięte względem siebie moduły pod wspólnym okapem z podbitką cedrową. Otwarta strefa dzienna połączona z żwirowym dziedzińcem.",
                geometry_notes="Wysokość w świetle 3.10 m, przeszklenia narożne bezsłupowe.",
                sketch_image_url=None,
                preview_image_url="/src/assets/images/modular_pavilion_concept_1794908154441.jpg",
                reference_ids_json=json.dumps(created_ref_ids[2:4] if len(created_ref_ids) >= 4 else []),
            ),
            Project(
                title="Wnętrze Modułu Dziennego — Strefa Relaksu",
                mode="sketch_to_render",
                status="awaiting_ai_pipeline",
                building_type="Wnętrze dzienne",
                area_sqm=42.0,
                modules_count=1,
                style_preset="Birch & Microcement",
                preserve_geometry=True,
                prompt_brief="Przekształcenie rzutu pokoju dziennego z zachowaniem biegu belek stropowych i układu kanapy L-kształtnej względem ściany okiennej.",
                geometry_notes="Zachować odległość stolika kawowego i szerokość ciągu komunikacyjnego do jadalni.",
                sketch_image_url="/src/assets/images/architectural_hand_sketch_1794908154196.jpg",
                preview_image_url="/src/assets/images/modular_interior_living_1794908152101.jpg",
                reference_ids_json=json.dumps([created_ref_ids[2]] if len(created_ref_ids) >= 3 else []),
            ),
        ]
        db.add_all(projects)
        db.flush()

    existing_project_ids = {row[0] for row in db.execute(select(Project.id)).all()}
    all_ref_ids = [row[0] for row in db.execute(select(ReferenceItem.id).order_by(ReferenceItem.id.asc())).all()]

    if 4 not in existing_project_ids:
        proj4 = Project(
            id=4,
            title="Test 1 (Prosty rzut) — Dom Modułowy 1-Modułowy 30 m² (Gemini 3.1 Flash Lite)",
            mode="sketch_to_render",
            status="awaiting_ai_pipeline",
            building_type="Dom modułowy parterowy",
            area_sqm=30.0,
            modules_count=1,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief="Wierna analiza technicznego rzutu 1-modułowego (7.5 m x 4.0 m) z wykryciem rozbieżności łańcucha wymiarowego (4.0 + 3.5 + 2.1 = 9.6 m vs 7.5 m).",
            geometry_notes="Blokada geometrii obrysu 7.5 m x 4.0 m, okien i drzwi wejściowych.",
            sketch_image_url="/src/assets/images/architectural_hand_sketch_1794908154196.jpg",
            preview_image_url=None,
            reference_ids_json=json.dumps(all_ref_ids[:2] if len(all_ref_ids) >= 2 else []),
        )
        db.add(proj4)
        db.flush()
        db.add(
            ProjectAnalysis(
                project_id=proj4.id,
                mode="sketch_to_render",
                provider="gemini",
                model="gemini-3.1-flash-lite-preview",
                is_free_tier=True,
                summary="Analiza technicznego rzutu 1-modułowego The Rectangle (deklarowany obrys 7.5 m x 4.0 m) z wykrytym konfliktem sumy odcinków (9.6 m vs 7.5 m, różnica 2.1 m).",
                spatial_layout="Strefa dzienna z aneksem po lewej stronie rzutu (20.8 m²), sypialnia (11.2 m²) i łazienka (3.8 m²) po prawej stronie rzutu.",
                materials_proposal="Nordic Graphite: blacha na rąbek grafit RAL 7016, modrzew syberyjski naturalny.",
                lighting_proposal="Światło dzienne rozproszone + oprawy podbitkowe 2700K.",
                geometry_preservation_note="GEOMETRY LOCK: Ścisłe zachowanie obrysu, ścian, okien i drzwi z oryginalnego rzutu.",
                visualization_prompt=(
                    "Architectural visualization in Nordic Graphite style. GEOMETRY LOCK (MANDATORY): "
                    "Strictly preserve exact sketch geometry, building footprint, all structural and "
                    "partition walls, all windows, entrance doors, sliding doors, and room layout. "
                    "FORBIDDEN: Do not add, remove, or shift any walls, windows, doors, rooms, or floors."
                ),
                structured_payload_json=json.dumps(
                    {
                        "analysis_source": "live",
                        "dimension_confidence": "niska pewność",
                        "dimension_conflicts": [
                            "Niezgodność wymiarowa: „Szerokość całkowita 7.5 m vs odcinki 4.0 m + 3.5 m + 2.1 m” — wymiar całkowity 7.5 m != suma odcinków 9.6 m (różnica 2.1 m)."
                        ],
                    },
                    ensure_ascii=False,
                ),
                response_time_ms=8969,
                schema_version="3.5",
                raw_response_text="{}",
            )
        )

    if 5 not in existing_project_ids:
        proj5 = Project(
            id=5,
            title="Test 2 (Złożony rzut) — Dom Modułowy 3-Modułowy 78 m² (Gemini 3.1 Flash Lite)",
            mode="sketch_to_render",
            status="awaiting_ai_pipeline",
            building_type="Dom modułowy parterowy",
            area_sqm=78.0,
            modules_count=3,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief="Wierna analiza złożonego rzutu 3-modułowego z centralnym korytarzem, 7 pomieszczeniami, przeszkleniem HS i pełną kontrolą kompletności otworów.",
            geometry_notes="Zachować układ 3 modułów, przeszklenie tarasowe HS oraz wszystkie drzwi wewnętrzne.",
            sketch_image_url="/src/assets/images/architectural_hand_sketch_1794908154196.jpg",
            preview_image_url=None,
            reference_ids_json=json.dumps(all_ref_ids[2:5] if len(all_ref_ids) >= 5 else []),
        )
        db.add(proj5)
        db.flush()
        db.add(
            ProjectAnalysis(
                project_id=proj5.id,
                mode="sketch_to_render",
                provider="gemini",
                model="gemini-3.1-flash-lite-preview",
                is_free_tier=True,
                summary="Analiza złożonego rzutu 3-modułowego (78 m²) z centralnym korytarzem, 7 pomieszczeniami, przeszkleniem tarasowym HS i kontrolą kierunków otwierania drzwi.",
                spatial_layout="Moduł lewy: salon z jadalnią i kuchnią; moduł środkowy: wiatrołap, hol, łazienka i pom. techniczne; moduł prawy: dwie sypialnie i gabinet.",
                materials_proposal="Nordic Graphite: grafitowa blacha na rąbek, deska modrzewiowa, stolarka aluminiowa czarna.",
                lighting_proposal="Naturalne światło z przeszklenia HS + ciepłe oświetlenie 2700K.",
                geometry_preservation_note="GEOMETRY LOCK: Zachowano układ 3 modułów, wszystkie ściany działowe i otwory stolarki.",
                visualization_prompt=(
                    "Architectural visualization of a 3-module house in Nordic Graphite style. "
                    "GEOMETRY LOCK (MANDATORY): Strictly preserve exact sketch geometry, building footprint, "
                    "all structural and partition walls, all windows, entrance doors, sliding doors, and room layout. "
                    "FORBIDDEN: Do not add, remove, or shift any walls, windows, doors, rooms, or floors."
                ),
                structured_payload_json=json.dumps(
                    {
                        "analysis_source": "live",
                        "dimension_confidence": "średnia pewność",
                        "orientation_source": "none",
                    },
                    ensure_ascii=False,
                ),
                response_time_ms=11220,
                schema_version="3.5",
                raw_response_text="{}",
            )
        )

    db.commit()
