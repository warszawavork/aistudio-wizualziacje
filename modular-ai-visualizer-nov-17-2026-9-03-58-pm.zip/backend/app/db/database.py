from collections.abc import Generator
from pathlib import Path

from sqlalchemy import create_engine, event, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import get_settings


class Base(DeclarativeBase):
    pass


def _build_engine():
    settings = get_settings()
    db_url = settings.database_url
    if db_url.startswith("sqlite:///"):
        db_file = Path(db_url.replace("sqlite:///", "", 1))
        db_file.parent.mkdir(parents=True, exist_ok=True)

    connect_args = (
        {"check_same_thread": False, "timeout": 15.0}
        if db_url.startswith("sqlite")
        else {}
    )
    engine = create_engine(db_url, connect_args=connect_args, future=True)

    if db_url.startswith("sqlite"):
        @event.listens_for(engine, "connect")
        def _set_sqlite_pragma(dbapi_connection, _connection_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.execute("PRAGMA busy_timeout=5000")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.close()

    return engine


def ensure_sqlite_schema_migrations(target_engine: Engine) -> None:
    """Safely adds new columns and performance indexes to pre-existing SQLite tables."""
    if not str(target_engine.url).startswith("sqlite"):
        return

    with target_engine.begin() as conn:
        analyses_exists = conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name='project_analyses'")
        ).scalar()
        if analyses_exists:
            existing_cols = {
                row[1]
                for row in conn.execute(text("PRAGMA table_info(project_analyses)")).fetchall()
            }

            if "structured_payload_json" not in existing_cols:
                conn.execute(
                    text(
                        "ALTER TABLE project_analyses "
                        "ADD COLUMN structured_payload_json TEXT NOT NULL DEFAULT ''"
                    )
                )
            if "response_time_ms" not in existing_cols:
                conn.execute(
                    text("ALTER TABLE project_analyses ADD COLUMN response_time_ms INTEGER")
                )
            if "schema_version" not in existing_cols:
                conn.execute(
                    text(
                        "ALTER TABLE project_analyses "
                        "ADD COLUMN schema_version VARCHAR(24) NOT NULL DEFAULT '3.2_legacy'"
                    )
                )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_project_analyses_project_id_created_at "
                    "ON project_analyses (project_id, created_at DESC)"
                )
            )

        refs_exists = conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name='reference_items'")
        ).scalar()
        if refs_exists:
            ref_cols = {
                row[1]
                for row in conn.execute(text("PRAGMA table_info(reference_items)")).fetchall()
            }
            if "project_id" not in ref_cols:
                conn.execute(
                    text("ALTER TABLE reference_items ADD COLUMN project_id INTEGER")
                )
            if "updated_at" not in ref_cols:
                conn.execute(
                    text(
                        "ALTER TABLE reference_items "
                        "ADD COLUMN updated_at DATETIME"
                    )
                )
                conn.execute(
                    text(
                        "UPDATE reference_items SET updated_at = created_at "
                        "WHERE updated_at IS NULL"
                    )
                )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_reference_items_project_id "
                    "ON reference_items (project_id)"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_reference_items_category "
                    "ON reference_items (category)"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_reference_items_title "
                    "ON reference_items (title)"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_reference_items_created_at "
                    "ON reference_items (created_at DESC)"
                )
            )

        projects_exists = conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name='projects'")
        ).scalar()
        if projects_exists:
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_projects_title ON projects (title)"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_projects_area_sqm ON projects (area_sqm)"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_projects_created_at ON projects (created_at DESC)"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS ix_projects_updated_at ON projects (updated_at DESC)"
                )
            )



engine = _build_engine()
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False, class_=Session)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
