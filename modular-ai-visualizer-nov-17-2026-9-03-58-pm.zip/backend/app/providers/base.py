from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from app.core.cost_guard import ProviderDescriptor

ImageGeneratorStatus = Literal[
    "available_free",
    "unavailable_free",
    "disabled_by_cost_policy",
    "unverified_blocked",
    "missing_api_key",
    "cooldown",
    "local_limit_reached",
    "provider_error",
]

VerificationStatus = Literal[
    "verified_free",
    "verified_paid",
    "verified_micro_credits",
    "unverified",
]


@dataclass(frozen=True)
class ImageProviderCapabilities:
    model: str
    is_truly_free: bool
    verification_status: VerificationStatus
    known_limits: str
    supported_resolutions: List[str] = field(default_factory=lambda: ["1024x768", "1024x1024"])
    supports_image_to_image: bool = False
    supports_geometry_preservation: bool = False
    hardware_requirements: str = "Brak lokalnych wymagań GPU (usługa zewnętrzna)"


@dataclass(frozen=True)
class ImageProviderStatusInfo:
    key: str
    name: str
    role: str
    model: str
    plan_type: str
    available: bool
    availability_status: str
    is_truly_free: bool
    is_paid_endpoint: bool
    is_verified: bool
    verification_status: VerificationStatus
    blocked_by_cost_policy: bool
    api_key_configured: bool
    known_limits: str
    cooldown_until: Optional[datetime]
    supported_resolutions: List[str]
    supports_image_to_image: bool
    supports_geometry_preservation: bool
    hardware_requirements: str
    unavailability_reason: str
    local_calls_today: int = 0
    local_calls_total: int = 0
    last_error: str = ""


@dataclass(frozen=True)
class GeneratedImageResult:
    provider_key: str
    provider_name: str
    model: str
    mode: str
    image_bytes: bytes
    mime_type: str
    width: int
    height: int
    used_image_to_image: bool
    geometry_preserved: bool
    is_conceptual: bool
    prompt_used: str
    response_time_ms: int


class VisionAnalyzerProvider(ABC):
    """Abstract interface for analyzing architectural sketches, floor plans, and text briefs."""

    @abstractmethod
    def get_descriptor(self) -> ProviderDescriptor:
        raise NotImplementedError

    @abstractmethod
    def is_key_configured(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def analyze_sketch(
        self,
        prompt: str,
        image_base64: str | None = None,
        preserve_geometry: bool = True,
        image_mime_type: str = "image/jpeg",
        system_instruction: Optional[str] = None,
        response_mime_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        raise NotImplementedError


class ImageGenerationProvider(ABC):
    """Unified multi-engine interface for zero-cost architectural image generation."""

    @abstractmethod
    def get_descriptor(self) -> ProviderDescriptor:
        raise NotImplementedError

    @abstractmethod
    def is_key_configured(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def get_capabilities(self) -> ImageProviderCapabilities:
        raise NotImplementedError

    @abstractmethod
    async def health_check(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def get_status(self, db: Optional[Any] = None) -> ImageProviderStatusInfo:
        raise NotImplementedError

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        raise NotImplementedError

    @abstractmethod
    async def image_to_image(
        self,
        prompt: str,
        reference_image_bytes: bytes,
        reference_mime_type: str = "image/png",
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        strength: float = 0.45,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        raise NotImplementedError


class ImageGeneratorProvider(ABC):
    """Legacy/boundary abstract interface preserved for backward compatibility."""

    @abstractmethod
    def get_descriptor(self) -> ProviderDescriptor:
        raise NotImplementedError

    @abstractmethod
    def is_key_configured(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def get_generation_status(self) -> ImageGeneratorStatus:
        raise NotImplementedError

    @abstractmethod
    async def generate_visualization(
        self,
        prompt: str,
        reference_image_paths: List[str],
        aspect_ratio: str = "16:9",
    ) -> Dict[str, Any]:
        raise NotImplementedError


class MessagingProvider(ABC):
    """Abstract interface for external communication channels (inactive in Stage 2.5)."""

    @abstractmethod
    def get_descriptor(self) -> ProviderDescriptor:
        raise NotImplementedError

    @abstractmethod
    def is_key_configured(self) -> bool:
        raise NotImplementedError

