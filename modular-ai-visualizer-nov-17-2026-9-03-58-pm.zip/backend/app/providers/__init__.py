"""Decoupled AI and Messaging provider abstractions under Zero-Cost Policy."""

from app.providers.base import (
    GeneratedImageResult,
    ImageGenerationProvider,
    ImageGeneratorProvider,
    ImageGeneratorStatus,
    ImageProviderCapabilities,
    ImageProviderStatusInfo,
    MessagingProvider,
    VerificationStatus,
    VisionAnalyzerProvider,
)
from app.providers.free_image_provider import FreeImageGeneratorProvider
from app.providers.gemini_provider import GeminiProvider
from app.providers.groq_provider import GroqProvider
from app.providers.huggingface_provider import HuggingFaceImageProvider
from app.providers.image_providers import (
    GeminiImagenProvider,
    HuggingFaceMultiImageProvider,
    LocalComfyUIImageProvider,
    LocalSDWebUIImageProvider,
    OpenAIMultiImageProvider,
    UnverifiedCloudImageProvider,
    build_default_image_providers,
    resolve_dimensions_for_aspect_ratio,
    validate_image_magic_bytes,
)
from app.providers.openai_provider import OpenAIImageProvider
from app.providers.telegram_provider import TelegramBotProvider

__all__ = [
    "VisionAnalyzerProvider",
    "ImageGenerationProvider",
    "ImageProviderCapabilities",
    "ImageProviderStatusInfo",
    "GeneratedImageResult",
    "VerificationStatus",
    "ImageGeneratorProvider",
    "ImageGeneratorStatus",
    "MessagingProvider",
    "GeminiProvider",
    "GroqProvider",
    "OpenAIImageProvider",
    "HuggingFaceImageProvider",
    "FreeImageGeneratorProvider",
    "LocalSDWebUIImageProvider",
    "LocalComfyUIImageProvider",
    "GeminiImagenProvider",
    "OpenAIMultiImageProvider",
    "HuggingFaceMultiImageProvider",
    "UnverifiedCloudImageProvider",
    "build_default_image_providers",
    "resolve_dimensions_for_aspect_ratio",
    "validate_image_magic_bytes",
    "TelegramBotProvider",
]

