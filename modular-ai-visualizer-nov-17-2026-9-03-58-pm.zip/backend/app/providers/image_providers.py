import base64
import time
from typing import Any, Dict, List, Optional, Tuple

import httpx
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.cost_guard import (
    CostGuard,
    CostPolicyViolation,
    ProviderDescriptor,
    ProviderQuotaExceededError,
    ProviderRequestError,
    ProviderTimeoutError,
    sanitize_sensitive_text,
)
from app.providers.base import (
    GeneratedImageResult,
    ImageGenerationProvider,
    ImageProviderCapabilities,
    ImageProviderStatusInfo,
)


def resolve_dimensions_for_aspect_ratio(aspect_ratio: str) -> Tuple[int, int]:
    ratio = (aspect_ratio or "16:9").strip()
    if ratio == "1:1":
        return 1024, 1024
    if ratio == "3:2":
        return 1152, 768
    if ratio == "4:3":
        return 1024, 768
    return 1024, 768


def validate_image_magic_bytes(data: bytes) -> str:
    """
    Validates that image bytes are complete and non-corrupted PNG, JPEG, or WEBP.
    Prevents saving partial, truncated, or invalid binary payloads as project renders.
    """
    if not data or len(data) < 32:
        raise ProviderRequestError(
            "Otrzymano pusty lub częściowy bufor obrazu (< 32 bajty) — zapis odrzucony."
        )

    # PNG: starts with 89 50 4E 47 0D 0A 1A 0A and must contain IEND chunk near the end
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        if b"IEND" not in data[-32:]:
            raise ProviderRequestError(
                "Otrzymany plik PNG jest uszkodzony lub niekompletny (brak znacznika końca IEND)."
            )
        return "image/png"

    # JPEG: starts with FF D8 FF and ends with FF D9 (allowing trailing whitespace)
    if data.startswith(b"\xff\xd8\xff"):
        stripped = data.rstrip(b"\x00\r\n\t ")
        if not stripped.endswith(b"\xff\xd9"):
            raise ProviderRequestError(
                "Otrzymany plik JPEG jest niekompletny (brak znacznika końca EOI 0xFFD9)."
            )
        return "image/jpeg"

    # WEBP: starts with RIFF....WEBP
    if len(data) >= 16 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"

    raise ProviderRequestError(
        "Nieprawidłowy lub uszkodzony format wygenerowanego obrazu (wymagany poprawny PNG, JPEG lub WEBP)."
    )


def _parse_retry_after(header_value: Optional[str]) -> Optional[int]:
    if not header_value:
        return None
    try:
        val = int(float(header_value.strip()))
        return max(1, val)
    except ValueError:
        return None


class _BaseMultiEngineImageProvider(ImageGenerationProvider):
    def __init__(
        self,
        settings: Settings,
        cost_guard: CostGuard,
        db: Optional[Session] = None,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ) -> None:
        self._settings = settings
        self._cost_guard = cost_guard
        self._db = db
        self._transport = transport

    async def get_status(self, db: Optional[Session] = None) -> ImageProviderStatusInfo:
        active_db = db or self._db
        descriptor = self.get_descriptor()
        caps = self.get_capabilities()
        key_configured = self.is_key_configured()

        is_healthy = True
        if descriptor.is_local_engine:
            is_healthy = await self.health_check()

        usage = (
            self._cost_guard.get_or_create_usage(active_db, descriptor.key)
            if active_db is not None
            else None
        )
        decision = self._cost_guard.evaluate_provider(
            descriptor,
            api_key_configured=key_configured,
            usage=usage,
            local_service_reachable=is_healthy,
        )

        unavailability_reason = "" if decision.allowed else decision.reason
        if descriptor.is_local_engine and not is_healthy and not decision.allowed:
            unavailability_reason = (
                f"Brak uruchomionego lokalnego serwera {descriptor.name} pod adresem "
                f"{self._get_local_endpoint_label()} oraz brak karty GPU/VRAM w środowisku kontenera."
            )

        return ImageProviderStatusInfo(
            key=descriptor.key,
            name=descriptor.name,
            role=descriptor.role,
            model=descriptor.model,
            plan_type=descriptor.plan_type,
            available=decision.allowed,
            availability_status=decision.availability_status,
            is_truly_free=caps.is_truly_free,
            is_paid_endpoint=descriptor.is_paid_endpoint,
            is_verified=descriptor.is_verified,
            verification_status=caps.verification_status,
            blocked_by_cost_policy=decision.blocked_by_cost_policy,
            api_key_configured=key_configured,
            known_limits=caps.known_limits,
            cooldown_until=decision.cooldown_until or (usage.cooldown_until if usage else None),
            supported_resolutions=list(caps.supported_resolutions),
            supports_image_to_image=caps.supports_image_to_image,
            supports_geometry_preservation=caps.supports_geometry_preservation,
            hardware_requirements=caps.hardware_requirements,
            unavailability_reason=unavailability_reason,
            local_calls_today=usage.calls_today if usage else 0,
            local_calls_total=usage.calls_total if usage else 0,
            last_error=usage.last_error if usage and usage.last_error else "",
        )

    def _get_local_endpoint_label(self) -> str:
        return "localhost"


class LocalSDWebUIImageProvider(_BaseMultiEngineImageProvider):
    """
    Truly free local Stable Diffusion WebUI (Automatic1111 / Forge) adapter.
    Supports both txt2img and img2img (geometry lock from architectural sketch).
    """

    def _get_local_endpoint_label(self) -> str:
        return self._settings.sd_webui_base_url

    def is_key_configured(self) -> bool:
        return True

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="local_sd_webui",
            name="Local Stable Diffusion WebUI (A1111 / Forge)",
            role="Lokalny silnik txt2img oraz img2img z zachowaniem geometrii szkicu (0 zł)",
            plan_type="Lokalny Open-Source (100% darmowy, bez limitów chmurowych)",
            model=self._settings.sd_webui_model_name,
            is_paid_endpoint=False,
            is_free_tier_confirmed=True,
            requires_micro_credits=False,
            rpm_limit=60,
            rpd_limit=5000,
            configured_limits_note="Brak opłat API. Wymaga uruchomionego lokalnie serwera SD WebUI (--api) oraz GPU.",
            is_verified=True,
            requires_api_key=False,
            is_local_engine=True,
        )

    def get_capabilities(self) -> ImageProviderCapabilities:
        return ImageProviderCapabilities(
            model=self._settings.sd_webui_model_name,
            is_truly_free=True,
            verification_status="verified_free",
            known_limits="Brak limitów zewnętrznych API (ograniczone wyłącznie lokalnym GPU)",
            supported_resolutions=["1024x768", "1024x1024", "1152x768"],
            supports_image_to_image=True,
            supports_geometry_preservation=True,
            hardware_requirements="Lokalne GPU min. 6–8 GB VRAM, 16 GB RAM, uruchomiony serwer :7860",
        )

    async def health_check(self) -> bool:
        base_url = self._settings.sd_webui_base_url.rstrip("/")
        try:
            async with httpx.AsyncClient(timeout=2.0, transport=self._transport) as client:
                resp = await client.get(f"{base_url}/sdapi/v1/sd-models")
                return resp.status_code == 200
        except Exception:
            return False

    async def generate(
        self,
        prompt: str,
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        return await self._execute_sd_request(
            endpoint_path="/sdapi/v1/txt2img",
            payload={
                "prompt": prompt,
                "negative_prompt": "deformed geometry, changed floor plan, altered window positions, blurry, watermark",
                "steps": 24,
                "cfg_scale": 7.0,
                "width": width,
                "height": height,
            },
            prompt=prompt,
            mode=mode,
            used_image_to_image=False,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
        )

    async def image_to_image(
        self,
        prompt: str,
        reference_image_bytes: bytes,
        reference_mime_type: str = "image/png",
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        strength: float = 0.45,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        if not reference_image_bytes:
            raise ProviderRequestError("Brak obrazu wejściowego szkicu dla trybu image-to-image.")
        b64_sketch = base64.b64encode(reference_image_bytes).decode("ascii")
        denoising = 0.38 if preserve_geometry else max(0.25, min(0.75, strength))
        return await self._execute_sd_request(
            endpoint_path="/sdapi/v1/img2img",
            payload={
                "init_images": [b64_sketch],
                "prompt": prompt,
                "negative_prompt": "altered wall layout, moved doors, moved windows, changed room proportions, watermark",
                "denoising_strength": denoising,
                "steps": 26,
                "cfg_scale": 7.5,
                "width": width,
                "height": height,
            },
            prompt=prompt,
            mode=mode,
            used_image_to_image=True,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
        )

    async def _execute_sd_request(
        self,
        *,
        endpoint_path: str,
        payload: Dict[str, Any],
        prompt: str,
        mode: str,
        used_image_to_image: bool,
        preserve_geometry: bool,
        width: int,
        height: int,
    ) -> GeneratedImageResult:
        descriptor = self.get_descriptor()
        is_healthy = await self.health_check()

        if self._db is not None:
            self._cost_guard.assert_call_allowed(
                self._db,
                descriptor,
                api_key_configured=True,
                local_service_reachable=is_healthy,
            )
        else:
            decision = self._cost_guard.evaluate_provider(
                descriptor,
                api_key_configured=True,
                local_service_reachable=is_healthy,
            )
            if not decision.allowed:
                if decision.blocked_by_cost_policy:
                    raise CostPolicyViolation(decision.reason)
                raise ProviderRequestError(decision.reason)

        base_url = self._settings.sd_webui_base_url.rstrip("/")
        started = time.perf_counter()
        try:
            async with httpx.AsyncClient(
                timeout=self._settings.image_gen_timeout_seconds,
                transport=self._transport,
            ) as client:
                response = await client.post(f"{base_url}{endpoint_path}", json=payload)
        except httpx.TimeoutException as exc:
            msg = f"Przekroczono czas oczekiwania ({self._settings.image_gen_timeout_seconds}s) na lokalny silnik {descriptor.name}."
            if self._db is not None:
                self._cost_guard.record_error(self._db, descriptor.key, msg, status_code=504)
            raise ProviderTimeoutError(msg) from exc
        except httpx.HTTPError as exc:
            msg = sanitize_sensitive_text(f"Błąd połączenia z silnikiem {descriptor.name}: {exc}")
            if self._db is not None:
                self._cost_guard.record_error(self._db, descriptor.key, msg, status_code=502)
            raise ProviderRequestError(msg) from exc

        elapsed_ms = max(1, int((time.perf_counter() - started) * 1000))

        if response.status_code == 429:
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            msg = (
                f"Silnik {descriptor.name} zwrócił HTTP 429 (przeciążenie kolejki). "
                "Wstrzymano wywołania bez automatycznych ponowień."
            )
            if self._db is not None:
                self._cost_guard.record_rate_limit_429(
                    self._db,
                    descriptor.key,
                    retry_after_seconds=retry_after,
                    error_message=msg,
                )
            raise ProviderQuotaExceededError(msg)

        if response.status_code >= 400:
            msg = f"Błąd HTTP {response.status_code} z silnika {descriptor.name}."
            if self._db is not None:
                self._cost_guard.record_error(
                    self._db, descriptor.key, msg, status_code=response.status_code
                )
            raise ProviderRequestError(msg)

        try:
            body = response.json()
            images_b64 = body.get("images") or []
            if not images_b64 or not isinstance(images_b64[0], str):
                raise ProviderRequestError("Odpowiedź silnika nie zawiera tablicy images[0].")
            raw_b64 = images_b64[0].split(",", 1)[-1]
            image_bytes = base64.b64decode(raw_b64)
        except ProviderRequestError:
            raise
        except Exception as exc:
            msg = f"Nieprawidłowa odpowiedź JSON/base64 z silnika {descriptor.name}."
            if self._db is not None:
                self._cost_guard.record_error(self._db, descriptor.key, msg, status_code=502)
            raise ProviderRequestError(msg) from exc

        mime_type = validate_image_magic_bytes(image_bytes)
        if self._db is not None:
            self._cost_guard.record_success(self._db, descriptor.key)

        return GeneratedImageResult(
            provider_key=descriptor.key,
            provider_name=descriptor.name,
            model=descriptor.model,
            mode=mode,
            image_bytes=image_bytes,
            mime_type=mime_type,
            width=width,
            height=height,
            used_image_to_image=used_image_to_image,
            geometry_preserved=preserve_geometry,
            is_conceptual=(mode == "idea_to_project"),
            prompt_used=prompt,
            response_time_ms=elapsed_ms,
        )


class LocalComfyUIImageProvider(_BaseMultiEngineImageProvider):
    """
    Truly free local ComfyUI workflow engine adapter (:8188).
    Supports ControlNet / img2img geometry preservation when running locally.
    """

    def _get_local_endpoint_label(self) -> str:
        return self._settings.comfyui_base_url

    def is_key_configured(self) -> bool:
        return True

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="local_comfyui",
            name="Local ComfyUI (ControlNet / SDXL)",
            role="Lokalny potok węzłowy ComfyUI z obsługą ControlNet Canny/Lineart (0 zł)",
            plan_type="Lokalny Open-Source (100% darmowy, wykonywany na własnym GPU)",
            model=self._settings.comfyui_model_name,
            is_paid_endpoint=False,
            is_free_tier_confirmed=True,
            requires_micro_credits=False,
            rpm_limit=60,
            rpd_limit=5000,
            configured_limits_note="Brak opłat API. Wymaga uruchomionego lokalnie serwera ComfyUI (:8188) oraz GPU.",
            is_verified=True,
            requires_api_key=False,
            is_local_engine=True,
        )

    def get_capabilities(self) -> ImageProviderCapabilities:
        return ImageProviderCapabilities(
            model=self._settings.comfyui_model_name,
            is_truly_free=True,
            verification_status="verified_free",
            known_limits="Brak limitów chmurowych (zależne od lokalnego GPU/VRAM)",
            supported_resolutions=["1024x768", "1024x1024", "1344x768"],
            supports_image_to_image=True,
            supports_geometry_preservation=True,
            hardware_requirements="Lokalne GPU min. 8 GB VRAM (SDXL + ControlNet), 16 GB RAM, port :8188",
        )

    async def health_check(self) -> bool:
        base_url = self._settings.comfyui_base_url.rstrip("/")
        try:
            async with httpx.AsyncClient(timeout=2.0, transport=self._transport) as client:
                resp = await client.get(f"{base_url}/system_stats")
                return resp.status_code == 200
        except Exception:
            return False

    async def generate(
        self,
        prompt: str,
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        return await self._execute_comfy_request(
            prompt=prompt,
            mode=mode,
            used_image_to_image=False,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
            reference_image_bytes=None,
        )

    async def image_to_image(
        self,
        prompt: str,
        reference_image_bytes: bytes,
        reference_mime_type: str = "image/png",
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        strength: float = 0.45,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        if not reference_image_bytes:
            raise ProviderRequestError("Brak obrazu szkicu dla potoku ComfyUI img2img.")
        return await self._execute_comfy_request(
            prompt=prompt,
            mode=mode,
            used_image_to_image=True,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
            reference_image_bytes=reference_image_bytes,
        )

    async def _execute_comfy_request(
        self,
        *,
        prompt: str,
        mode: str,
        used_image_to_image: bool,
        preserve_geometry: bool,
        width: int,
        height: int,
        reference_image_bytes: Optional[bytes],
    ) -> GeneratedImageResult:
        descriptor = self.get_descriptor()
        is_healthy = await self.health_check()

        if self._db is not None:
            self._cost_guard.assert_call_allowed(
                self._db,
                descriptor,
                api_key_configured=True,
                local_service_reachable=is_healthy,
            )
        else:
            decision = self._cost_guard.evaluate_provider(
                descriptor,
                api_key_configured=True,
                local_service_reachable=is_healthy,
            )
            if not decision.allowed:
                if decision.blocked_by_cost_policy:
                    raise CostPolicyViolation(decision.reason)
                raise ProviderRequestError(decision.reason)

        base_url = self._settings.comfyui_base_url.rstrip("/")
        workflow_payload: Dict[str, Any] = {
            "prompt": prompt,
            "width": width,
            "height": height,
            "preserve_geometry": preserve_geometry,
            "used_image_to_image": used_image_to_image,
        }
        if reference_image_bytes:
            workflow_payload["reference_image_base64"] = base64.b64encode(
                reference_image_bytes
            ).decode("ascii")

        started = time.perf_counter()
        try:
            async with httpx.AsyncClient(
                timeout=self._settings.image_gen_timeout_seconds,
                transport=self._transport,
            ) as client:
                response = await client.post(f"{base_url}/prompt", json=workflow_payload)
        except httpx.TimeoutException as exc:
            msg = f"Przekroczono czas oczekiwania ({self._settings.image_gen_timeout_seconds}s) na lokalny serwer {descriptor.name}."
            if self._db is not None:
                self._cost_guard.record_error(self._db, descriptor.key, msg, status_code=504)
            raise ProviderTimeoutError(msg) from exc
        except httpx.HTTPError as exc:
            msg = sanitize_sensitive_text(f"Błąd komunikacji z {descriptor.name}: {exc}")
            if self._db is not None:
                self._cost_guard.record_error(self._db, descriptor.key, msg, status_code=502)
            raise ProviderRequestError(msg) from exc

        elapsed_ms = max(1, int((time.perf_counter() - started) * 1000))

        if response.status_code == 429:
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            msg = f"Kolejka {descriptor.name} zwróciła HTTP 429. Zatrzymano dalsze próby."
            if self._db is not None:
                self._cost_guard.record_rate_limit_429(
                    self._db,
                    descriptor.key,
                    retry_after_seconds=retry_after,
                    error_message=msg,
                )
            raise ProviderQuotaExceededError(msg)

        if response.status_code >= 400:
            msg = f"Błąd HTTP {response.status_code} z serwera {descriptor.name}."
            if self._db is not None:
                self._cost_guard.record_error(
                    self._db, descriptor.key, msg, status_code=response.status_code
                )
            raise ProviderRequestError(msg)

        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            body = response.json()
            raw_b64 = body.get("image_base64") or (body.get("images") or [""])[0]
            if not raw_b64:
                raise ProviderRequestError("Serwer ComfyUI nie zwrócił wygenerowanego obrazu.")
            image_bytes = base64.b64decode(raw_b64.split(",", 1)[-1])
        else:
            image_bytes = response.content

        mime_type = validate_image_magic_bytes(image_bytes)
        if self._db is not None:
            self._cost_guard.record_success(self._db, descriptor.key)

        return GeneratedImageResult(
            provider_key=descriptor.key,
            provider_name=descriptor.name,
            model=descriptor.model,
            mode=mode,
            image_bytes=image_bytes,
            mime_type=mime_type,
            width=width,
            height=height,
            used_image_to_image=used_image_to_image,
            geometry_preserved=preserve_geometry,
            is_conceptual=(mode == "idea_to_project"),
            prompt_used=prompt,
            response_time_ms=elapsed_ms,
        )


class GeminiImagenProvider(_BaseMultiEngineImageProvider):
    """
    Google Gemini / Imagen 3 image generation adapter.
    Strictly blocked under Zero-Cost Policy because Imagen 3 requires a billed account.
    """

    def is_key_configured(self) -> bool:
        return bool(self._settings.gemini_api_key.strip())

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="gemini_imagen",
            name="Google Imagen 3 (Gemini API)",
            role="Chmurowe generowanie obrazów (wymaga płatnego planu rozliczeniowego)",
            plan_type="Płatny (Pay-As-You-Go — niedostępny w darmowym planie Gemini bez bilingu)",
            model="imagen-3.0-generate-002",
            is_paid_endpoint=True,
            is_free_tier_confirmed=False,
            requires_micro_credits=False,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note=(
                "Zablokowany przez CostGuard: generowanie obrazów Imagen w Gemini API wymaga "
                "aktywnego planu płatnego (ALLOW_PAID_APIS=false)."
            ),
            is_verified=True,
            requires_api_key=True,
            is_local_engine=False,
        )

    def get_capabilities(self) -> ImageProviderCapabilities:
        return ImageProviderCapabilities(
            model="imagen-3.0-generate-002",
            is_truly_free=False,
            verification_status="verified_paid",
            known_limits="Płatny za każdy wygenerowany obraz (~$0.03–$0.04 / obraz)",
            supported_resolutions=["1024x1024", "1344x768"],
            supports_image_to_image=False,
            supports_geometry_preservation=False,
            hardware_requirements="Chmura Google (zablokowana przez politykę 0 zł)",
        )

    async def health_check(self) -> bool:
        return False

    async def generate(
        self,
        prompt: str,
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        descriptor = self.get_descriptor()
        if self._db is not None:
            self._cost_guard.assert_call_allowed(self._db, descriptor, self.is_key_configured())
        decision = self._cost_guard.evaluate_provider(descriptor, self.is_key_configured())
        raise CostPolicyViolation(decision.reason)

    async def image_to_image(
        self,
        prompt: str,
        reference_image_bytes: bytes,
        reference_mime_type: str = "image/png",
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        strength: float = 0.45,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        return await self.generate(
            prompt,
            mode=mode,
            aspect_ratio=aspect_ratio,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
        )


class OpenAIMultiImageProvider(_BaseMultiEngineImageProvider):
    """
    OpenAI Image API (gpt-image-1) — strictly blocked under Zero-Cost Policy.
    """

    def is_key_configured(self) -> bool:
        return bool(self._settings.openai_api_key.strip())

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="openai",
            name="OpenAI Image API (gpt-image-1)",
            role="Płatne generowanie i edycja obrazów (zablokowane)",
            plan_type="Płatny Pay-As-You-Go (brak planu darmowego)",
            model="gpt-image-1",
            is_paid_endpoint=True,
            is_free_tier_confirmed=False,
            requires_micro_credits=False,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note="Zablokowane przez centralną politykę Zero Kosztów (ALLOW_PAID_APIS=false).",
            is_verified=True,
            requires_api_key=True,
            is_local_engine=False,
        )

    def get_capabilities(self) -> ImageProviderCapabilities:
        return ImageProviderCapabilities(
            model="gpt-image-1",
            is_truly_free=False,
            verification_status="verified_paid",
            known_limits="Płatny Pay-As-You-Go (brak darmowego limitu)",
            supported_resolutions=["1024x1024", "1536x1024", "1024x1536"],
            supports_image_to_image=True,
            supports_geometry_preservation=True,
            hardware_requirements="Chmura OpenAI (zablokowana przez politykę 0 zł)",
        )

    async def health_check(self) -> bool:
        return False

    async def generate(
        self,
        prompt: str,
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        descriptor = self.get_descriptor()
        if self._db is not None:
            self._cost_guard.assert_call_allowed(self._db, descriptor, self.is_key_configured())
        decision = self._cost_guard.evaluate_provider(descriptor, self.is_key_configured())
        raise CostPolicyViolation(decision.reason)

    async def image_to_image(
        self,
        prompt: str,
        reference_image_bytes: bytes,
        reference_mime_type: str = "image/png",
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        strength: float = 0.45,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        return await self.generate(
            prompt,
            mode=mode,
            aspect_ratio=aspect_ratio,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
        )


class HuggingFaceMultiImageProvider(_BaseMultiEngineImageProvider):
    """
    Hugging Face Inference Providers — micro-credit tier (~$0.10/mo), blocked when ALLOW_HF_MICRO_FREE_CREDITS=false.
    """

    def is_key_configured(self) -> bool:
        return bool(self._settings.huggingface_api_token.strip())

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="huggingface",
            name="Hugging Face Inference Providers",
            role="Generowanie obrazów (jedynie mikro-kredyt ~$0.10/mies.)",
            plan_type="Darmowy mikro-kredyt (~$0.10/mies., brak stałego darmowego limitu)",
            model="black-forest-labs/FLUX.1-schnell",
            is_paid_endpoint=False,
            is_free_tier_confirmed=False,
            requires_micro_credits=True,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note=(
                "Wyłączony domyślnie (ALLOW_HF_MICRO_FREE_CREDITS=false). "
                "Po zużyciu $0.10 zwraca HTTP 402 Payment Required."
            ),
            is_verified=True,
            requires_api_key=True,
            is_local_engine=False,
        )

    def get_capabilities(self) -> ImageProviderCapabilities:
        return ImageProviderCapabilities(
            model="black-forest-labs/FLUX.1-schnell",
            is_truly_free=False,
            verification_status="verified_micro_credits",
            known_limits="Mikro-kredyt ~$0.10/mies., po wyczerpaniu HTTP 402",
            supported_resolutions=["1024x768", "1024x1024"],
            supports_image_to_image=False,
            supports_geometry_preservation=False,
            hardware_requirements="Chmura HF (wyłączona przy ALLOW_HF_MICRO_FREE_CREDITS=false)",
        )

    async def health_check(self) -> bool:
        return False

    async def generate(
        self,
        prompt: str,
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        descriptor = self.get_descriptor()
        if self._db is not None:
            self._cost_guard.assert_call_allowed(self._db, descriptor, self.is_key_configured())
        decision = self._cost_guard.evaluate_provider(descriptor, self.is_key_configured())
        raise CostPolicyViolation(decision.reason)

    async def image_to_image(
        self,
        prompt: str,
        reference_image_bytes: bytes,
        reference_mime_type: str = "image/png",
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        strength: float = 0.45,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        return await self.generate(
            prompt,
            mode=mode,
            aspect_ratio=aspect_ratio,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
        )


class UnverifiedCloudImageProvider(_BaseMultiEngineImageProvider):
    """
    Represents external community/third-party image endpoints without verified free terms,
    rate-limit SLA, privacy guarantees, or explicit billing protection.
    Strictly marked `is_verified=False` and blocked by CostGuard (`unverified_blocked`).
    """

    def is_key_configured(self) -> bool:
        return False

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="unverified_cloud_image",
            name="Zewnętrzne Niezweryfikowane API Obrazów",
            role="Zewnętrzny przekaźnik obrazów bez formalnej weryfikacji regulaminu i bilingu",
            plan_type="Niezweryfikowany (brak gwarancji darmowości, limitów i poufności szkiców)",
            model="unverified-external-diffusion",
            is_paid_endpoint=False,
            is_free_tier_confirmed=False,
            requires_micro_credits=False,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note=(
                "Zablokowany przez CostGuard (status: unverified_blocked). "
                "Brak udokumentowanych warunków darmowego użytku i polityki bilingowej."
            ),
            is_verified=False,
            requires_api_key=False,
            is_local_engine=False,
        )

    def get_capabilities(self) -> ImageProviderCapabilities:
        return ImageProviderCapabilities(
            model="unverified-external-diffusion",
            is_truly_free=False,
            verification_status="unverified",
            known_limits="Nieznane limity oraz brak gwarancji braku ukrytych kosztów",
            supported_resolutions=["1024x768"],
            supports_image_to_image=False,
            supports_geometry_preservation=False,
            hardware_requirements="Zewnętrzna usługa niezweryfikowana (zablokowana)",
        )

    async def health_check(self) -> bool:
        return False

    async def generate(
        self,
        prompt: str,
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        descriptor = self.get_descriptor()
        if self._db is not None:
            self._cost_guard.assert_call_allowed(self._db, descriptor, self.is_key_configured())
        decision = self._cost_guard.evaluate_provider(descriptor, self.is_key_configured())
        raise CostPolicyViolation(decision.reason)

    async def image_to_image(
        self,
        prompt: str,
        reference_image_bytes: bytes,
        reference_mime_type: str = "image/png",
        *,
        mode: str = "sketch_to_render",
        aspect_ratio: str = "16:9",
        preserve_geometry: bool = True,
        strength: float = 0.45,
        width: int = 1024,
        height: int = 768,
    ) -> GeneratedImageResult:
        return await self.generate(
            prompt,
            mode=mode,
            aspect_ratio=aspect_ratio,
            preserve_geometry=preserve_geometry,
            width=width,
            height=height,
        )


def build_default_image_providers(
    settings: Settings,
    cost_guard: CostGuard,
    db: Optional[Session] = None,
    transport: Optional[httpx.AsyncBaseTransport] = None,
) -> List[ImageGenerationProvider]:
    return [
        LocalSDWebUIImageProvider(settings, cost_guard, db=db, transport=transport),
        LocalComfyUIImageProvider(settings, cost_guard, db=db, transport=transport),
        GeminiImagenProvider(settings, cost_guard, db=db, transport=transport),
        OpenAIMultiImageProvider(settings, cost_guard, db=db, transport=transport),
        HuggingFaceMultiImageProvider(settings, cost_guard, db=db, transport=transport),
        UnverifiedCloudImageProvider(settings, cost_guard, db=db, transport=transport),
    ]
