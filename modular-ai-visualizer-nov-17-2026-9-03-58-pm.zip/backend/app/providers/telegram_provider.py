from app.core.config import Settings
from app.core.cost_guard import ProviderDescriptor
from app.providers.base import MessagingProvider


class TelegramBotProvider(MessagingProvider):
    """Adapter boundary for future Telegram Bot workflow integration (inactive)."""

    def __init__(self, settings: Settings) -> None:
        self._token = settings.telegram_bot_token.strip()

    def is_key_configured(self) -> bool:
        return bool(self._token)

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="telegram",
            name="Telegram Bot API",
            role="Zdalne przesyłanie szkiców i odbieranie wizualizacji (nieaktywny)",
            plan_type="Darmowe API komunikacyjne (moduł nieaktywny w tym etapie)",
            model="bot-webhook-placeholder",
            is_paid_endpoint=False,
            is_free_tier_confirmed=False,
            requires_micro_credits=False,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note="Integracja Telegrama jest wyłączona w Etapie 2.5.",
        )
