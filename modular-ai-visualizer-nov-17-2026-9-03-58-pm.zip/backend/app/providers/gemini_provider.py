import time
from typing import Any, Dict, Optional

import httpx
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.cost_guard import (
    CostGuard,
    ProviderDescriptor,
    ProviderQuotaExceededError,
    ProviderRequestError,
    ProviderTimeoutError,
    sanitize_sensitive_text,
)
from app.providers.base import VisionAnalyzerProvider


def _parse_retry_after(header_val: Optional[str]) -> Optional[int]:
    if not header_val:
        return None
    try:
        parsed = int(header_val.strip())
        return parsed if parsed > 0 else None
    except ValueError:
        return None


def _extract_gemini_text(data: Dict[str, Any]) -> str:
    candidates = data.get("candidates") or []
    if not candidates:
        return ""
    content = candidates[0].get("content") or {}
    parts = content.get("parts") or []
    chunks: list[str] = []
    for part in parts:
        if isinstance(part, dict) and not part.get("thought") and isinstance(part.get("text"), str):
            chunks.append(part["text"])
    return "\n".join(chunks).strip()


class GeminiProvider(VisionAnalyzerProvider):
    """Free-tier adapter for Google Gemini image/sketch and text analysis."""

    def __init__(
        self,
        settings: Settings,
        cost_guard: CostGuard,
        db: Optional[Session] = None,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ) -> None:
        self._settings = settings
        self._cost_guard = cost_guard
        self._db = db
        self._transport = transport

    def is_key_configured(self) -> bool:
        return bool(self._settings.gemini_api_key.strip())

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="gemini",
            name="Google Gemini API",
            role="Analiza obrazów, szkiców i briefów tekstowych (bez generowania obrazów)",
            plan_type="Oficjalny Free Tier (bez karty płatniczej)",
            model=self._settings.gemini_vision_model,
            is_paid_endpoint=False,
            is_free_tier_confirmed=True,
            requires_micro_credits=False,
            rpm_limit=self._settings.gemini_rpm_limit,
            rpd_limit=self._settings.gemini_rpd_limit,
            configured_limits_note=(
                f"Konfigurowalne progi lokalne: {self._settings.gemini_rpm_limit} RPM / "
                f"{self._settings.gemini_rpd_limit} RPD (brak oficjalnego API salda)."
            ),
        )

    async def analyze_sketch(
        self,
        prompt: str,
        image_base64: str | None = None,
        preserve_geometry: bool = True,
        image_mime_type: str = "image/jpeg",
        system_instruction: Optional[str] = None,
        response_mime_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        if self._db is None:
            raise RuntimeError("Sesja bazy danych jest wymagana przed wywołaniem dostawcy AI.")

        descriptor = self.get_descriptor()
        self._cost_guard.assert_call_allowed(self._db, descriptor, self.is_key_configured())

        parts: list[dict[str, Any]] = [
            {
                "text": (
                    f"{prompt}\nZachowaj geometrię oryginalnego szkicu: "
                    f"{'TAK — BEZWZGLĘDNY GEOMETRY LOCK (zachowaj obrys, ściany, wszystkie okna, wszystkie drzwi i układ pomieszczeń)' if preserve_geometry else 'ELASTYCZNIE'}."
                )
            }
        ]
        if image_base64:
            parts.append(
                {
                    "inline_data": {
                        "mime_type": image_mime_type,
                        "data": image_base64,
                    }
                }
            )

        payload: Dict[str, Any] = {"contents": [{"parts": parts}]}
        if system_instruction:
            payload["system_instruction"] = {"parts": [{"text": system_instruction}]}
        if response_mime_type:
            payload["generationConfig"] = {"responseMimeType": response_mime_type}

        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{descriptor.model}:generateContent"
        )
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self._settings.gemini_api_key.strip(),
        }

        started = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=30.0, transport=self._transport) as client:
                response = await client.post(url, headers=headers, json=payload)
        except httpx.TimeoutException as exc:
            msg = "Przekroczono czas oczekiwania na odpowiedź Google Gemini API."
            self._cost_guard.record_error(self._db, descriptor.key, msg, status_code=504)
            raise ProviderTimeoutError(msg) from exc
        except httpx.RequestError as exc:
            msg = "Błąd połączenia sieciowego podczas wywołania Google Gemini API."
            self._cost_guard.record_error(self._db, descriptor.key, msg, status_code=502)
            raise ProviderRequestError(msg) from exc

        elapsed_ms = max(1, int(round((time.perf_counter() - started) * 1000)))

        if response.status_code == 429:
            retry_after = _parse_retry_after(response.headers.get("retry-after"))
            self._cost_guard.record_rate_limit_429(
                self._db,
                descriptor.key,
                retry_after_seconds=retry_after,
                error_message="Google Gemini Free Tier: osiągnięto limit zapytań (HTTP 429).",
            )
            raise ProviderQuotaExceededError(
                "Limit darmowego planu Google Gemini został wyczerpany (HTTP 429). "
                "Zatrzymano kolejne próby i aktywowano cooldown."
            )

        if response.status_code >= 400:
            raw_err = ""
            try:
                err_json = response.json()
                raw_err = str((err_json.get("error") or {}).get("message") or "")
            except Exception:
                raw_err = ""
            safe_detail = sanitize_sensitive_text(
                raw_err[:200],
                secrets=[self._settings.gemini_api_key],
            )
            msg = (
                f"Google Gemini API zwróciło błąd HTTP {response.status_code}"
                + (f" ({safe_detail})." if safe_detail else ".")
            )
            self._cost_guard.record_error(self._db, descriptor.key, msg, response.status_code)
            raise ProviderRequestError(msg)

        self._cost_guard.record_success(self._db, descriptor.key)
        data = response.json()
        return {
            "provider": descriptor.key,
            "model": descriptor.model,
            "text": _extract_gemini_text(data),
            "response_time_ms": elapsed_ms,
            "raw": data,
        }
