from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.cost_guard import CostGuard, CostPolicyViolation, ProviderDescriptor
from app.providers.base import ImageGeneratorProvider, ImageGeneratorStatus


class HuggingFaceImageProvider(ImageGeneratorProvider):
    """Hugging Face Inference Providers — micro-credit tier (~$0.10/mo), blocked by default."""

    def __init__(
        self,
        settings: Settings,
        cost_guard: CostGuard,
        db: Optional[Session] = None,
    ) -> None:
        self._settings = settings
        self._cost_guard = cost_guard
        self._db = db

    def is_key_configured(self) -> bool:
        return bool(self._settings.huggingface_api_token.strip())

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="huggingface",
            name="Hugging Face Inference Providers",
            role="Generowanie obrazów (jedynie mikro-kredyt ~$0.10/mies.)",
            plan_type="Darmowy mikro-kredyt (~$0.10/mies., brak stałego darmowego limitu)",
            model="konfigurowalny (zablokowany przy ALLOW_HF_MICRO_FREE_CREDITS=false)",
            is_paid_endpoint=False,
            is_free_tier_confirmed=False,
            requires_micro_credits=True,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note=(
                "Wyłączony domyślnie (ALLOW_HF_MICRO_FREE_CREDITS=false). "
                "Po zużyciu $0.10 zwraca HTTP 402 Payment Required."
            ),
        )

    def get_generation_status(self) -> ImageGeneratorStatus:
        if not self._settings.allow_hf_micro_free_credits:
            return "disabled_by_cost_policy"
        return "unavailable_free"

    async def generate_visualization(
        self,
        prompt: str,
        reference_image_paths: List[str],
        aspect_ratio: str = "16:9",
    ) -> Dict[str, Any]:
        descriptor = self.get_descriptor()
        if self._db is not None:
            self._cost_guard.assert_call_allowed(self._db, descriptor, self.is_key_configured())
        decision = self._cost_guard.evaluate_provider(descriptor, self.is_key_configured())
        raise CostPolicyViolation(decision.reason)
