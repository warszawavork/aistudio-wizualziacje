from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.cost_guard import CostGuard, CostPolicyViolation, ProviderDescriptor
from app.providers.base import ImageGeneratorProvider, ImageGeneratorStatus


class OpenAIImageProvider(ImageGeneratorProvider):
    """Paid image generation adapter — strictly blocked by Zero-Cost Policy."""

    def __init__(
        self,
        settings: Settings,
        cost_guard: CostGuard,
        db: Optional[Session] = None,
    ) -> None:
        self._settings = settings
        self._cost_guard = cost_guard
        self._db = db

    def is_key_configured(self) -> bool:
        return bool(self._settings.openai_api_key.strip())

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="openai",
            name="OpenAI Image API",
            role="Płatne generowanie i edycja obrazów (zablokowane)",
            plan_type="Płatny Pay-As-You-Go (brak planu darmowego)",
            model="gpt-image-1",
            is_paid_endpoint=True,
            is_free_tier_confirmed=False,
            requires_micro_credits=False,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note="Zablokowane przez centralną politykę Zero Kosztów (ALLOW_PAID_APIS=false).",
        )

    def get_generation_status(self) -> ImageGeneratorStatus:
        if self._cost_guard.paid_apis_blocked:
            return "disabled_by_cost_policy"
        return "provider_error"

    async def generate_visualization(
        self,
        prompt: str,
        reference_image_paths: List[str],
        aspect_ratio: str = "16:9",
    ) -> Dict[str, Any]:
        descriptor = self.get_descriptor()
        if self._db is not None:
            self._cost_guard.assert_call_allowed(self._db, descriptor, self.is_key_configured())
        decision = self._cost_guard.evaluate_provider(descriptor, self.is_key_configured())
        raise CostPolicyViolation(decision.reason)
