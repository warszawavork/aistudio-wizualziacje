from typing import Any, Dict, List

from app.core.cost_guard import ProviderDescriptor
from app.providers.base import ImageGeneratorProvider, ImageGeneratorStatus


class FreeImageGeneratorProvider(ImageGeneratorProvider):
    """
    Zero-cost image generator boundary.
    Returns `unavailable_free` honestly until a verified, truly free image API is connected,
    preserving sketch, analysis, and prompt without generating fake renders.
    """

    def is_key_configured(self) -> bool:
        return False

    def get_descriptor(self) -> ProviderDescriptor:
        return ProviderDescriptor(
            key="free_image_generator",
            name="Darmowy Generator Obrazów",
            role="Fotorealistyczna wizualizacja architektoniczna (oczekuje na darmowy model)",
            plan_type="Brak potwierdzonego darmowego API chmurowego (budżet 0 zł)",
            model="brak aktywnego modelu darmowego",
            is_paid_endpoint=False,
            is_free_tier_confirmed=False,
            requires_micro_credits=False,
            rpm_limit=None,
            rpd_limit=None,
            configured_limits_note=(
                "Gemini/Imagen i OpenAI wymagają płatności. Szkic, analiza i prompt są zachowywane w SQLite."
            ),
        )

    def get_generation_status(self) -> ImageGeneratorStatus:
        return "unavailable_free"

    async def generate_visualization(
        self,
        prompt: str,
        reference_image_paths: List[str],
        aspect_ratio: str = "16:9",
    ) -> Dict[str, Any]:
        return {
            "status": self.get_generation_status(),
            "generated_image_url": None,
            "message": (
                "Brak potwierdzonej darmowej usługi generowania obrazów API przy budżecie 0 zł. "
                "Szkic, analiza oraz prompt zostały zachowane w projekcie — możesz wrócić do "
                "generowania po podłączeniu darmowego generatora."
            ),
            "preserved_prompt": prompt,
            "preserved_references": reference_image_paths,
            "aspect_ratio": aspect_ratio,
        }
