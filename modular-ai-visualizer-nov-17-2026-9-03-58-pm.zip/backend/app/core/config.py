from functools import lru_cache
from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


ROOT_DIR = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    app_name: str = "Modular AI Visualizer"
    app_env: str = "development"
    app_stage: str = "stage_2_5_zero_cost_foundation"
    api_prefix: str = "/api"

    database_url: str = f"sqlite:///{(ROOT_DIR / 'storage' / 'modular_visualizer.db').as_posix()}"
    storage_dir: str = str(ROOT_DIR / "storage")
    cors_origins: str = (
        "http://localhost:3000,http://localhost:5173,"
        "http://127.0.0.1:3000,http://127.0.0.1:5173,http://127.0.0.1:8011"
    )

    # Central Zero-Cost Policy defaults (strictly free, 0 budget)
    free_only: bool = True
    allow_paid_apis: bool = False
    monthly_budget: float = 0.0
    allow_hf_micro_free_credits: bool = False
    default_cooldown_seconds: int = 60

    # Free-tier provider credentials & configurable models/limits (never hardcoded secrets)
    gemini_api_key: str = ""
    gemini_vision_model: str = "gemini-3.1-flash-lite"
    gemini_rpm_limit: int = 10
    gemini_rpd_limit: int = 500

    groq_api_key: str = ""
    groq_vision_model: str = "meta-llama/llama-4-scout-17b-16e-instruct"
    groq_rpm_limit: int = 30
    groq_rpd_limit: int = 1000

    # Paid / micro-credit / future keys (blocked by default under Zero-Cost Policy)
    huggingface_api_token: str = ""
    openai_api_key: str = ""
    telegram_bot_token: str = ""

    # Local zero-cost image generation engines (only used when running locally and reachable)
    comfyui_base_url: str = "http://127.0.0.1:8188"
    comfyui_model_name: str = "sd_xl_base_1.0.safetensors"
    sd_webui_base_url: str = "http://127.0.0.1:7860"
    sd_webui_model_name: str = "sd_xl_base_1.0"
    image_gen_timeout_seconds: float = 30.0

    model_config = SettingsConfigDict(
        env_file=str(ROOT_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def cors_origin_list(self) -> List[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def storage_path(self) -> Path:
        path = Path(self.storage_dir)
        if not path.is_absolute():
            path = ROOT_DIR / path
        return path


@lru_cache
def get_settings() -> Settings:
    return Settings()
