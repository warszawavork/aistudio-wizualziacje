import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional, Sequence

from sqlalchemy.orm import Session

from app.core.config import Settings
from app.models.provider_usage import ProviderUsageState


class CostPolicyViolation(RuntimeError):
    """Raised whenever an operation would use a paid or unconfirmed endpoint under Zero-Cost Policy."""


class ProviderQuotaExceededError(RuntimeError):
    """Raised when a free-tier provider hits a 429 cooldown or local daily limit."""


class ProviderTimeoutError(RuntimeError):
    """Raised when a free-tier provider times out without performing automatic retries."""


class ProviderRequestError(RuntimeError):
    """Raised when a network/transport error occurs while contacting a free-tier provider."""


class ProviderKeyMissingError(RuntimeError):
    """Raised when no free-tier provider has a backend API key configured."""


@dataclass(frozen=True)
class ProviderDescriptor:
    key: str
    name: str
    role: str
    plan_type: str
    model: str
    is_paid_endpoint: bool
    is_free_tier_confirmed: bool
    requires_micro_credits: bool
    rpm_limit: Optional[int]
    rpd_limit: Optional[int]
    configured_limits_note: str
    is_verified: bool = True
    requires_api_key: bool = True
    is_local_engine: bool = False


@dataclass(frozen=True)
class CostCheckDecision:
    allowed: bool
    availability_status: str
    blocked_by_cost_policy: bool
    reason: str
    cooldown_until: Optional[datetime] = None


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _ensure_aware_utc(dt: Optional[datetime]) -> Optional[datetime]:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


_SECRET_PATTERNS = (
    re.compile(r"AIza[0-9A-Za-z\-_]{8,}"),
    re.compile(r"gsk_[0-9A-Za-z\-_]{8,}"),
    re.compile(r"sk-[0-9A-Za-z\-_]{8,}"),
    re.compile(r"hf_[0-9A-Za-z\-_]{8,}"),
    re.compile(r"(Bearer\s+)[0-9A-Za-z\-_.]{6,}", flags=re.IGNORECASE),
)


def sanitize_sensitive_text(text: str, secrets: Sequence[str] = ()) -> str:
    cleaned = str(text or "")
    for secret in secrets:
        s = str(secret or "").strip()
        if s:
            cleaned = cleaned.replace(s, "[REDACTED]")
    for idx, pattern in enumerate(_SECRET_PATTERNS):
        if idx == len(_SECRET_PATTERNS) - 1:
            cleaned = pattern.sub(r"\1[REDACTED]", cleaned)
        else:
            cleaned = pattern.sub("[REDACTED]", cleaned)
    return cleaned


class CostGuard:
    """Central zero-cost enforcement gate checked before any external provider call."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    @property
    def paid_apis_blocked(self) -> bool:
        return (
            self.settings.free_only
            or not self.settings.allow_paid_apis
            or self.settings.monthly_budget <= 0
        )

    def get_or_create_usage(self, db: Session, provider_key: str) -> ProviderUsageState:
        today = _utcnow().strftime("%Y-%m-%d")
        record = db.get(ProviderUsageState, provider_key)
        if record is None:
            record = ProviderUsageState(
                provider_key=provider_key,
                calls_total=0,
                calls_today=0,
                usage_date=today,
                last_error="",
            )
            db.add(record)
            db.flush()
        elif record.usage_date != today:
            record.calls_today = 0
            record.usage_date = today
            db.flush()
        return record

    def evaluate_provider(
        self,
        descriptor: ProviderDescriptor,
        api_key_configured: bool,
        usage: Optional[ProviderUsageState] = None,
        now: Optional[datetime] = None,
        local_service_reachable: bool = True,
    ) -> CostCheckDecision:
        current_time = now or _utcnow()

        # 1. Hard block on paid endpoints when zero-cost policy is active
        if self.paid_apis_blocked and descriptor.is_paid_endpoint:
            return CostCheckDecision(
                allowed=False,
                availability_status="disabled_by_cost_policy",
                blocked_by_cost_policy=True,
                reason=(
                    f"Dostawca {descriptor.name} jest zablokowany przez politykę Zero Kosztów "
                    "(FREE_ONLY=true, ALLOW_PAID_APIS=false, MONTHLY_BUDGET=0)."
                ),
            )

        # 2. Hard block on unverified external endpoints (unknown terms, limits, or billing)
        if self.paid_apis_blocked and not descriptor.is_verified:
            return CostCheckDecision(
                allowed=False,
                availability_status="unverified_blocked",
                blocked_by_cost_policy=True,
                reason=(
                    f"Dostawca {descriptor.name} ma status niezweryfikowany (brak potwierdzonych "
                    "warunków darmowego planu, limitów lub gwarancji braku opłat) i został "
                    "zablokowany przez CostGuard."
                ),
            )

        # 3. Block micro-credit endpoints (e.g., HF $0.10/mo) unless explicitly permitted
        if descriptor.requires_micro_credits and not self.settings.allow_hf_micro_free_credits:
            return CostCheckDecision(
                allowed=False,
                availability_status="disabled_by_cost_policy",
                blocked_by_cost_policy=True,
                reason=(
                    f"{descriptor.name} wyłączony domyślnie (ALLOW_HF_MICRO_FREE_CREDITS=false). "
                    "Symboliczny kredyt miesięczny nie zapewnia stabilnego darmowego generowania."
                ),
            )

        # 4. Never allow an endpoint unless free tier is explicitly confirmed
        if not descriptor.is_free_tier_confirmed and self.paid_apis_blocked:
            return CostCheckDecision(
                allowed=False,
                availability_status="unavailable_free",
                blocked_by_cost_policy=True,
                reason=(
                    f"Brak potwierdzonego darmowego planu API dla {descriptor.name}. "
                    "Wywołanie zablokowane, aby uniknąć niejawnych opłat."
                ),
            )

        # 5. For local engines, check if local service is actually reachable
        if descriptor.is_local_engine and not local_service_reachable:
            return CostCheckDecision(
                allowed=False,
                availability_status="unavailable_free",
                blocked_by_cost_policy=False,
                reason=(
                    f"Lokalny silnik {descriptor.name} jest niedostępny (brak uruchomionego serwera "
                    "lokalnego lub brak GPU/VRAM w środowisku uruchomieniowym)."
                ),
            )

        # 6. Require key in backend environment when applicable
        if descriptor.requires_api_key and not api_key_configured:
            return CostCheckDecision(
                allowed=False,
                availability_status="missing_api_key",
                blocked_by_cost_policy=False,
                reason=f"Brak skonfigurowanego klucza w zmiennych środowiskowych backendu dla {descriptor.name}.",
            )

        # 7. Enforce 429 cooldown without retries or paid fallback
        if usage is not None:
            cooldown_until = _ensure_aware_utc(usage.cooldown_until)
            if cooldown_until is not None and cooldown_until > current_time:
                return CostCheckDecision(
                    allowed=False,
                    availability_status="cooldown",
                    blocked_by_cost_policy=False,
                    reason=(
                        f"Limit zapytań {descriptor.name} został chwilowo wyczerpany. "
                        f"Oczekiwanie na odnowienie limitu do {cooldown_until.isoformat()}."
                    ),
                    cooldown_until=cooldown_until,
                )

            if (
                descriptor.rpd_limit is not None
                and descriptor.rpd_limit > 0
                and usage.calls_today >= descriptor.rpd_limit
            ):
                return CostCheckDecision(
                    allowed=False,
                    availability_status="local_limit_reached",
                    blocked_by_cost_policy=False,
                    reason=(
                        f"Osiągnięto skonfigurowany lokalny limit dzienny aplikacji "
                        f"({usage.calls_today}/{descriptor.rpd_limit}) dla {descriptor.name}."
                    ),
                )

        return CostCheckDecision(
            allowed=True,
            availability_status="available_free",
            blocked_by_cost_policy=False,
            reason=f"Dostawca {descriptor.name} gotowy w ramach potwierdzonego darmowego planu.",
        )

    def assert_call_allowed(
        self,
        db: Session,
        descriptor: ProviderDescriptor,
        api_key_configured: bool,
        local_service_reachable: bool = True,
    ) -> ProviderUsageState:
        usage = self.get_or_create_usage(db, descriptor.key)
        decision = self.evaluate_provider(
            descriptor,
            api_key_configured,
            usage=usage,
            local_service_reachable=local_service_reachable,
        )
        if not decision.allowed:
            if decision.blocked_by_cost_policy:
                raise CostPolicyViolation(decision.reason)
            if decision.availability_status == "missing_api_key":
                raise ProviderKeyMissingError(decision.reason)
            if decision.availability_status in {"cooldown", "local_limit_reached"}:
                raise ProviderQuotaExceededError(decision.reason)
            if decision.availability_status == "unavailable_free":
                raise ProviderRequestError(decision.reason)
            raise CostPolicyViolation(decision.reason)
        return usage

    def record_success(self, db: Session, provider_key: str) -> ProviderUsageState:
        now = _utcnow()
        usage = self.get_or_create_usage(db, provider_key)
        usage.calls_today += 1
        usage.calls_total += 1
        usage.last_called_at = now
        usage.last_error = ""
        usage.last_error_code = None
        usage.cooldown_until = None
        db.commit()
        db.refresh(usage)
        return usage

    def record_rate_limit_429(
        self,
        db: Session,
        provider_key: str,
        retry_after_seconds: Optional[int] = None,
        error_message: str = "HTTP 429: Limit darmowego planu wyczerpany.",
    ) -> ProviderUsageState:
        now = _utcnow()
        cooldown_secs = (
            retry_after_seconds
            if retry_after_seconds is not None and retry_after_seconds > 0
            else self.settings.default_cooldown_seconds
        )
        usage = self.get_or_create_usage(db, provider_key)
        usage.last_error = error_message[:500]
        usage.last_error_code = 429
        usage.cooldown_until = now + timedelta(seconds=cooldown_secs)
        usage.last_called_at = now
        db.commit()
        db.refresh(usage)
        return usage

    def record_error(
        self,
        db: Session,
        provider_key: str,
        error_message: str,
        status_code: Optional[int] = None,
    ) -> ProviderUsageState:
        now = _utcnow()
        usage = self.get_or_create_usage(db, provider_key)
        usage.last_error = error_message[:500]
        usage.last_error_code = status_code
        usage.last_called_at = now
        db.commit()
        db.refresh(usage)
        return usage
