"""Core application configuration."""
