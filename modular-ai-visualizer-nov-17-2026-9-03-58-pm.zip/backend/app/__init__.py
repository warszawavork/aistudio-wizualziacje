"""Modular AI Visualizer backend package."""
