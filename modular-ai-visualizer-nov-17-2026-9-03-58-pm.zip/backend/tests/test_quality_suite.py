"""
Etap 3.3 architectural quality evaluation, provider comparison, and SQLite legacy migration tests.
NOTE: Tests using httpx.MockTransport verify prompt structure, parsing, quality evaluator,
Zero-Cost routing, and persistence deterministically without real upstream API keys;
they do NOT evaluate real upstream Gemini/Groq model reasoning quality.
"""

import asyncio
import json
import os
import sqlite3
import sys
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.config import Settings, get_settings  # noqa: E402
from app.core.cost_guard import CostGuard  # noqa: E402
from app.db.database import ensure_sqlite_schema_migrations  # noqa: E402
from app.main import create_app  # noqa: E402
from app.providers.gemini_provider import GeminiProvider  # noqa: E402
from app.providers.groq_provider import GroqProvider  # noqa: E402
from app.schemas.analysis import (  # noqa: E402
    AnalysisContentFields,
    DEFAULT_ARCHITECTURAL_DISCLAIMER,
    GeometryAnalysis,
    GeometryProtectionRules,
    OpeningAnalysisItem,
    RoomAnalysisItem,
    UncertaintyItem,
)
from app.services.provider_router import ProviderRouter, SelectedVisionProvider  # noqa: E402
from app.services.quality_benchmark_service import (  # noqa: E402
    build_minimal_png_bytes,
    compare_providers_across_suite,
    evaluate_analysis_quality,
    get_default_benchmark_cases,
    run_safe_provider_comparison,
)


def _mock_structured_payload_for_case(case_id: str) -> dict:
    common_disclaimer = DEFAULT_ARCHITECTURAL_DISCLAIMER
    if case_id == "simple_modular_plan":
        return {
            "summary": "Prosty rzut jednokondygnacyjnego domu modułowego o zwartym prostokątnym obrysie 48 m².",
            "spatial_layout": "Jeden moduł Nordic Graphite z wejściem od frontu prowadzącym do strefy dziennej.",
            "geometry": {
                "building_footprint": "Prostokątny pojedynczy moduł o zwartej bryle",
                "floors_count": "1 kondygnacja (parterowy)",
                "structural_vs_partition_walls": "Obwodowe ściany nośne modułu; ściany działowe przy strefie łazienki (niska pewność szczegółu).",
                "circulation": "Krótkie bezpośrednie wejście od frontu do strefy dziennej.",
                "proportions_and_scale": "Powierzchnia z formularza: 48 m², 1 moduł.",
                "confidence": "wysoka pewność",
            },
            "rooms": [
                {
                    "name": "Strefa dzienna z aneksem",
                    "zone": "strefa dzienna",
                    "approximate_area": "brak szczegółowego rozbicia na rysunku (całość 48 m²)",
                    "spatial_relations": "Bezpośrednio przy wejściu głównym",
                    "confidence": "średnia pewność",
                },
                {
                    "name": "Łazienka",
                    "zone": "pomocnicza",
                    "approximate_area": "brak wymiarów na materiale",
                    "spatial_relations": "Wydzielona przy strefie wejścia",
                    "confidence": "średnia pewność",
                },
            ],
            "openings": [
                {
                    "category": "drzwi wejściowe",
                    "location": "Ściana frontowa",
                    "opening_direction": "niemożliwe do ustalenia na podstawie materiału",
                    "notes": "Główne wejście do modułu",
                    "confidence": "wysoka pewność",
                },
                {
                    "category": "okno",
                    "location": "Elewacja ogrodowa",
                    "opening_direction": "niemożliwe do ustalenia na podstawie materiału",
                    "notes": "Doświetlenie strefy dziennej",
                    "confidence": "średnia pewność",
                },
            ],
            "materials_proposal": "Elewacja Nordic Graphite: blacha na rąbek grafitowy, okładzina drewniana, panele podłogowe dębowe, sufit ze sklejki.",
            "lighting_proposal": "Światło dzienne rozproszone oraz ciepłe oświetlenie 2700K we wnętrzu i przy wejściu.",
            "geometry_protection": {
                "must_preserve": ["Prostokątny obrys 1 modułu i oś wejścia frontowego"],
                "can_change": ["Kolorystyka detali wykończeniowych i zieleń wokół modułu"],
                "forbidden_changes": ["Przesuwanie drzwi wejściowych i okien, dokładanie drugiego modułu"],
            },
            "geometry_preservation_note": "Zachować obrys 1 modułu i wejście od frontu bez zmiany proporcji.",
            "visualization_prompt": "Photorealistic Nordic Graphite single modular house 48 sqm preserving exact sketch geometry and front entrance layout.",
            "uncertainties": [
                {
                    "element": "Kierunek otwierania drzwi wejściowych",
                    "confidence": "niemożliwe do ustalenia na podstawie materiału",
                    "reason": "Brak wyraźnego łuku otwierania skrzydła na szkicu.",
                }
            ],
            "user_requirements": ["Powierzchnia 48 m²", "1 moduł", "Wejście od frontu", "Styl Nordic Graphite"],
            "ai_suggestions": ["Zastosowanie jasnego sufitu dla optycznego powiększenia wnętrza"],
            "clarification_questions": ["Jaka jest szerokość i wysokość drzwi wejściowych?"],
            "disclaimer": common_disclaimer,
        }

    if case_id == "multi_room_modular_plan":
        return {
            "summary": "Pawilon dwumodułowy 76 m² w stylu Raw Steel & Cedar z podziałem na strefę dzienną i nocną.",
            "spatial_layout": "Moduł dzienny połączony korytarzem z dwiema sypialniami i łazienką w drugim module.",
            "geometry": {
                "building_footprint": "Układ dwóch połączonych modułów (76 m²)",
                "floors_count": "1 kondygnacja",
                "structural_vs_partition_walls": "Ramy obwodowe dwóch modułów jako ściany nośne; przegrody między sypialniami i łazienką jako ściany działowe.",
                "circulation": "Oś korytarza łącząca strefę dzienną z dwiema sypialniami i łazienką.",
                "proportions_and_scale": "76 m², 2 moduły zgodnie z danymi formularza.",
                "confidence": "średnia pewność",
            },
            "rooms": [
                {"name": "Strefa dzienna z kuchnią", "zone": "strefa dzienna", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Moduł I", "confidence": "wysoka pewność"},
                {"name": "Sypialnia 1", "zone": "strefa nocna", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Dostęp z korytarza", "confidence": "średnia pewność"},
                {"name": "Sypialnia 2", "zone": "strefa nocna", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Dostęp z korytarza", "confidence": "średnia pewność"},
                {"name": "Łazienka", "zone": "pomocnicza", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Pomiędzy sypialniami", "confidence": "średnia pewność"},
            ],
            "openings": [
                {"category": "drzwi wewnętrzne", "location": "Korytarz → sypialnie i łazienka", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "notes": "3 pary drzwi wewnętrznych", "confidence": "średnia pewność"},
                {"category": "drzwi wejściowe", "location": "Strefa wejściowa", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "notes": "Wejście przy osi komunikacji", "confidence": "średnia pewność"},
            ],
            "materials_proposal": "Elewacja: surowa stal i cedr kanadyjski (Raw Steel & Cedar); podłogi dębowe, łazienka w płytkach gresowych, sufity z deski.",
            "lighting_proposal": "Światło dzienne przez przeszklenia dzienne oraz liniowe oprawy korytarzowe.",
            "geometry_protection": {
                "must_preserve": ["Układ 2 modułów i oś komunikacyjna do 2 sypialni i łazienki"],
                "can_change": ["Odcień cedru i detale opraw oświetleniowych"],
                "forbidden_changes": ["Łączenie sypialni w jedno pomieszczenie lub przesuwanie osi korytarza"],
            },
            "geometry_preservation_note": "Nie zmieniać układu 2 modułów ani rozmieszczenia otworów drzwiowych.",
            "visualization_prompt": "Architectural render in Raw Steel & Cedar style preserving exact two-module sketch layout and corridor alignment.",
            "uncertainties": [
                {"element": "Grubość ścian wewnętrznych", "confidence": "niska pewność", "reason": "Szkic koncepcyjny bez szczegółowego wymiarowania przegród."}
            ],
            "user_requirements": ["76 m²", "2 moduły", "Strefa dzienna, dwie sypialnie, łazienka", "Raw Steel & Cedar"],
            "ai_suggestions": ["Wyciszenie ścian działowych między sypialniami wełną mineralną"],
            "clarification_questions": ["Czy łazienka ma posiadać okno zewnętrzne?"],
            "disclaimer": common_disclaimer,
        }

    if case_id == "large_glazing_plan":
        return {
            "summary": "Dom modułowy 68 m² z rozbudowaną strefą przeszkleń tarasowych HS od strony południowej.",
            "spatial_layout": "Salon otwarty dużym przeszkleniem HS na podcień tarasu bez słupków pośrednich.",
            "geometry": {
                "building_footprint": "Dwumodułowa bryła z podcieniem tarasowym",
                "floors_count": "1 kondygnacja",
                "structural_vs_partition_walls": "Nadproże tarasowe w strefie dużych przeszkleń wymaga indywidualnych obliczeń konstrukcyjnych.",
                "circulation": "Bezpośrednie wyjście z salonu na taras przez przeszklenie HS.",
                "proportions_and_scale": "68 m², 2 moduły.",
                "confidence": "średnia pewność",
            },
            "rooms": [
                {"name": "Salon z wyjściem na taras", "zone": "strefa dzienna", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Wzdłuż elewacji z przeszkleniem HS", "confidence": "wysoka pewność"},
            ],
            "openings": [
                {"category": "przeszklenie", "location": "Elewacja południowa (salon → taras)", "opening_direction": "przesuwne HS (bez słupka pośredniego wg uwag)", "notes": "Główne przeszklenie tarasowe", "confidence": "wysoka pewność"},
            ],
            "materials_proposal": "Nordic Graphite: aluminiowe ramy HS w kolorze antracytowym, deska tarasowa z modrzewia, beton architektoniczny.",
            "lighting_proposal": "Silne doświetlenie naturalne od południa i ciepłe oprawy podcienia tarasu.",
            "geometry_protection": {
                "must_preserve": ["Szerokie przeszklenie HS na osi salonu oraz podcień tarasowy"],
                "can_change": ["Odcień deski tarasowej i aranżacja mebli tarasowych"],
                "forbidden_changes": ["Dzielenie przeszklenia HS na małe okna ani likwidacja podcienia"],
            },
            "geometry_preservation_note": "Zachować bezsłupkowy charakter przeszklenia HS i linię tarasu ze szkicu.",
            "visualization_prompt": "Nordic Graphite modular cabin with large HS terrace glazing preserving exact sketch geometry and terrace overhang.",
            "uncertainties": [
                {"element": "Rozpiętość nadproża HS", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Brak wymiaru szerokości otworu na szkicu."}
            ],
            "user_requirements": ["Przeszklenia HS od południa", "Podcień na taras", "Brak słupka pośredniego"],
            "ai_suggestions": ["Zastosowanie szkła o podwyższonej ochronie przed przegrzewaniem (g-value)"],
            "clarification_questions": ["Jaka jest docelowa szerokość przeszklenia HS?"],
            "disclaimer": common_disclaimer,
        }

    if case_id == "illegible_incomplete_dimensions":
        return {
            "summary": "Szkic odręczny bez wymiarów i bez legendy pomieszczeń — rozpoznano wyłącznie ogólny obrys.",
            "spatial_layout": "Widoczny przybliżony obrys dwumodułowy, jednak brak wymiarów i oznaczeń uniemożliwia pewne przypisanie funkcji pomieszczeń.",
            "geometry": {
                "building_footprint": "Zarys prostokątny o nieczytelnym detalowaniu krawędzi",
                "floors_count": "niemożliwe do ustalenia na podstawie materiału",
                "structural_vs_partition_walls": "niemożliwe do ustalenia na podstawie materiału",
                "circulation": "niemożliwe do ustalenia na podstawie materiału",
                "proportions_and_scale": "Brak wymiarów na rysunku; nie podano metrażu w formularzu.",
                "confidence": "niska pewność",
            },
            "rooms": [
                {"name": "Przestrzeń główna (funkcja niejednoznaczna)", "zone": "nieustalone", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Wewnątrz obrysu głównego", "confidence": "niska pewność"}
            ],
            "openings": [
                {"category": "inne", "location": "Przerwy w linii ścian (niejednoznaczne)", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "notes": "Nieczytelne oznaczenia okien i drzwi", "confidence": "niemożliwe do ustalenia na podstawie materiału"}
            ],
            "materials_proposal": "Shou Sugi Ban Minimal: opalana deska elewacyjna, ciemna stolarka — do potwierdzenia po uzupełnieniu rzutu.",
            "lighting_proposal": "Oświetlenie robocze neutralne; szczegółowe oprawy wymagają określenia funkcji pomieszczeń.",
            "geometry_protection": {
                "must_preserve": ["Ogólny zarys szkicu wejściowego bez dopowiadania nieistniejących wykuszy"],
                "can_change": ["Materiały elewacyjne po doprecyzowaniu wymiarów"],
                "forbidden_changes": ["Wymyślanie brakujących okien, drzwi lub konkretnych wymiarów na etapie wizualizacji"],
            },
            "geometry_preservation_note": "Nie dopowiadać nieczytelnych otworów ani wymiarów bez potwierdzenia użytkownika.",
            "visualization_prompt": "Conceptual Shou Sugi Ban Minimal modular volume preserving rough sketch silhouette without inventing extra windows or dimensions.",
            "uncertainties": [
                {"element": "Wymiary ścian zewnętrznych i metraż", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Brak linii wymiarowych i skali na szkicu."},
                {"element": "Kierunki otwierania drzwi i typ okien", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Oznaczenia na rysunku są nieczytelne."},
            ],
            "user_requirements": ["2 moduły", "Styl Shou Sugi Ban Minimal"],
            "ai_suggestions": ["Przesłanie czytelniejszego rzutu z naniesionymi symbolami okien i drzwi"],
            "clarification_questions": ["Jakie są orientacyjne wymiary bryły?", "Które otwory na szkicu to drzwi, a które okna?"],
            "disclaimer": common_disclaimer,
        }

    if case_id in {"ambiguous_doors_windows_sketch", "illegible_incomplete_dimensions"}:
        if case_id == "ambiguous_doors_windows_sketch":
            return {
                "summary": "Szkic domu 62 m² (2 moduły) w stylu Birch & Microcement z niejednoznacznymi oznaczeniami stolarki.",
                "spatial_layout": "Dwa moduły mieszkalne z otworami w ścianach bez czytelnych łuków otwierania drzwi i bez rozróżnienia typów okien.",
                "geometry": {
                    "building_footprint": "Prostokąt dwumodułowy 62 m²",
                    "floors_count": "niemożliwe do ustalenia na podstawie materiału",
                    "structural_vs_partition_walls": "niemożliwe do ustalenia na podstawie materiału",
                    "circulation": "Oś wejścia niepewna ze względu na niejednoznaczne otwory",
                    "proportions_and_scale": "62 m², 2 moduły wg formularza",
                    "confidence": "średnia pewność",
                },
                "rooms": [
                    {"name": "Strefa główna", "zone": "strefa dzienna", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "W obrębie dwóch modułów", "confidence": "średnia pewność"}
                ],
                "openings": [
                    {"opening_id": "OT-01", "category": "inne", "location": "Narożnik dolny i ściana wejściowa", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "has_swing_arc": False, "notes": "Niejednoznaczne oznaczenia drzwi i okien wymagające potwierdzenia", "confidence": "niska pewność"}
                ],
                "materials_proposal": "Birch & Microcement: sklejka brzozowa, posadzka mikrocementowa, stolarka ciemna.",
                "lighting_proposal": "Światło dzienne rozproszone.",
                "geometry_protection": {
                    "must_preserve": ["Lokalizacja istniejących przerw w ścianach do czasu weryfikacji przez użytkownika"],
                    "can_change": ["Materiały wykończeniowe"],
                    "forbidden_changes": ["Samowolne przesuwanie lub zamykanie otworów"],
                },
                "geometry_preservation_note": "Zachować pozycje otworów bez zmiany funkcji przed potwierdzeniem inwestora.",
                "visualization_prompt": "Birch & Microcement modular home preserving exact sketch openings and footprint.",
                "uncertainties": [
                    {"element": "Rozróżnienie okien narożnych i wyjścia tarasowego oraz kierunki otwierania drzwi", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Brak symboli łuków otwierania i oznaczeń stolarki."}
                ],
                "user_requirements": ["62 m²", "2 moduły", "Birch & Microcement"],
                "ai_suggestions": ["Naniesienie symboli otwierania drzwi przed kolejnym etapem"],
                "observed_facts": ["Deklarowana powierzchnia 62 m², 2 moduły"],
                "model_interpretations": ["Przerwy w obrysie wskazują prawdopodobne otwory okienne/drzwiowe"],
                "indeterminable_elements": ["Kierunek otwierania drzwi", "Typ przeszklenia narożnego"],
                "clarification_questions": ["Które otwory pełnią funkcję drzwi wejściowych, a które okien narożnych?"],
                "disclaimer": common_disclaimer,
            }

    if case_id == "structural_vs_partition_walls_sketch":
        return {
            "summary": "Pawilon dwumodułowy 80 m² z wyraźnym rozróżnieniem grubych ścian konstrukcyjnych i cienkich ścian działowych.",
            "spatial_layout": "Zewnętrzna rama nośna obu modułów (ściany konstrukcyjne) oraz wewnętrzne ściany działowe w strefie nocnej.",
            "geometry": {
                "building_footprint": "Dwumodułowy rzut 80 m²",
                "floors_count": "1 kondygnacja",
                "structural_vs_partition_walls": "Grube ściany obwodowe i styku modułów jako ściany konstrukcyjne; cienkie przegrody wewnętrzne w strefie nocnej jako ściany działowe.",
                "circulation": "Korytarz wewnętrzny wzdłuż podziału stref.",
                "proportions_and_scale": "80 m², 2 moduły.",
                "confidence": "wysoka pewność",
            },
            "rooms": [
                {"name": "Strefa dzienna", "zone": "strefa dzienna", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Moduł I", "confidence": "wysoka pewność"},
                {"name": "Strefa nocna", "zone": "strefa nocna", "approximate_area": "brak wymiarów na materiale", "spatial_relations": "Wydzielona ściankami działowymi", "confidence": "średnia pewność"},
            ],
            "openings": [
                {"category": "drzwi wewnętrzne", "location": "W ściankach działowych", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "notes": "Przejścia do sypialni", "confidence": "średnia pewność"},
            ],
            "materials_proposal": "Nordic Graphite: blacha grafitowa, drewno naturalne, tynki matowe na ściankach działowych.",
            "lighting_proposal": "Światło dzienne i oprawy sufitowe.",
            "geometry_protection": {
                "must_preserve": ["Wszystkie ściany konstrukcyjne obwodowe i linię łączenia modułów"],
                "can_change": ["Wykończenie powierzchni ścian działowych"],
                "forbidden_changes": ["Naruszanie ścian konstrukcyjnych modułów"],
            },
            "geometry_preservation_note": "Zachować ściany konstrukcyjne bez jakichkolwiek przesunięć.",
            "visualization_prompt": "Nordic Graphite two-module pavilion preserving exact structural walls and sketch geometry.",
            "uncertainties": [
                {"element": "Szczegóły zbrojenia / przekrój belek", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Rzut nie stanowi projektu konstrukcyjnego."}
            ],
            "user_requirements": ["80 m²", "2 moduły", "Nordic Graphite"],
            "ai_suggestions": ["Zastosowanie izolacji akustycznej w ściankach działowych"],
            "observed_facts": ["Różna grubość linii ścian obwodowych i wewnętrznych"],
            "model_interpretations": ["Grubsze ściany obwodowe pełnią rolę konstrukcyjną, cieńsze wewnętrzne działową"],
            "indeterminable_elements": ["Nośność i parametry materiałowe układu konstrukcyjnego"],
            "clarification_questions": ["Czy przegrody działowe mogą być modyfikowane na późniejszym etapie?"],
            "disclaimer": common_disclaimer,
        }

    if case_id == "tryb_b_small_two_person_house":
        return {
            "summary": "Koncepcja małego całorocznego domu jednomodułowego 46 m² dla dwóch osób w stylu Nordic Graphite.",
            "spatial_layout": "Jednomodułowy układ z jasną strefą dzienną z aneksem, sypialnią dwuosobową, łazienką i zadaszonym tarasem.",
            "geometry": {
                "building_footprint": "Pojedynczy moduł 3.45 x 13.5 m (46 m²)",
                "floors_count": "1 kondygnacja, dach jednospadowy",
                "structural_vs_partition_walls": "Rama stalowo-drewniana modułu jako układ nośny; ścianki działowe przy sypialni i łazience.",
                "circulation": "Bezpośrednie przejście z wejścia do strefy dziennej i sypialni.",
                "proportions_and_scale": "46 m², 1 moduł 3.45 x 13.5 m.",
                "confidence": "wysoka pewność",
            },
            "rooms": [
                {"name": "Strefa dzienna z aneksem", "zone": "strefa dzienna", "approximate_area": "do doprecyzowania", "spatial_relations": "Otwarta na zadaszony taras drewniany", "confidence": "wysoka pewność"},
                {"name": "Sypialnia dwuosobowa", "zone": "strefa nocna", "approximate_area": "do doprecyzowania", "spatial_relations": "Wydzielona w tylnej części modułu", "confidence": "wysoka pewność"},
                {"name": "Łazienka", "zone": "pomocnicza", "approximate_area": "do doprecyzowania", "spatial_relations": "Pomiędzy aneksem a sypialnią", "confidence": "średnia pewność"},
            ],
            "openings": [
                {"category": "przeszklenie", "location": "Wyjście na taras ze strefy dziennej", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "notes": "Duże doświetlenie salonu", "confidence": "wysoka pewność"},
            ],
            "materials_proposal": "Nordic Graphite: grafitowa blacha na rąbek, deska tarasowa modrzewiowa, sklejka i dąb we wnętrzu.",
            "lighting_proposal": "Światło dzienne oraz ciepłe oświetlenie 2700K pod zadaszeniem tarasu.",
            "geometry_protection": {
                "must_preserve": ["Gabaryt transportowy 3.45 x 13.5 m, 1 moduł, 46 m²"],
                "can_change": ["Układ zabudowy kuchennej"],
                "forbidden_changes": ["Przekraczanie skrajni transportowej modułu"],
            },
            "geometry_preservation_note": "Zachować obrys jednego modułu 3.45 x 13.5 m i dach jednospadowy.",
            "visualization_prompt": "Nordic Graphite 46 sqm single modular house for two with covered wooden terrace.",
            "uncertainties": [
                {"element": "Orientacja względem stron świata", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Nie podano układu działki."}
            ],
            "user_requirements": ["46 m²", "2 osoby", "1 sypialnia", "Łazienka", "Taras drewniany pod zadaszeniem", "Dach jednospadowy"],
            "ai_suggestions": ["Zgrupowanie pionów wodnych między kuchnią a łazienką"],
            "observed_facts": ["Powierzchnia 46 m², 1 moduł, moduł 3.45 x 13.5 m"],
            "model_interpretations": ["Liniowy układ minimalizuje powierzchnię korytarza"],
            "indeterminable_elements": ["Strony świata na działce i lokalizacja przyłączy"],
            "clarification_questions": ["Z której strony działki przewidują Państwo wjazd?"],
            "disclaimer": common_disclaimer,
        }

    if case_id == "tryb_b_family_day_night_zones":
        return {
            "summary": "Koncepcja domu rodzinnego 96 m² (3 moduły) w stylu Raw Steel & Cedar z podziałem na strefę dzienną i nocną.",
            "spatial_layout": "Wyraźne rozdzielenie strefy dziennej z jadalnią od strefy nocnej z trzema sypialniami poprzez przeszklony łącznik.",
            "geometry": {
                "building_footprint": "Układ 3 modułów połączonych przeszklonym łącznikiem (96 m²)",
                "floors_count": "1 kondygnacja",
                "structural_vs_partition_walls": "Ramy 3 modułów nośne; przegrody między 3 sypialniami działowe.",
                "circulation": "Przeszklony łącznik rozdzielający strefę głośną dzienną i cichą nocną.",
                "proportions_and_scale": "96 m², 3 moduły do 3.5 m szerokości.",
                "confidence": "wysoka pewność",
            },
            "rooms": [
                {"name": "Strefa dzienna z jadalnią", "zone": "strefa dzienna", "approximate_area": "część z 96 m²", "spatial_relations": "Osobny moduł dzienny", "confidence": "wysoka pewność"},
                {"name": "Trzy sypialnie i dwie łazienki", "zone": "strefa nocna", "approximate_area": "część z 96 m²", "spatial_relations": "Za przeszklonym łącznikiem", "confidence": "średnia pewność"},
            ],
            "openings": [
                {"category": "przeszklenie", "location": "Łącznik pomiędzy strefą dzienną i nocną", "opening_direction": "stałe / tarasowe", "notes": "Doświetlenie komunikacji", "confidence": "wysoka pewność"},
            ],
            "materials_proposal": "Raw Steel & Cedar: surowa stal, cedr kanadyjski na elewacji, dębowe podłogi.",
            "lighting_proposal": "Oświetlenie strefowe dzienne i wyciszone nocne w korytarzu.",
            "geometry_protection": {
                "must_preserve": ["Podział na strefę dzienną i nocną oraz łącznik przeszklony"],
                "can_change": ["Układ szaf w sypialniach"],
                "forbidden_changes": ["Przekraczanie szerokości modułów 3.5 m"],
            },
            "geometry_preservation_note": "Zachować 3 moduły i separację strefy dziennej od nocnej.",
            "visualization_prompt": "Raw Steel & Cedar 96 sqm three-module family home with glass connector separating day and night zones.",
            "uncertainties": [
                {"element": "Kształt i nachylenie działki", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Brak mapy działki w briefie."}
            ],
            "user_requirements": ["96 m²", "3 moduły", "Rodzina 2+2", "Strefa dzienna z jadalnią i nocna z 3 sypialniami"],
            "ai_suggestions": ["Zastosowanie drzwi akustycznych na wejściu do strefy nocnej"],
            "observed_facts": ["Powierzchnia 96 m², 3 moduły, rodzina 2+2"],
            "model_interpretations": ["Konfiguracja w kształcie litery H lub L naturalnie izoluje strefę nocną"],
            "indeterminable_elements": ["Dokładna orientacja działki względem słońca"],
            "clarification_questions": ["Czy preferują Państwo układ w kształcie L czy równoległy?"],
            "disclaimer": common_disclaimer,
        }

    if case_id == "tryb_b_modern_glazed_interior":
        return {
            "summary": "Koncepcja nowoczesnego wnętrza dziennego 42 m² w stylu Birch & Microcement z wysokimi przeszkleniami na las.",
            "spatial_layout": "Otwarta strefa dzienna z wyspą kuchenną w osi wysokiego okna od podłogi do sufitu.",
            "geometry": {
                "building_footprint": "Moduł wnętrza 42 m², wysokość 2.95 m",
                "floors_count": "1 poziom",
                "structural_vs_partition_walls": "Ściana okienna z trzema wysokimi przeszkleniami w czarnych ramach.",
                "circulation": "Swobodny obieg wokół wyspy kuchennej.",
                "proportions_and_scale": "42 m², wysokość 2.95 m.",
                "confidence": "wysoka pewność",
            },
            "rooms": [
                {"name": "Salon z kuchnią i wyspą", "zone": "strefa dzienna", "approximate_area": "42 m²", "spatial_relations": "W osi trzech wysokich przeszkleń", "confidence": "wysoka pewność"},
            ],
            "openings": [
                {"category": "przeszklenie", "location": "Ściana leśna", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "notes": "Trzy wysokie okna od podłogi do sufitu", "confidence": "wysoka pewność"},
            ],
            "materials_proposal": "Birch & Microcement: sufit ze sklejki brzozowej, posadzka z mikrocementu, czarne ramy okienne.",
            "lighting_proposal": "Światło dzienne przez 3 wysokie przeszklenia i oprawy nad wyspą.",
            "geometry_protection": {
                "must_preserve": ["Wysokość 2.95 m, 3 wysokie przeszklenia i oś wyspy kuchennej"],
                "can_change": ["Odcień mikrocementu"],
                "forbidden_changes": ["Obniżanie okien lub sufitu"],
            },
            "geometry_preservation_note": "Zachować proporcje 42 m² i wysokość 2.95 m.",
            "visualization_prompt": "Birch & Microcement modern 42 sqm living interior with birch plywood ceiling, microcement floor, and three tall black-framed forest windows.",
            "uncertainties": [
                {"element": "Ekspozycja stron świata", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Nie wskazano kierunku geograficznego lasu."}
            ],
            "user_requirements": ["42 m²", "3 wysokie przeszklenia", "Sklejka brzozowa", "Mikrocement", "Wyspa kuchenna"],
            "ai_suggestions": ["Zastosowanie bezuchwytowej zabudowy z matowego forniru"],
            "observed_facts": ["42 m², wysokość 2.95 m, sufit ze sklejki brzozowej, posadzka z mikrocementu"],
            "model_interpretations": ["Centralna wyspa porządkuje strefę gotowania i widok na las"],
            "indeterminable_elements": ["Kierunek padania słońca na elewację okienną"],
            "clarification_questions": ["Czy w strefie wypoczynkowej planują Państwo kominek lub piec wolnostojący?"],
            "disclaimer": common_disclaimer,
        }

    # Case 10: tryb_b_incomplete_requirements
    return {
        "summary": "Wstępna koncepcja dwumodułowego domu Shou Sugi Ban Minimal w lesie z tarasem — przy licznych nieokreślonych parametrach.",
        "spatial_layout": "Zarys koncepcji dwumodułowej z tarasem; dokładny podział pomieszczeń niemożliwy do przesądzenia bez podania metrażu i liczby sypialni.",
        "geometry": {
            "building_footprint": "Wstępna bryła 2 modułów z tarasem (metraż nieustalony)",
            "floors_count": "1 kondygnacja (robocze założenie do potwierdzenia)",
            "structural_vs_partition_walls": "niemożliwe do ustalenia na podstawie materiału",
            "circulation": "Do zaprojektowania po określeniu liczby sypialni",
            "proportions_and_scale": "Brak metrażu w wymaganiach użytkownika — nie przyjęto sztywnych wymiarów.",
            "confidence": "niska pewność",
        },
        "rooms": [
            {"name": "Strefa dzienna z wyjściem na taras", "zone": "strefa dzienna", "approximate_area": "brak wymiarów w briefie", "spatial_relations": "Otwarta na taras", "confidence": "średnia pewność"},
            {"name": "Strefa prywatna (liczba sypialni nieokreślona)", "zone": "strefa nocna", "approximate_area": "brak wymiarów w briefie", "spatial_relations": "Do doprecyzowania", "confidence": "niska pewność"},
        ],
        "openings": [
            {"category": "przeszklenie", "location": "Wyjście na taras", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "notes": "Wymaga określenia stron świata", "confidence": "niska pewność"},
        ],
        "materials_proposal": "Shou Sugi Ban Minimal: czarna deska opalana na elewacji, ciemna stolarka.",
        "lighting_proposal": "Ciepłe oświetlenie tarasowe kontrastujące z ciemną elewacją.",
        "geometry_protection": {
            "must_preserve": ["Dwumodułowy charakter bryły, czarna elewacja, taras w otoczeniu leśnym"],
            "can_change": ["Metraż oraz dokładny rozkład sypialni po doprecyzowaniu briefu"],
            "forbidden_changes": ["Traktowanie wstępnego wariantu bez metrażu jako gotowego projektu"],
        },
        "geometry_preservation_note": "Założenia wstępne wymagające potwierdzenia metrażu i liczby pomieszczeń.",
        "visualization_prompt": "Shou Sugi Ban Minimal two-module black timber forest house with terrace.",
        "uncertainties": [
            {"element": "Metraż całkowity i liczba sypialni", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Użytkownik nie podał powierzchni ani liczby domowników."},
            {"element": "Strony świata i usytuowanie tarasu", "confidence": "niemożliwe do ustalenia na podstawie materiału", "reason": "Brak informacji o działce."},
        ],
        "user_requirements": ["Nieduży czarny dom modułowy", "2 moduły", "Taras", "Otoczenie leśne"],
        "ai_suggestions": ["Rozważenie wariantu 55–70 m² dla 1–2 sypialni po potwierdzeniu potrzeb"],
        "observed_facts": ["Czarna elewacja (Shou Sugi Ban Minimal), taras, otoczenie leśne, 2 moduły"],
        "model_interpretations": ["Założono parterową bryłę dwumodułową jako punkt wyjścia do rozmowy"],
        "indeterminable_elements": ["Metraż budynku", "Liczba sypialni", "Orientacja stron świata"],
        "clarification_questions": [
            "Jaki jest preferowany metraż (np. do 50 m² czy 70 m²)?",
            "Ile sypialni powinno znaleźć się w części prywatnej?",
            "Od której strony znajduje się nasłoneczniona część działki leśnej?",
        ],
        "disclaimer": common_disclaimer,
    }


@pytest.fixture()
def isolated_env(tmp_path: Path):
    db_file = tmp_path / "quality_test.db"
    storage_dir = tmp_path / "storage"
    os.environ["DATABASE_URL"] = f"sqlite:///{db_file.as_posix()}"
    os.environ["STORAGE_DIR"] = str(storage_dir)
    os.environ["GEMINI_API_KEY"] = ""
    os.environ["GROQ_API_KEY"] = ""
    os.environ["FREE_ONLY"] = "true"
    os.environ["ALLOW_PAID_APIS"] = "false"
    os.environ["MONTHLY_BUDGET"] = "0"
    os.environ["ALLOW_HF_MICRO_FREE_CREDITS"] = "false"
    get_settings.cache_clear()

    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db import database

    test_engine = create_engine(
        os.environ["DATABASE_URL"],
        connect_args={"check_same_thread": False},
        future=True,
    )
    database.engine = test_engine
    database.SessionLocal = sessionmaker(bind=test_engine, autocommit=False, autoflush=False)

    from app import main as app_main

    app_main.engine = test_engine
    app_main.SessionLocal = database.SessionLocal

    app = create_app()
    with TestClient(app) as client:
        yield client, database.SessionLocal, tmp_path


def test_six_benchmark_cases_pass_quality_evaluation_with_mocked_providers(isolated_env):
    """
    Tests all 6 required architectural cases (with mocked HTTP provider transport).
    Explicitly marked mocked: verifies prompt routing, structured parser, uncertainty handling,
    and quality evaluator — NOT real upstream Gemini/Groq model intelligence.
    """
    client, SessionLocal, _tmp_path = isolated_env
    # Ensure we also have a local PNG sketch uploaded in storage for sketch cases
    upload_res = client.post(
        "/api/projects/upload-sketch",
        files={"file": ("bench_plan.png", build_minimal_png_bytes(), "image/png")},
    )
    assert upload_res.status_code == 200
    uploaded_png_url = upload_res.json()["url"]

    cases = get_default_benchmark_cases()
    assert len(cases) == 10
    assert len([c for c in cases if c.mode == "sketch_to_render"]) == 6
    assert len([c for c in cases if c.mode == "idea_to_project"]) == 4

    def make_mock_router(target_provider: str, settings: Settings, guard: CostGuard, case_id: str) -> ProviderRouter:
        payload_json = json.dumps(_mock_structured_payload_for_case(case_id), ensure_ascii=False)

        def gemini_handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                status_code=200,
                json={"candidates": [{"content": {"parts": [{"text": payload_json}]}}]},
            )

        def groq_handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                status_code=200,
                json={"choices": [{"message": {"content": payload_json}}]},
            )

        class MockedSuiteRouter(ProviderRouter):
            def select_vision_provider(self, session, preferred_key=None, strict_preferred=False):
                chosen = preferred_key or target_provider
                if chosen == "groq":
                    prov = GroqProvider(settings, guard, db=session, transport=httpx.MockTransport(groq_handler))
                else:
                    prov = GeminiProvider(settings, guard, db=session, transport=httpx.MockTransport(gemini_handler))
                usage = guard.get_or_create_usage(session, chosen)
                decision = guard.evaluate_provider(prov.get_descriptor(), True, usage=usage)
                return SelectedVisionProvider(provider=prov, decision=decision, checked_providers=[chosen])

        return MockedSuiteRouter(settings, guard)

    settings = Settings(_env_file=None, gemini_api_key="AIza_mock_bench", groq_api_key="gsk_mock_bench")
    guard = CostGuard(settings)
    db = SessionLocal()
    reports_by_provider = {"gemini": [], "groq": []}

    try:
        from app.services import analysis_service

        for case in cases:
            sketch_url = case.sketch_image_url
            if case.mode == "sketch_to_render" and not sketch_url:
                sketch_url = uploaded_png_url

            for provider_key in ("gemini", "groq"):
                preview = asyncio.run(
                    analysis_service.execute_free_ai_analysis(
                        db,
                        settings,
                        mode=case.mode,
                        title=case.title,
                        building_type=case.building_type,
                        area_sqm=case.area_sqm,
                        modules_count=case.modules_count,
                        style_preset=case.style_preset,
                        preserve_geometry=case.preserve_geometry,
                        prompt_brief=case.prompt_brief,
                        geometry_notes=case.geometry_notes,
                        sketch_image_url=sketch_url,
                        reference_ids=[],
                        preferred_provider=provider_key,  # type: ignore[arg-type]
                        router=make_mock_router(provider_key, settings, guard, case.case_id),
                    )
                )
                report = evaluate_analysis_quality(
                    case,
                    preview,
                    provider=preview.provider,
                    model=preview.model,
                    response_time_ms=preview.response_time_ms,
                )
                assert report.passed, f"Case {case.case_id} ({provider_key}) failed: {report.defects}"
                assert report.overall_score >= 85
                reports_by_provider[provider_key].append(report)
    finally:
        db.close()

    comparison = compare_providers_across_suite(reports_by_provider)
    assert comparison.ranking_allowed is True
    assert len(comparison.shared_case_ids) == 10
    assert all(p.avg_response_time_ms is not None for p in comparison.providers)


def test_quality_evaluator_flags_geometry_mutation_in_prompt():
    cases = {c.case_id: c for c in get_default_benchmark_cases()}
    tryb_a_case = cases["simple_modular_plan"]
    mutating = AnalysisContentFields(
        summary="Prosty moduł 48 m² Nordic Graphite z wejściem od frontu.",
        spatial_layout="Jeden moduł.",
        geometry=GeometryAnalysis(building_footprint="Prostokąt", confidence="wysoka pewność"),
        rooms=[RoomAnalysisItem(name="Salon", confidence="wysoka pewność")],
        openings=[OpeningAnalysisItem(category="drzwi wejściowe", confidence="wysoka pewność")],
        materials_proposal="Nordic Graphite",
        lighting_proposal="2700K",
        geometry_protection=GeometryProtectionRules(must_preserve=["Obrys"], can_change=["Kolor"], forbidden_changes=["Piętro"]),
        visualization_prompt="Nordic Graphite cabin, move windows to side wall and add second floor.",
        uncertainties=[UncertaintyItem(element="Kierunek drzwi", confidence="niska pewność", reason="Brak łuku")],
        user_requirements=["48 m²"],
        observed_facts=["48 m², 1 moduł"],
        model_interpretations=["Wejście frontowe"],
        ai_suggestions=["Jasny sufit"],
        indeterminable_elements=["Kierunek otwierania"],
        clarification_questions=["Szerokość drzwi?"],
    )
    report = evaluate_analysis_quality(tryb_a_case, mutating, provider="mock", model="test")
    assert report.prompt_consistency_score <= 50
    assert any("zmieniać geometrię" in d for d in report.defects)


def test_quality_evaluator_flags_invented_dimensions_and_missing_uncertainty():
    cases = {c.case_id: c for c in get_default_benchmark_cases()}
    illegible_case = cases["illegible_incomplete_dimensions"]

    hallucinated = AnalysisContentFields(
        summary="Salon ma dokładnie 34.5 m², a ściana frontowa długość 11.2 m.",
        spatial_layout="Sypialnia 16 m² i kuchnia 14 m².",
        geometry=GeometryAnalysis(
            building_footprint="11.2 m x 8.4 m",
            floors_count="1",
            structural_vs_partition_walls="Spełnia normy konstrukcyjne",
            circulation="Korytarz 1.4 m",
            proportions_and_scale="11.2 m x 8.4 m",
            confidence="wysoka pewność",
        ),
        rooms=[
            RoomAnalysisItem(name="Salon", zone="strefa dzienna", approximate_area="34.5 m²", confidence="wysoka pewność"),
        ],
        openings=[
            OpeningAnalysisItem(category="okno", location="front", opening_direction="do wewnątrz", confidence="wysoka pewność"),
        ],
        materials_proposal="Shou Sugi Ban",
        lighting_proposal="LED",
        geometry_protection=GeometryProtectionRules(must_preserve=["Obrys"], can_change=[], forbidden_changes=["Okna"]),
        visualization_prompt="Shou Sugi Ban cabin",
        uncertainties=[],
        user_requirements=["2 moduły"],
        ai_suggestions=[],
        clarification_questions=[],
    )

    report = evaluate_analysis_quality(illegible_case, hallucinated, provider="mock", model="test")
    assert report.passed is False
    assert report.caution_score < 60
    assert any("Wymyślono konkretne wymiary" in d for d in report.defects)
    assert any("Nie oznaczono niepewności" in d for d in report.defects)


def test_provider_comparison_refuses_ranking_on_single_test():
    cases = get_default_benchmark_cases()
    first_case = cases[0]
    sample_analysis = AnalysisContentFields(
        summary="Dom 48 m² w stylu Nordic Graphite.",
        spatial_layout="1 moduł z wejściem od frontu.",
        geometry=GeometryAnalysis(building_footprint="Prostokąt", confidence="średnia pewność"),
        rooms=[RoomAnalysisItem(name="Salon", confidence="średnia pewność")],
        openings=[OpeningAnalysisItem(category="drzwi wejściowe", confidence="średnia pewność")],
        materials_proposal="Nordic Graphite",
        lighting_proposal="2700K",
        geometry_protection=GeometryProtectionRules(must_preserve=["Obrys"], can_change=["Kolor"], forbidden_changes=["Okna"]),
        visualization_prompt=(
            "Nordic Graphite house preserving exact sketch geometry, building footprint, "
            "all walls, windows, entrance doors, and room layout. FORBIDDEN: Do not add rooms or move walls."
        ),
        uncertainties=[UncertaintyItem(element="Otwieranie drzwi", confidence="niemożliwe do ustalenia na podstawie materiału", reason="Brak łuku")],
        user_requirements=["48 m²"],
        ai_suggestions=["Jasny sufit"],
        clarification_questions=["Szerokość drzwi?"],
    )

    r_gem = evaluate_analysis_quality(first_case, sample_analysis, provider="gemini", model="g", response_time_ms=120)
    r_groq = evaluate_analysis_quality(first_case, sample_analysis, provider="groq", model="q", response_time_ms=80)

    comparison = compare_providers_across_suite({"gemini": [r_gem], "groq": [r_groq]})
    assert comparison.ranking_allowed is False
    assert comparison.winner_by_dimension == {}
    assert "pojedynczego testu" in comparison.notice


def test_run_safe_provider_comparison_stops_on_429_without_retries(isolated_env):
    _, SessionLocal, _ = isolated_env
    settings = Settings(_env_file=None, gemini_api_key="AIza_429", groq_api_key="gsk_429")
    guard = CostGuard(settings)
    calls = {"gemini": 0, "groq": 0}

    def gemini_429(_req: httpx.Request) -> httpx.Response:
        calls["gemini"] += 1
        return httpx.Response(status_code=429, headers={"retry-after": "60"})

    def groq_429(_req: httpx.Request) -> httpx.Response:
        calls["groq"] += 1
        return httpx.Response(status_code=429, headers={"retry-after": "60"})

    class CooldownRouter(ProviderRouter):
        def select_vision_provider(self, session, preferred_key=None, strict_preferred=False):
            key = preferred_key or "gemini"
            if key == "groq":
                prov = GroqProvider(settings, guard, db=session, transport=httpx.MockTransport(groq_429))
            else:
                prov = GeminiProvider(settings, guard, db=session, transport=httpx.MockTransport(gemini_429))
            usage = guard.get_or_create_usage(session, key)
            decision = guard.evaluate_provider(prov.get_descriptor(), True, usage=usage)
            return SelectedVisionProvider(provider=prov, decision=decision, checked_providers=[key])

    db = SessionLocal()
    try:
        cases = [c for c in get_default_benchmark_cases() if c.mode == "idea_to_project"] * 3
        outcome = asyncio.run(
            run_safe_provider_comparison(
                db,
                settings,
                cases,
                router=CooldownRouter(settings, guard),
                max_cases=3,
            )
        )
        # Must stop after the very first 429 per provider (never 3 retries!)
        assert calls["gemini"] == 1
        assert calls["groq"] == 1
        assert "gemini" in outcome["errors"]
        assert "groq" in outcome["errors"]
    finally:
        db.close()


def test_legacy_sqlite_migration_preserves_old_analyses(tmp_path: Path):
    """
    Simulates upgrading an older Etap 3.2 SQLite database whose project_analyses table
    lacks structured_payload_json, response_time_ms, and schema_version.
    Verifies zero data loss and backward-compatible API serialization + editing.
    """
    db_file = tmp_path / "legacy_32.db"
    conn = sqlite3.connect(db_file)
    try:
        conn.executescript(
            """
            CREATE TABLE projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(160) NOT NULL,
                mode VARCHAR(32) NOT NULL,
                status VARCHAR(32) NOT NULL DEFAULT 'draft',
                building_type VARCHAR(80) NOT NULL DEFAULT 'Dom modułowy',
                area_sqm FLOAT,
                modules_count INTEGER NOT NULL DEFAULT 1,
                style_preset VARCHAR(80) NOT NULL DEFAULT 'Nordic Graphite',
                preserve_geometry BOOLEAN NOT NULL DEFAULT 1,
                prompt_brief TEXT NOT NULL DEFAULT '',
                geometry_notes TEXT NOT NULL DEFAULT '',
                sketch_image_url VARCHAR(500),
                preview_image_url VARCHAR(500),
                reference_ids_json TEXT NOT NULL DEFAULT '[]',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE project_analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                mode VARCHAR(32) NOT NULL,
                provider VARCHAR(40) NOT NULL,
                model VARCHAR(120) NOT NULL,
                is_free_tier BOOLEAN NOT NULL DEFAULT 1,
                summary TEXT NOT NULL DEFAULT '',
                spatial_layout TEXT NOT NULL DEFAULT '',
                materials_proposal TEXT NOT NULL DEFAULT '',
                lighting_proposal TEXT NOT NULL DEFAULT '',
                geometry_preservation_note TEXT NOT NULL DEFAULT '',
                visualization_prompt TEXT NOT NULL DEFAULT '',
                raw_response_text TEXT NOT NULL DEFAULT '',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO projects (id, title, mode, prompt_brief)
            VALUES (1, 'Starszy Projekt 3.2', 'sketch_to_render', 'Opis historyczny');
            INSERT INTO project_analyses (
                id, project_id, mode, provider, model, is_free_tier,
                summary, spatial_layout, materials_proposal, lighting_proposal,
                geometry_preservation_note, visualization_prompt, raw_response_text
            ) VALUES (
                1, 1, 'sketch_to_render', 'gemini', 'gemini-2.5-flash', 1,
                'Stare podsumowanie z Etapu 3.2',
                'Stary układ pomieszczeń',
                'Stare materiały',
                'Stare oświetlenie',
                'Stara ochrona geometrii',
                'Legacy render prompt',
                '{}'
            );
            """
        )
        conn.commit()
    finally:
        conn.close()

    os.environ["DATABASE_URL"] = f"sqlite:///{db_file.as_posix()}"
    os.environ["STORAGE_DIR"] = str(tmp_path / "storage")
    os.environ["GEMINI_API_KEY"] = ""
    os.environ["GROQ_API_KEY"] = ""
    get_settings.cache_clear()

    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db import database

    legacy_engine = create_engine(
        os.environ["DATABASE_URL"],
        connect_args={"check_same_thread": False},
        future=True,
    )
    database.engine = legacy_engine
    database.SessionLocal = sessionmaker(bind=legacy_engine, autocommit=False, autoflush=False)

    from app import main as app_main

    app_main.engine = legacy_engine
    app_main.SessionLocal = database.SessionLocal

    ensure_sqlite_schema_migrations(legacy_engine)

    app = create_app()
    with TestClient(app) as client:
        res = client.get("/api/projects/1")
        assert res.status_code == 200
        project = res.json()
        assert project["title"] == "Starszy Projekt 3.2"
        analysis = project["latest_analysis"]
        assert analysis is not None
        assert analysis["summary"] == "Stare podsumowanie z Etapu 3.2"
        assert analysis["is_legacy_format"] is True
        assert analysis["schema_version"] == "3.2_legacy"
        assert analysis["rooms"] == []
        assert analysis["openings"] == []
        assert analysis["disclaimer"]

        # Editing the legacy record works safely without losing legacy fields
        patch_res = client.patch(
            "/api/projects/1/analysis",
            json={"summary": "Zaktualizowane podsumowanie po migracji"},
        )
        assert patch_res.status_code == 200
        updated_analysis = patch_res.json()["latest_analysis"]
        assert updated_analysis["summary"] == "Zaktualizowane podsumowanie po migracji"
        assert updated_analysis["spatial_layout"] == "Stary układ pomieszczeń"


def test_etap_3_5_project_id4_dimension_conflict_and_abcd_distinction():
    """
    Regression based on real Gemini Test 1 (Project ID 4):
    Overall width 7.5 m vs segments 4.0 + 3.5 + 2.1 = 9.6 m MUST flag 2.1 m conflict
    and override false 'spójne wymiarowo' declarations.
    """
    from app.services import analysis_service

    raw = json.dumps(
        {
            "summary": "Prosty rzut domu The Rectangle z deklaracją 7.5m x 4.0m.",
            "spatial_layout": "Strefa dzienna po lewej stronie rzutu, sypialnia i łazienka po prawej stronie rzutu.",
            "geometry": {
                "building_footprint": "7.5m x 4.0m",
                "floors_count": "1",
                "structural_vs_partition_walls": "niemożliwe do ustalenia na podstawie materiału",
                "circulation": "Korytarz prowadzący od wejścia w dolnej części rzutu.",
                "proportions_and_scale": "Skala 1:100, rzut i wizualizacja spójne wymiarowo.",
                "confidence": "wysoka pewność",
            },
            "rooms": [
                {"name": "Living/Dining/Kitchenette", "zone": "dzienna", "approximate_area": "20.8 m2", "spatial_relations": "lewa strona rzutu", "confidence": "wysoka pewność"}
            ],
            "openings": [
                {"opening_id": "D-01", "category": "drzwi wejściowe", "location": "prawa strona rzutu", "opening_direction": "niemożliwe do ustalenia na podstawie materiału", "has_swing_arc": False, "confidence": "średnia pewność"}
            ],
            "dimension_observations": [
                {"label": "Szerokość całkowita", "value": "7.5 m", "source_type": "direct", "unit": "m", "location": "górna krawędź", "confidence": "wysoka pewność"},
                {"label": "Suma odcinków (4.0 + 3.5 + 2.1)", "value": "9.6 m", "source_type": "calculated", "unit": "m", "location": "dolna krawędź", "confidence": "średnia pewność"},
                {"label": "Wysokość pomieszczeń", "value": "ok. 2.6 m", "source_type": "estimated", "unit": "m", "location": "przekrój (brak)", "confidence": "wysoka pewność"},
                {"label": "Grubość ścian", "value": "niemożliwe do ustalenia na podstawie materiału", "source_type": "indeterminable", "unit": "brak", "location": "ściany zewnętrzne", "confidence": "niemożliwe do ustalenia na podstawie materiału"},
            ],
            "dimension_checks": [
                {
                    "description": "Szerokość całkowita 7.5 m vs odcinki 4.0 m + 3.5 m + 2.1 m",
                    "overall_dimension": "7.5 m",
                    "segment_sum": "9.6 m",
                    "status": "indeterminable",
                    "difference": "",
                }
            ],
            "dimension_confidence": "wysoka pewność",
            "materials_proposal": "Nordic Graphite: blacha grafitowa",
            "lighting_proposal": "LED 2700K",
            "visualization_prompt": "Nordic Graphite house.",
        },
        ensure_ascii=False,
    )

    parsed = analysis_service.parse_ai_analysis_response(raw, mode="sketch_to_render", preserve_geometry=True)
    assert parsed.dimension_checks[0].status == "conflict"
    assert parsed.dimension_checks[0].difference == "2.1 m"
    assert any("2.1 m" in c for c in parsed.dimension_conflicts)
    assert parsed.dimension_confidence == "niska pewność"
    assert "KOREKTA WALIDACJI" in parsed.geometry.proportions_and_scale
    # Source types A/B/C/D preserved and estimated clamped from high confidence
    src_map = {obs.label: obs for obs in parsed.dimension_observations}
    assert src_map["Szerokość całkowita"].source_type == "direct"
    assert src_map["Suma odcinków (4.0 + 3.5 + 2.1)"].source_type == "calculated"
    assert src_map["Wysokość pomieszczeń"].source_type == "estimated"
    assert src_map["Wysokość pomieszczeń"].confidence != "wysoka pewność"
    assert src_map["Grubość ścian"].source_type == "indeterminable"
    # Geometry Lock auto-injected on Mode A visualization_prompt
    assert analysis_service.has_complete_geometry_lock(parsed.visualization_prompt)


def test_etap_3_5_project_id5_doors_swing_arcs_and_unjustified_cardinal_directions():
    """
    Regression based on real Gemini Test 2 (Project ID 5):
    - Doors without swing arc remain in openings with has_swing_arc=False and cannot claim high swing confidence.
    - Uncertainties referencing indicative arcs cannot claim 'wysoka pewność'.
    - Cardinal directions without compass/user orientation are flagged, while valid user-supplied ones are preserved.
    """
    from app.services import analysis_service

    raw = json.dumps(
        {
            "summary": "Dom 3-modułowy z wejściem od południa.",
            "spatial_layout": "Salon po lewej stronie rzutu, łazienka w północno-wschodniej części.",
            "geometry": {
                "building_footprint": "Prostokątny obrys 3 modułów",
                "floors_count": "1 kondygnacja",
                "structural_vs_partition_walls": "niemożliwe do ustalenia na podstawie materiału",
                "circulation": "Centralny korytarz",
                "proportions_and_scale": "niemożliwe do ustalenia na podstawie materiału",
                "confidence": "wysoka pewność",
            },
            "rooms": [
                {"name": "Łazienka", "zone": "sanitarna", "approximate_area": "niemożliwe do ustalenia", "spatial_relations": "północno-wschodnia część", "confidence": "wysoka pewność"}
            ],
            "openings": [
                {"opening_id": "DW-01", "category": "drzwi wewnętrzne", "location": "Korytarz ↔ Łazienka", "opening_direction": "do wewnątrz", "has_swing_arc": False, "confidence": "wysoka pewność"},
                {"opening_id": "D-01", "category": "drzwi wejściowe", "location": "Wiatrołap (południe)", "opening_direction": "do wewnątrz", "has_swing_arc": True, "confidence": "wysoka pewność"},
            ],
            "openings_completeness_check": "Rozpoznano 2 otwory drzwiowe; brak łuku przy DW-01 oznaczono jako niepewny.",
            "materials_proposal": "Nordic Graphite",
            "lighting_proposal": "Światło dzienne",
            "visualization_prompt": "Nordic Graphite house on the north side.",
            "uncertainties": [
                {"element": "kierunki otwierania drzwi wewnętrznych", "confidence": "wysoka pewność", "reason": "symbolika łuków jest orientacyjna"}
            ],
        },
        ensure_ascii=False,
    )

    # Case A: No compass or cardinal directions in user brief -> must flag unjustified directions
    parsed_no_compass = analysis_service.parse_ai_analysis_response(
        raw,
        mode="sketch_to_render",
        preserve_geometry=True,
        user_context_text="Wierna analiza rzutu z centralnym korytarzem.",
    )
    assert len(parsed_no_compass.unjustified_directions_detected) >= 3
    dw_01 = parsed_no_compass.openings[0]
    assert dw_01.opening_id == "DW-01"
    assert dw_01.has_swing_arc is False
    assert "niemożliwe do ustalenia" in dw_01.opening_direction
    assert dw_01.confidence == "niska pewność"
    assert parsed_no_compass.uncertainties[0].confidence == "niska pewność"

    # Case B: User explicitly specified cardinal direction -> must NOT flag valid direction
    parsed_with_compass = analysis_service.parse_ai_analysis_response(
        raw,
        mode="sketch_to_render",
        preserve_geometry=True,
        user_context_text="Wejście od południa, taras od strony północno-wschodniej (oznaczenie północy na rzucie).",
    )
    assert parsed_with_compass.unjustified_directions_detected == []


def test_etap_3_5_prompts_and_evaluator_enforce_geometry_lock_and_completeness():
    from app.services import analysis_service

    sys_prompt, user_prompt = analysis_service.build_analysis_prompts(
        mode="sketch_to_render",
        title="Test Etap 3.5",
        building_type="Dom modułowy",
        area_sqm=None,
        modules_count=3,
        style_preset="Nordic Graphite",
        preserve_geometry=True,
        prompt_brief="Analiza rzutu",
        geometry_notes="",
        reference_context="Brak",
    )
    assert "ZAKAZ WYMYŚLANIA STRON ŚWIATA" in sys_prompt
    assert "drzwi przesuwne" in user_prompt and "przeszklenia HS" in user_prompt
    assert "Brak łuku otwierania NIE oznacza, że drzwi nie istnieją" in user_prompt
    assert "KOŃCOWA KONTROLA KOMPLETNOŚCI OTWORÓW" in user_prompt
    assert "GEOMETRY LOCK (MANDATORY):" in user_prompt

    # Evaluator must reject a Mode A prompt missing full Geometry Lock even if it says 'Nordic Graphite'
    cases = {c.case_id: c for c in get_default_benchmark_cases()}
    tryb_a = cases["simple_modular_plan"]
    weak_prompt_analysis = AnalysisContentFields(
        summary="Prosty moduł 48 m² Nordic Graphite z wejściem od frontu.",
        spatial_layout="Jeden moduł z wejściem od frontu.",
        geometry=GeometryAnalysis(building_footprint="Prostokąt", confidence="średnia pewność"),
        rooms=[RoomAnalysisItem(name="Salon", confidence="średnia pewność")],
        openings=[OpeningAnalysisItem(opening_id="D-01", category="drzwi wejściowe", confidence="średnia pewność")],
        materials_proposal="Nordic Graphite",
        lighting_proposal="2700K",
        geometry_protection=GeometryProtectionRules(must_preserve=["Obrys"], can_change=["Kolor"], forbidden_changes=["Ściany"]),
        visualization_prompt="Architectural render in Nordic Graphite style, dusk lighting, 8k.",
        uncertainties=[UncertaintyItem(element="Kierunek drzwi", confidence="niska pewność", reason="Brak łuku")],
        user_requirements=["48 m²", "1 moduł"],
        observed_facts=["Wejście od frontu"],
        clarification_questions=["Szerokość drzwi?"],
    )
    report = evaluate_analysis_quality(tryb_a, weak_prompt_analysis, provider="mock", model="test")
    assert any("GEOMETRY LOCK" in d for d in report.defects)
    assert report.prompt_consistency_score <= 65

