import json
import os
import sys
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.config import Settings, get_settings  # noqa: E402
from app.core.cost_guard import (  # noqa: E402
    CostGuard,
    ProviderQuotaExceededError,
    ProviderRequestError,
    ProviderTimeoutError,
    sanitize_sensitive_text,
)
from app.main import create_app  # noqa: E402
from app.providers.gemini_provider import GeminiProvider  # noqa: E402
from app.providers.groq_provider import GroqProvider  # noqa: E402
from app.services import analysis_service  # noqa: E402
from app.services.provider_router import ProviderRouter  # noqa: E402


@pytest.fixture()
def isolated_app(tmp_path: Path):
    db_file = tmp_path / "ai_test.db"
    storage_dir = tmp_path / "storage"
    os.environ["DATABASE_URL"] = f"sqlite:///{db_file.as_posix()}"
    os.environ["STORAGE_DIR"] = str(storage_dir)
    os.environ["GEMINI_API_KEY"] = ""
    os.environ["GROQ_API_KEY"] = ""
    os.environ["FREE_ONLY"] = "true"
    os.environ["ALLOW_PAID_APIS"] = "false"
    os.environ["MONTHLY_BUDGET"] = "0"
    os.environ["ALLOW_HF_MICRO_FREE_CREDITS"] = "false"
    get_settings.cache_clear()

    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db import database

    test_engine = create_engine(
        os.environ["DATABASE_URL"],
        connect_args={"check_same_thread": False},
        future=True,
    )
    database.engine = test_engine
    database.SessionLocal = sessionmaker(bind=test_engine, autocommit=False, autoflush=False)

    from app import main as app_main

    app_main.engine = test_engine
    app_main.SessionLocal = database.SessionLocal

    app = create_app()
    with TestClient(app) as client:
        yield client, database.SessionLocal


def test_parse_ai_analysis_response_handles_fenced_json_and_lists():
    raw = """```json
    {
      "summary": "Dom dwumodułowy 68 m² z tarasem frontowym.",
      "spatial_layout": ["Strefa dzienna 32 m²", "Sypialnia 14 m²", "Trzy okna HS od południa"],
      "materials_proposal": "Blacha na rąbek RAL 7016, modrzew syberyjski",
      "lighting_proposal": "Światło dzienne rozproszone i podbitka LED 2700K",
      "geometry_preservation_note": "Zachować osie ścian nośnych i szerokość tarasu.",
      "visualization_prompt": "Photorealistic modular cabin preserving exact sketch layout"
    }
    ```"""
    parsed = analysis_service.parse_ai_analysis_response(raw, mode="sketch_to_render", preserve_geometry=True)
    assert "Dom dwumodułowy" in parsed.summary
    assert "- Strefa dzienna 32 m²" in parsed.spatial_layout
    assert "RAL 7016" in parsed.materials_proposal
    assert "Photorealistic modular cabin" in parsed.visualization_prompt
    assert parsed.geometry_protection is not None
    assert parsed.disclaimer


def test_analyze_missing_api_key_returns_503_without_fake_output(isolated_app):
    client, _ = isolated_app
    res = client.post(
        "/api/ai/analyze",
        json={
            "mode": "idea_to_project",
            "title": "Dom bez klucza",
            "prompt_brief": "Nowoczesny dom modułowy 75 m² na leśnej polanie z dużym tarasem.",
            "preferred_provider": "auto",
        },
    )
    assert res.status_code == 503
    assert "Brak skonfigurowanego darmowego klucza API" in res.json()["detail"]


def test_tryb_a_sketch_analysis_persists_to_sqlite_with_mocked_gemini(isolated_app, monkeypatch):
    client, SessionLocal = isolated_app

    # Create a real PNG/JPG test sketch file in storage via upload endpoint
    upload_res = client.post(
        "/api/projects/upload-sketch",
        files={"file": ("test_plan.png", b"\x89PNG\r\n\x1a\nfake-png-bytes", "image/png")},
    )
    assert upload_res.status_code == 200
    sketch_url = upload_res.json()["url"]

    create_res = client.post(
        "/api/projects",
        json={
            "title": "Test Tryb A Szkic",
            "mode": "sketch_to_render",
            "building_type": "Dom modułowy parterowy",
            "area_sqm": 68.0,
            "modules_count": 2,
            "style_preset": "Nordic Graphite",
            "preserve_geometry": True,
            "prompt_brief": "Zachować układ okien i tarasu.",
            "geometry_notes": "Okno HS 3.5 m",
            "sketch_image_url": sketch_url,
            "reference_ids": [],
        },
    )
    assert create_res.status_code == 201
    project_id = create_res.json()["id"]

    captured_requests = []

    def mock_handler(request: httpx.Request) -> httpx.Response:
        captured_requests.append(json.loads(request.content.decode("utf-8")))
        return httpx.Response(
            status_code=200,
            json={
                "candidates": [
                    {
                        "content": {
                            "parts": [
                                {
                                    "text": json.dumps(
                                        {
                                            "summary": "Analiza szkicu parterowego domu dwumodułowego.",
                                            "spatial_layout": "Układ liniowy: strefa dzienna od frontu, 3 przeszklenia tarasowe.",
                                            "materials_proposal": "Grafitowa blacha na rąbek i modrzew.",
                                            "lighting_proposal": "Światło rozproszone dzienne.",
                                            "geometry_preservation_note": "Nie zmieniać osi okien ani obrysu tarasu.",
                                            "visualization_prompt": "Architectural render matching exact sketch walls and windows.",
                                        },
                                        ensure_ascii=False,
                                    )
                                }
                            ]
                        }
                    }
                ]
            },
        )

    settings = Settings(_env_file=None, gemini_api_key="AIza_mock_secret_do_not_leak")
    guard = CostGuard(settings)
    transport = httpx.MockTransport(mock_handler)

    db = SessionLocal()
    try:
        # Patch router factory inside analysis_service for this test
        class MockedRouter(ProviderRouter):
            def select_vision_provider(self, session, preferred_key=None, strict_preferred=False):
                provider = GeminiProvider(settings, guard, db=session, transport=transport)
                usage = guard.get_or_create_usage(session, "gemini")
                decision = guard.evaluate_provider(provider.get_descriptor(), True, usage=usage)
                from app.services.provider_router import SelectedVisionProvider

                return SelectedVisionProvider(provider=provider, decision=decision, checked_providers=["gemini"])

        import asyncio

        updated_project = asyncio.run(
            analysis_service.analyze_and_save_for_project(
                db,
                settings,
                project_id=project_id,
                preferred_provider="gemini",
                router=MockedRouter(settings, guard),
            )
        )
        assert updated_project is not None
        assert updated_project.latest_analysis is not None
        assert updated_project.latest_analysis.provider == "gemini"
        assert updated_project.latest_analysis.is_free_tier is True
        assert "Układ liniowy" in updated_project.latest_analysis.spatial_layout
        assert "AIza_mock_secret" not in json.dumps(updated_project.model_dump(mode="json"))
    finally:
        db.close()

    # Verify the image inline_data was actually sent to Gemini
    assert len(captured_requests) == 1
    parts = captured_requests[0]["contents"][0]["parts"]
    assert any(p.get("inline_data", {}).get("mime_type") == "image/png" for p in parts)

    # Verify persistence via API GET and editing via PATCH /analysis
    get_res = client.get(f"/api/projects/{project_id}")
    assert get_res.status_code == 200
    assert get_res.json()["latest_analysis"]["summary"].startswith("Analiza szkicu")

    patch_res = client.patch(
        f"/api/projects/{project_id}/analysis",
        json={"materials_proposal": "Zmieniono: opalany modrzew i czarna stal"},
    )
    assert patch_res.status_code == 200
    assert patch_res.json()["latest_analysis"]["materials_proposal"] == "Zmieniono: opalany modrzew i czarna stal"


def test_tryb_b_draft_analysis_and_atomic_project_save_with_mocked_groq(isolated_app):
    client, SessionLocal = isolated_app

    def mock_groq_handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code=200,
            json={
                "choices": [
                    {
                        "message": {
                            "content": json.dumps(
                                {
                                    "summary": "Koncepcja pawilonu dwumodułowego 92 m² na działce leśnej.",
                                    "spatial_layout": "Moduł dzienny 48 m², łącznik wejściowy, moduł nocny 34 m².",
                                    "materials_proposal": "Stal malowana mat + cedr kanadyjski.",
                                    "lighting_proposal": "Podświetlenie liniowe okapu 2700K.",
                                    "geometry_preservation_note": "Szerokość transportowa modułu 3.45 m.",
                                    "visualization_prompt": "Two-module modern woodland pavilion at twilight.",
                                },
                                ensure_ascii=False,
                            )
                        }
                    }
                ]
            },
        )

    settings = Settings(_env_file=None, groq_api_key="gsk_mock_secret")
    guard = CostGuard(settings)
    transport = httpx.MockTransport(mock_groq_handler)

    db = SessionLocal()
    try:
        class MockedGroqRouter(ProviderRouter):
            def select_vision_provider(self, session, preferred_key=None, strict_preferred=False):
                provider = GroqProvider(settings, guard, db=session, transport=transport)
                usage = guard.get_or_create_usage(session, "groq")
                decision = guard.evaluate_provider(provider.get_descriptor(), True, usage=usage)
                from app.services.provider_router import SelectedVisionProvider

                return SelectedVisionProvider(provider=provider, decision=decision, checked_providers=["groq"])

        from app.schemas.analysis import AnalyzeDraftRequest
        import asyncio

        preview = asyncio.run(
            analysis_service.analyze_draft(
                db,
                settings,
                AnalyzeDraftRequest(
                    mode="idea_to_project",
                    title="Pawilon Leśny 92 m²",
                    prompt_brief="Nowoczesny dom z dwóch modułów z dużym tarasem i łącznikiem.",
                    preferred_provider="groq",
                ),
                router=MockedGroqRouter(settings, guard),
            )
        )
        assert preview.provider == "groq"
        assert preview.image_generation_available is False
        assert "niedostęp" in preview.image_generation_note.lower() or "brak" in preview.image_generation_note.lower()
    finally:
        db.close()

    # Now save project + initial_analysis atomically through REST API
    create_res = client.post(
        "/api/projects",
        json={
            "title": "Pawilon Leśny 92 m²",
            "mode": "idea_to_project",
            "building_type": "Pawilon dwumodułowy",
            "area_sqm": 92.0,
            "modules_count": 2,
            "style_preset": "Raw Steel & Cedar",
            "preserve_geometry": True,
            "prompt_brief": "Nowoczesny dom z dwóch modułów z dużym tarasem i łącznikiem.",
            "geometry_notes": "Szerokość 3.45 m",
            "reference_ids": [],
            "initial_analysis": {
                "mode": "idea_to_project",
                "provider": preview.provider,
                "model": preview.model,
                "is_free_tier": True,
                "summary": preview.summary + " (edytowano)",
                "spatial_layout": preview.spatial_layout,
                "materials_proposal": preview.materials_proposal,
                "lighting_proposal": preview.lighting_proposal,
                "geometry_preservation_note": preview.geometry_preservation_note,
                "visualization_prompt": preview.visualization_prompt,
            },
        },
    )
    assert create_res.status_code == 201
    created = create_res.json()
    assert created["latest_analysis"] is not None
    assert "(edytowano)" in created["latest_analysis"]["summary"]
    assert created["latest_analysis"]["provider"] == "groq"


def test_timeout_records_error_without_retries(isolated_app):
    _, SessionLocal = isolated_app
    settings = Settings(_env_file=None, gemini_api_key="AIza_timeout_secret")
    guard = CostGuard(settings)
    calls = 0

    def timeout_handler(_request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        raise httpx.ReadTimeout("Simulated read timeout")

    db = SessionLocal()
    try:
        provider = GeminiProvider(settings, guard, db=db, transport=httpx.MockTransport(timeout_handler))
        import asyncio

        with pytest.raises(ProviderTimeoutError):
            asyncio.run(provider.analyze_sketch("Analiza testowa"))
        assert calls == 1
        usage = guard.get_or_create_usage(db, "gemini")
        assert usage.last_error_code == 504
        assert "AIza_timeout_secret" not in usage.last_error
    finally:
        db.close()


def test_svg_sketch_rejected_cleanly_for_vision(isolated_app):
    client, _ = isolated_app
    upload_res = client.post(
        "/api/projects/upload-sketch",
        files={"file": ("vector_plan.svg", b"<svg></svg>", "image/svg+xml")},
    )
    assert upload_res.status_code == 200
    svg_url = upload_res.json()["url"]

    res = client.post(
        "/api/ai/analyze",
        json={
            "mode": "sketch_to_render",
            "title": "Test SVG",
            "sketch_image_url": svg_url,
            "preferred_provider": "auto",
        },
    )
    assert res.status_code == 400
    assert "SVG" in res.json()["detail"]


def test_fake_png_extension_rejected_by_magic_bytes(isolated_app):
    client, _ = isolated_app
    upload_res = client.post(
        "/api/projects/upload-sketch",
        files={"file": ("disguised.png", b"not-actually-a-png-header", "image/png")},
    )
    assert upload_res.status_code == 400
    assert "sygnaturę" in upload_res.json()["detail"]

    # Also verify that if a corrupted file already exists on disk, /api/ai/analyze rejects it by magic bytes
    settings = get_settings()
    sketches_dir = settings.storage_path / "sketches"
    sketches_dir.mkdir(parents=True, exist_ok=True)
    corrupted_file = sketches_dir / "disguised_on_disk.png"
    corrupted_file.write_bytes(b"not-actually-a-png-header")

    res = client.post(
        "/api/ai/analyze",
        json={
            "mode": "sketch_to_render",
            "title": "Test Fake PNG",
            "sketch_image_url": "/storage/sketches/disguised_on_disk.png",
            "preferred_provider": "auto",
        },
    )
    assert res.status_code == 400
    assert "nagłówkowi" in res.json()["detail"]


def test_groq_non_vision_model_blocked_before_http_call(isolated_app):
    _, SessionLocal = isolated_app
    settings = Settings(
        _env_file=None,
        groq_api_key="gsk_test_non_vision",
        groq_vision_model="qwen/qwen3.8-27b",
    )
    guard = CostGuard(settings)
    calls = 0

    def fail_if_called(_req: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(status_code=200, json={})

    db = SessionLocal()
    try:
        provider = GroqProvider(settings, guard, db=db, transport=httpx.MockTransport(fail_if_called))
        import asyncio

        with pytest.raises(ProviderRequestError) as exc_info:
            asyncio.run(provider.analyze_sketch("Analiza szkicu", image_base64="ZmFrZQ=="))
        assert "nie obsługuje analizy obrazów" in str(exc_info.value)
        assert calls == 0
    finally:
        db.close()


def test_error_sanitization_strips_secrets_and_fallback_marks_source(isolated_app):
    _, SessionLocal = isolated_app
    raw_msg = "Upstream rejected key AIzaSySecret12345678 and Bearer gsk_SecretToken9999"
    cleaned = sanitize_sensitive_text(raw_msg, secrets=["AIzaSySecret12345678"])
    assert "AIzaSySecret" not in cleaned
    assert "gsk_SecretToken" not in cleaned
    assert "[REDACTED]" in cleaned

    fallback = analysis_service.parse_ai_analysis_response(
        "Luźna odpowiedź tekstowa bez JSON.",
        mode="idea_to_project",
        preserve_geometry=True,
    )
    assert fallback.analysis_source == "fallback"

    settings = Settings(_env_file=None, gemini_api_key="AIza_http400_secret")
    guard = CostGuard(settings)

    def bad_request_handler(_req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code=400,
            json={"error": {"message": "Invalid key AIza_http400_secret"}},
        )

    db = SessionLocal()
    try:
        provider = GeminiProvider(settings, guard, db=db, transport=httpx.MockTransport(bad_request_handler))
        import asyncio

        with pytest.raises(ProviderRequestError) as exc_info:
            asyncio.run(provider.analyze_sketch("Test"))
        assert "AIza_http400_secret" not in str(exc_info.value)
        usage = guard.get_or_create_usage(db, "gemini")
        assert "AIza_http400_secret" not in usage.last_error
    finally:
        db.close()
