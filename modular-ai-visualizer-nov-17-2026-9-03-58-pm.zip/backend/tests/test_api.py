import os
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.config import get_settings  # noqa: E402
from app.main import create_app  # noqa: E402


@pytest.fixture()
def client(tmp_path: Path):
    db_file = tmp_path / "test_modular.db"
    storage_dir = tmp_path / "storage"
    os.environ["DATABASE_URL"] = f"sqlite:///{db_file.as_posix()}"
    os.environ["STORAGE_DIR"] = str(storage_dir)
    get_settings.cache_clear()

    # Rebind database engine for isolated test db
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db import database

    test_engine = create_engine(
        os.environ["DATABASE_URL"],
        connect_args={"check_same_thread": False},
        future=True,
    )
    database.engine = test_engine
    database.SessionLocal = sessionmaker(
        bind=test_engine, autocommit=False, autoflush=False
    )

    from app import main as app_main

    app_main.engine = test_engine
    app_main.SessionLocal = database.SessionLocal

    app = create_app()
    with TestClient(app) as test_client:
        yield test_client


def test_health_endpoint_checks_sqlite(client: TestClient):
    res = client.get("/api/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "ok"
    assert data["database_connected"] is True
    assert data["storage_ready"] is True


def test_projects_crud_and_summary(client: TestClient):
    summary_res = client.get("/api/projects/summary")
    assert summary_res.status_code == 200
    initial_total = summary_res.json()["total_projects"]
    assert initial_total >= 1

    create_res = client.post(
        "/api/projects",
        json={
            "title": "Testowy Moduł Leśny 55 m²",
            "mode": "sketch_to_render",
            "building_type": "Dom modułowy parterowy",
            "area_sqm": 55.0,
            "modules_count": 2,
            "style_preset": "Nordic Graphite",
            "preserve_geometry": True,
            "prompt_brief": "Zachować proporcje przeszkleń tarasowych.",
            "geometry_notes": "Okno tarasowe 3.6 m",
            "reference_ids": [],
        },
    )
    assert create_res.status_code == 201
    created = create_res.json()
    assert created["title"] == "Testowy Moduł Leśny 55 m²"
    assert created["preserve_geometry"] is True

    list_res = client.get("/api/projects")
    assert list_res.status_code == 200
    assert any(p["id"] == created["id"] for p in list_res.json())

    del_res = client.delete(f"/api/projects/{created['id']}")
    assert del_res.status_code == 204


def test_references_crud(client: TestClient):
    create_res = client.post(
        "/api/references",
        json={
            "title": "Beton architektoniczny szlifowany",
            "category": "material",
            "description": "Płyta posadzkowa do strefy dziennej.",
            "materials_note": "Beton C30/37 mat",
            "lighting_note": "Światło rozproszone",
            "style_tags": "beton, minimalizm",
        },
    )
    assert create_res.status_code == 201
    ref_id = create_res.json()["id"]

    filter_res = client.get("/api/references", params={"category": "material"})
    assert filter_res.status_code == 200
    assert any(item["id"] == ref_id for item in filter_res.json())


def test_providers_status_enforces_zero_cost_policy(client: TestClient):
    res = client.get("/api/providers/status")
    assert res.status_code == 200
    data = res.json()
    assert data["cost_policy"]["free_only"] is True
    assert data["cost_policy"]["allow_paid_apis"] is False
    assert data["cost_policy"]["monthly_budget"] == 0
    assert data["cost_policy"]["paid_services_blocked"] is True
    assert data["image_generator"]["status"] == "unavailable_free"
    assert len(data["providers"]) == 5
    openai_row = next(p for p in data["providers"] if p["key"] == "openai")
    assert openai_row["blocked_by_cost_policy"] is True
