import io
import os
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

ROOT_DIR = Path(__file__).resolve().parents[2]
BACKEND_DIR = ROOT_DIR / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.core.config import get_settings  # noqa: E402
from app.main import create_app  # noqa: E402
from scripts.backup_restore_storage import (  # noqa: E402
    create_backup,
    restore_backup,
    verify_sqlite_integrity,
)

SAMPLE_PNG = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
    b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01"
    b"\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
)


@pytest.fixture()
def isolated_env(tmp_path: Path):
    prev_db = os.environ.get("DATABASE_URL")
    prev_storage = os.environ.get("STORAGE_DIR")
    prev_gemini = os.environ.get("GEMINI_API_KEY")
    prev_groq = os.environ.get("GROQ_API_KEY")

    storage_dir = tmp_path / "storage"
    db_file = storage_dir / "modular_visualizer.db"
    backups_dir = tmp_path / "backups"

    os.environ["DATABASE_URL"] = f"sqlite:///{db_file.as_posix()}"
    os.environ["STORAGE_DIR"] = str(storage_dir)
    # Symulacja uruchomienia lokalnego całkowicie bez kluczy zewnętrznych usług AI
    os.environ["GEMINI_API_KEY"] = ""
    os.environ["GROQ_API_KEY"] = ""
    get_settings.cache_clear()

    from app import main as app_main
    from app.db import database

    test_engine = create_engine(
        os.environ["DATABASE_URL"],
        connect_args={"check_same_thread": False, "timeout": 15.0},
        future=True,
    )
    database.engine = test_engine
    database.SessionLocal = sessionmaker(bind=test_engine, autocommit=False, autoflush=False)
    app_main.engine = test_engine
    app_main.SessionLocal = database.SessionLocal

    app = create_app()
    try:
        with TestClient(app) as client:
            yield client, storage_dir, db_file, backups_dir
    finally:
        test_engine.dispose()
        if prev_db is None:
            os.environ.pop("DATABASE_URL", None)
        else:
            os.environ["DATABASE_URL"] = prev_db
        if prev_storage is None:
            os.environ.pop("STORAGE_DIR", None)
        else:
            os.environ["STORAGE_DIR"] = prev_storage
        if prev_gemini is None:
            os.environ.pop("GEMINI_API_KEY", None)
        else:
            os.environ["GEMINI_API_KEY"] = prev_gemini
        if prev_groq is None:
            os.environ.pop("GROQ_API_KEY", None)
        else:
            os.environ["GROQ_API_KEY"] = prev_groq
        get_settings.cache_clear()


def test_offline_startup_without_external_ai_keys(isolated_env):
    """Sprawdza, że aplikacja uruchamia się i działa lokalnie bez kluczy Gemini/Groq i bez internetu."""
    client, _, _, _ = isolated_env

    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"
    assert health.json()["database_connected"] is True
    assert health.json()["storage_ready"] is True

    # Wszystkie 5 projektów startowych (ID 1–5) i 8 kategorii referencji jest dostępnych offline
    projects = client.get("/api/projects").json()
    assert len(projects) >= 5
    references = client.get("/api/references").json()
    assert len(references) >= 8

    # Status providerów poprawnie informuje o polityce Zero-Cost (0 zł) i braku kluczy bez awarii
    status_res = client.get("/api/providers/status")
    assert status_res.status_code == 200
    status_data = status_res.json()
    assert status_data["cost_policy"]["free_only"] is True
    assert status_data["cost_policy"]["allow_paid_apis"] is False
    assert status_data["cost_policy"]["monthly_budget"] == 0.0
    assert status_data["cost_policy"]["paid_services_blocked"] is True


def test_backup_and_restore_preserves_projects_references_and_files(isolated_env):
    """Sprawdza pełny cykl wykonania kopii zapasowej SQLite + storage oraz odtworzenia danych."""
    client, storage_dir, db_file, backups_dir = isolated_env

    # 1. Przesłanie pliku do storage/uploads i dodanie własnej referencji oraz projektu
    up_res = client.post(
        "/api/references/upload-image",
        files={"file": ("local_wood_sample.png", io.BytesIO(SAMPLE_PNG), "image/png")},
    )
    assert up_res.status_code == 200
    uploaded_url = up_res.json()["url"]

    ref_res = client.post(
        "/api/references",
        json={
            "title": "Lokalny Wzornik Modrzewia (Test Backup)",
            "category": "material",
            "description": "Referencja do testu kopii zapasowej.",
            "tags": ["backup", "lokalny"],
            "image_url": uploaded_url,
        },
    )
    assert ref_res.status_code == 201
    new_ref_id = ref_res.json()["id"]

    proj_res = client.post(
        "/api/projects",
        json={
            "title": "Dom Testowy Kopii Zapasowej 84 m²",
            "mode": "idea_to_project",
            "building_type": "Dom modułowy",
            "area_sqm": 84.0,
            "modules_count": 3,
            "style_preset": "Nordic Graphite",
            "preserve_geometry": True,
            "prompt_brief": "Test trwałości kopii zapasowej i odtwarzania.",
            "reference_ids": [new_ref_id],
        },
    )
    assert proj_res.status_code == 201
    new_proj_id = proj_res.json()["id"]

    # 2. Wykonanie kopii zapasowej
    backup_folder = create_backup(
        storage_dir=storage_dir,
        db_path=db_file,
        backups_root=backups_dir,
        label="etap_3_9_test",
    )
    assert (backup_folder / "backup_manifest.json").exists()

    # 3. Symulacja utraty nowego projektu, referencji i pliku na dysku po wykonaniu kopii
    assert client.delete(f"/api/projects/{new_proj_id}").status_code == 204
    assert client.delete(f"/api/references/{new_ref_id}").status_code == 204
    uploaded_disk_file = storage_dir / uploaded_url.removeprefix("/storage/")
    if uploaded_disk_file.exists():
        uploaded_disk_file.unlink()
    assert not uploaded_disk_file.exists()

    # 4. Odtworzenie danych z kopii zapasowej
    restored_stats = restore_backup(
        backup_dir=backup_folder,
        target_storage_dir=storage_dir,
        target_db_path=db_file,
    )
    assert restored_stats["ok"] is True

    # 5. Weryfikacja, że projekt, referencja oraz plik fizyczny wróciły na miejsce
    restored_proj = client.get(f"/api/projects/{new_proj_id}")
    assert restored_proj.status_code == 200
    assert restored_proj.json()["title"] == "Dom Testowy Kopii Zapasowej 84 m²"
    assert new_ref_id in restored_proj.json()["reference_ids"]

    restored_ref = client.get(f"/api/references/{new_ref_id}")
    assert restored_ref.status_code == 200
    assert restored_ref.json()["title"] == "Lokalny Wzornik Modrzewia (Test Backup)"
    assert uploaded_disk_file.exists()


def test_production_sqlite_database_non_destructive_verification():
    """Sprawdza integralność aktualnej produkcyjnej bazy SQLite bez wykonywania zmian."""
    prod_db = ROOT_DIR / "storage" / "modular_visualizer.db"
    if prod_db.exists():
        stats = verify_sqlite_integrity(prod_db)
        assert stats["ok"] is True
        assert stats["projects_count"] >= 5
        assert stats["references_count"] >= 8
        assert stats["analyses_count"] >= 2
