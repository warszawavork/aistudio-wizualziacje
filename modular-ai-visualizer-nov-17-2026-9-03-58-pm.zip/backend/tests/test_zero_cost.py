import asyncio
import sys
from pathlib import Path

import httpx
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.config import Settings  # noqa: E402
from app.core.cost_guard import (  # noqa: E402
    CostGuard,
    CostPolicyViolation,
    ProviderQuotaExceededError,
)
from app.db.database import Base  # noqa: E402
from app.providers import (  # noqa: E402
    FreeImageGeneratorProvider,
    GeminiProvider,
    GroqProvider,
    HuggingFaceImageProvider,
    OpenAIImageProvider,
)
from app.services.provider_router import ProviderRouter  # noqa: E402


@pytest.fixture()
def db_session(tmp_path: Path):
    db_file = tmp_path / "zero_cost_test.db"
    engine = create_engine(
        f"sqlite:///{db_file.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    session = Session()
    try:
        yield session
    finally:
        session.close()


def test_default_settings_enforce_zero_budget():
    settings = Settings(_env_file=None)
    assert settings.free_only is True
    assert settings.allow_paid_apis is False
    assert settings.monthly_budget == 0.0
    assert settings.allow_hf_micro_free_credits is False


def test_paid_provider_blocked_before_network_call(db_session):
    settings = Settings(_env_file=None, openai_api_key="sk-test-never-used")
    guard = CostGuard(settings)
    openai_provider = OpenAIImageProvider(settings, guard, db=db_session)

    assert openai_provider.get_generation_status() == "disabled_by_cost_policy"
    with pytest.raises(CostPolicyViolation):
        asyncio.run(openai_provider.generate_visualization("Dom modułowy", []))


def test_hf_micro_credits_blocked_by_default(db_session):
    settings = Settings(_env_file=None, huggingface_api_token="hf_test_token")
    guard = CostGuard(settings)
    hf_provider = HuggingFaceImageProvider(settings, guard, db=db_session)

    assert hf_provider.get_generation_status() == "disabled_by_cost_policy"
    with pytest.raises(CostPolicyViolation):
        asyncio.run(hf_provider.generate_visualization("Dom modułowy", []))


def test_free_provider_can_be_selected_when_configured(db_session):
    settings = Settings(_env_file=None, groq_api_key="gsk_test_free_key")
    guard = CostGuard(settings)
    router = ProviderRouter(settings, guard)

    selected = router.select_vision_provider(db_session)
    assert selected.provider is not None
    assert selected.provider.get_descriptor().key == "groq"
    assert selected.decision.allowed is True
    assert selected.decision.availability_status == "available_free"


def test_missing_api_key_returns_clear_polish_message(db_session):
    settings = Settings(_env_file=None, gemini_api_key="", groq_api_key="")
    guard = CostGuard(settings)
    router = ProviderRouter(settings, guard)

    selected = router.select_vision_provider(db_session)
    assert selected.provider is None
    assert selected.decision.availability_status == "missing_api_key"
    assert "Brak skonfigurowanego klucza" in selected.decision.reason


def test_http_429_triggers_cooldown_and_stops_retries(db_session):
    settings = Settings(_env_file=None, gemini_api_key="AIza_test_key", default_cooldown_seconds=120)
    guard = CostGuard(settings)

    call_count = 0

    def handler(_request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        return httpx.Response(
            status_code=429,
            headers={"Retry-After": "90"},
            json={"error": {"message": "Quota exceeded"}},
        )

    transport = httpx.MockTransport(handler)
    gemini = GeminiProvider(settings, guard, db=db_session, transport=transport)

    with pytest.raises(ProviderQuotaExceededError):
        asyncio.run(gemini.analyze_sketch("Analiza szkicu domu modułowego"))

    # Must NOT perform uncontrolled retries
    assert call_count == 1

    usage = guard.get_or_create_usage(db_session, "gemini")
    assert usage.last_error_code == 429
    assert usage.cooldown_until is not None

    # Subsequent selection must block immediately during cooldown without network hit
    router = ProviderRouter(settings, guard)
    selected = router.select_vision_provider(db_session, preferred_key="gemini")
    assert selected.provider is None
    assert selected.decision.availability_status == "cooldown"


def test_groq_429_also_triggers_cooldown_without_paid_fallback(db_session):
    settings = Settings(_env_file=None, groq_api_key="gsk_test_key")
    guard = CostGuard(settings)

    call_count = 0

    def handler(_request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        return httpx.Response(status_code=429, headers={"Retry-After": "45"})

    groq = GroqProvider(settings, guard, db=db_session, transport=httpx.MockTransport(handler))
    with pytest.raises(ProviderQuotaExceededError):
        asyncio.run(groq.analyze_sketch("Analiza"))

    assert call_count == 1
    usage = guard.get_or_create_usage(db_session, "groq")
    assert usage.last_error_code == 429
    assert usage.cooldown_until is not None


def test_free_image_generator_does_not_make_paid_calls_or_fake_renders():
    free_gen = FreeImageGeneratorProvider()
    assert free_gen.get_generation_status() == "unavailable_free"
    result = asyncio.run(free_gen.generate_visualization("Dom sosnowy", []))
    assert result["status"] == "unavailable_free"
    assert result["generated_image_url"] is None
    assert "Brak potwierdzonej darmowej usługi" in result["message"]
