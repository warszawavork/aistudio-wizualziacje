import asyncio
import base64
import struct
import sys
import zlib
from pathlib import Path

import httpx
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.config import Settings  # noqa: E402
from app.core.cost_guard import (  # noqa: E402
    CostGuard,
    CostPolicyViolation,
    ProviderQuotaExceededError,
    ProviderRequestError,
    ProviderTimeoutError,
)
from app.db.database import Base  # noqa: E402
from app.providers import (  # noqa: E402
    GeminiImagenProvider,
    LocalComfyUIImageProvider,
    LocalSDWebUIImageProvider,
    OpenAIMultiImageProvider,
    UnverifiedCloudImageProvider,
    validate_image_magic_bytes,
)
from app.schemas.analysis import ProjectAnalysisDraft  # noqa: E402
from app.schemas.image_generation import (  # noqa: E402
    GenerateDraftImageRequest,
    GenerateImageRequest,
)
from app.schemas.project import ProjectCreate  # noqa: E402
from app.services import image_generation_service, project_service  # noqa: E402
from app.services.provider_router import ImageProviderRouter  # noqa: E402


def _make_valid_png_bytes(width: int = 32, height: int = 24) -> bytes:
    """Builds a minimal valid PNG binary with IHDR, IDAT, and IEND chunks."""

    def _chunk(chunk_type: bytes, data: bytes) -> bytes:
        crc = zlib.crc32(chunk_type + data) & 0xFFFFFFFF
        return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", crc)

    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = _chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
    raw_scanlines = b"".join(b"\x00" + (b"\x20\x40\x60" * width) for _ in range(height))
    idat = _chunk(b"IDAT", zlib.compress(raw_scanlines))
    iend = _chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


@pytest.fixture()
def db_session(tmp_path: Path):
    db_file = tmp_path / "image_gen_test.db"
    engine = create_engine(
        f"sqlite:///{db_file.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    session = Session()
    try:
        yield session
    finally:
        session.close()


def test_1_paid_image_providers_strictly_blocked_by_cost_guard(db_session):
    settings = Settings(
        _env_file=None,
        openai_api_key="sk-test-never-call",
        gemini_api_key="AIza-test-never-call",
    )
    guard = CostGuard(settings)

    openai_gen = OpenAIMultiImageProvider(settings, guard, db=db_session)
    imagen_gen = GeminiImagenProvider(settings, guard, db=db_session)

    openai_status = asyncio.run(openai_gen.get_status(db_session))
    imagen_status = asyncio.run(imagen_gen.get_status(db_session))

    assert openai_status.available is False
    assert openai_status.blocked_by_cost_policy is True
    assert openai_status.availability_status == "disabled_by_cost_policy"
    assert openai_status.is_truly_free is False

    assert imagen_status.available is False
    assert imagen_status.blocked_by_cost_policy is True
    assert imagen_status.availability_status == "disabled_by_cost_policy"
    assert imagen_status.is_truly_free is False

    with pytest.raises(CostPolicyViolation):
        asyncio.run(openai_gen.generate("Dom modułowy w lesie"))

    with pytest.raises(CostPolicyViolation):
        asyncio.run(imagen_gen.generate("Dom modułowy w lesie"))


def test_2_unverified_image_provider_blocked_by_cost_guard(db_session):
    settings = Settings(_env_file=None)
    guard = CostGuard(settings)
    unverified = UnverifiedCloudImageProvider(settings, guard, db=db_session)

    status_info = asyncio.run(unverified.get_status(db_session))
    assert status_info.available is False
    assert status_info.is_verified is False
    assert status_info.verification_status == "unverified"
    assert status_info.blocked_by_cost_policy is True
    assert status_info.availability_status == "unverified_blocked"
    assert "niezweryfikowany" in status_info.unavailability_reason.lower()

    with pytest.raises(CostPolicyViolation):
        asyncio.run(unverified.generate("Dom modułowy"))


def test_3_router_selects_only_verified_free_healthy_provider(db_session):
    settings = Settings(_env_file=None)
    guard = CostGuard(settings)
    png_b64 = base64.b64encode(_make_valid_png_bytes()).decode("ascii")

    def healthy_sd_handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/sdapi/v1/sd-models"):
            return httpx.Response(200, json=[{"title": "sd_xl_base_1.0"}])
        if request.url.path.endswith("/sdapi/v1/txt2img"):
            return httpx.Response(200, json={"images": [png_b64]})
        return httpx.Response(404)

    def offline_comfy_handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(503)

    candidates = [
        OpenAIMultiImageProvider(settings, guard, db=db_session),
        UnverifiedCloudImageProvider(settings, guard, db=db_session),
        LocalComfyUIImageProvider(
            settings,
            guard,
            db=db_session,
            transport=httpx.MockTransport(offline_comfy_handler),
        ),
        LocalSDWebUIImageProvider(
            settings,
            guard,
            db=db_session,
            transport=httpx.MockTransport(healthy_sd_handler),
        ),
    ]
    router = ImageProviderRouter(settings, guard, candidates=candidates)
    selected = asyncio.run(router.select_image_provider(db_session))

    assert selected.provider is not None
    assert selected.provider.get_descriptor().key == "local_sd_webui"
    assert selected.decision.allowed is True
    assert selected.decision.availability_status == "available_free"
    assert selected.status is not None
    assert selected.status.supports_image_to_image is True
    assert selected.status.supports_geometry_preservation is True


def test_4_no_available_engine_returns_clean_status_without_fake_render(db_session, tmp_path: Path):
    settings = Settings(_env_file=None, storage_dir=str(tmp_path / "storage"))
    guard = CostGuard(settings)

    def offline_handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(503)

    offline_transport = httpx.MockTransport(offline_handler)
    candidates = [
        LocalSDWebUIImageProvider(settings, guard, db=db_session, transport=offline_transport),
        LocalComfyUIImageProvider(settings, guard, db=db_session, transport=offline_transport),
        GeminiImagenProvider(settings, guard, db=db_session, transport=offline_transport),
        OpenAIMultiImageProvider(settings, guard, db=db_session, transport=offline_transport),
        UnverifiedCloudImageProvider(settings, guard, db=db_session, transport=offline_transport),
    ]
    router = ImageProviderRouter(settings, guard, candidates=candidates)

    resp = asyncio.run(
        image_generation_service.generate_image_for_draft(
            db_session,
            settings,
            GenerateDraftImageRequest(
                mode="idea_to_project",
                title="Dom Sosnowy 72m2",
                prompt="Parterowy dom modułowy w lesie sosnowym",
            ),
            router=router,
        )
    )

    assert resp.render_status == "unavailable_free"
    assert resp.generated_image_url is None
    assert resp.provider_key is None


def test_5_http_429_and_timeout_handling_without_retry_loops(db_session):
    settings = Settings(
        _env_file=None,
        default_cooldown_seconds=90,
        image_gen_timeout_seconds=1.5,
    )
    guard = CostGuard(settings)

    post_calls = 0

    def rate_limit_handler(request: httpx.Request) -> httpx.Response:
        nonlocal post_calls
        if request.url.path.endswith("/sdapi/v1/sd-models"):
            return httpx.Response(200, json=[{"title": "sd_xl_base_1.0"}])
        post_calls += 1
        return httpx.Response(429, headers={"Retry-After": "75"}, json={"detail": "Queue full"})

    sd_provider = LocalSDWebUIImageProvider(
        settings,
        guard,
        db=db_session,
        transport=httpx.MockTransport(rate_limit_handler),
    )

    with pytest.raises(ProviderQuotaExceededError):
        asyncio.run(sd_provider.generate("Dom modułowy parterowy"))

    # Exactly 1 generation attempt, no retry loop
    assert post_calls == 1
    status_after_429 = asyncio.run(sd_provider.get_status(db_session))
    assert status_after_429.available is False
    assert status_after_429.availability_status == "cooldown"
    assert status_after_429.cooldown_until is not None

    # Timeout test on LocalComfyUIImageProvider
    def timeout_handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/system_stats"):
            return httpx.Response(200, json={"system": {"os": "linux"}})
        raise httpx.ReadTimeout("Simulated generation timeout", request=request)

    comfy_provider = LocalComfyUIImageProvider(
        settings,
        guard,
        db=db_session,
        transport=httpx.MockTransport(timeout_handler),
    )

    with pytest.raises(ProviderTimeoutError):
        asyncio.run(comfy_provider.generate("Dom modułowy"))


def test_6_strict_separation_of_analysis_status_and_image_generation_status(
    db_session, tmp_path: Path
):
    settings = Settings(_env_file=None, storage_dir=str(tmp_path / "storage"))
    guard = CostGuard(settings)

    # Create a project with a completed AI architectural analysis
    sketch_dir = settings.storage_path / "sketches"
    sketch_dir.mkdir(parents=True, exist_ok=True)
    sketch_path = sketch_dir / "plan_mod.png"
    sketch_path.write_bytes(_make_valid_png_bytes())

    project = project_service.create_project(
        db_session,
        ProjectCreate(
            title="Dom Modułowy z Gotową Analizą AI",
            mode="sketch_to_render",
            building_type="Dom modułowy parterowy",
            area_sqm=68.0,
            modules_count=2,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief="Elewacja z grafitowej blachy i modrzewia",
            geometry_notes="Zachować układ 3 pomieszczeń i drzwi D1-D3",
            sketch_image_url="/storage/sketches/plan_mod.png",
            reference_ids=[],
            initial_analysis=ProjectAnalysisDraft(
                mode="sketch_to_render",
                provider="gemini",
                model="gemini-3.1-flash-lite",
                is_free_tier=True,
                summary="Rozpoznano 3 pomieszczenia i obrys prostokątny.",
                spatial_layout="Salon, sypialnia, łazienka.",
                materials_proposal="Blacha na rąbek + modrzew.",
                lighting_proposal="Światło dzienne rozproszone.",
                geometry_preservation_note="Bezwzględna blokada geometrii.",
                visualization_prompt="Wizualizacja domu modułowego z zachowaniem rzutu.",
            ),
        ),
    )

    assert project.latest_analysis is not None
    assert project.preview_image_url is None

    def offline_handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(503)

    router = ImageProviderRouter(
        settings,
        guard,
        candidates=[
            LocalSDWebUIImageProvider(
                settings,
                guard,
                db=db_session,
                transport=httpx.MockTransport(offline_handler),
            )
        ],
    )

    gen_resp = asyncio.run(
        image_generation_service.generate_image_for_project(
            db_session,
            settings,
            project_id=project.id,
            payload=GenerateImageRequest(preferred_provider="auto"),
            router=router,
        )
    )

    # Analysis is completed, while image generation is honestly unavailable_free
    assert gen_resp.analysis_status == "completed"
    assert gen_resp.render_status == "unavailable_free"
    assert gen_resp.generated_image_url is None
    assert gen_resp.project is not None
    assert gen_resp.project.latest_analysis is not None
    assert gen_resp.project.latest_analysis.summary == "Rozpoznano 3 pomieszczenia i obrys prostokątny."


def test_7_save_and_read_generated_image_mode_a_img2img_and_mode_b_conceptual(
    db_session, tmp_path: Path
):
    settings = Settings(_env_file=None, storage_dir=str(tmp_path / "storage"))
    guard = CostGuard(settings)

    valid_png = _make_valid_png_bytes(64, 48)
    valid_png_b64 = base64.b64encode(valid_png).decode("ascii")

    sketch_dir = settings.storage_path / "sketches"
    sketch_dir.mkdir(parents=True, exist_ok=True)
    (sketch_dir / "input_sketch.png").write_bytes(valid_png)

    captured_requests = []

    def mock_sd_handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/sdapi/v1/sd-models"):
            return httpx.Response(200, json=[{"title": "sd_xl_base_1.0"}])
        if request.url.path.endswith("/sdapi/v1/img2img") or request.url.path.endswith(
            "/sdapi/v1/txt2img"
        ):
            captured_requests.append(request.url.path)
            return httpx.Response(200, json={"images": [valid_png_b64]})
        return httpx.Response(404)

    sd_provider = LocalSDWebUIImageProvider(
        settings,
        guard,
        db=db_session,
        transport=httpx.MockTransport(mock_sd_handler),
    )
    router = ImageProviderRouter(settings, guard, candidates=[sd_provider])

    # Mode A project (sketch_to_render) -> must use img2img and preserve geometry
    project_a = project_service.create_project(
        db_session,
        ProjectCreate(
            title="Mode A — Rzut Domu 68m2",
            mode="sketch_to_render",
            building_type="Dom modułowy",
            area_sqm=68.0,
            modules_count=2,
            style_preset="Nordic Graphite",
            preserve_geometry=True,
            prompt_brief="Modrzew i grafit",
            geometry_notes="Bez zmian stolarki",
            sketch_image_url="/storage/sketches/input_sketch.png",
            reference_ids=[],
        ),
    )

    res_a = asyncio.run(
        image_generation_service.generate_image_for_project(
            db_session,
            settings,
            project_id=project_a.id,
            payload=GenerateImageRequest(preferred_provider="local_sd_webui"),
            router=router,
        )
    )

    assert res_a.render_status == "completed"
    assert res_a.used_image_to_image is True
    assert res_a.geometry_preserved is True
    assert res_a.is_conceptual is False
    assert "GEOMETRY LOCK" in res_a.prompt_used
    assert res_a.generated_image_url is not None
    assert res_a.generated_image_url.startswith("/storage/renders/")
    assert any(p.endswith("/sdapi/v1/img2img") for p in captured_requests)

    # Verify saved file on disk is readable and passes magic byte validation
    rel_file = res_a.generated_image_url[len("/storage/") :]
    saved_bytes = (settings.storage_path / rel_file).read_bytes()
    assert validate_image_magic_bytes(saved_bytes) == "image/png"

    # Verify SQLite project was updated with preview_image_url
    reloaded_a = project_service.get_project(db_session, project_a.id)
    assert reloaded_a is not None
    assert reloaded_a.preview_image_url == res_a.generated_image_url

    # Mode B project (idea_to_project) -> must generate conceptual image and mark is_conceptual=True
    project_b = project_service.create_project(
        db_session,
        ProjectCreate(
            title="Mode B — Koncepcja Leśna",
            mode="idea_to_project",
            building_type="Pawilon dwumodułowy",
            area_sqm=92.0,
            modules_count=3,
            style_preset="Raw Steel & Cedar",
            preserve_geometry=True,
            prompt_brief="Trzy moduły połączone przeszklonym łącznikiem.",
            geometry_notes="",
            sketch_image_url=None,
            reference_ids=[],
        ),
    )

    res_b = asyncio.run(
        image_generation_service.generate_image_for_project(
            db_session,
            settings,
            project_id=project_b.id,
            payload=GenerateImageRequest(preferred_provider="local_sd_webui"),
            router=router,
        )
    )

    assert res_b.render_status == "completed"
    assert res_b.used_image_to_image is False
    assert res_b.is_conceptual is True
    assert res_b.conceptual_label is not None
    assert "koncepcyjna" in res_b.conceptual_label.lower()

    # Corrupted / truncated image bytes must be rejected before saving
    with pytest.raises(ProviderRequestError):
        validate_image_magic_bytes(b"\x89PNG\r\n\x1a\ntruncated_no_iend")
