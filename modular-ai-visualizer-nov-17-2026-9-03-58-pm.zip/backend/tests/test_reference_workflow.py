import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.config import ROOT_DIR, Settings, get_settings  # noqa: E402
from app.core.cost_guard import CostGuard  # noqa: E402
from app.db import database  # noqa: E402
from app.main import create_app  # noqa: E402
from app.models.project import Project  # noqa: E402
from app.models.reference import ReferenceItem  # noqa: E402
from app.services import analysis_service, reference_service  # noqa: E402
from app.services.provider_router import ProviderRouter  # noqa: E402


@pytest.fixture()
def workflow_env(tmp_path: Path):
    db_file = tmp_path / "test_stage_3_7.db"
    storage_dir = tmp_path / "storage"
    os.environ["DATABASE_URL"] = f"sqlite:///{db_file.as_posix()}"
    os.environ["STORAGE_DIR"] = str(storage_dir)
    get_settings.cache_clear()

    test_engine = create_engine(
        os.environ["DATABASE_URL"],
        connect_args={"check_same_thread": False},
        future=True,
    )
    database.engine = test_engine
    database.SessionLocal = sessionmaker(
        bind=test_engine, autocommit=False, autoflush=False
    )

    from app import main as app_main

    app_main.engine = test_engine
    app_main.SessionLocal = database.SessionLocal

    app = create_app()
    with TestClient(app) as client:
        yield client, database.SessionLocal, db_file


def test_reference_crud_all_eight_categories_and_metadata_editing(workflow_env):
    client, _, _ = workflow_env

    categories_to_test = [
        ("sketch_plan", "Szkic rzutu modułu 54 m²", "szkic i rzut odniesienia"),
        ("visualization", "Wizualizacja dzienna z tarasem", "wizualizacja referencyjna"),
        ("realization", "Realizacja: Dom w sosnowym lesie", "przykład ukończonej realizacji"),
        ("material", "Faktura: modrzew szczotkowany", "materiał i faktura wykończeniowa"),
        ("color", "Paleta barwna: antracyt i piasek", "paleta kolorystyczna"),
        ("lighting", "Oświetlenie liniowe okapu 2700K", "scenariusz oświetlenia"),
        ("style", "Styl: Nordic Minimalist Timber", "styl architektoniczny"),
        ("interior", "Aranżacja salonu z wyspą kuchenną", "aranżacja wnętrza i wyposażenia"),
    ]

    created_ids = []
    for cat_key, title, expected_role in categories_to_test:
        res = client.post(
            "/api/references",
            json={
                "title": title,
                "category": cat_key,
                "description": f"Opis testowy dla kategorii {cat_key}.",
                "materials_note": "Modrzew, stal grafitowa",
                "lighting_note": "Naturalne dzienne 4500K",
                "style_tags": f"{cat_key}, test_tag, architektura",
                "image_url": "/src/assets/images/modular_cabin_exterior_1794908155648.jpg",
            },
        )
        assert res.status_code == 201, res.text
        body = res.json()
        assert body["title"] == title
        assert body["category"] == cat_key
        assert body["role"] == expected_role
        assert body["original_file_path"] == "/src/assets/images/modular_cabin_exterior_1794908155648.jpg"
        assert cat_key in body["tags"]
        assert "created_at" in body
        created_ids.append(body["id"])

    # Edit metadata (title, category, description, tags, materials_note, lighting_note)
    target_id = created_ids[0]
    patch_res = client.patch(
        f"/api/references/{target_id}",
        json={
            "title": "Zaktualizowany Rzut Modułu 54 m² — Wersja B",
            "category": "style",
            "description": "Zmieniony opis po weryfikacji architektonicznej.",
            "materials_note": "Opalane drewno Shou Sugi Ban + czarna anoda",
            "lighting_note": "Złota godzina 3000K",
            "style_tags": "shou_sugi_ban, korekta, styl_premium",
        },
    )
    assert patch_res.status_code == 200
    updated = patch_res.json()
    assert updated["title"] == "Zaktualizowany Rzut Modułu 54 m² — Wersja B"
    assert updated["category"] == "style"
    assert updated["role"] == "styl architektoniczny"
    assert updated["description"] == "Zmieniony opis po weryfikacji architektonicznej."
    assert updated["materials_note"] == "Opalane drewno Shou Sugi Ban + czarna anoda"
    assert updated["tags"] == ["shou_sugi_ban", "korekta", "styl_premium"]

    # Verify via GET by ID
    get_res = client.get(f"/api/references/{target_id}")
    assert get_res.status_code == 200
    assert get_res.json()["title"] == "Zaktualizowany Rzut Modułu 54 m² — Wersja B"


def test_reference_filtering_and_searching(workflow_env):
    client, _, _ = workflow_env

    client.post(
        "/api/references",
        json={
            "title": "Unikalny Trawertyn Srebrzysty",
            "category": "material",
            "description": "Kamień naturalny na ścianę kominkową.",
            "materials_note": "Trawertyn cięty wzdłuż włókien",
            "style_tags": "trawertyn_xyz, kamień, premium",
        },
    )
    client.post(
        "/api/references",
        json={
            "title": "Kolorystyka Ziemi i Mchu",
            "category": "color",
            "description": "Zestawienie oliwkowej zieleni z ciepłym dębem.",
            "materials_note": "NCS S 6010-G50Y, dąb naturalny",
            "style_tags": "oliwka_xyz, kolory_natury",
        },
    )

    # Filter by category
    color_res = client.get("/api/references", params={"category": "color"})
    assert color_res.status_code == 200
    color_items = color_res.json()
    assert len(color_items) >= 1
    assert all(item["category"] == "color" for item in color_items)

    # Search by query
    search_res = client.get("/api/references", params={"search": "Trawertyn Srebrzysty"})
    assert search_res.status_code == 200
    search_items = search_res.json()
    assert len(search_items) == 1
    assert search_items[0]["title"] == "Unikalny Trawertyn Srebrzysty"

    # Filter by tag
    tag_res = client.get("/api/references", params={"tag": "oliwka_xyz"})
    assert tag_res.status_code == 200
    tag_items = tag_res.json()
    assert len(tag_items) == 1
    assert tag_items[0]["title"] == "Kolorystyka Ziemi i Mchu"


def test_multi_reference_assignment_and_sqlite_persistence_across_sessions(workflow_env):
    client, session_factory, db_file = workflow_env

    # Create 4 references representing material, style, lighting, realization
    ref_ids = []
    for cat, title in [
        ("material", "Materiał: Blacha tytan-cynk"),
        ("style", "Styl: Pawilon horyzontalny"),
        ("lighting", "Oświetlenie: Szyny magnetyczne 2700K"),
        ("realization", "Realizacja: Rezydencja nad jeziorem"),
    ]:
        r = client.post(
            "/api/references",
            json={
                "title": title,
                "category": cat,
                "description": f"Opis dla {title}",
                "style_tags": f"{cat}, jezioro",
                "image_url": "/src/assets/images/modular_pavilion_concept_1794908154441.jpg",
            },
        )
        assert r.status_code == 201
        ref_ids.append(r.json()["id"])

    # Create Mode A project with first 3 references
    proj_res = client.post(
        "/api/projects",
        json={
            "title": "Projekt Testowy z Wieloma Referencjami",
            "mode": "sketch_to_render",
            "building_type": "Dom modułowy parterowy",
            "area_sqm": 78.0,
            "modules_count": 2,
            "style_preset": "Nordic Graphite",
            "preserve_geometry": True,
            "prompt_brief": "Zachować pełną geometrię rzutu i zastosować wybrane referencje.",
            "geometry_notes": "Oś okien bez zmian",
            "sketch_image_url": "/src/assets/images/architectural_hand_sketch_1794908154196.jpg",
            "reference_ids": ref_ids[:3],
        },
    )
    assert proj_res.status_code == 201
    project_id = proj_res.json()["id"]
    assert proj_res.json()["reference_ids"] == ref_ids[:3]

    # Modify assigned references via PATCH (remove first, add fourth)
    updated_ref_ids = [ref_ids[1], ref_ids[2], ref_ids[3]]
    patch_res = client.patch(
        f"/api/projects/{project_id}",
        json={"reference_ids": updated_ref_ids},
    )
    assert patch_res.status_code == 200
    assert patch_res.json()["reference_ids"] == updated_ref_ids

    # Re-open a brand new SQLite engine & session from disk to verify true persistence
    fresh_engine = create_engine(
        f"sqlite:///{db_file.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    FreshSession = sessionmaker(bind=fresh_engine, autocommit=False, autoflush=False)
    with FreshSession() as fresh_db:
        persisted_proj = fresh_db.get(Project, project_id)
        assert persisted_proj is not None
        read_proj = client.get(f"/api/projects/{project_id}").json()
        assert read_proj["reference_ids"] == updated_ref_ids

        # Verify reference list filtered by project_id returns the exact 3 references
        proj_refs = reference_service.list_references(fresh_db, project_id=project_id)
        proj_ref_ids = {r.id for r in proj_refs}
        assert set(updated_ref_ids).issubset(proj_ref_ids)
    fresh_engine.dispose()


def test_safe_deletion_protects_references_used_by_projects(workflow_env):
    client, _, _ = workflow_env

    # Create a reference and assign it to a new project
    ref_res = client.post(
        "/api/references",
        json={
            "title": "Chroniona Referencja Drewna Cedrowego",
            "category": "material",
            "description": "Referencja przypisana do aktywnego projektu.",
            "image_url": "/src/assets/images/material_charred_larch_1794908156119.jpg",
        },
    )
    ref_id = ref_res.json()["id"]

    proj_res = client.post(
        "/api/projects",
        json={
            "title": "Projekt Chroniący Referencję",
            "mode": "idea_to_project",
            "building_type": "Pawilon dwumodułowy",
            "area_sqm": 64.0,
            "modules_count": 2,
            "style_preset": "Raw Steel & Cedar",
            "preserve_geometry": True,
            "prompt_brief": "Koncepcja pawilonu z elewacją cedrową.",
            "reference_ids": [ref_id],
        },
    )
    project_id = proj_res.json()["id"]

    # Attempt to delete without force -> must be blocked with 409 Conflict
    del_blocked = client.delete(f"/api/references/{ref_id}")
    assert del_blocked.status_code == 409
    assert "Projekt Chroniący Referencję" in del_blocked.json()["detail"]

    # Reference still exists in SQLite
    check_ref = client.get(f"/api/references/{ref_id}")
    assert check_ref.status_code == 200
    assert check_ref.json()["is_in_use"] is True

    # Detach reference from project first, then delete cleanly
    client.patch(f"/api/projects/{project_id}", json={"reference_ids": []})
    del_ok = client.delete(f"/api/references/{ref_id}")
    assert del_ok.status_code == 204


def test_structured_ai_context_and_no_external_ai_calls_during_tests(workflow_env, monkeypatch):
    client, session_factory, _ = workflow_env

    # Guard against any real external HTTP call in Gemini or Groq
    import httpx

    async def _forbid_network(*args, **kwargs):
        raise AssertionError("Zewnętrzne wywołanie HTTP AI jest zabronione w testach Etapu 3.7!")

    monkeypatch.setattr(httpx.AsyncClient, "post", _forbid_network)

    # Create 2 references with distinct roles
    r1 = client.post(
        "/api/references",
        json={
            "title": "Faktura: Łupek Grafitowy",
            "category": "material",
            "description": "Kamień elewacyjny o strukturze łupanej.",
            "materials_note": "Łupek naturalny ciemny",
            "style_tags": "łupek, elewacja, kamień",
            "image_url": "/src/assets/images/material_charred_larch_1794908156119.jpg",
        },
    ).json()
    r2 = client.post(
        "/api/references",
        json={
            "title": "Oświetlenie: Podświetlenie Okapu 2700K",
            "category": "lighting",
            "description": "Ciepła linia LED pod okapem dachowym.",
            "lighting_note": "Taśma LED IP67 2700K",
            "style_tags": "led, zmierzch, okap",
            "image_url": "/src/assets/images/modular_pavilion_concept_1794908154441.jpg",
        },
    ).json()

    ctx_res = client.post(
        "/api/references/context-preview",
        json={
            "reference_ids": [r1["id"], r2["id"]],
            "project_id": 1,
            "project_title": "Dom Modułowy Sosnowy 68 m²",
        },
    )
    assert ctx_res.status_code == 200
    ctx = ctx_res.json()
    assert ctx["total_references"] == 2
    assert len(ctx["items"]) == 2
    assert ctx["items"][0]["role"] == "materiał i faktura wykończeniowa"
    assert ctx["items"][0]["image_path"] == "/src/assets/images/material_charred_larch_1794908156119.jpg"
    assert "Dom Modułowy Sosnowy 68 m²" in ctx["items"][0]["project_relation"]
    assert ctx["items"][1]["role"] == "scenariusz oświetlenia"
    assert "NIE TRENING MODELU" in ctx["formatted_prompt_context"]
    assert "Faktura: Łupek Grafitowy" in ctx["formatted_prompt_context"]
    assert "Oświetlenie: Podświetlenie Okapu 2700K" in ctx["formatted_prompt_context"]


def test_project_management_search_sort_edit_and_preserve_existing_projects():
    """Verify live production SQLite database preserves existing projects 1-5 and zero AI calls are made."""
    prod_db_path = ROOT_DIR / "storage" / "modular_visualizer.db"
    if not prod_db_path.exists():
        pytest.skip("Brak produkcyjnej bazy SQLite.")

    prod_engine = create_engine(
        f"sqlite:///{prod_db_path.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    ProdSession = sessionmaker(bind=prod_engine, autocommit=False, autoflush=False)
    with ProdSession() as db:
        projects = db.scalars(select(Project).order_by(Project.id.asc())).all()
        project_ids = [p.id for p in projects]
        assert len(projects) >= 5
        assert {1, 2, 3, 4, 5}.issubset(set(project_ids))
    prod_engine.dispose()
