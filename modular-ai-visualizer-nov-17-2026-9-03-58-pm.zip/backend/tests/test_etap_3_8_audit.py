import io
import os
import sqlite3
import sys
import time
from pathlib import Path

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.config import get_settings  # noqa: E402
from app.core.cost_guard import CostGuard, ProviderDescriptor  # noqa: E402
from app.db.database import ensure_sqlite_schema_migrations  # noqa: E402
from app.main import create_app  # noqa: E402
from app.services.storage_service import (  # noqa: E402
    _validate_safe_target_dir,
    ensure_storage_directories,
)

MINIMAL_PNG = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
    b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01"
    b"\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
)

SECOND_PNG = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x02\x00\x00\x00\x02"
    b"\x08\x02\x00\x00\x00\xfd\xd4\x9as\x00\x00\x00\x0eIDATx\x9cc`\xa0\x1d"
    b"\x00\x00\x00\x1e\x00\x01\xa9\x91\x87\xb1\x00\x00\x00\x00IEND\xaeB`\x82"
)


@pytest.fixture()
def client(tmp_path: Path):
    prev_db_url = os.environ.get("DATABASE_URL")
    prev_storage_dir = os.environ.get("STORAGE_DIR")

    db_file = tmp_path / "test_etap_3_8.db"
    storage_dir = tmp_path / "storage"
    os.environ["DATABASE_URL"] = f"sqlite:///{db_file.as_posix()}"
    os.environ["STORAGE_DIR"] = str(storage_dir)
    get_settings.cache_clear()

    from app import main as app_main
    from app.db import database

    test_engine = create_engine(
        os.environ["DATABASE_URL"],
        connect_args={"check_same_thread": False, "timeout": 15.0},
        future=True,
    )
    database.engine = test_engine
    database.SessionLocal = sessionmaker(bind=test_engine, autocommit=False, autoflush=False)
    app_main.engine = test_engine
    app_main.SessionLocal = database.SessionLocal

    app = create_app()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        test_engine.dispose()
        if prev_db_url is None:
            os.environ.pop("DATABASE_URL", None)
        else:
            os.environ["DATABASE_URL"] = prev_db_url
        if prev_storage_dir is None:
            os.environ.pop("STORAGE_DIR", None)
        else:
            os.environ["STORAGE_DIR"] = prev_storage_dir
        get_settings.cache_clear()


def test_repeated_reference_crud_cycle(client: TestClient):
    """1. Wielokrotne dodawanie, edytowanie i usuwanie referencji bez wycieków ani sierot."""
    initial_refs = client.get("/api/references").json()
    initial_count = len(initial_refs)

    for cycle in range(5):
        create_res = client.post(
            "/api/references",
            json={
                "title": f"Cykl testowy #{cycle} — Deska elewacyjna",
                "category": "material",
                "description": f"Opis poczatkowy cyklu {cycle}",
                "materials_note": "Swierk skandynawski",
                "lighting_note": "Dzienne rozproszone",
                "tags": ["cykl", f"iteracja-{cycle}"],
                "image_url": "/storage/samples/ref_timber.svg",
            },
        )
        assert create_res.status_code == 201
        ref_id = create_res.json()["id"]

        for edit_step in range(3):
            patch_res = client.patch(
                f"/api/references/{ref_id}",
                json={
                    "title": f"Cykl testowy #{cycle} — Edycja {edit_step}",
                    "category": "color" if edit_step % 2 == 1 else "material",
                    "description": f"Zaktualizowany opis w kroku {edit_step}",
                    "tags": ["cykl", f"krok-{edit_step}"],
                },
            )
            assert patch_res.status_code == 200
            body = patch_res.json()
            assert body["title"] == f"Cykl testowy #{cycle} — Edycja {edit_step}"
            assert f"krok-{edit_step}" in body["tags"]

        del_res = client.delete(f"/api/references/{ref_id}")
        assert del_res.status_code == 204
        assert client.get(f"/api/references/{ref_id}").status_code == 404

    final_refs = client.get("/api/references").json()
    assert len(final_refs) == initial_count


def test_many_references_assigned_to_single_project(client: TestClient):
    """2. Przypisanie wielu referencji (np. 15) do jednego projektu i budowanie kontekstu AI."""
    created_ref_ids = []
    categories = [
        "sketch_pair",
        "visualization",
        "realization",
        "material",
        "color",
        "lighting",
        "style",
        "interior",
    ]
    for idx in range(15):
        cat = categories[idx % len(categories)]
        res = client.post(
            "/api/references",
            json={
                "title": f"Masowa referencja #{idx + 1} ({cat})",
                "category": cat,
                "description": f"Material referencyjny nr {idx + 1}",
                "tags": [f"tag-{idx}", cat],
                "image_url": "/storage/samples/ref_nordic.svg",
            },
        )
        assert res.status_code == 201
        created_ref_ids.append(res.json()["id"])

    proj_res = client.post(
        "/api/projects",
        json={
            "title": "Projekt z 15 referencjami",
            "mode": "idea_to_project",
            "building_type": "Rezydencja modułowa",
            "area_sqm": 135.0,
            "modules_count": 5,
            "style_preset": "Nordic Graphite",
            "preserve_geometry": True,
            "prompt_brief": "Test wielu referencji przypisanych do jednego projektu.",
            "reference_ids": created_ref_ids,
        },
    )
    assert proj_res.status_code == 201
    proj = proj_res.json()
    assert len(proj["reference_ids"]) == 15
    assert proj["reference_ids"] == created_ref_ids

    ctx_res = client.get(f"/api/projects/{proj['id']}/reference-context")
    assert ctx_res.status_code == 200
    ctx = ctx_res.json()
    assert ctx["total_references"] == 15
    assert len(ctx["items"]) == 15


def test_single_reference_shared_across_multiple_projects(client: TestClient):
    """3. Przypisanie jednej referencji do wielu projektów oraz odłączanie kaskadowe."""
    ref_res = client.post(
        "/api/references",
        json={
            "title": "Współdzielony wzornik dębu wędzonego",
            "category": "material",
            "description": "Wspólny materiał dla 3 projektów.",
            "tags": ["dąb", "współdzielony"],
            "image_url": "/storage/samples/ref_timber.svg",
        },
    )
    assert ref_res.status_code == 201
    ref_id = ref_res.json()["id"]

    project_ids = []
    for idx in range(3):
        p_res = client.post(
            "/api/projects",
            json={
                "title": f"Projekt współdzielący #{idx + 1}",
                "mode": "sketch_to_render",
                "building_type": "Pawilon modułowy",
                "area_sqm": 48.0 + idx * 10,
                "modules_count": 2,
                "style_preset": "Timber Warm",
                "preserve_geometry": True,
                "prompt_brief": "Test współdzielenia jednej referencji.",
                "reference_ids": [ref_id],
            },
        )
        assert p_res.status_code == 201
        project_ids.append(p_res.json()["id"])

    ref_detail = client.get(f"/api/references/{ref_id}").json()
    assert ref_detail["is_in_use"] is True
    assert set(project_ids).issubset(set(ref_detail["linked_project_ids"]))

    # Próba zwykłego usunięcia musi zwrócić 409 Conflict
    conflict_res = client.delete(f"/api/references/{ref_id}")
    assert conflict_res.status_code == 409

    # Odłączenie z pierwszego projektu zachowuje powiązanie z pozostałymi dwoma
    client.patch(f"/api/projects/{project_ids[0]}", json={"reference_ids": []})
    ref_after_first = client.get(f"/api/references/{ref_id}").json()
    assert ref_after_first["is_in_use"] is True
    assert project_ids[0] not in ref_after_first["linked_project_ids"]
    assert project_ids[1] in ref_after_first["linked_project_ids"]
    assert project_ids[2] in ref_after_first["linked_project_ids"]
    assert ref_after_first["project_id"] in (project_ids[1], project_ids[2])


def test_corrupted_upload_and_path_traversal_protection(client: TestClient):
    """4. Błąd przesyłania uszkodzonego pliku, złośliwego SVG i niedozwolonego podkatalogu."""
    # Plik z rozszerzeniem .png, ale niepoprawnymi magic bytes
    fake_png = client.post(
        "/api/references/upload-image",
        files={"file": ("corrupted.png", io.BytesIO(b"NOT_A_REAL_PNG_HEADER_12345"), "image/png")},
    )
    assert fake_png.status_code == 400
    assert "sygnaturę" in fake_png.json()["detail"]

    # Pusty plik
    empty_png = client.post(
        "/api/references/upload-image",
        files={"file": ("empty.png", io.BytesIO(b""), "image/png")},
    )
    assert empty_png.status_code == 400

    # SVG ze znacznikiem <script>
    malicious_svg = (
        b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
        b"<script>alert(1)</script><rect width='100' height='100'/></svg>"
    )
    bad_svg_res = client.post(
        "/api/references/upload-image",
        files={"file": ("xss.svg", io.BytesIO(malicious_svg), "image/svg+xml")},
    )
    assert bad_svg_res.status_code == 400
    assert "skrypty" in bad_svg_res.json()["detail"]

    # Niedozwolony podkatalog w _validate_safe_target_dir
    settings = get_settings()
    base = ensure_storage_directories(settings)
    with pytest.raises(HTTPException) as exc_info:
        _validate_safe_target_dir(base, "../etc")
    assert exc_info.value.status_code == 400


def test_file_deduplication_and_atomic_write(client: TestClient):
    """5. Deduplikacja identycznych plików po skrócie SHA-256 i zapis atomowy."""
    res1 = client.post(
        "/api/references/upload-image",
        files={"file": ("first_name.png", io.BytesIO(SECOND_PNG), "image/png")},
    )
    res2 = client.post(
        "/api/references/upload-image",
        files={"file": ("different_name_same_bytes.png", io.BytesIO(SECOND_PNG), "image/png")},
    )
    assert res1.status_code == 200
    assert res2.status_code == 200
    # Ten sam obraz przesłany dwukrotnie wskazuje na ten sam zdeduplikowany plik na dysku
    assert res1.json()["url"] == res2.json()["url"]


def test_sqlite_rollback_and_missing_file_resilience(client: TestClient):
    """6. Obsługa brakujących plików oraz spójność bazy danych przy brakujących zasobach."""
    p_res = client.post(
        "/api/projects",
        json={
            "title": "Projekt z brakującym plikiem na dysku",
            "mode": "sketch_to_render",
            "building_type": "Dom modułowy",
            "area_sqm": 64.0,
            "modules_count": 2,
            "style_preset": "Nordic Graphite",
            "preserve_geometry": True,
            "prompt_brief": "Test odporności na brak pliku na dysku.",
            "sketch_image_url": "/storage/sketches/non_existent_sketch_file_999.png",
        },
    )
    assert p_res.status_code == 201
    pid = p_res.json()["id"]

    # Próba analizy AI na brakującym pliku zwraca czytelny błąd 400 bez uszkodzenia bazy
    analyze_res = client.post(
        f"/api/projects/{pid}/analyze",
        json={"preferred_provider": "auto"},
    )
    assert analyze_res.status_code == 400
    # Projekt nadal istnieje i baza jest w pełni spójna
    get_res = client.get(f"/api/projects/{pid}")
    assert get_res.status_code == 200
    assert get_res.json()["title"] == "Projekt z brakującym plikiem na dysku"


def test_large_lists_pagination_and_query_performance(client: TestClient):
    """7. Duża lista projektów i referencji — paginacja (limit/offset) i pomiar czasu odpowiedzi."""
    for i in range(25):
        r = client.post(
            "/api/references",
            json={
                "title": f"Wydajnościowa referencja #{i:02d}",
                "category": "style" if i % 2 == 0 else "interior",
                "description": "Test wydajności filtrowania i paginacji.",
                "tags": ["perf", f"batch-{i % 5}"],
                "image_url": "/storage/samples/ref_minimal.svg",
            },
        )
        assert r.status_code == 201

    for i in range(20):
        p = client.post(
            "/api/projects",
            json={
                "title": f"Wydajnościowy projekt #{i:02d}",
                "mode": "idea_to_project" if i % 2 == 0 else "sketch_to_render",
                "building_type": "Pawilon modułowy",
                "area_sqm": 45.0 + i,
                "modules_count": 2,
                "style_preset": "Minimal Concrete",
                "preserve_geometry": True,
                "prompt_brief": "Test wydajności listy projektów.",
            },
        )
        assert p.status_code == 201

    t0 = time.perf_counter()
    page1_refs = client.get("/api/references?limit=10&offset=0")
    page2_refs = client.get("/api/references?limit=10&offset=10")
    refs_elapsed_ms = (time.perf_counter() - t0) * 1000.0

    assert page1_refs.status_code == 200
    assert page2_refs.status_code == 200
    assert len(page1_refs.json()) == 10
    assert len(page2_refs.json()) == 10
    assert page1_refs.json()[0]["id"] != page2_refs.json()[0]["id"]
    assert refs_elapsed_ms < 500.0

    t1 = time.perf_counter()
    page1_projs = client.get("/api/projects?limit=10&offset=0&sort_by=area_desc")
    page2_projs = client.get("/api/projects?limit=10&offset=10&sort_by=area_desc")
    projs_elapsed_ms = (time.perf_counter() - t1) * 1000.0

    assert page1_projs.status_code == 200
    assert page2_projs.status_code == 200
    assert len(page1_projs.json()) == 10
    assert len(page2_projs.json()) == 10
    assert projs_elapsed_ms < 500.0


def test_rapid_sequential_queries_and_referential_integrity(client: TestClient):
    """8. Szybkie kolejne zapytania i odporność na wyścigi odczytu/zapisu."""
    start = time.perf_counter()
    for _ in range(15):
        assert client.get("/api/projects/summary").status_code == 200
        assert client.get("/api/references?category=material").status_code == 200
        assert client.get("/api/projects?mode=sketch_to_render").status_code == 200
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    assert elapsed_ms < 2500.0


def test_invalid_inputs_and_referential_filtering(client: TestClient):
    """9. Niepoprawne dane wejściowe: białe znaki, path traversal, nieistniejące ID referencji."""
    whitespace_proj = client.post(
        "/api/projects",
        json={
            "title": "    ",
            "mode": "idea_to_project",
            "building_type": "Dom",
        },
    )
    assert whitespace_proj.status_code == 422

    whitespace_ref = client.post(
        "/api/references",
        json={
            "title": "   ",
            "category": "material",
        },
    )
    assert whitespace_ref.status_code == 422

    traversal_ref = client.post(
        "/api/references",
        json={
            "title": "Próba path traversal",
            "category": "material",
            "image_url": "/storage/../../etc/passwd",
        },
    )
    assert traversal_ref.status_code == 422

    neg_area = client.post(
        "/api/projects",
        json={
            "title": "Ujemny metraż",
            "mode": "idea_to_project",
            "area_sqm": -15.0,
        },
    )
    assert neg_area.status_code == 422

    valid_proj = client.post(
        "/api/projects",
        json={
            "title": "Projekt z nieistniejącymi ID referencji",
            "mode": "idea_to_project",
            "reference_ids": [999991, 999992],
        },
    )
    assert valid_proj.status_code == 201
    assert valid_proj.json()["reference_ids"] == []


def test_production_db_integrity_indexes_and_zero_cost_guard():
    """10. Weryfikacja produkcyjnej bazy SQLite (Projekty ID 1-5), indeksów i CostGuard (0 zł)."""
    settings = get_settings()
    assert settings.free_only is True
    assert settings.allow_paid_apis is False
    assert settings.monthly_budget == 0.0
    assert settings.allow_hf_micro_free_credits is False

    guard = CostGuard(settings)
    assert guard.paid_apis_blocked is True

    paid_descriptor = ProviderDescriptor(
        key="paid_cloud_engine",
        name="Paid Cloud Engine",
        role="image_generation",
        plan_type="paid",
        model="paid-v1",
        is_paid_endpoint=True,
        is_free_tier_confirmed=False,
        requires_micro_credits=False,
        rpm_limit=10,
        rpd_limit=100,
        configured_limits_note="Paid endpoint test",
        is_verified=True,
        requires_api_key=True,
    )
    decision = guard.evaluate_provider(paid_descriptor, api_key_configured=True)
    assert decision.allowed is False
    assert decision.blocked_by_cost_policy is True

    prod_db_path = Path(__file__).resolve().parents[2] / "storage" / "modular_visualizer.db"
    if prod_db_path.exists():
        prod_engine = create_engine(
            f"sqlite:///{prod_db_path.as_posix()}",
            connect_args={"check_same_thread": False, "timeout": 15.0},
            future=True,
        )
        try:
            ensure_sqlite_schema_migrations(prod_engine)
        finally:
            prod_engine.dispose()

        conn = sqlite3.connect(str(prod_db_path))
        try:
            cur = conn.cursor()
            cur.execute("SELECT id, title FROM projects WHERE id IN (1, 2, 3, 4, 5) ORDER BY id")
            rows = cur.fetchall()
            found_ids = [r[0] for r in rows]
            assert found_ids == [1, 2, 3, 4, 5], f"Brak wymaganych projektów ID 1-5: {found_ids}"

            cur.execute("SELECT COUNT(*) FROM project_analyses WHERE project_id IN (4, 5)")
            analyses_4_5 = cur.fetchone()[0]
            assert analyses_4_5 >= 2

            cur.execute("SELECT COUNT(*) FROM reference_items")
            refs_count = cur.fetchone()[0]
            assert refs_count >= 8

            cur.execute(
                "SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'ix_%'"
            )
            indexes = {r[0] for r in cur.fetchall()}
            assert "ix_projects_created_at" in indexes
            assert "ix_reference_items_created_at" in indexes
            assert "ix_project_analyses_project_id_created_at" in indexes
        finally:
            conn.close()
