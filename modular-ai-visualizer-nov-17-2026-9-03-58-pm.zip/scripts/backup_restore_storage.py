#!/usr/bin/env python3
"""
Modular AI Visualizer — Bezpieczna kopia zapasowa i odtwarzanie bazy SQLite oraz magazynu plików (ETAP 3.9).

Funkcje:
- Tworzy spójną transakcyjnie kopię bazy SQLite (`sqlite3.Connection.backup`) bez zatrzymywania aplikacji.
- Kopiuje pliki referencyjne, szkice i wygenerowane wizualizacje z katalogu `storage/` (`uploads`, `sketches`, `renders`).
- Weryfikuje integralność bazy (`PRAGMA integrity_check`) oraz zapisuje manifest SHA-256 (`backup_manifest.json`).
- Umożliwia bezpieczne odtworzenie danych z wybranej kopii zapasowej z zachowaniem wszystkich projektów i referencji.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List

ROOT_DIR = Path(__file__).resolve().parents[1]
DEFAULT_STORAGE_DIR = ROOT_DIR / "storage"
DEFAULT_DB_FILE = DEFAULT_STORAGE_DIR / "modular_visualizer.db"
DEFAULT_BACKUPS_ROOT = ROOT_DIR / "backups"
STORAGE_SUBFOLDERS = ("uploads", "sketches", "renders")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_sqlite_integrity(db_path: Path) -> Dict[str, int | str | bool]:
    if not db_path.exists():
        raise FileNotFoundError(f"Brak pliku bazy SQLite: {db_path}")

    conn = sqlite3.connect(str(db_path))
    try:
        cur = conn.cursor()
        integrity = cur.execute("PRAGMA integrity_check;").fetchone()[0]
        projects_count = cur.execute("SELECT COUNT(*) FROM projects;").fetchone()[0]
        analyses_count = cur.execute("SELECT COUNT(*) FROM project_analyses;").fetchone()[0]
        references_count = cur.execute("SELECT COUNT(*) FROM reference_items;").fetchone()[0]
        return {
            "ok": integrity == "ok",
            "integrity": str(integrity),
            "projects_count": int(projects_count),
            "analyses_count": int(analyses_count),
            "references_count": int(references_count),
        }
    finally:
        conn.close()


def create_backup(
    storage_dir: Path = DEFAULT_STORAGE_DIR,
    db_path: Path = DEFAULT_DB_FILE,
    backups_root: Path = DEFAULT_BACKUPS_ROOT,
    label: str = "manual",
) -> Path:
    if not db_path.exists():
        raise FileNotFoundError(f"Nie znaleziono pliku bazy SQLite do skopiowania: {db_path}")

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    safe_label = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in label).strip("_")
    backup_dir = backups_root / f"backup_{timestamp}_{safe_label or 'snapshot'}"
    backup_storage_dir = backup_dir / "storage"
    backup_storage_dir.mkdir(parents=True, exist_ok=True)

    backup_db_path = backup_storage_dir / db_path.name

    # Transakcyjny hot-backup SQLite przez natywne API sqlite3.backup
    src_conn = sqlite3.connect(str(db_path))
    dst_conn = sqlite3.connect(str(backup_db_path))
    try:
        with dst_conn:
            src_conn.backup(dst_conn)
    finally:
        dst_conn.close()
        src_conn.close()

    copied_files: List[Dict[str, str | int]] = []
    for subfolder in STORAGE_SUBFOLDERS:
        src_sub = storage_dir / subfolder
        dst_sub = backup_storage_dir / subfolder
        dst_sub.mkdir(parents=True, exist_ok=True)
        if not src_sub.exists():
            continue
        for item in sorted(src_sub.iterdir()):
            if item.is_file():
                target_file = dst_sub / item.name
                shutil.copy2(item, target_file)
                copied_files.append(
                    {
                        "relative_path": f"storage/{subfolder}/{item.name}",
                        "size_bytes": target_file.stat().st_size,
                        "sha256": _sha256_file(target_file),
                    }
                )

    integrity_stats = verify_sqlite_integrity(backup_db_path)
    manifest = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "database_file": f"storage/{db_path.name}",
        "database_sha256": _sha256_file(backup_db_path),
        "database_stats": integrity_stats,
        "copied_files_count": len(copied_files),
        "copied_files": copied_files,
    }
    (backup_dir / "backup_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return backup_dir


def restore_backup(
    backup_dir: Path,
    target_storage_dir: Path = DEFAULT_STORAGE_DIR,
    target_db_path: Path = DEFAULT_DB_FILE,
) -> Dict[str, int | str | bool]:
    manifest_path = backup_dir / "backup_manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Brak pliku backup_manifest.json w katalogu: {backup_dir}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    backup_db_path = backup_dir / manifest["database_file"]
    if not backup_db_path.exists():
        raise FileNotFoundError(f"Brak pliku bazy w kopii zapasowej: {backup_db_path}")

    stats = verify_sqlite_integrity(backup_db_path)
    if not stats["ok"]:
        raise RuntimeError(f"Kopia bazy danych nie przeszła kontroli integralności: {stats}")

    target_storage_dir.mkdir(parents=True, exist_ok=True)
    target_db_path.parent.mkdir(parents=True, exist_ok=True)

    # Odtworzenie bazy SQLite przez sqlite3.backup (bezpieczne dla blokad plików w Windows)
    src_conn = sqlite3.connect(str(backup_db_path))
    dst_conn = sqlite3.connect(str(target_db_path))
    try:
        with dst_conn:
            src_conn.backup(dst_conn)
    finally:
        dst_conn.close()
        src_conn.close()

    # Odtworzenie plików w podkatalogach storage
    for subfolder in STORAGE_SUBFOLDERS:
        src_sub = backup_dir / "storage" / subfolder
        dst_sub = target_storage_dir / subfolder
        dst_sub.mkdir(parents=True, exist_ok=True)
        if not src_sub.exists():
            continue
        for item in sorted(src_sub.iterdir()):
            if item.is_file():
                shutil.copy2(item, dst_sub / item.name)

    return verify_sqlite_integrity(target_db_path)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Modular AI Visualizer — Narzędzie kopii zapasowej SQLite i katalogu storage/"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    backup_cmd = sub.add_parser("backup", help="Utwórz nową kopię zapasową SQLite i storage/")
    backup_cmd.add_argument("--label", default="local", help="Opcjonalna etykieta kopii")

    verify_cmd = sub.add_parser("verify", help="Sprawdź integralność aktualnej bazy SQLite")
    verify_cmd.add_argument("--db", default=str(DEFAULT_DB_FILE), help="Ścieżka do pliku .db")

    restore_cmd = sub.add_parser("restore", help="Odtwórz bazę SQLite i pliki z katalogu kopii")
    restore_cmd.add_argument("backup_path", help="Ścieżka do katalogu backup_<timestamp>")

    args = parser.parse_args()
    if args.command == "backup":
        out_dir = create_backup(label=args.label)
        print(f"[OK] Utworzono kopię zapasową w: {out_dir}")
        return 0
    if args.command == "verify":
        stats = verify_sqlite_integrity(Path(args.db))
        print(json.dumps(stats, indent=2, ensure_ascii=False))
        return 0 if stats["ok"] else 1
    if args.command == "restore":
        stats = restore_backup(Path(args.backup_path))
        print(f"[OK] Odtworzono dane z kopii. Stan bazy: {json.dumps(stats, ensure_ascii=False)}")
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
