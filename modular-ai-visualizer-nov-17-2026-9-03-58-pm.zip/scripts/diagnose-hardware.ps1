<#
.SYNOPSIS
    Modular AI Visualizer — Bezpieczna diagnostyka sprzetu i srodowiska lokalnego (ETAP 3.9)
.DESCRIPTION
    Skrypt WYLACZNIE ODCZYTUJE informacje o konfiguracji komputera:
    - model procesora (CPU), liczba rdzeni i watkow;
    - ilosc pamieci RAM (calkowita i aktualnie wolna);
    - model karty graficznej (GPU) oraz rzeczywista pamiec VRAM (z nvidia-smi, rejestru 64-bit i WMI);
    - wolne miejsce na dyskach lokalnych;
    - wersja i kompilacja systemu Windows;
    - dostepnosc sterownika NVIDIA / CUDA (jesli wystepuje);
    - dostepnosc narzedzi Python, Node.js, npm oraz Git.

    GWARANCJA BEZPIECZENSTWA (READ-ONLY / ZERO-COST):
    - Nie instaluje zadnych programow ani pakietow.
    - Nie pobiera modeli AI.
    - Nie zmienia zadnych ustawien systemowych ani zmiennych srodowiskowych.
    - Nie wykonuje zadnych polaczen internetowych ani nie wysyla danych na zewnatrz.
#>

$ErrorActionPreference = "SilentlyContinue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host " MODULAR AI VISUALIZER — DIAGNOSTYKA SPRZETU (ETAP 3.9 | TYLKO ODCZYT)" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Wersja systemu Windows
$os = Get-CimInstance -ClassName Win32_OperatingSystem
if ($os) {
    Write-Host "[1] SYSTEM OPERACYJNY WINDOWS" -ForegroundColor Yellow
    Write-Host ("    Nazwa systemu     : {0}" -f $os.Caption)
    Write-Host ("    Wersja / Build    : {0} (Build {1}, {2})" -f $os.Version, $os.BuildNumber, $os.OSArchitecture)
} else {
    Write-Host "[1] SYSTEM OPERACYJNY : Nie udalo sie odczytac danych WMI." -ForegroundColor Red
}
Write-Host ""

# 2. Procesor (CPU)
$cpus = Get-CimInstance -ClassName Win32_Processor
Write-Host "[2] PROCESOR (CPU)" -ForegroundColor Yellow
foreach ($cpu in $cpus) {
    Write-Host ("    Model             : {0}" -f $cpu.Name.Trim())
    Write-Host ("    Rdzenie / Watki   : {0} rdzeni fizycznych / {1} watkow logicznych" -f $cpu.NumberOfCores, $cpu.NumberOfLogicalProcessors)
    Write-Host ("    Taktowanie bazowe : {0} MHz" -f $cpu.MaxClockSpeed)
}
Write-Host ""

# 3. Pamiec RAM
$cs = Get-CimInstance -ClassName Win32_ComputerSystem
$totalRamGb = if ($cs) { [math]::Round($cs.TotalPhysicalMemory / 1GB, 2) } else { 0 }
$freeRamGb = if ($os) { [math]::Round(($os.FreePhysicalMemory * 1KB) / 1GB, 2) } else { 0 }
Write-Host "[3] PAMIEC OPERACYJNA (RAM)" -ForegroundColor Yellow
Write-Host ("    Calkowity RAM     : {0} GB" -f $totalRamGb)
Write-Host ("    Wolny RAM teraz   : {0} GB" -f $freeRamGb)
Write-Host ""

# 4. Karta graficzna (GPU) i pamiec VRAM
Write-Host "[4] KARTA GRAFICZNA (GPU) I PAMIEC VRAM" -ForegroundColor Yellow

# 4a. Odczyt 64-bitowych licznikow VRAM z rejestru (Win32_VideoController obcina >4 GB do 4 GB)
$regVramMap = @{}
$displayClassPath = "HKLM:\SYSTEM\ControlSet001\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
if (Test-Path $displayClassPath) {
    Get-ChildItem -Path $displayClassPath | ForEach-Object {
        $props = Get-ItemProperty -Path $_.PSPath
        $desc = $props.DriverDesc
        $qwMem = $props."HardwareInformation.qwMemorySize"
        if ($desc -and $qwMem -and ($qwMem -is [int64] -or $qwMem -is [uint64])) {
            $regVramMap[$desc] = [math]::Round($qwMem / 1GB, 2)
        }
    }
}

$gpus = Get-CimInstance -ClassName Win32_VideoController
foreach ($gpu in $gpus) {
    $gpuName = $gpu.Name
    $wmiVramGb = if ($gpu.AdapterRAM) { [math]::Round($gpu.AdapterRAM / 1GB, 2) } else { 0 }
    $realVramGb = if ($regVramMap.ContainsKey($gpuName)) { $regVramMap[$gpuName] } else { $wmiVramGb }
    Write-Host ("    Model GPU         : {0}" -f $gpuName)
    Write-Host ("    Wykryty VRAM      : {0} GB (WMI: {1} GB)" -f $realVramGb, $wmiVramGb)
    Write-Host ("    Wersja sterownika : {0}" -f $gpu.DriverVersion)
}
Write-Host ""

# 5. Dostepnosc NVIDIA CUDA (nvidia-smi / nvcc)
Write-Host "[5] DOSTEPNOSC CUDA / STEROWNIKA NVIDIA" -ForegroundColor Yellow
$nvidiaSmiCmd = Get-Command "nvidia-smi"
$nvidiaSmiPath = if ($nvidiaSmiCmd) {
    $nvidiaSmiCmd.Source
} elseif (Test-Path "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe") {
    "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe"
} else {
    $null
}

if ($nvidiaSmiPath) {
    $smiHeader = & $nvidiaSmiPath | Select-String -Pattern "CUDA Version"
    $smiQuery = & $nvidiaSmiPath --query-gpu=name,memory.total,memory.free,driver_version --format=csv,noheader,nounits
    Write-Host "    Status nvidia-smi : DOSTEPNY" -ForegroundColor Green
    if ($smiHeader) {
        Write-Host ("    Sterownik / CUDA  : {0}" -f $smiHeader.Line.Trim())
    }
    foreach ($line in $smiQuery) {
        $parts = $line -split ","
        if ($parts.Count -ge 4) {
            $vramTotalGb = [math]::Round(([double]$parts[1].Trim()) / 1024, 2)
            $vramFreeGb = [math]::Round(([double]$parts[2].Trim()) / 1024, 2)
            Write-Host ("    GPU (NVIDIA)      : {0} | VRAM calkowity: {1} GB | VRAM wolny: {2} GB | Driver: {3}" -f $parts[0].Trim(), $vramTotalGb, $vramFreeGb, $parts[3].Trim())
        }
    }
} else {
    Write-Host "    Status nvidia-smi : BRAK (nie wykryto karty NVIDIA lub sterownika NVIDIA CUDA)" -ForegroundColor DarkYellow
}

$nvccCmd = Get-Command "nvcc"
if ($nvccCmd) {
    $nvccVer = (& nvcc --version | Select-String -Pattern "release")
    Write-Host ("    CUDA Toolkit nvcc : DOSTEPNY ({0})" -f $nvccVer.Line.Trim())
} else {
    Write-Host "    CUDA Toolkit nvcc : Niezainstalowany globalnie (ComfyUI Portable posiada wlasne srodowisko PyTorch+CUDA)"
}
Write-Host ""

# 6. Wolne miejsce na dyskach lokalnych
Write-Host "[6] MIEJSCE NA DYSKACH LOKALNYCH (DriveType=3)" -ForegroundColor Yellow
$disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3"
foreach ($disk in $disks) {
    $freeGb = [math]::Round($disk.FreeSpace / 1GB, 2)
    $sizeGb = [math]::Round($disk.Size / 1GB, 2)
    Write-Host ("    Dysk {0}           : {1} GB wolne z {2} GB calkowitych" -f $disk.DeviceID, $freeGb, $sizeGb)
}
Write-Host ""

# 7. Dostepnosc narzedzi deweloperskich (Python, Node.js, npm, Git)
Write-Host "[7] DOSTEPNOSC NARZEDZI (Python, Node.js, Git)" -ForegroundColor Yellow

$pythonCmd = Get-Command "python"
if ($pythonCmd) {
    $pyVer = & python --version 2>&1
    Write-Host ("    Python            : DOSTEPNY ({0}) -> {1}" -f $pyVer, $pythonCmd.Source)
} else {
    Write-Host "    Python            : BRAK W PATH (wymagany Python 3.10 - 3.12)" -ForegroundColor Red
}

$nodeCmd = Get-Command "node"
if ($nodeCmd) {
    $nodeVer = & node --version 2>&1
    Write-Host ("    Node.js           : DOSTEPNY ({0}) -> {1}" -f $nodeVer, $nodeCmd.Source)
} else {
    Write-Host "    Node.js           : BRAK W PATH (wymagany Node.js 20 LTS lub 22 LTS)" -ForegroundColor Red
}

$npmCmd = Get-Command "npm"
if ($npmCmd) {
    $npmVer = & npm --version 2>&1
    Write-Host ("    npm               : DOSTEPNY (v{0})" -f $npmVer)
} else {
    Write-Host "    npm               : BRAK W PATH" -ForegroundColor Red
}

$gitCmd = Get-Command "git"
if ($gitCmd) {
    $gitVer = & git --version 2>&1
    Write-Host ("    Git               : DOSTEPNY ({0}) -> {1}" -f $gitVer, $gitCmd.Source)
} else {
    Write-Host "    Git               : BRAK W PATH (zalecany Git for Windows)" -ForegroundColor DarkYellow
}

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host " Koniec diagnostyki. Skopiuj powyzszy wynik i wklej go w czacie." -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
