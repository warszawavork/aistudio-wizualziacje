import { spawn } from 'node:child_process';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';

const isWindows = process.platform === 'win32';
const rootDir = process.cwd();
const backendDir = path.join(rootDir, 'backend');
const venvDir = path.join(backendDir, '.venv');
const venvBinDir = path.join(venvDir, isWindows ? 'Scripts' : 'bin');
const venvPython = path.join(venvBinDir, isWindows ? 'python.exe' : 'python3');
const venvUvicorn = path.join(venvBinDir, isWindows ? 'uvicorn.exe' : 'uvicorn');

function isPortAvailable(port, host = '127.0.0.1') {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.unref();
    server.once('error', () => resolve(false));
    server.once('listening', () => {
      server.close(() => resolve(true));
    });
    server.listen(port, host);
  });
}

async function pickPreviewBackendPort() {
  if (process.env.BACKEND_PORT) {
    return Number(process.env.BACKEND_PORT);
  }
  // Never probe or bind port 8000 in preview (reserved by container control-plane-api).
  for (const candidate of [8011, 8012, 8013, 8014]) {
    if (await isPortAvailable(candidate, '127.0.0.1')) {
      return candidate;
    }
  }
  return 8011;
}

function runCommand(cmd, args, cwd) {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, { cwd, stdio: 'inherit', env: process.env });
    proc.on('error', reject);
    proc.on('exit', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`${cmd} ${args.join(' ')} exited with code ${code}`));
      }
    });
  });
}

async function ensureBackendVenv() {
  if (fs.existsSync(venvUvicorn) && fs.existsSync(venvPython)) {
    return true;
  }

  console.log('[dev-preview] backend/.venv missing; bootstrapping Python virtualenv...');
  try {
    const systemPython = isWindows ? 'python' : 'python3';
    if (!fs.existsSync(venvPython)) {
      try {
        await runCommand(systemPython, ['-m', 'venv', venvDir], rootDir);
      } catch {
        if (!isWindows) {
          await runCommand(systemPython, ['-m', 'venv', '--without-pip', venvDir], rootDir);
        } else {
          throw new Error('Nie udalo sie utworzyc wirtualnego srodowiska Python (python -m venv).');
        }
      }
    }

    const pipBin = path.join(venvBinDir, isWindows ? 'pip.exe' : 'pip');
    if (!fs.existsSync(pipBin) && !isWindows) {
      await runCommand(
        'bash',
        [
          '-lc',
          'curl -sS https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip-preview.py && ' +
            `"${venvPython}" /tmp/get-pip-preview.py && rm -f /tmp/get-pip-preview.py`,
        ],
        rootDir
      );
    }

    await runCommand(
      venvPython,
      ['-m', 'pip', 'install', '-q', '-r', path.join(backendDir, 'requirements.txt')],
      rootDir
    );
    return fs.existsSync(venvUvicorn) || fs.existsSync(venvPython);
  } catch (err) {
    console.error('[dev-preview] Failed to bootstrap backend/.venv:', err);
    return false;
  }
}

function startFastApi(backendPort, children, isShuttingDown) {
  if (isShuttingDown()) return;
  console.log(`[dev-preview] Starting FastAPI on 127.0.0.1:${backendPort}`);
  const backendProc = spawn(
    venvPython,
    ['-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', String(backendPort)],
    {
      cwd: backendDir,
      stdio: 'inherit',
      env: { ...process.env, PYTHONUNBUFFERED: '1' },
    }
  );
  children.push(backendProc);
}

async function main() {
  const children = [];
  let shuttingDown = false;
  const backendPort = await pickPreviewBackendPort();
  const apiTarget = process.env.VITE_API_TARGET || `http://127.0.0.1:${backendPort}`;

  const forwardedArgs = process.argv.slice(2);
  const viteArgs = forwardedArgs.length > 0 ? [...forwardedArgs] : [];
  if (!viteArgs.some((arg) => arg === '--port' || arg.startsWith('--port='))) {
    viteArgs.push('--port=3000');
  }
  if (!viteArgs.some((arg) => arg === '--host' || arg.startsWith('--host='))) {
    viteArgs.push('--host=0.0.0.0');
  }

  const viteCliJs = path.join(rootDir, 'node_modules', 'vite', 'bin', 'vite.js');

  // Start Vite immediately via node so it works identically on Windows, macOS, and Linux.
  const viteProc = spawn(process.execPath, [viteCliJs, ...viteArgs], {
    cwd: rootDir,
    stdio: 'inherit',
    env: {
      ...process.env,
      VITE_API_TARGET: apiTarget,
    },
  });
  children.push(viteProc);

  function shutdown(signal) {
    shuttingDown = true;
    for (const child of children) {
      if (!child.killed) {
        child.kill(signal);
      }
    }
  }

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  viteProc.on('exit', (code) => {
    shutdown('SIGTERM');
    process.exit(code ?? 0);
  });

  if (fs.existsSync(venvUvicorn) && fs.existsSync(venvPython)) {
    startFastApi(backendPort, children, () => shuttingDown);
  } else {
    void ensureBackendVenv().then((ready) => {
      if (ready) {
        startFastApi(backendPort, children, () => shuttingDown);
      }
    });
  }
}

main().catch((err) => {
  console.error('[dev-preview] Failed to launch preview:', err);
  process.exit(1);
});
