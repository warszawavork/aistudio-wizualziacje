# Modular AI Visualizer — Etap 1: Fundament

Profesjonalne narzędzie do projektowania i wizualizacji domów modułowych oraz wnętrz.

## Struktura katalogów

- `frontend/` — aplikacja React + TypeScript + Vite
- `backend/` — API FastAPI + SQLAlchemy + Pydantic + SQLite
  - `backend/app/api/` — endpointy HTTP (`/api/health`, `/api/projects`, `/api/references`, `/api/settings`, `/api/providers/status`)
  - `backend/app/models/` — modele ORM SQLAlchemy
  - `backend/app/schemas/` — schematy walidacji Pydantic
  - `backend/app/services/` — logika aplikacyjna i obsługa plików
  - `backend/app/providers/` — odseparowane interfejsy pod przyszłe integracje (Gemini, OpenAI, Telegram)
  - `backend/tests/` — testy API (`pytest`)
- `storage/` — lokalna baza SQLite i przesłane pliki (ignorowane przez Git)
- `docs/` — dokumentacja architektury

## Wymagania wstępne

- Python 3.10+
- Node.js 20+ oraz npm

## Uruchomienie lokalne

### 1. Konfiguracja zmiennych środowiskowych

```bash
cp .env.example .env
```

Plik `.env` jest ignorowany przez Git. Domyślnie aktywna jest twarda blokada kosztów (`FREE_ONLY=true`, `ALLOW_PAID_APIS=false`, `MONTHLY_BUDGET=0`, `ALLOW_HF_MICRO_FREE_CREDITS=false`). Klucze AI mogą pozostać puste — żadne płatne wywołania zewnętrznych API nie są wykonywane.

### 2. Backend (FastAPI + SQLite)

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Sprawdzenie działania backendu i połączenia z SQLite:

```bash
curl http://127.0.0.1:8000/api/health
```

Uruchomienie testów backendu (API + polityka Zero Kosztów):

```bash
cd backend
.venv/bin/pytest -v tests/test_api.py tests/test_zero_cost.py
```

### 3. Frontend (React + TypeScript + Vite)

Z katalogu głównego repozytorium (w środowisku preview `scripts/dev-preview.mjs` automatycznie dobiera wolny port backendu `8011–8014`, omijając port `8000`, oraz uruchamia Vite na porcie `3000`):

```bash
npm install
npm run dev
```

Lub niezależnie z katalogu `frontend/`:

```bash
cd frontend
npm install
npm run dev
```
