# Architektura systemu — Modular AI Visualizer (Etap 1)

## 1. Założenia fundamentu

Modular AI Visualizer rozdziela warstwę interfejsu użytkownika (React + TypeScript + Vite), logikę aplikacyjną i bazę danych (FastAPI + SQLAlchemy + SQLite) oraz odseparowaną warstwę dostawców zewnętrznych (`backend/app/providers/`).

## 2. Dwa główne tryby projektowe

- **Tryb A (`sketch_to_render`)**: Szkic → Fotorealistyczna wizualizacja. Przechowuje przesłany szkic w `storage/sketches/`, blokadę geometrii (`preserve_geometry`), uwagi dotyczące ścian, okien i drzwi oraz powiązane referencje.
- **Tryb B (`idea_to_project`)**: Pomysł → Szkic koncepcyjny → Wizualizacja. Przechowuje brief architektoniczny, konfigurację modułów, metraż i referencje stylistyczne.

## 3. Biblioteka referencji

Tabela `reference_items` w SQLite przechowuje pięć kategorii przykładów:
- `sketch_pair` (szkic + wizualizacja)
- `realization` (ukończone realizacje)
- `material` (materiały, kolory, faktury)
- `lighting` (przykłady oświetlenia)
- `style` (style architektoniczne i aranżacje)

W Etapie 1 biblioteka działa jako trwałe repozytorium przykładów (bez automatycznego trenowania ani wywołań modeli AI).

## 4. Odseparowana warstwa dostawców (`backend/app/providers/`)

- `VisionAnalyzerProvider` → `GeminiVisionProvider` (przyszła analiza geometrii szkiców przez Google Gemini)
- `ImageGeneratorProvider` → `OpenAIImageProvider` (przyszłe generowanie i edycja wizualizacji przez OpenAI API)
- `MessagingProvider` → `TelegramBotProvider` (przyszła komunikacja przez Telegram Bot API)

W Etapie 1 wszystkie adaptery raportują wyłącznie stan gotowości i nie wykonują płatnych wywołań sieciowych.
