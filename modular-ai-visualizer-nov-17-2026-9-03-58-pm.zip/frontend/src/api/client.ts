import type {
  AnalysisEditableFields,
  AnalysisPreviewResponse,
  AnalyzeDraftPayload,
  DashboardSummary,
  GenerateDraftImagePayload,
  GenerateImagePayload,
  HealthResponse,
  ImageGenerationResponse,
  ImageProvidersOverviewRead,
  Project,
  ProjectCreatePayload,
  ProjectStatus,
  ProjectUpdatePayload,
  ProviderPreference,
  ProvidersOverview,
  ReferenceContextPreview,
  ReferenceCreatePayload,
  ReferenceItem,
  ReferenceUpdatePayload,
  StudioSettings,
} from '../types/domain';

const API_BASE = '/api';

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    ...init,
  });

  if (!response.ok) {
    let message = `Błąd serwera (${response.status})`;
    try {
      const data = await response.json();
      if (typeof data?.detail === 'string') {
        message = data.detail;
      }
    } catch {
      // ignore non-json body
    }
    throw new Error(message);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  return response.json() as Promise<T>;
}

export const apiClient = {
  getHealth(): Promise<HealthResponse> {
    return requestJson<HealthResponse>('/health');
  },

  getDashboardSummary(): Promise<DashboardSummary> {
    return requestJson<DashboardSummary>('/projects/summary');
  },

  listProjects(params?: {
    mode?: string;
    status?: string;
    search?: string;
    sort_by?: string;
  }): Promise<Project[]> {
    const query = new URLSearchParams();
    if (params?.mode) query.set('mode', params.mode);
    if (params?.status) query.set('status', params.status);
    if (params?.search) query.set('search', params.search);
    if (params?.sort_by) query.set('sort_by', params.sort_by);
    const qs = query.toString();
    return requestJson<Project[]>(`/projects${qs ? `?${qs}` : ''}`);
  },

  createProject(payload: ProjectCreatePayload): Promise<Project> {
    return requestJson<Project>('/projects', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateProject(projectId: number, payload: ProjectUpdatePayload): Promise<Project> {
    return requestJson<Project>(`/projects/${projectId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateProjectStatus(projectId: number, status: ProjectStatus): Promise<Project> {
    return requestJson<Project>(`/projects/${projectId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  getProjectReferenceContext(projectId: number): Promise<ReferenceContextPreview> {
    return requestJson<ReferenceContextPreview>(`/projects/${projectId}/reference-context`);
  },

  analyzeDraft(payload: AnalyzeDraftPayload): Promise<AnalysisPreviewResponse> {
    return requestJson<AnalysisPreviewResponse>('/ai/analyze', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  analyzeProject(
    projectId: number,
    preferredProvider: ProviderPreference = 'auto'
  ): Promise<Project> {
    return requestJson<Project>(`/projects/${projectId}/analyze`, {
      method: 'POST',
      body: JSON.stringify({ preferred_provider: preferredProvider }),
    });
  },

  updateProjectAnalysis(
    projectId: number,
    payload: Partial<AnalysisEditableFields>
  ): Promise<Project> {
    return requestJson<Project>(`/projects/${projectId}/analysis`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getImageProvidersStatus(): Promise<ImageProvidersOverviewRead> {
    return requestJson<ImageProvidersOverviewRead>('/ai/image-providers');
  },

  generateProjectImage(
    projectId: number,
    payload?: GenerateImagePayload
  ): Promise<ImageGenerationResponse> {
    return requestJson<ImageGenerationResponse>(`/projects/${projectId}/generate-image`, {
      method: 'POST',
      body: JSON.stringify(payload ?? { preferred_provider: 'auto', aspect_ratio: '16:9' }),
    });
  },

  generateDraftImage(payload: GenerateDraftImagePayload): Promise<ImageGenerationResponse> {
    return requestJson<ImageGenerationResponse>('/ai/generate-image', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  deleteProject(projectId: number): Promise<void> {
    return requestJson<void>(`/projects/${projectId}`, {
      method: 'DELETE',
    });
  },

  async uploadSketch(file: File): Promise<{ url: string; filename: string }> {
    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch(`${API_BASE}/projects/upload-sketch`, {
      method: 'POST',
      body: formData,
    });
    if (!response.ok) {
      let message = 'Nie udało się przesłać szkicu.';
      try {
        const data = await response.json();
        if (typeof data?.detail === 'string') message = data.detail;
      } catch {
        // ignore
      }
      throw new Error(message);
    }
    return response.json();
  },

  listReferences(params?: {
    category?: string;
    search?: string;
    project_id?: number;
    tag?: string;
  }): Promise<ReferenceItem[]> {
    const query = new URLSearchParams();
    if (params?.category) query.set('category', params.category);
    if (params?.search) query.set('search', params.search);
    if (params?.project_id !== undefined) query.set('project_id', String(params.project_id));
    if (params?.tag) query.set('tag', params.tag);
    const qs = query.toString();
    return requestJson<ReferenceItem[]>(`/references${qs ? `?${qs}` : ''}`);
  },

  createReference(payload: ReferenceCreatePayload): Promise<ReferenceItem> {
    return requestJson<ReferenceItem>('/references', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateReference(referenceId: number, payload: ReferenceUpdatePayload): Promise<ReferenceItem> {
    return requestJson<ReferenceItem>(`/references/${referenceId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  deleteReference(referenceId: number, force = false): Promise<void> {
    const qs = force ? '?force=true' : '';
    return requestJson<void>(`/references/${referenceId}${qs}`, {
      method: 'DELETE',
    });
  },

  previewReferenceContext(payload: {
    reference_ids: number[];
    project_id?: number;
    project_title?: string;
  }): Promise<ReferenceContextPreview> {
    return requestJson<ReferenceContextPreview>('/references/context-preview', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },


  async uploadReferenceImage(file: File): Promise<{ url: string; filename: string }> {
    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch(`${API_BASE}/references/upload-image`, {
      method: 'POST',
      body: formData,
    });
    if (!response.ok) {
      let message = 'Nie udało się przesłać obrazu referencyjnego.';
      try {
        const data = await response.json();
        if (typeof data?.detail === 'string') message = data.detail;
      } catch {
        // ignore
      }
      throw new Error(message);
    }
    return response.json();
  },

  getSettings(): Promise<StudioSettings> {
    return requestJson<StudioSettings>('/settings');
  },

  updateSettings(payload: Partial<StudioSettings>): Promise<StudioSettings> {
    return requestJson<StudioSettings>('/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  getProvidersStatus(): Promise<ProvidersOverview> {
    return requestJson<ProvidersOverview>('/providers/status');
  },
};

