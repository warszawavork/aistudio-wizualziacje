import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildClientReferenceContextSummary,
  canTriggerFreeImageGeneration,
  formatAnalysisSourceLabel,
  formatAreaSqm,
  formatCategoryLabel,
  formatConfidenceLabel,
  formatDimensionCheckStatusLabel,
  formatDimensionSourceTypeLabel,
  formatFullAnalysisForClipboard,
  formatImageEngineStatusLabel,
  formatModeLabel,
  formatModulesCount,
  formatProviderLabel,
  formatReferenceRoleLabel,
  formatRenderLifecycleLabel,
  formatResponseTimeMs,
  getConfidenceToneClass,
  hasGeometryLockInPrompt,
  parseReferenceTags,
  sortProjects,
  validateProjectDraft,
  validateReferenceDraft,
} from './formatters';

test('formatModeLabel maps modes accurately', () => {
  assert.equal(formatModeLabel('sketch_to_render'), 'Szkic → Wizualizacja');
  assert.equal(formatModeLabel('idea_to_project'), 'Pomysł → Projekt');
});

test('formatAreaSqm handles integer, decimal and null values', () => {
  assert.equal(formatAreaSqm(68), '68 m²');
  assert.equal(formatAreaSqm(68.5), '68.5 m²');
  assert.equal(formatAreaSqm(null), 'Powierzchnia nieokreślona');
});

test('formatModulesCount applies Polish pluralization', () => {
  assert.equal(formatModulesCount(1), '1 moduł');
  assert.equal(formatModulesCount(2), '2 moduły');
  assert.equal(formatModulesCount(5), '5 modułów');
});

test('formatCategoryLabel and formatReferenceRoleLabel format all 8 reference library categories', () => {
  assert.equal(formatCategoryLabel('sketch_pair'), 'Szkice i rzuty');
  assert.equal(formatCategoryLabel('sketch_plan'), 'Szkice i rzuty');
  assert.equal(formatCategoryLabel('visualization'), 'Wizualizacje');
  assert.equal(formatCategoryLabel('realization'), 'Zdjęcia ukończonych realizacji');
  assert.equal(formatCategoryLabel('material'), 'Materiały i faktury');
  assert.equal(formatCategoryLabel('color'), 'Kolory');
  assert.equal(formatCategoryLabel('lighting'), 'Oświetlenie');
  assert.equal(formatCategoryLabel('style'), 'Style architektoniczne');
  assert.equal(formatCategoryLabel('interior'), 'Aranżacje wnętrz');

  assert.equal(formatReferenceRoleLabel('material'), 'materiał i faktura wykończeniowa');
  assert.equal(formatReferenceRoleLabel('style'), 'styl architektoniczny');
  assert.equal(formatReferenceRoleLabel('lighting'), 'scenariusz oświetlenia');
  assert.equal(formatReferenceRoleLabel('realization'), 'przykład ukończonej realizacji');
});

test('parseReferenceTags and buildClientReferenceContextSummary build structured context', () => {
  assert.deepEqual(parseReferenceTags('#nordic, drewno, #Modrzew, drewno'), [
    'nordic',
    'drewno',
    'Modrzew',
  ]);

  const summary = buildClientReferenceContextSummary(
    [
      {
        id: 10,
        title: 'Opalany Modrzew',
        category: 'material',
        description: 'Deska elewacyjna',
        materials_note: 'Shou Sugi Ban',
        lighting_note: '',
        style_tags: 'modrzew, elewacja',
        image_url: '/src/assets/images/material_charred_larch_1794908156119.jpg',
      },
      {
        id: 20,
        title: 'Oświetlenie Okapu',
        category: 'lighting',
        description: 'Linia LED 2700K',
        materials_note: '',
        lighting_note: '2700K',
        style_tags: 'led, zmierzch',
        image_url: '/src/assets/images/modular_pavilion_concept_1794908154441.jpg',
      },
    ],
    [20, 10],
    'Dom Sosnowy 68 m²'
  );
  assert.equal(summary.length, 2);
  assert.equal(summary[0].id, 20);
  assert.equal(summary[0].role, 'scenariusz oświetlenia');
  assert.equal(summary[1].id, 10);
  assert.equal(summary[1].role, 'materiał i faktura wykończeniowa');
  assert.ok(summary[1].relation.includes('Dom Sosnowy 68 m²'));
});

test('validateProjectDraft rejects missing title or short idea brief', () => {
  assert.ok(
    validateProjectDraft({
      title: 'A',
      mode: 'sketch_to_render',
      prompt_brief: '',
    })
  );
  assert.ok(
    validateProjectDraft({
      title: 'Dom Leśny',
      mode: 'idea_to_project',
      prompt_brief: 'Krótko',
    })
  );
  assert.equal(
    validateProjectDraft({
      title: 'Dom Leśny',
      mode: 'idea_to_project',
      prompt_brief: 'Nowoczesny dom dwumodułowy z dużym tarasem i czarną elewacją.',
      area_sqm: 72,
    }),
    null
  );
});

test('validateReferenceDraft requires at least 2 characters', () => {
  assert.ok(validateReferenceDraft({ title: 'X' }));
  assert.equal(validateReferenceDraft({ title: 'Modrzew syberyjski' }), null);
});

test('sortProjects sorts by date, name, and area without inventing null area values', () => {
  const sample = [
    { title: 'Willa Atrium', updated_at: '2026-11-10T10:00:00Z', area_sqm: 96 },
    { title: 'Brzozowy Moduł', updated_at: '2026-11-15T10:00:00Z', area_sqm: null },
    { title: 'Dom Sosnowy', updated_at: '2026-11-12T10:00:00Z', area_sqm: 54 },
  ];

  assert.deepEqual(
    sortProjects(sample, 'date_desc').map((i) => i.title),
    ['Brzozowy Moduł', 'Dom Sosnowy', 'Willa Atrium']
  );
  assert.deepEqual(
    sortProjects(sample, 'name_asc').map((i) => i.title),
    ['Brzozowy Moduł', 'Dom Sosnowy', 'Willa Atrium']
  );
  assert.deepEqual(
    sortProjects(sample, 'name_desc').map((i) => i.title),
    ['Willa Atrium', 'Dom Sosnowy', 'Brzozowy Moduł']
  );
  assert.deepEqual(
    sortProjects(sample, 'area_desc').map((i) => i.title),
    ['Willa Atrium', 'Dom Sosnowy', 'Brzozowy Moduł']
  );
  assert.deepEqual(
    sortProjects(sample, 'area_asc').map((i) => i.title),
    ['Dom Sosnowy', 'Willa Atrium', 'Brzozowy Moduł']
  );
});


test('formatProviderLabel and formatFullAnalysisForClipboard handle legacy and structured 3.3/3.5 outputs', () => {
  assert.equal(formatProviderLabel('gemini'), 'Google Gemini (Free Tier)');
  assert.equal(formatProviderLabel('groq'), 'GroqCloud (Free Tier)');

  const legacyText = formatFullAnalysisForClipboard('sketch_to_render', {
    summary: 'Dom 68 m²',
    spatial_layout: 'Salon i 2 sypialnie',
    materials_proposal: 'Blacha grafitowa',
    lighting_proposal: 'Światło dzienne',
    geometry_preservation_note: 'Zachować osie okien',
    visualization_prompt: 'Modular cabin render',
  });
  assert.ok(legacyText.includes('[Układ pomieszczeń, ścian, okien, drzwi i proporcji]'));
  assert.ok(legacyText.includes('[Prompt do przyszłej wizualizacji]\nModular cabin render'));
  assert.equal(legacyText.includes('[Lista pomieszczeń'), false);

  const structuredText = formatFullAnalysisForClipboard('idea_to_project', {
    summary: 'Koncepcja dwumodułowa',
    spatial_layout: 'Podział na strefę dzienną i nocną',
    materials_proposal: 'Modrzew + blacha',
    lighting_proposal: 'Światło poranne',
    geometry_preservation_note: 'Zachować moduł transportowy 3.45 m',
    visualization_prompt: 'Architectural exterior view',
    orientation_source: 'brak róży wiatrów',
    dimension_observations: [
      {
        label: 'Szerokość całkowita',
        value: '7.5 m',
        source_type: 'direct',
        confidence: 'wysoka pewność',
      },
    ],
    dimension_checks: [
      {
        description: '7.5 m vs 9.6 m',
        status: 'conflict',
        difference: '2.1 m',
      },
    ],
    dimension_conflicts: ['Sprzeczność 2.1 m'],
    geometry: {
      building_footprint: 'Prostokąt z łącznikiem',
      floors_count: '1 kondygnacja',
      structural_vs_partition_walls: 'Ramy stalowe + ściany działowe',
      circulation: 'Korytarz osiowy',
      proportions_and_scale: 'Bez skali na rysunku',
      confidence: 'średnia pewność',
    },
    rooms: [
      {
        name: 'Salon z aneksem',
        zone: 'dzienna',
        approximate_area: 'ok. 32 m²',
        spatial_relations: 'Otwarty na taras',
        confidence: 'wysoka pewność',
      },
    ],
    openings: [
      {
        opening_id: 'HS-01',
        category: 'okno tarasowe HS',
        location: 'elewacja ogrodowa',
        opening_direction: 'niemożliwe do ustalenia na podstawie materiału',
        has_swing_arc: false,
        notes: 'duże przeszklenie',
        confidence: 'średnia pewność',
      },
    ],
    openings_completeness_check: 'Sprawdzono wszystkie ściany zewnętrzne i działowe.',
    user_requirements: ['Dwa moduły', 'Duży taras'],
    ai_suggestions: ['Podcień wejściowy 1.8 m'],
    observed_facts: ['Dwa moduły parterowe w kształcie litery L'],
    model_interpretations: ['Możliwa strefa dzienna od części ogrodowej'],
    indeterminable_elements: ['Orientacja stron świata na działce'],
    uncertainties: [
      {
        element: 'Wysokość attyki',
        confidence: 'niska pewność',
        reason: 'Brak przekroju pionowego',
      },
    ],
    clarification_questions: ['Jaka jest orientacja wjazdu na działkę?'],
    geometry_protection: {
      must_preserve: ['Dwa moduły połączone osiowo'],
      can_change: ['Kolor obróbek blacharskich'],
      forbidden_changes: ['Dodawanie piętra'],
    },
    disclaimer: 'Analiza ma charakter koncepcyjny.',
  });

  assert.ok(structuredText.includes('[Kontrola spójności wymiarowej]'));
  assert.ok(structuredText.includes('[HS-01] okno tarasowe HS'));
  assert.ok(structuredText.includes('[Lista pomieszczeń (1)]'));
  assert.ok(structuredText.includes('[Stolarka i otwory (1)]'));
  assert.ok(structuredText.includes('[A. Informacje odczytane ze szkicu / briefu]'));
  assert.ok(structuredText.includes('[B. Interpretacje modelu (do weryfikacji)]'));
  assert.ok(structuredText.includes('[D. Niemożliwe do ustalenia na podstawie materiału]'));
  assert.ok(structuredText.includes('[Wymagania użytkownika]'));
  assert.ok(structuredText.includes('[Sugestie AI]'));
  assert.ok(structuredText.includes('[Niepewności i pytania do doprecyzowania]'));
  assert.ok(structuredText.includes('[Ochrona geometrii]'));
  assert.ok(structuredText.includes('[Uwaga koncepcyjna]'));
});

test('confidence, response time and analysis provenance formatters handle all states', () => {
  assert.equal(formatConfidenceLabel('wysoka pewność'), 'Wysoka pewność');
  assert.equal(
    formatConfidenceLabel('niemożliwe do ustalenia na podstawie materiału'),
    'Niemożliwe do ustalenia na podstawie materiału'
  );
  assert.ok(getConfidenceToneClass('niska pewność').includes('amber'));
  assert.equal(formatResponseTimeMs(480), '480 ms');
  assert.equal(formatResponseTimeMs(1520), '1.52 s');
  assert.equal(formatResponseTimeMs(null), null);
  assert.equal(formatAnalysisSourceLabel('live', false), null);
  assert.equal(formatAnalysisSourceLabel('live', true), 'Wynik testowy (mock)');
  assert.equal(formatAnalysisSourceLabel('mock', false), 'Wynik testowy (mock)');
  assert.equal(formatAnalysisSourceLabel('fallback', false), 'Odpowiedź opisowa (fallback JSON)');
  assert.equal(formatAnalysisSourceLabel('legacy', false), 'Zapis archiwalny 3.2');
});

test('Etap 3.5 dimension labels and Geometry Lock prompt validator work deterministically', () => {
  assert.equal(formatDimensionSourceTypeLabel('direct'), 'A. Bezpośrednio odczytany');
  assert.equal(formatDimensionSourceTypeLabel('calculated'), 'B. Obliczony z oznaczeń');
  assert.equal(formatDimensionSourceTypeLabel('estimated'), 'C. Szacunkowy');
  assert.equal(formatDimensionSourceTypeLabel('indeterminable'), 'D. Niemożliwy do ustalenia');
  assert.equal(formatDimensionCheckStatusLabel('conflict'), 'Sprzeczność wymiarowa');

  assert.equal(
    hasGeometryLockInPrompt('Architectural render, Nordic Graphite, dusk lighting, 8k.'),
    false
  );
  assert.equal(
    hasGeometryLockInPrompt(
      'Nordic Graphite render. GEOMETRY LOCK: Preserve building footprint, room layout, all walls, window placement and door positions. FORBIDDEN: Do not add rooms or move walls.'
    ),
    true
  );
});

test('Etap 3.6 image engine status labels and free generation gate work accurately', () => {
  assert.equal(formatImageEngineStatusLabel('available_free'), 'Dostępny (darmowy 0 zł)');
  assert.equal(
    formatImageEngineStatusLabel('disabled_by_cost_policy'),
    'Zablokowany (płatny / mikro-kredyt)'
  );
  assert.equal(
    formatImageEngineStatusLabel('unverified_blocked'),
    'Zablokowany (niezweryfikowany)'
  );
  assert.equal(formatRenderLifecycleLabel('queued'), 'W kolejce...');
  assert.equal(formatRenderLifecycleLabel('generating'), 'Generowanie obrazu...');
  assert.equal(formatRenderLifecycleLabel('completed'), 'Zakończono (obraz zapisany)');

  assert.equal(canTriggerFreeImageGeneration(null), false);
  assert.equal(
    canTriggerFreeImageGeneration({
      any_free_engine_available: false,
      providers: [
        {
          available: false,
          is_truly_free: true,
          is_verified: true,
          is_paid_endpoint: false,
          blocked_by_cost_policy: false,
        },
      ],
    }),
    false
  );
  assert.equal(
    canTriggerFreeImageGeneration({
      any_free_engine_available: true,
      providers: [
        {
          available: true,
          is_truly_free: true,
          is_verified: true,
          is_paid_endpoint: false,
          blocked_by_cost_policy: false,
        },
      ],
    }),
    true
  );
});


