import type {
  DimensionSourceType,
  ProjectMode,
  ProjectStatus,
  ReferenceCategory,
  StructuredAnalysisSections,
} from '../types/domain';

export function formatModeLabel(mode: ProjectMode | string): string {
  if (mode === 'sketch_to_render') return 'Szkic → Wizualizacja';
  if (mode === 'idea_to_project') return 'Pomysł → Projekt';
  return mode;
}

export function formatModeShortLabel(mode: ProjectMode | string): string {
  if (mode === 'sketch_to_render') return 'Tryb A';
  if (mode === 'idea_to_project') return 'Tryb B';
  return mode;
}

export function formatStatusLabel(status: ProjectStatus | string): string {
  switch (status) {
    case 'draft':
      return 'Szkic roboczy';
    case 'awaiting_ai_pipeline':
      return 'Gotowy do pipeline AI';
    case 'archived':
      return 'Zarchiwizowany';
    default:
      return status;
  }
}

export function formatCategoryLabel(category: ReferenceCategory | string): string {
  switch (category) {
    case 'sketch_pair':
    case 'sketch_plan':
      return 'Szkice i rzuty';
    case 'visualization':
      return 'Wizualizacje';
    case 'realization':
      return 'Zdjęcia ukończonych realizacji';
    case 'material':
      return 'Materiały i faktury';
    case 'color':
      return 'Kolory';
    case 'lighting':
      return 'Oświetlenie';
    case 'style':
      return 'Style architektoniczne';
    case 'interior':
      return 'Aranżacje wnętrz';
    default:
      return category;
  }
}

export function formatReferenceRoleLabel(category: ReferenceCategory | string): string {
  switch (category) {
    case 'sketch_pair':
    case 'sketch_plan':
      return 'szkic i rzut odniesienia';
    case 'visualization':
      return 'wizualizacja referencyjna';
    case 'realization':
      return 'przykład ukończonej realizacji';
    case 'material':
      return 'materiał i faktura wykończeniowa';
    case 'color':
      return 'paleta kolorystyczna';
    case 'lighting':
      return 'scenariusz oświetlenia';
    case 'style':
      return 'styl architektoniczny';
    case 'interior':
      return 'aranżacja wnętrza i wyposażenia';
    default:
      return 'materiał referencyjny';
  }
}

export function parseReferenceTags(styleTags: string, explicitTags?: string[]): string[] {
  if (Array.isArray(explicitTags) && explicitTags.length > 0) {
    return explicitTags.map((t) => t.trim().replace(/^#+/, '').trim()).filter(Boolean);
  }
  if (!styleTags) return [];
  const seen = new Set<string>();
  const result: string[] = [];
  for (const raw of styleTags.split(',')) {
    const cleaned = raw.trim().replace(/^#+/, '').trim();
    if (cleaned && !seen.has(cleaned.toLowerCase())) {
      seen.add(cleaned.toLowerCase());
      result.push(cleaned);
    }
  }
  return result;
}

export function buildClientReferenceContextSummary(
  references: Array<{
    id: number;
    title: string;
    category: ReferenceCategory | string;
    description: string;
    materials_note: string;
    lighting_note: string;
    style_tags: string;
    tags?: string[];
    image_url: string | null;
    paired_sketch_url?: string | null;
    linked_project_titles?: string[];
  }>,
  selectedIds: number[],
  projectTitle?: string
): Array<{
  id: number;
  title: string;
  categoryLabel: string;
  role: string;
  tags: string[];
  imagePath: string;
  relation: string;
}> {
  if (!selectedIds || selectedIds.length === 0) return [];
  const byId = new Map(references.map((r) => [r.id, r]));
  const items: Array<{
    id: number;
    title: string;
    categoryLabel: string;
    role: string;
    tags: string[];
    imagePath: string;
    relation: string;
  }> = [];

  for (const id of selectedIds) {
    const ref = byId.get(id);
    if (!ref) continue;
    const relation = projectTitle?.trim()
      ? `Przypisana do projektu „${projectTitle.trim()}”`
      : ref.linked_project_titles && ref.linked_project_titles.length > 0
      ? `Powiązana z: ${ref.linked_project_titles.join(', ')}`
      : 'Wybrana jako kontekst referencyjny do analizy AI';
    items.push({
      id: ref.id,
      title: ref.title,
      categoryLabel: formatCategoryLabel(ref.category),
      role: formatReferenceRoleLabel(ref.category),
      tags: parseReferenceTags(ref.style_tags, ref.tags),
      imagePath: ref.image_url || ref.paired_sketch_url || 'brak pliku',
      relation,
    });
  }
  return items;
}

export function formatAreaSqm(area: number | null | undefined): string {
  if (area === null || area === undefined || Number.isNaN(area)) {
    return 'Powierzchnia nieokreślona';
  }
  return `${Number.isInteger(area) ? area : area.toFixed(1)} m²`;
}

export function formatModulesCount(count: number): string {
  if (count === 1) return '1 moduł';
  if (count >= 2 && count <= 4) return `${count} moduły`;
  return `${count} modułów`;
}

export function formatPolishDate(isoString: string): string {
  const date = new Date(isoString);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('pl-PL', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date);
}

export function validateProjectDraft(input: {
  title: string;
  mode: ProjectMode;
  prompt_brief: string;
  area_sqm?: number | null;
}): string | null {
  if (!input.title || input.title.trim().length < 2) {
    return 'Podaj nazwę projektu (minimum 2 znaki).';
  }
  if (input.area_sqm !== null && input.area_sqm !== undefined && input.area_sqm <= 0) {
    return 'Powierzchnia zabudowy musi być większa od zera.';
  }
  if (input.mode === 'idea_to_project' && input.prompt_brief.trim().length < 8) {
    return 'W trybie Pomysł → Projekt opisz koncepcję budynku (minimum 8 znaków).';
  }
  return null;
}

export function validateReferenceDraft(input: { title: string }): string | null {
  if (!input.title || input.title.trim().length < 2) {
    return 'Podaj tytuł materiału referencyjnego (minimum 2 znaki).';
  }
  return null;
}

export type ProjectSortOption =
  | 'date_desc'
  | 'date_asc'
  | 'name_asc'
  | 'name_desc'
  | 'area_desc'
  | 'area_asc';

export function sortProjects<
  T extends { title: string; updated_at: string; area_sqm: number | null },
>(items: T[], sortBy: ProjectSortOption): T[] {
  const copy = [...items];

  copy.sort((a, b) => {
    if (sortBy === 'date_desc' || sortBy === 'date_asc') {
      const timeA = Date.parse(a.updated_at) || 0;
      const timeB = Date.parse(b.updated_at) || 0;
      return sortBy === 'date_desc' ? timeB - timeA : timeA - timeB;
    }

    if (sortBy === 'name_asc') {
      return a.title.localeCompare(b.title, 'pl', { sensitivity: 'base' });
    }

    if (sortBy === 'name_desc') {
      return b.title.localeCompare(a.title, 'pl', { sensitivity: 'base' });
    }

    const areaA = a.area_sqm;
    const areaB = b.area_sqm;
    const hasA = typeof areaA === 'number' && !Number.isNaN(areaA);
    const hasB = typeof areaB === 'number' && !Number.isNaN(areaB);

    // Projects without recorded area always stay after those with recorded area
    if (!hasA && !hasB) return 0;
    if (!hasA) return 1;
    if (!hasB) return -1;

    return sortBy === 'area_desc' ? areaB - areaA : areaA - areaB;
  });

  return copy;
}


export function formatProviderLabel(providerKey: string): string {
  switch (providerKey) {
    case 'gemini':
      return 'Google Gemini (Free Tier)';
    case 'groq':
      return 'GroqCloud (Free Tier)';
    default:
      return providerKey;
  }
}

export function formatConfidenceLabel(confidence?: string | null): string {
  switch (confidence) {
    case 'wysoka pewność':
      return 'Wysoka pewność';
    case 'średnia pewność':
      return 'Średnia pewność';
    case 'niska pewność':
      return 'Niska pewność';
    case 'niemożliwe do ustalenia na podstawie materiału':
      return 'Niemożliwe do ustalenia na podstawie materiału';
    default:
      return confidence?.trim() || 'Średnia pewność';
  }
}

export function getConfidenceToneClass(confidence?: string | null): string {
  switch (confidence) {
    case 'wysoka pewność':
      return 'text-emerald-800 border-emerald-200 bg-emerald-50/70';
    case 'średnia pewność':
      return 'text-zinc-700 border-zinc-200 bg-zinc-50';
    case 'niska pewność':
      return 'text-amber-800 border-amber-200 bg-amber-50/70';
    case 'niemożliwe do ustalenia na podstawie materiału':
      return 'text-red-800 border-red-200 bg-red-50/70';
    default:
      return 'text-zinc-700 border-zinc-200 bg-zinc-50';
  }
}

export function formatResponseTimeMs(ms?: number | null): string | null {
  if (typeof ms !== 'number' || Number.isNaN(ms) || ms < 0) {
    return null;
  }
  if (ms < 1000) {
    return `${Math.round(ms)} ms`;
  }
  return `${(ms / 1000).toFixed(2)} s`;
}

export function formatAnalysisSourceLabel(
  source?: string | null,
  isMock?: boolean
): string | null {
  if (isMock || source === 'mock') {
    return 'Wynik testowy (mock)';
  }
  if (source === 'fallback') {
    return 'Odpowiedź opisowa (fallback JSON)';
  }
  if (source === 'legacy') {
    return 'Zapis archiwalny 3.2';
  }
  return null;
}

export function formatDimensionSourceTypeLabel(sourceType?: DimensionSourceType | string): string {
  switch (sourceType) {
    case 'direct':
      return 'A. Bezpośrednio odczytany';
    case 'calculated':
      return 'B. Obliczony z oznaczeń';
    case 'estimated':
      return 'C. Szacunkowy';
    case 'indeterminable':
    default:
      return 'D. Niemożliwy do ustalenia';
  }
}

export function formatDimensionCheckStatusLabel(
  status?: 'consistent' | 'conflict' | 'indeterminable' | string
): string {
  switch (status) {
    case 'consistent':
      return 'Spójne';
    case 'conflict':
      return 'Sprzeczność wymiarowa';
    default:
      return 'Niemożliwe do ustalenia';
  }
}

export function hasGeometryLockInPrompt(prompt?: string | null): boolean {
  const text = (prompt || '').toLowerCase();
  if (!text.trim()) return false;
  const hasFootprint =
    text.includes('footprint') || text.includes('obrys') || text.includes('silhouette');
  const hasWalls = text.includes('wall') || text.includes('ścian');
  const hasWindows = text.includes('window') || text.includes('okien') || text.includes('okna');
  const hasDoors = text.includes('door') || text.includes('drzwi');
  const hasRooms =
    text.includes('room') ||
    text.includes('pomieszczeń') ||
    text.includes('pomieszczenia') ||
    text.includes('layout') ||
    text.includes('układ');
  const hasProhibition =
    text.includes('geometry lock') ||
    text.includes('do not add') ||
    text.includes('do not remove') ||
    text.includes('do not move') ||
    text.includes('forbidden') ||
    text.includes('nie dodawaj') ||
    text.includes('nie usuwaj') ||
    text.includes('nie przesuwaj');
  return hasFootprint && hasWalls && hasWindows && hasDoors && hasRooms && hasProhibition;
}

export function formatFullAnalysisForClipboard(
  mode: ProjectMode | string,
  analysis: StructuredAnalysisSections & {
    summary: string;
    spatial_layout: string;
    materials_proposal: string;
    lighting_proposal: string;
    geometry_preservation_note: string;
    visualization_prompt: string;
  }
): string {
  const layoutTitle =
    mode === 'sketch_to_render'
      ? 'Układ pomieszczeń, ścian, okien, drzwi i proporcji'
      : 'Struktura projektu i układ modułów';
  const geometryTitle =
    mode === 'sketch_to_render'
      ? 'Zasady ochrony geometrii szkicu'
      : 'Założenia bryłowe do szkicu koncepcyjnego';

  const blocks: string[] = [
    `[Podsumowanie]\n${analysis.summary || '—'}`,
    `[${layoutTitle}]\n${analysis.spatial_layout || '—'}`,
  ];

  if (analysis.geometry) {
    const g = analysis.geometry;
    blocks.push(
      [
        `[Geometria i układ konstrukcyjny · ${formatConfidenceLabel(g.confidence)}]`,
        g.building_footprint ? `- Obrys bryły: ${g.building_footprint}` : null,
        g.floors_count ? `- Kondygnacje: ${g.floors_count}` : null,
        g.structural_vs_partition_walls
          ? `- Ściany nośne vs działowe: ${g.structural_vs_partition_walls}`
          : null,
        g.circulation ? `- Komunikacja: ${g.circulation}` : null,
        g.proportions_and_scale ? `- Proporcje i skala: ${g.proportions_and_scale}` : null,
      ]
        .filter(Boolean)
        .join('\n')
    );
  }

  if (analysis.orientation_source || (analysis.unjustified_directions_detected?.length ?? 0) > 0) {
    const orientParts: string[] = [];
    if (analysis.orientation_source) {
      orientParts.push(`Źródło orientacji: ${analysis.orientation_source}`);
    }
    if (analysis.unjustified_directions_detected && analysis.unjustified_directions_detected.length > 0) {
      orientParts.push(
        `Ostrzeżenie (nieuzasadnione strony świata): ${analysis.unjustified_directions_detected.join(', ')}`
      );
    }
    blocks.push(`[Orientacja rzutu]\n${orientParts.join('\n')}`);
  }

  if (
    (analysis.dimension_observations?.length ?? 0) > 0 ||
    (analysis.dimension_checks?.length ?? 0) > 0 ||
    (analysis.dimension_conflicts?.length ?? 0) > 0
  ) {
    const dimLines: string[] = [];
    for (const obs of analysis.dimension_observations ?? []) {
      dimLines.push(
        `- ${obs.label}: ${obs.value} [${formatDimensionSourceTypeLabel(obs.source_type)}, ${formatConfidenceLabel(obs.confidence)}]`
      );
    }
    for (const chk of analysis.dimension_checks ?? []) {
      dimLines.push(
        `- Kontrola: ${chk.description} → ${formatDimensionCheckStatusLabel(chk.status)}${
          chk.difference ? ` (różnica: ${chk.difference})` : ''
        }`
      );
    }
    for (const conf of analysis.dimension_conflicts ?? []) {
      dimLines.push(`! SPRZECZNOŚĆ: ${conf}`);
    }
    blocks.push(`[Kontrola spójności wymiarowej]\n${dimLines.join('\n')}`);
  }

  if (analysis.rooms && analysis.rooms.length > 0) {
    const roomLines = analysis.rooms.map(
      (r) =>
        `- ${r.name} (strefa: ${r.zone}, metraż: ${r.approximate_area}, ${formatConfidenceLabel(r.confidence)})${
          r.spatial_relations ? ` — ${r.spatial_relations}` : ''
        }`
    );
    blocks.push(`[Lista pomieszczeń (${analysis.rooms.length})]\n${roomLines.join('\n')}`);
  }

  if (analysis.openings && analysis.openings.length > 0) {
    const openingLines = analysis.openings.map((o) => {
      const idPrefix = o.opening_id ? `[${o.opening_id}] ` : '';
      const arcNote =
        o.has_swing_arc === true
          ? ', łuk otwierania: widoczny'
          : o.has_swing_arc === false
          ? ', brak łuku otwierania'
          : '';
      return `- ${idPrefix}${o.category}: ${o.location || 'brak lokalizacji'} (kierunek: ${o.opening_direction}${arcNote}, ${formatConfidenceLabel(o.confidence)})${
        o.notes ? ` — ${o.notes}` : ''
      }`;
    });
    if (analysis.openings_completeness_check) {
      openingLines.push(`Kontrola kompletności: ${analysis.openings_completeness_check}`);
    }
    blocks.push(`[Stolarka i otwory (${analysis.openings.length})]\n${openingLines.join('\n')}`);
  }

  if (
    (analysis.observed_facts && analysis.observed_facts.length > 0) ||
    (analysis.model_interpretations && analysis.model_interpretations.length > 0) ||
    (analysis.indeterminable_elements && analysis.indeterminable_elements.length > 0)
  ) {
    const factLines = (analysis.observed_facts ?? []).map((item) => `- ${item}`);
    const interpLines = (analysis.model_interpretations ?? []).map((item) => `- ${item}`);
    const indetLines = (analysis.indeterminable_elements ?? []).map((item) => `- ${item}`);
    const epistemicParts: string[] = [];
    if (factLines.length > 0) {
      epistemicParts.push(`[A. Informacje odczytane ze szkicu / briefu]\n${factLines.join('\n')}`);
    }
    if (interpLines.length > 0) {
      epistemicParts.push(`[B. Interpretacje modelu (do weryfikacji)]\n${interpLines.join('\n')}`);
    }
    if (indetLines.length > 0) {
      epistemicParts.push(
        `[D. Niemożliwe do ustalenia na podstawie materiału]\n${indetLines.join('\n')}`
      );
    }
    if (epistemicParts.length > 0) {
      blocks.push(epistemicParts.join('\n\n'));
    }
  }

  if (
    (analysis.user_requirements && analysis.user_requirements.length > 0) ||
    (analysis.ai_suggestions && analysis.ai_suggestions.length > 0)
  ) {
    const reqLines =
      analysis.user_requirements && analysis.user_requirements.length > 0
        ? analysis.user_requirements.map((item) => `- ${item}`).join('\n')
        : '- Brak wyodrębnionych wymagań';
    const sugLines =
      analysis.ai_suggestions && analysis.ai_suggestions.length > 0
        ? analysis.ai_suggestions.map((item) => `- ${item}`).join('\n')
        : '- Brak dodatkowych sugestii AI';
    blocks.push(`[Wymagania użytkownika]\n${reqLines}\n\n[Sugestie AI]\n${sugLines}`);
  }

  if (
    (analysis.uncertainties && analysis.uncertainties.length > 0) ||
    (analysis.clarification_questions && analysis.clarification_questions.length > 0)
  ) {
    const uncLines = (analysis.uncertainties ?? []).map(
      (u) => `- ${u.element} (${formatConfidenceLabel(u.confidence)}): ${u.reason || 'wymaga weryfikacji'}`
    );
    const qLines = (analysis.clarification_questions ?? []).map((q) => `? ${q}`);
    blocks.push(
      `[Niepewności i pytania do doprecyzowania]\n${[...uncLines, ...qLines].join('\n')}`
    );
  }

  if (analysis.geometry_protection) {
    const gp = analysis.geometry_protection;
    blocks.push(
      [
        '[Ochrona geometrii]',
        `Do zachowania: ${(gp.must_preserve ?? []).join('; ') || '—'}`,
        `Można zmieniać: ${(gp.can_change ?? []).join('; ') || '—'}`,
        `Zmiany zabronione: ${(gp.forbidden_changes ?? []).join('; ') || '—'}`,
      ].join('\n')
    );
  }

  blocks.push(
    `[Propozycja materiałów i kolorystyki]\n${analysis.materials_proposal || '—'}`,
    `[Propozycja oświetlenia]\n${analysis.lighting_proposal || '—'}`,
    `[${geometryTitle}]\n${analysis.geometry_preservation_note || '—'}`,
    `[Prompt do przyszłej wizualizacji]\n${analysis.visualization_prompt || '—'}`
  );

  if (analysis.disclaimer) {
    blocks.push(`[Uwaga koncepcyjna]\n${analysis.disclaimer}`);
  }

  return blocks.join('\n\n');
}

export function formatImageEngineStatusLabel(status?: string | null): string {
  switch (status) {
    case 'available_free':
      return 'Dostępny (darmowy 0 zł)';
    case 'unavailable_free':
      return 'Niedostępny lokalnie / brak darmowego API';
    case 'disabled_by_cost_policy':
      return 'Zablokowany (płatny / mikro-kredyt)';
    case 'unverified_blocked':
      return 'Zablokowany (niezweryfikowany)';
    case 'missing_api_key':
      return 'Brak klucza w .env backendu';
    case 'cooldown':
      return 'Cooldown po limicie 429';
    case 'local_limit_reached':
      return 'Osiągnięto limit dzienny';
    default:
      return status || 'Niedostępny';
  }
}

export function formatRenderLifecycleLabel(state?: string | null): string {
  switch (state) {
    case 'queued':
      return 'W kolejce...';
    case 'generating':
      return 'Generowanie obrazu...';
    case 'completed':
      return 'Zakończono (obraz zapisany)';
    case 'unavailable_free':
      return 'Wstrzymano — brak darmowego silnika';
    case 'disabled_by_cost_policy':
      return 'Zablokowano przez CostGuard (0 zł)';
    case 'unverified_blocked':
      return 'Zablokowano (niezweryfikowany silnik)';
    case 'cooldown':
      return 'Cooldown po HTTP 429';
    case 'error':
      return 'Błąd generowania';
    case 'not_requested':
    default:
      return 'Oczekuje na darmowy silnik';
  }
}

export function canTriggerFreeImageGeneration(overview?: {
  any_free_engine_available?: boolean;
  providers?: Array<{
    available?: boolean;
    is_truly_free?: boolean;
    is_verified?: boolean;
    is_paid_endpoint?: boolean;
    blocked_by_cost_policy?: boolean;
  }>;
} | null): boolean {
  if (!overview) return false;
  if (!overview.any_free_engine_available) return false;
  return (overview.providers ?? []).some(
    (p) =>
      p.available === true &&
      p.is_truly_free === true &&
      p.is_verified === true &&
      p.is_paid_endpoint === false &&
      p.blocked_by_cost_policy === false
  );
}


