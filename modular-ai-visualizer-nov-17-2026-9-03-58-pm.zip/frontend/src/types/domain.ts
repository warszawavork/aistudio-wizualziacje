export type NavSection =
  | 'dashboard'
  | 'new_project'
  | 'sketch_mode'
  | 'idea_mode'
  | 'references'
  | 'history'
  | 'settings';

export type ProjectMode = 'sketch_to_render' | 'idea_to_project';
export type ProjectStatus = 'draft' | 'awaiting_ai_pipeline' | 'archived';
export type ProviderPreference = 'auto' | 'gemini' | 'groq';

export type ReferenceCategory =
  | 'sketch_pair'
  | 'sketch_plan'
  | 'visualization'
  | 'realization'
  | 'material'
  | 'color'
  | 'lighting'
  | 'style'
  | 'interior';


export type ConfidenceLevel =
  | 'wysoka pewność'
  | 'średnia pewność'
  | 'niska pewność'
  | 'niemożliwe do ustalenia na podstawie materiału';

export interface GeometryAnalysis {
  building_footprint: string;
  floors_count: string;
  structural_vs_partition_walls: string;
  circulation: string;
  proportions_and_scale: string;
  confidence: ConfidenceLevel | string;
}

export interface RoomAnalysisItem {
  name: string;
  zone: string;
  approximate_area: string;
  spatial_relations: string;
  confidence: ConfidenceLevel | string;
}

export interface OpeningAnalysisItem {
  opening_id?: string;
  category: string;
  location: string;
  opening_direction: string;
  has_swing_arc?: boolean | null;
  opening_completeness_note?: string;
  notes: string;
  confidence: ConfidenceLevel | string;
}

export type DimensionSourceType =
  | 'direct'
  | 'calculated'
  | 'estimated'
  | 'indeterminable';

export interface DimensionObservationItem {
  label: string;
  value: string;
  source_type: DimensionSourceType;
  unit?: string;
  location?: string;
  confidence: ConfidenceLevel | string;
}

export interface DimensionCheckItem {
  description: string;
  overall_dimension?: string;
  segment_sum?: string;
  status: 'consistent' | 'conflict' | 'indeterminable';
  difference?: string;
}

export interface GeometryProtectionRules {
  must_preserve: string[];
  can_change: string[];
  forbidden_changes: string[];
}

export interface UncertaintyItem {
  element: string;
  confidence: ConfidenceLevel | string;
  reason: string;
}

export type AnalysisSource = 'live' | 'mock' | 'legacy' | 'fallback';

export interface StructuredAnalysisSections {
  rooms?: RoomAnalysisItem[];
  geometry?: GeometryAnalysis | null;
  openings?: OpeningAnalysisItem[];
  openings_completeness_check?: string;
  orientation_source?: string;
  unjustified_directions_detected?: string[];
  dimension_observations?: DimensionObservationItem[];
  dimension_checks?: DimensionCheckItem[];
  dimension_conflicts?: string[];
  dimension_confidence?: ConfidenceLevel | string;
  geometry_protection?: GeometryProtectionRules | null;
  uncertainties?: UncertaintyItem[];
  user_requirements?: string[];
  ai_suggestions?: string[];
  observed_facts?: string[];
  model_interpretations?: string[];
  indeterminable_elements?: string[];
  clarification_questions?: string[];
  disclaimer?: string;
}

export interface AnalysisEditableFields {
  summary: string;
  spatial_layout: string;
  materials_proposal: string;
  lighting_proposal: string;
  geometry_preservation_note: string;
  visualization_prompt: string;
}

export interface ProjectAnalysis extends AnalysisEditableFields, StructuredAnalysisSections {
  id: number;
  project_id: number;
  mode: ProjectMode;
  provider: string;
  model: string;
  is_free_tier: boolean;
  response_time_ms?: number | null;
  schema_version?: string;
  is_legacy_format?: boolean;
  analysis_source?: AnalysisSource;
  is_mock?: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProjectAnalysisDraft extends AnalysisEditableFields, StructuredAnalysisSections {
  mode: ProjectMode;
  provider: string;
  model: string;
  is_free_tier: boolean;
  response_time_ms?: number | null;
  schema_version?: string;
  analysis_source?: AnalysisSource;
  is_mock?: boolean;
  raw_response_text?: string;
}

export interface AnalysisPreviewResponse extends ProjectAnalysisDraft {
  image_generation_available: boolean;
  image_generation_note: string;
}

export interface AnalyzeDraftPayload {
  mode: ProjectMode;
  title: string;
  building_type: string;
  area_sqm: number | null;
  modules_count: number;
  style_preset: string;
  preserve_geometry: boolean;
  prompt_brief: string;
  geometry_notes: string;
  sketch_image_url: string | null;
  reference_ids: number[];
  preferred_provider: ProviderPreference;
}

export interface Project {
  id: number;
  title: string;
  mode: ProjectMode;
  status: ProjectStatus;
  building_type: string;
  area_sqm: number | null;
  modules_count: number;
  style_preset: string;
  preserve_geometry: boolean;
  prompt_brief: string;
  geometry_notes: string;
  sketch_image_url: string | null;
  preview_image_url: string | null;
  reference_ids: number[];
  latest_analysis: ProjectAnalysis | null;
  analyses_count?: number;
  analysis_history?: ProjectAnalysis[];
  created_at: string;
  updated_at: string;
}

export interface ProjectCreatePayload {
  title: string;
  mode: ProjectMode;
  status?: ProjectStatus;
  building_type: string;
  area_sqm: number | null;
  modules_count: number;
  style_preset: string;
  preserve_geometry: boolean;
  prompt_brief: string;
  geometry_notes: string;
  sketch_image_url: string | null;
  preview_image_url?: string | null;
  reference_ids: number[];
  initial_analysis?: ProjectAnalysisDraft | null;
}

export interface ProjectUpdatePayload {
  title?: string;
  status?: ProjectStatus;
  building_type?: string;
  area_sqm?: number | null;
  modules_count?: number;
  style_preset?: string;
  preserve_geometry?: boolean;
  prompt_brief?: string;
  geometry_notes?: string;
  sketch_image_url?: string | null;
  preview_image_url?: string | null;
  reference_ids?: number[];
}

export interface DashboardSummary {
  total_projects: number;
  sketch_mode_count: number;
  idea_mode_count: number;
  total_references: number;
  recent_projects: Project[];
}

export interface ReferenceItem {
  id: number;
  title: string;
  category: ReferenceCategory;
  category_label?: string;
  role?: string;
  description: string;
  materials_note: string;
  lighting_note: string;
  style_tags: string;
  tags?: string[];
  image_url: string | null;
  paired_sketch_url: string | null;
  original_file_path?: string | null;
  project_id?: number | null;
  linked_project_ids?: number[];
  linked_project_titles?: string[];
  is_in_use?: boolean;
  created_at: string;
  updated_at?: string;
}

export interface ReferenceCreatePayload {
  title: string;
  category: ReferenceCategory;
  description: string;
  materials_note: string;
  lighting_note: string;
  style_tags: string;
  tags?: string[];
  image_url: string | null;
  paired_sketch_url?: string | null;
  project_id?: number | null;
  linked_project_ids?: number[];
}

export interface ReferenceUpdatePayload {
  title?: string;
  category?: ReferenceCategory;
  description?: string;
  materials_note?: string;
  lighting_note?: string;
  style_tags?: string;
  tags?: string[];
  image_url?: string | null;
  paired_sketch_url?: string | null;
  project_id?: number | null;
  linked_project_ids?: number[];
}

export interface ReferenceContextItem {
  reference_id: number;
  title: string;
  category: string;
  category_label: string;
  role: string;
  description: string;
  tags: string[];
  materials_note: string;
  lighting_note: string;
  image_path: string;
  paired_sketch_path?: string | null;
  project_relation: string;
}

export interface ReferenceContextPreview {
  project_id?: number | null;
  project_title?: string | null;
  total_references: number;
  context_note: string;
  formatted_prompt_context: string;
  items: ReferenceContextItem[];
}


export interface StudioSettings {
  id: number;
  studio_name: string;
  default_style: string;
  default_preserve_geometry: boolean;
  preferred_aspect_ratio: string;
  preferred_vision_provider: string;
  preferred_image_provider: string;
  updated_at: string;
}

export type ImageGeneratorStatus =
  | 'available_free'
  | 'unavailable_free'
  | 'disabled_by_cost_policy'
  | 'unverified_blocked'
  | 'missing_api_key'
  | 'cooldown'
  | 'local_limit_reached'
  | 'provider_error';

export type RenderLifecycleState =
  | 'not_requested'
  | 'queued'
  | 'generating'
  | 'completed'
  | 'unavailable_free'
  | 'disabled_by_cost_policy'
  | 'unverified_blocked'
  | 'cooldown'
  | 'error';

export type AnalysisLifecycleState = 'not_started' | 'completed';

export interface ImageProviderStatusRead {
  key: string;
  name: string;
  role: string;
  model: string;
  plan_type: string;
  available: boolean;
  availability_status: string;
  is_truly_free: boolean;
  is_paid_endpoint: boolean;
  is_verified: boolean;
  verification_status: string;
  blocked_by_cost_policy: boolean;
  api_key_configured: boolean;
  known_limits: string;
  cooldown_until: string | null;
  supported_resolutions: string[];
  supports_image_to_image: boolean;
  supports_geometry_preservation: boolean;
  hardware_requirements: string;
  unavailability_reason: string;
  local_calls_today: number;
  local_calls_total: number;
  last_error: string;
}

export interface ImageProvidersOverviewRead {
  any_free_engine_available: boolean;
  active_free_engine_key: string | null;
  active_free_engine_name: string | null;
  summary_message: string;
  providers: ImageProviderStatusRead[];
}

export interface GenerateImagePayload {
  preferred_provider?: string;
  aspect_ratio?: string;
  custom_prompt_override?: string | null;
}

export interface GenerateDraftImagePayload {
  mode: ProjectMode;
  title: string;
  building_type: string;
  style_preset: string;
  preserve_geometry: boolean;
  prompt: string;
  sketch_image_url: string | null;
  preferred_provider?: string;
  aspect_ratio?: string;
}

export interface ImageGenerationResponse {
  project_id: number | null;
  mode: ProjectMode | string;
  analysis_status: AnalysisLifecycleState;
  render_status: RenderLifecycleState;
  generated_image_url: string | null;
  provider_key: string | null;
  provider_name: string | null;
  model: string | null;
  used_image_to_image: boolean;
  geometry_preserved: boolean;
  is_conceptual: boolean;
  conceptual_label: string | null;
  prompt_used: string;
  response_time_ms: number | null;
  message: string;
  project: Project | null;
}

export interface CostPolicyOverview {
  free_only: boolean;
  allow_paid_apis: boolean;
  monthly_budget: number;
  allow_hf_micro_free_credits: boolean;
  paid_services_blocked: boolean;
}

export interface ImageGeneratorStatusRead {
  status: ImageGeneratorStatus;
  provider_name: string;
  message: string;
  preserves_project_artifacts: boolean;
}

export interface ProviderStatusItem {
  key: string;
  name: string;
  role: string;
  model: string;
  plan_type: string;
  api_key_configured: boolean;
  available: boolean;
  availability_status: string;
  is_paid_endpoint: boolean;
  blocked_by_cost_policy: boolean;
  configured_limits: string;
  local_calls_today: number;
  local_calls_total: number;
  last_error: string;
  cooldown_until: string | null;
  local_counter_disclaimer: string;
  notes: string;
}

export interface ProvidersOverview {
  stage: string;
  cost_policy: CostPolicyOverview;
  image_generator: ImageGeneratorStatusRead;
  image_providers_overview?: ImageProvidersOverviewRead | null;
  providers: ProviderStatusItem[];
}

export interface HealthResponse {
  status: string;
  app_name: string;
  stage: string;
  database_connected: boolean;
  storage_ready: boolean;
  timestamp: string;
}

