import { useCallback, useEffect, useRef, useState } from 'react';
import { apiClient } from './api/client';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { Sidebar } from './components/Sidebar';
import { StatusNotice } from './components/StatusNotice';
import { TopBar } from './components/TopBar';
import type {
  AnalysisEditableFields,
  DashboardSummary,
  HealthResponse,
  NavSection,
  Project,
  ProjectCreatePayload,
  ProjectStatus,
  ProjectUpdatePayload,
  ProviderPreference,
  ProvidersOverview,
  ReferenceCreatePayload,
  ReferenceItem,
  ReferenceUpdatePayload,
  StudioSettings,
} from './types/domain';
import { DashboardView } from './views/DashboardView';
import { IdeaModeView } from './views/IdeaModeView';
import { NewProjectView } from './views/NewProjectView';
import { ProjectHistoryView } from './views/ProjectHistoryView';
import { ReferenceLibraryView } from './views/ReferenceLibraryView';
import { SettingsView } from './views/SettingsView';
import { SketchModeView } from './views/SketchModeView';

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [references, setReferences] = useState<ReferenceItem[]>([]);
  const [settings, setSettings] = useState<StudioSettings | null>(null);
  const [providers, setProviders] = useState<ProvidersOverview | null>(null);
  const [health, setHealth] = useState<HealthResponse | null>(null);

  const [loading, setLoading] = useState(true);
  const [backendError, setBackendError] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const requestSeqRef = useRef(0);

  const loadWorkspaceData = useCallback(async () => {
    const seq = ++requestSeqRef.current;
    setLoading(true);
    setBackendError(null);
    try {
      const [summaryData, projectsData, referencesData, settingsData, providersData, healthData] =
        await Promise.all([
          apiClient.getDashboardSummary(),
          apiClient.listProjects(),
          apiClient.listReferences(),
          apiClient.getSettings(),
          apiClient.getProvidersStatus(),
          apiClient.getHealth(),
        ]);

      if (seq !== requestSeqRef.current) return;
      setSummary(summaryData);
      setProjects(projectsData);
      setReferences(referencesData);
      setSettings(settingsData);
      setProviders(providersData);
      setHealth(healthData);
    } catch (err) {
      if (seq !== requestSeqRef.current) return;
      const message =
        err instanceof Error
          ? err.message
          : 'Nie można połączyć się z backendem FastAPI (/api).';
      setBackendError(
        `${message} Upewnij się, że serwer FastAPI jest uruchomiony i dostępny przez proxy /api.`
      );
    } finally {
      if (seq === requestSeqRef.current) {
        setLoading(false);
      }
    }
  }, []);

  const refreshProjectsAndReferences = useCallback(async () => {
    const seq = ++requestSeqRef.current;
    try {
      const [summaryData, projectsData, referencesData] = await Promise.all([
        apiClient.getDashboardSummary(),
        apiClient.listProjects(),
        apiClient.listReferences(),
      ]);
      if (seq !== requestSeqRef.current) return;
      setSummary(summaryData);
      setProjects(projectsData);
      setReferences(referencesData);
      setBackendError(null);
    } catch (err) {
      if (seq !== requestSeqRef.current) return;
      const message =
        err instanceof Error
          ? err.message
          : 'Nie udało się odświeżyć danych projektów i referencji.';
      setBackendError(message);
    }
  }, []);

  useEffect(() => {
    void loadWorkspaceData();
  }, [loadWorkspaceData]);

  const handleCreateProject = async (payload: ProjectCreatePayload) => {
    await apiClient.createProject(payload);
    await refreshProjectsAndReferences();
  };

  const handleUpdateProjectStatus = async (projectId: number, status: ProjectStatus) => {
    const updated = await apiClient.updateProjectStatus(projectId, status);
    setSelectedProject(updated);
    await refreshProjectsAndReferences();
  };

  const handleUpdateProject = async (projectId: number, payload: ProjectUpdatePayload) => {
    const updated = await apiClient.updateProject(projectId, payload);
    setSelectedProject(updated);
    await refreshProjectsAndReferences();
  };

  const refreshProvidersStatus = useCallback(async () => {
    try {
      const providersData = await apiClient.getProvidersStatus();
      setProviders(providersData);
    } catch {
      // Ignore background provider status refresh errors
    }
  }, []);

  const handleAnalyzeProject = async (projectId: number, provider: ProviderPreference) => {
    try {
      const updated = await apiClient.analyzeProject(projectId, provider);
      setSelectedProject(updated);
      await refreshProjectsAndReferences();
    } finally {
      void refreshProvidersStatus();
    }
  };

  const handleUpdateProjectAnalysis = async (
    projectId: number,
    fields: Partial<AnalysisEditableFields>
  ) => {
    const updated = await apiClient.updateProjectAnalysis(projectId, fields);
    setSelectedProject(updated);
    await refreshProjectsAndReferences();
  };

  const handleGenerateProjectImage = async (
    projectId: number,
    preferredProvider: string,
    aspectRatio: string
  ) => {
    try {
      const response = await apiClient.generateProjectImage(projectId, {
        preferred_provider: preferredProvider,
        aspect_ratio: aspectRatio,
      });
      if (response.project) {
        setSelectedProject(response.project);
      }
      await refreshProjectsAndReferences();
      return response;
    } finally {
      void refreshProvidersStatus();
    }
  };

  const handleDeleteProject = async (projectId: number) => {
    await apiClient.deleteProject(projectId);
    if (selectedProject?.id === projectId) {
      setSelectedProject(null);
    }
    await refreshProjectsAndReferences();
  };

  const handleAddReference = async (payload: ReferenceCreatePayload) => {
    await apiClient.createReference(payload);
    await refreshProjectsAndReferences();
  };

  const handleUpdateReference = async (referenceId: number, payload: ReferenceUpdatePayload) => {
    await apiClient.updateReference(referenceId, payload);
    await refreshProjectsAndReferences();
  };

  const handleDeleteReference = async (referenceId: number, force: boolean = false) => {
    await apiClient.deleteReference(referenceId, force);
    await refreshProjectsAndReferences();
  };

  const handleSaveSettings = async (payload: Partial<StudioSettings>) => {
    const updated = await apiClient.updateSettings(payload);
    setSettings(updated);
  };

  const handleRefreshHealth = async () => {
    try {
      const nextHealth = await apiClient.getHealth();
      setHealth(nextHealth);
      setBackendError(null);
    } catch (err) {
      setBackendError(
        err instanceof Error ? err.message : 'Brak odpowiedzi z endpointu /api/health.'
      );
    }
  };

  return (
    <div className="min-h-screen flex bg-[#f7f6f3] text-[#141518]">
      <Sidebar
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        <TopBar
          activeSection={activeSection}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onStartNewProject={() => setActiveSection('new_project')}
        />

        <main className="flex-1 p-4 sm:p-8 lg:p-10 max-w-[1380px] w-full mx-auto">
          {backendError && (
            <div className="mb-6">
              <StatusNotice
                tone="error"
                title="Brak połączenia z API backendu"
                description={backendError}
                actionLabel={loading ? 'Ładowanie...' : 'Spróbuj ponownie'}
                onAction={() => void loadWorkspaceData()}
              />
            </div>
          )}

          {activeSection === 'dashboard' && (
            <DashboardView
              studioName={settings?.studio_name}
              summary={summary}
              references={references}
              loading={loading}
              onNavigate={setActiveSection}
              onInspectProject={setSelectedProject}
            />
          )}

          {activeSection === 'new_project' && (
            <NewProjectView onNavigate={setActiveSection} />
          )}

          {activeSection === 'sketch_mode' && (
            <SketchModeView
              defaultStyle={settings?.default_style ?? 'Nordic Graphite'}
              references={references}
              imageProvidersOverview={providers?.image_providers_overview ?? null}
              onCreateProject={handleCreateProject}
              onNavigate={setActiveSection}
              onAfterAiCall={refreshProvidersStatus}
            />
          )}

          {activeSection === 'idea_mode' && (
            <IdeaModeView
              defaultStyle={settings?.default_style ?? 'Nordic Graphite'}
              references={references}
              imageProvidersOverview={providers?.image_providers_overview ?? null}
              onCreateProject={handleCreateProject}
              onNavigate={setActiveSection}
              onAfterAiCall={refreshProvidersStatus}
            />
          )}

          {activeSection === 'references' && (
            <ReferenceLibraryView
              references={references}
              projects={projects}
              loading={loading}
              onAddReference={handleAddReference}
              onUpdateReference={handleUpdateReference}
              onDeleteReference={handleDeleteReference}
            />
          )}

          {activeSection === 'history' && (
            <ProjectHistoryView
              projects={projects}
              loading={loading}
              onInspectProject={setSelectedProject}
              onDeleteProject={handleDeleteProject}
              onNavigate={setActiveSection}
            />
          )}

          {activeSection === 'settings' && (
            <SettingsView
              settings={settings}
              providers={providers}
              health={health}
              onSaveSettings={handleSaveSettings}
              onRefreshHealth={handleRefreshHealth}
            />
          )}
        </main>
      </div>

      <ProjectDetailModal
        project={selectedProject}
        references={references}
        imageProvidersOverview={providers?.image_providers_overview ?? null}
        onClose={() => setSelectedProject(null)}
        onUpdateProject={handleUpdateProject}
        onStatusChange={handleUpdateProjectStatus}
        onDelete={handleDeleteProject}
        onAnalyzeProject={handleAnalyzeProject}
        onUpdateProjectAnalysis={handleUpdateProjectAnalysis}
        onGenerateProjectImage={handleGenerateProjectImage}
      />
    </div>
  );
}

