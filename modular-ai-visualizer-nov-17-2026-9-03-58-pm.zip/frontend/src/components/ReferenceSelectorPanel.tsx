import { useEffect, useMemo, useState } from 'react';
import { BookOpen, Check, ChevronDown, ChevronUp, Search, X } from 'lucide-react';
import type { ReferenceCategory, ReferenceItem } from '../types/domain';
import {
  buildClientReferenceContextSummary,
  formatCategoryLabel,
  formatReferenceRoleLabel,
  parseReferenceTags,
} from '../utils/formatters';

interface ReferenceSelectorPanelProps {
  references: ReferenceItem[];
  selectedIds: number[];
  onChangeSelectedIds: (nextIds: number[]) => void;
  projectTitle?: string;
  title?: string;
  subtitle?: string;
  disabled?: boolean;
  onSaveSelection?: (nextIds: number[]) => Promise<void>;
  savingSelection?: boolean;
  selectionSaved?: boolean;
}

const SELECTOR_PAGE_SIZE = 12;

const SELECTOR_CATEGORIES: Array<{ id: 'all' | ReferenceCategory; label: string }> = [
  { id: 'all', label: 'Wszystkie' },
  { id: 'material', label: 'Materiały' },
  { id: 'color', label: 'Kolory' },
  { id: 'style', label: 'Style' },
  { id: 'lighting', label: 'Oświetlenie' },
  { id: 'realization', label: 'Realizacje' },
  { id: 'sketch_pair', label: 'Szkice i rzuty' },
  { id: 'visualization', label: 'Wizualizacje' },
  { id: 'interior', label: 'Wnętrza' },
];

export function ReferenceSelectorPanel({
  references,
  selectedIds,
  onChangeSelectedIds,
  projectTitle,
  title = 'Referencje z biblioteki pracowni',
  subtitle = 'Wybierz materiały, styl, oświetlenie lub wcześniejsze realizacje jako kontekst dla analizy i wizualizacji.',
  disabled = false,
  onSaveSelection,
  savingSelection = false,
  selectionSaved = false,
}: ReferenceSelectorPanelProps) {
  const [categoryFilter, setCategoryFilter] = useState<'all' | ReferenceCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAiContextPreview, setShowAiContextPreview] = useState(false);
  const [visibleCount, setVisibleCount] = useState(SELECTOR_PAGE_SIZE);

  useEffect(() => {
    setVisibleCount(SELECTOR_PAGE_SIZE);
  }, [categoryFilter, searchQuery]);

  const toggleRef = (id: number) => {
    if (disabled) return;
    const next = selectedIds.includes(id)
      ? selectedIds.filter((item) => item !== id)
      : [...selectedIds, id];
    onChangeSelectedIds(next);
  };

  const filteredReferences = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return references.filter((item) => {
      const matchesCategory =
        categoryFilter === 'all' ||
        (categoryFilter === 'sketch_pair'
          ? item.category === 'sketch_pair' || item.category === 'sketch_plan'
          : item.category === categoryFilter);
      const matchesSearch =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.materials_note.toLowerCase().includes(q) ||
        item.lighting_note.toLowerCase().includes(q) ||
        item.style_tags.toLowerCase().includes(q);
      return matchesCategory && matchesSearch;
    });
  }, [references, categoryFilter, searchQuery]);

  const visibleReferences = useMemo(
    () => filteredReferences.slice(0, visibleCount),
    [filteredReferences, visibleCount]
  );

  const contextSummary = useMemo(
    () => buildClientReferenceContextSummary(references, selectedIds, projectTitle),
    [references, selectedIds, projectTitle]
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-zinc-700 shrink-0" aria-hidden="true" />
            <h3 className="text-xs font-semibold text-zinc-950">
              {title} ({selectedIds.length} wybrano)
            </h3>
          </div>
          <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">{subtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {selectedIds.length > 0 && (
            <button
              type="button"
              disabled={disabled}
              onClick={() => onChangeSelectedIds([])}
              className="text-xs font-medium text-zinc-600 hover:text-zinc-950 underline underline-offset-4 disabled:opacity-50"
            >
              Wyczyść wybór
            </button>
          )}
          {onSaveSelection && (
            <button
              type="button"
              disabled={disabled || savingSelection}
              onClick={() => void onSaveSelection(selectedIds)}
              className="px-3 py-1.5 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 disabled:opacity-50 transition-colors whitespace-nowrap"
            >
              {savingSelection ? 'Zapisywanie powiązań...' : 'Zapisz przypisane referencje'}
            </button>
          )}
        </div>
      </div>

      {selectionSaved && (
        <p className="text-xs text-emerald-800 bg-emerald-50/80 border border-emerald-200 rounded-md px-3 py-2">
          Powiązania referencji z projektem zostały trwale zapisane w bazie SQLite.
        </p>
      )}

      {/* Wybrane referencje — szybki podgląd z możliwością odpięcia */}
      {contextSummary.length > 0 && (
        <div className="p-3 rounded-md border border-zinc-200 bg-zinc-50/70 space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-medium text-zinc-800">
              Przypisane do projektu ({contextSummary.length}):
            </span>
            <button
              type="button"
              onClick={() => setShowAiContextPreview((prev) => !prev)}
              className="inline-flex items-center gap-1 text-xs font-medium text-zinc-700 hover:text-zinc-950"
            >
              <span>
                {showAiContextPreview
                  ? 'Ukryj kontekst przekazywany do AI'
                  : 'Podgląd kontekstu dla AI'}
              </span>
              {showAiContextPreview ? (
                <ChevronUp className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {contextSummary.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between gap-2 p-2 rounded border border-zinc-200 bg-white min-w-0"
              >
                <div className="min-w-0">
                  <p className="text-xs font-medium text-zinc-900 truncate">{item.title}</p>
                  <p className="text-[11px] text-zinc-500 truncate">
                    {item.categoryLabel} · Rola: {item.role}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={disabled}
                  onClick={() => toggleRef(item.id)}
                  aria-label={`Odłącz referencję ${item.title}`}
                  className="p-1 text-zinc-400 hover:text-red-700 rounded hover:bg-zinc-100 shrink-0 disabled:opacity-50"
                >
                  <X className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              </div>
            ))}
          </div>

          {showAiContextPreview && (
            <div className="pt-2 border-t border-zinc-200/80 space-y-2 text-xs">
              <p className="text-[11px] text-zinc-600 leading-relaxed">
                <strong>Kontekst referencyjny dla Gemini / Groq:</strong> przekazywany wyłącznie
                wtedy, gdy wybrano referencje i wywołanie jest dozwolone przez CostGuard (biblioteka
                jest trwałym kontekstem projektowym, a nie automatycznym treningiem modelu).
              </p>
              <div className="bg-white border border-zinc-200 rounded p-2.5 space-y-2 font-mono-tabular text-[11px] text-zinc-700 max-h-48 overflow-y-auto">
                {contextSummary.map((item, idx) => (
                  <div
                    key={item.id}
                    className="pb-2 border-b border-zinc-100 last:border-b-0 last:pb-0"
                  >
                    <p className="font-semibold text-zinc-900">
                      {idx + 1}. [{item.role}] {item.title} ({item.categoryLabel})
                    </p>
                    <p className="text-zinc-600 break-all">
                      Plik: {item.imagePath} · Relacja: {item.relation}
                    </p>
                    {item.tags.length > 0 && (
                      <p className="text-zinc-500">
                        Tagi: {item.tags.map((t) => `#${t}`).join(' · ')}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Filtry kategorii i wyszukiwarka wewnątrz selektora */}
      <div className="space-y-2">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-zinc-200/75 rounded-md max-w-full">
          {SELECTOR_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-2.5 py-1 text-[11px] font-medium rounded transition-colors ${
                categoryFilter === cat.id
                  ? 'bg-white text-zinc-950 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search
            className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filtruj referencje po nazwie, materiale, stylu lub tagu..."
            aria-label="Szukaj referencji do przypisania"
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-zinc-300 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
          />
        </div>
      </div>

      {/* Lista wyboru z miniaturami */}
      {filteredReferences.length === 0 ? (
        <div className="p-4 text-center border border-dashed border-zinc-300 rounded-md bg-zinc-50/50 text-xs text-zinc-500">
          Brak referencji pasujących do wybranego filtru.
        </div>
      ) : (
        <div className="space-y-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-1">
            {visibleReferences.map((ref) => {
              const checked = selectedIds.includes(ref.id);
              const tags = parseReferenceTags(ref.style_tags, ref.tags);
              const thumbUrl = ref.image_url || ref.paired_sketch_url;

              return (
                <button
                  key={ref.id}
                  type="button"
                  disabled={disabled}
                  onClick={() => toggleRef(ref.id)}
                  className={`w-full flex items-center gap-2.5 p-2 rounded-md border text-left transition-colors min-w-0 ${
                    checked
                      ? 'border-zinc-950 bg-zinc-50 text-zinc-950'
                      : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50/80'
                  }`}
                >
                  <div className="w-12 h-10 rounded overflow-hidden shrink-0 border border-zinc-200 bg-zinc-100">
                    {thumbUrl ? (
                      <img
                        src={thumbUrl}
                        alt={ref.title}
                        loading="lazy"
                        decoding="async"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[10px] text-zinc-400">
                        brak
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-zinc-950 truncate">{ref.title}</p>
                    <p className="text-[11px] text-zinc-500 truncate">
                      {formatCategoryLabel(ref.category)} · {formatReferenceRoleLabel(ref.category)}
                    </p>
                    {tags.length > 0 && (
                      <p className="text-[10px] text-zinc-400 truncate">
                        {tags.slice(0, 3).map((t) => `#${t}`).join(' · ')}
                      </p>
                    )}
                  </div>

                  <div
                    className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                      checked
                        ? 'bg-zinc-950 border-zinc-950 text-white'
                        : 'border-zinc-300 bg-white'
                    }`}
                  >
                    {checked && <Check className="w-3 h-3" aria-hidden="true" />}
                  </div>
                </button>
              );
            })}
          </div>

          {filteredReferences.length > visibleCount && (
            <div className="flex justify-center pt-1">
              <button
                type="button"
                onClick={() => setVisibleCount((prev) => prev + SELECTOR_PAGE_SIZE)}
                className="px-3 py-1 text-xs font-medium text-zinc-700 hover:text-zinc-950 border border-zinc-300 rounded-md bg-white hover:bg-zinc-50"
              >
                Pokaż więcej referencji ({filteredReferences.length - visibleCount} pozostało)
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
