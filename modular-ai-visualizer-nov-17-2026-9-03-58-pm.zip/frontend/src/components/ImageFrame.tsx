import { useEffect, useState } from 'react';
import { Compass } from 'lucide-react';

interface ImageFrameProps {
  src?: string | null;
  alt: string;
  aspectClass?: string;
  fallbackLabel?: string;
  fit?: 'cover' | 'contain';
  className?: string;
}

export function ImageFrame({
  src,
  alt,
  aspectClass = 'aspect-video',
  fallbackLabel = 'Brak podglądu graficznego',
  fit = 'cover',
  className = '',
}: ImageFrameProps) {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [src]);

  if (!src || hasError) {
    return (
      <div
        className={`${aspectClass} w-full bg-zinc-100 border border-zinc-200 flex flex-col items-center justify-center p-6 text-center select-none ${className}`}
      >
        <div
          className="w-10 h-10 rounded-md border border-zinc-300 bg-white flex items-center justify-center text-zinc-500 mb-3"
          aria-hidden="true"
        >
          <Compass className="w-5 h-5" />
        </div>
        <p className="text-xs font-medium text-zinc-600 max-w-[220px]">{fallbackLabel}</p>
      </div>
    );
  }

  return (
    <div
      className={`${aspectClass} w-full overflow-hidden border border-zinc-200 ${
        fit === 'contain' ? 'bg-white' : 'bg-zinc-100'
      } ${className}`}
    >
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        referrerPolicy="no-referrer"
        onError={() => setHasError(true)}
        className={`w-full h-full ${fit === 'contain' ? 'object-contain p-2' : 'object-cover'}`}
      />
    </div>
  );
}
