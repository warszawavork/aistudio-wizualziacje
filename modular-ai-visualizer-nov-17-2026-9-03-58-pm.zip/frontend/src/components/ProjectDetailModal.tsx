import { useEffect, useState, type FormEvent } from 'react';
import { BookOpen, Edit3, History, Sparkles, Trash2, X } from 'lucide-react';
import type {
  AnalysisEditableFields,
  ImageGenerationResponse,
  ImageProvidersOverviewRead,
  Project,
  ProjectAnalysis,
  ProjectStatus,
  ProjectUpdatePayload,
  ProviderPreference,
  ReferenceItem,
} from '../types/domain';
import {
  formatAreaSqm,
  formatCategoryLabel,
  formatModeLabel,
  formatModeShortLabel,
  formatModulesCount,
  formatPolishDate,
  formatReferenceRoleLabel,
  formatStatusLabel,
} from '../utils/formatters';
import { AnalysisResultPanel, type AnalysisDisplayData } from './AnalysisResultPanel';
import { ImageFrame } from './ImageFrame';
import { ImageGenerationPanel } from './ImageGenerationPanel';
import { ReferenceSelectorPanel } from './ReferenceSelectorPanel';
import { StatusNotice } from './StatusNotice';

interface ProjectDetailModalProps {
  project: Project | null;
  references: ReferenceItem[];
  imageProvidersOverview: ImageProvidersOverviewRead | null;
  onClose: () => void;
  onUpdateProject: (projectId: number, payload: ProjectUpdatePayload) => Promise<void>;
  onStatusChange: (projectId: number, status: ProjectStatus) => Promise<void>;
  onDelete: (projectId: number) => Promise<void>;
  onAnalyzeProject: (projectId: number, provider: ProviderPreference) => Promise<void>;
  onUpdateProjectAnalysis: (
    projectId: number,
    fields: Partial<AnalysisEditableFields>
  ) => Promise<void>;
  onGenerateProjectImage: (
    projectId: number,
    preferredProvider: string,
    aspectRatio: string
  ) => Promise<ImageGenerationResponse>;
}

function mapAnalysisToDisplay(item: ProjectAnalysis): AnalysisDisplayData {
  return {
    provider: item.provider,
    model: item.model,
    is_free_tier: item.is_free_tier,
    response_time_ms: item.response_time_ms,
    schema_version: item.schema_version,
    is_legacy_format: item.is_legacy_format,
    analysis_source: item.analysis_source,
    is_mock: item.is_mock,
    summary: item.summary,
    spatial_layout: item.spatial_layout,
    materials_proposal: item.materials_proposal,
    lighting_proposal: item.lighting_proposal,
    geometry_preservation_note: item.geometry_preservation_note,
    visualization_prompt: item.visualization_prompt,
    rooms: item.rooms,
    geometry: item.geometry,
    openings: item.openings,
    openings_completeness_check: item.openings_completeness_check,
    orientation_source: item.orientation_source,
    unjustified_directions_detected: item.unjustified_directions_detected,
    dimension_observations: item.dimension_observations,
    dimension_checks: item.dimension_checks,
    dimension_conflicts: item.dimension_conflicts,
    dimension_confidence: item.dimension_confidence,
    geometry_protection: item.geometry_protection,
    uncertainties: item.uncertainties,
    user_requirements: item.user_requirements,
    ai_suggestions: item.ai_suggestions,
    observed_facts: item.observed_facts,
    model_interpretations: item.model_interpretations,
    indeterminable_elements: item.indeterminable_elements,
    clarification_questions: item.clarification_questions,
    disclaimer: item.disclaimer,
  };
}

export function ProjectDetailModal({
  project,
  references,
  imageProvidersOverview,
  onClose,
  onUpdateProject,
  onStatusChange,
  onDelete,
  onAnalyzeProject,
  onUpdateProjectAnalysis,
  onGenerateProjectImage,
}: ProjectDetailModalProps) {
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [providerChoice, setProviderChoice] = useState<ProviderPreference>('auto');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [savingEdits, setSavingEdits] = useState(false);
  const [editsSaved, setEditsSaved] = useState(false);
  const [draftDisplay, setDraftDisplay] = useState<AnalysisDisplayData | null>(null);
  const [selectedAnalysisId, setSelectedAnalysisId] = useState<number | null>(null);

  // Project metadata editing state
  const [editingMetadata, setEditingMetadata] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editPromptBrief, setEditPromptBrief] = useState('');
  const [editGeometryNotes, setEditGeometryNotes] = useState('');
  const [editBuildingType, setEditBuildingType] = useState('');
  const [editStylePreset, setEditStylePreset] = useState('');
  const [editAreaSqm, setEditAreaSqm] = useState('');
  const [editModulesCount, setEditModulesCount] = useState('1');
  const [savingMetadata, setSavingMetadata] = useState(false);
  const [metadataSaved, setMetadataSaved] = useState(false);

  // Reference assignment state
  const [editingRefs, setEditingRefs] = useState(false);
  const [selectedRefIds, setSelectedRefIds] = useState<number[]>([]);
  const [savingRefs, setSavingRefs] = useState(false);
  const [refsSaved, setRefsSaved] = useState(false);

  useEffect(() => {
    setConfirmDelete(false);
    setActionError(null);
    setUpdatingStatus(false);
    setDeleting(false);
    setAnalysisError(null);
    setAnalyzing(false);
    setSavingEdits(false);
    setEditsSaved(false);
    setEditingMetadata(false);
    setMetadataSaved(false);
    setEditingRefs(false);
    setRefsSaved(false);
  }, [project?.id]);

  useEffect(() => {
    if (!project) return;
    setEditTitle(project.title);
    setEditPromptBrief(project.prompt_brief || '');
    setEditGeometryNotes(project.geometry_notes || '');
    setEditBuildingType(project.building_type || 'Dom modułowy parterowy');
    setEditStylePreset(project.style_preset || 'Nordic Graphite');
    setEditAreaSqm(project.area_sqm !== null ? String(project.area_sqm) : '');
    setEditModulesCount(String(project.modules_count || 1));
    setSelectedRefIds(project.reference_ids ?? []);
  }, [
    project?.id,
    project?.title,
    project?.prompt_brief,
    project?.geometry_notes,
    project?.building_type,
    project?.style_preset,
    project?.area_sqm,
    project?.modules_count,
    project?.reference_ids,
  ]);

  useEffect(() => {
    const latest = project?.latest_analysis;
    if (!latest) {
      setDraftDisplay(null);
      setSelectedAnalysisId(null);
      return;
    }
    setSelectedAnalysisId(latest.id);
    setDraftDisplay(mapAnalysisToDisplay(latest));
  }, [project?.id, project?.latest_analysis]);

  useEffect(() => {
    if (!project) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [project, onClose]);

  if (!project) return null;

  const linkedReferences = (project.reference_ids ?? [])
    .map((id) => references.find((ref) => ref.id === id))
    .filter((ref): ref is ReferenceItem => Boolean(ref));

  const analysisHistory =
    project.analysis_history && project.analysis_history.length > 0
      ? project.analysis_history
      : project.latest_analysis
        ? [project.latest_analysis]
        : [];

  const handleSelectHistoricalAnalysis = (analysisId: number) => {
    const found = analysisHistory.find((item) => item.id === analysisId);
    if (found) {
      setSelectedAnalysisId(found.id);
      setDraftDisplay(mapAnalysisToDisplay(found));
      setEditsSaved(false);
    }
  };

  const handleSaveMetadata = async (e: FormEvent) => {
    e.preventDefault();
    if (!editTitle.trim() || editTitle.trim().length < 3) {
      setActionError('Nazwa projektu musi zawierać co najmniej 3 znaki.');
      return;
    }
    const parsedArea = editAreaSqm.trim() ? Number(editAreaSqm) : null;
    if (parsedArea !== null && (Number.isNaN(parsedArea) || parsedArea <= 0)) {
      setActionError('Powierzchnia musi być liczbą większą od zera.');
      return;
    }

    setActionError(null);
    setMetadataSaved(false);
    setSavingMetadata(true);
    try {
      await onUpdateProject(project.id, {
        title: editTitle.trim(),
        prompt_brief: editPromptBrief.trim(),
        geometry_notes: editGeometryNotes.trim(),
        building_type: editBuildingType,
        style_preset: editStylePreset,
        area_sqm: parsedArea,
        modules_count: Math.max(1, Number(editModulesCount) || 1),
      });
      setEditingMetadata(false);
      setMetadataSaved(true);
    } catch (err) {
      setActionError(
        err instanceof Error ? err.message : 'Nie udało się zapisać zmian w projekcie.'
      );
    } finally {
      setSavingMetadata(false);
    }
  };

  const handleSaveReferences = async (nextIds: number[]) => {
    setActionError(null);
    setRefsSaved(false);
    setSavingRefs(true);
    try {
      await onUpdateProject(project.id, {
        reference_ids: nextIds,
      });
      setSelectedRefIds(nextIds);
      setRefsSaved(true);
    } catch (err) {
      setActionError(
        err instanceof Error
          ? err.message
          : 'Nie udało się zapisać przypisanych referencji dla projektu.'
      );
    } finally {
      setSavingRefs(false);
    }
  };

  const handleStatusSelect = async (nextStatus: ProjectStatus) => {
    setActionError(null);
    setUpdatingStatus(true);
    try {
      await onStatusChange(project.id, nextStatus);
    } catch (err) {
      setActionError(
        err instanceof Error ? err.message : 'Nie udało się zmienić statusu projektu.'
      );
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleConfirmDelete = async () => {
    setActionError(null);
    setDeleting(true);
    try {
      await onDelete(project.id);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Nie udało się usunąć projektu.');
      setDeleting(false);
    }
  };

  const handleRunProjectAnalysis = async () => {
    setAnalysisError(null);
    setEditsSaved(false);
    setAnalyzing(true);
    try {
      await onAnalyzeProject(project.id, providerChoice);
    } catch (err) {
      setAnalysisError(
        err instanceof Error ? err.message : 'Nie udało się uruchomić darmowej analizy AI.'
      );
    } finally {
      setAnalyzing(false);
    }
  };

  const handleDraftFieldChange = (field: keyof AnalysisEditableFields, value: string) => {
    setEditsSaved(false);
    setDraftDisplay((prev) => (prev ? { ...prev, [field]: value } : prev));
  };

  const handleSaveAnalysisEdits = async () => {
    if (!draftDisplay) return;
    setAnalysisError(null);
    setEditsSaved(false);
    setSavingEdits(true);
    try {
      await onUpdateProjectAnalysis(project.id, {
        summary: draftDisplay.summary,
        spatial_layout: draftDisplay.spatial_layout,
        materials_proposal: draftDisplay.materials_proposal,
        lighting_proposal: draftDisplay.lighting_proposal,
        geometry_preservation_note: draftDisplay.geometry_preservation_note,
        visualization_prompt: draftDisplay.visualization_prompt,
      });
      setEditsSaved(true);
    } catch (err) {
      setAnalysisError(
        err instanceof Error ? err.message : 'Nie udało się zapisać edycji analizy w SQLite.'
      );
    } finally {
      setSavingEdits(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white border border-zinc-200 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-xl"
      >
        <div className="px-6 py-4 border-b border-zinc-200 flex items-center justify-between gap-4 sticky top-0 bg-white z-10">
          <div className="min-w-0">
            <h2 id="project-modal-title" className="text-lg font-semibold text-zinc-950 truncate">
              {project.title}
            </h2>
            <p className="text-xs text-zinc-500 mt-0.5 font-mono-tabular break-words">
              {formatModeShortLabel(project.mode)} · {formatModeLabel(project.mode)} ·{' '}
              {formatAreaSqm(project.area_sqm)} · {formatModulesCount(project.modules_count)} ·{' '}
              {formatPolishDate(project.updated_at)}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                setEditingMetadata((prev) => !prev);
                setMetadataSaved(false);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50 transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{editingMetadata ? 'Zamknij edycję' : 'Edytuj dane projektu'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label={`Zamknij podgląd projektu ${project.title}`}
              className="p-2 rounded-md text-zinc-500 hover:text-zinc-950 hover:bg-zinc-100 transition-colors shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {actionError && (
            <StatusNotice tone="error" title="Błąd operacji" description={actionError} />
          )}
          {metadataSaved && (
            <StatusNotice
              tone="success"
              title="Zapisano zmiany w projekcie"
              description="Nazwa, opis i parametry projektu zostały zaktualizowane w bazie SQLite."
            />
          )}

          {editingMetadata && (
            <form
              onSubmit={handleSaveMetadata}
              className="p-4 rounded-lg border border-zinc-200 bg-zinc-50/80 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-zinc-200 pb-2">
                <h3 className="text-xs font-semibold text-zinc-950">
                  Edycja nazwy, opisu i parametrów projektu
                </h3>
                <span className="text-[11px] text-zinc-500 font-mono-tabular">
                  ID projektu: #{project.id}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="edit-proj-title"
                    className="block text-xs font-medium text-zinc-700 mb-1"
                  >
                    Nazwa projektu
                  </label>
                  <input
                    id="edit-proj-title"
                    type="text"
                    required
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>

                <div>
                  <label
                    htmlFor="edit-proj-type"
                    className="block text-xs font-medium text-zinc-700 mb-1"
                  >
                    Typ obiektu
                  </label>
                  <input
                    id="edit-proj-type"
                    type="text"
                    value={editBuildingType}
                    onChange={(e) => setEditBuildingType(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label
                    htmlFor="edit-proj-area"
                    className="block text-xs font-medium text-zinc-700 mb-1"
                  >
                    Powierzchnia (m²)
                  </label>
                  <input
                    id="edit-proj-area"
                    type="number"
                    step="0.5"
                    min="1"
                    value={editAreaSqm}
                    onChange={(e) => setEditAreaSqm(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white font-mono-tabular"
                  />
                </div>

                <div>
                  <label
                    htmlFor="edit-proj-modules"
                    className="block text-xs font-medium text-zinc-700 mb-1"
                  >
                    Liczba modułów
                  </label>
                  <input
                    id="edit-proj-modules"
                    type="number"
                    min="1"
                    max="24"
                    value={editModulesCount}
                    onChange={(e) => setEditModulesCount(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white font-mono-tabular"
                  />
                </div>

                <div>
                  <label
                    htmlFor="edit-proj-style"
                    className="block text-xs font-medium text-zinc-700 mb-1"
                  >
                    Kierunek stylistyczny
                  </label>
                  <select
                    id="edit-proj-style"
                    value={editStylePreset}
                    onChange={(e) => setEditStylePreset(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  >
                    <option value="Nordic Graphite">Nordic Graphite</option>
                    <option value="Raw Steel & Cedar">Raw Steel & Cedar</option>
                    <option value="Birch & Microcement">Birch & Microcement</option>
                    <option value="Shou Sugi Ban Minimal">Shou Sugi Ban Minimal</option>
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="edit-proj-brief"
                  className="block text-xs font-medium text-zinc-700 mb-1"
                >
                  Założenia i opis projektu
                </label>
                <textarea
                  id="edit-proj-brief"
                  rows={3}
                  value={editPromptBrief}
                  onChange={(e) => setEditPromptBrief(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                />
              </div>

              <div>
                <label
                  htmlFor="edit-proj-geometry"
                  className="block text-xs font-medium text-zinc-700 mb-1"
                >
                  Wytyczne wymiarowe i stolarka
                </label>
                <textarea
                  id="edit-proj-geometry"
                  rows={2}
                  value={editGeometryNotes}
                  onChange={(e) => setEditGeometryNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-zinc-200">
                <button
                  type="button"
                  onClick={() => setEditingMetadata(false)}
                  className="px-3.5 py-1.5 text-xs font-medium text-zinc-700 hover:text-zinc-950"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  disabled={savingMetadata}
                  className="px-4 py-1.5 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 disabled:opacity-50"
                >
                  {savingMetadata ? 'Zapisywanie...' : 'Zapisz dane projektu'}
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <p className="text-xs font-medium text-zinc-600 mb-2">
                {project.mode === 'sketch_to_render'
                  ? 'Szkic źródłowy (geometria wejściowa)'
                  : 'Szkic koncepcyjny (Tryb B)'}
              </p>
              <ImageFrame
                src={project.sketch_image_url}
                alt={`Szkic projektu ${project.title}`}
                aspectClass="aspect-[4/3]"
                fit="contain"
                fallbackLabel={
                  project.mode === 'sketch_to_render'
                    ? 'Brak przesłanego szkicu wejściowego'
                    : 'Szkic koncepcyjny nie został jeszcze wygenerowany'
                }
              />
            </div>

            <div>
              <p className="text-xs font-medium text-zinc-600 mb-2">
                Podgląd wizualizacji docelowej
              </p>
              <ImageFrame
                src={project.preview_image_url}
                alt={`Wizualizacja projektu ${project.title}`}
                aspectClass="aspect-[4/3]"
                fallbackLabel="Generowanie obrazu jest obecnie niedostępne w darmowym wariancie (parametry projektu są zapisane)"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4 border-y border-zinc-200 text-sm">
            <div>
              <span className="block text-xs text-zinc-500">Typ obiektu</span>
              <span className="font-medium text-zinc-900">{project.building_type}</span>
            </div>
            <div>
              <span className="block text-xs text-zinc-500">Kierunek stylistyczny</span>
              <span className="font-medium text-zinc-900">{project.style_preset}</span>
            </div>
            <div>
              <span className="block text-xs text-zinc-500">Ochrona geometrii szkicu</span>
              <span className="font-medium text-zinc-900">
                {project.preserve_geometry
                  ? 'Tak — zachowanie układu ścian i okien'
                  : 'Elastyczna interpretacja bryły'}
              </span>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-medium text-zinc-500 mb-1">Założenia i opis projektu</h3>
              <p className="text-sm text-zinc-800 leading-relaxed whitespace-pre-wrap">
                {project.prompt_brief || 'Brak opisu tekstowego.'}
              </p>
            </div>
            {project.geometry_notes && (
              <div>
                <h3 className="text-xs font-medium text-zinc-500 mb-1">
                  Wytyczne wymiarowe i stolarka
                </h3>
                <p className="text-sm text-zinc-700 leading-relaxed">{project.geometry_notes}</p>
              </div>
            )}

            {/* Sekcja powiązanych referencji z możliwością edycji powiązań */}
            <div className="pt-2 border-t border-zinc-100 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-zinc-500" aria-hidden="true" />
                  <h3 className="text-xs font-semibold text-zinc-900">
                    Powiązane referencje ({linkedReferences.length})
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEditingRefs((prev) => !prev);
                    setRefsSaved(false);
                  }}
                  className="text-xs font-medium text-zinc-700 hover:text-zinc-950 underline underline-offset-4"
                >
                  {editingRefs ? 'Ukryj selektor referencji' : 'Zmień przypisane referencje'}
                </button>
              </div>

              {editingRefs ? (
                <div className="p-4 rounded-md border border-zinc-200 bg-zinc-50/60">
                  <ReferenceSelectorPanel
                    references={references}
                    selectedIds={selectedRefIds}
                    onChangeSelectedIds={setSelectedRefIds}
                    projectTitle={project.title}
                    title="Zarządzaj referencjami przypisanymi do projektu"
                    subtitle="Wybierz materiały, kolory, styl, oświetlenie lub realizacje i zapisz powiązania w SQLite."
                    onSaveSelection={handleSaveReferences}
                    savingSelection={savingRefs}
                    selectionSaved={refsSaved}
                  />
                </div>
              ) : linkedReferences.length === 0 ? (
                <p className="text-xs text-zinc-500 bg-zinc-50 border border-zinc-200 rounded-md px-3.5 py-2.5">
                  Brak przypisanych referencji dla tego projektu. Kliknij „Zmień przypisane
                  referencje”, aby powiązać materiały, styl lub oświetlenie z biblioteki.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {linkedReferences.map((ref) => {
                    const thumb = ref.image_url || ref.paired_sketch_url;
                    return (
                      <div
                        key={ref.id}
                        className="flex items-center gap-3 p-2.5 rounded-md border border-zinc-200 bg-zinc-50/70"
                      >
                        <div className="w-12 h-10 rounded overflow-hidden shrink-0 border border-zinc-200 bg-white">
                          {thumb ? (
                            <img
                              src={thumb}
                              alt={ref.title}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-[10px] text-zinc-400">
                              brak
                            </div>
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-medium text-zinc-900 truncate">{ref.title}</p>
                          <p className="text-[11px] text-zinc-500 truncate">
                            {formatCategoryLabel(ref.category)} · Rola:{' '}
                            {ref.role || formatReferenceRoleLabel(ref.category)}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-zinc-200 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold text-zinc-950">
                    Analiza i koncepcja AI (Zero Kosztów)
                  </h3>
                  <p className="text-xs text-zinc-500 mt-0.5">
                    Darmowa analiza (Gemini / Groq Free Tier) przypisana do projektu w SQLite.
                    {analysisHistory.length > 0
                      ? ` Zapisanych analiz w historii: ${analysisHistory.length}.`
                      : ''}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 min-w-0">
                  <label
                    htmlFor="modal-ai-provider"
                    className="text-xs font-medium text-zinc-600 whitespace-nowrap"
                  >
                    Dostawca:
                  </label>
                  <select
                    id="modal-ai-provider"
                    value={providerChoice}
                    disabled={analyzing || updatingStatus || deleting}
                    onChange={(e) => setProviderChoice(e.target.value as ProviderPreference)}
                    className="px-2.5 py-1.5 text-xs font-medium border border-zinc-300 rounded-md bg-white text-zinc-900 min-w-0 max-w-full w-full sm:w-auto"
                  >
                    <option value="auto">Automatyczny (0 zł)</option>
                    <option value="gemini">Google Gemini (Free)</option>
                    <option value="groq">GroqCloud (Free)</option>
                  </select>
                  <button
                    type="button"
                    disabled={analyzing || updatingStatus || deleting}
                    onClick={() => void handleRunProjectAnalysis()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-md bg-[#141518] text-white hover:bg-zinc-800 disabled:opacity-50 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>
                      {analyzing
                        ? 'Analizowanie...'
                        : draftDisplay
                          ? 'Ponów analizę AI'
                          : 'Uruchom darmową analizę AI'}
                    </span>
                  </button>
                </div>
              </div>

              {analysisHistory.length > 1 && (
                <div className="flex flex-wrap items-center gap-2 p-2.5 rounded-md border border-zinc-200 bg-zinc-50/70 text-xs">
                  <History className="w-3.5 h-3.5 text-zinc-600 shrink-0" aria-hidden="true" />
                  <span className="font-medium text-zinc-700">Historia analiz projektu:</span>
                  <select
                    aria-label="Wybierz wersję analizy z historii projektu"
                    value={selectedAnalysisId ?? ''}
                    onChange={(e) => handleSelectHistoricalAnalysis(Number(e.target.value))}
                    className="px-2.5 py-1 rounded border border-zinc-300 bg-white text-xs font-mono-tabular text-zinc-900"
                  >
                    {analysisHistory.map((hist, idx) => (
                      <option key={hist.id} value={hist.id}>
                        #{hist.id} · {idx === 0 ? 'Najnowsza' : `Wersja -${idx}`} · {hist.provider}{' '}
                        ({formatPolishDate(hist.created_at)})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {!draftDisplay && !analyzing && !analysisError && (
                <div className="border border-dashed border-zinc-300 rounded-md bg-zinc-50/70 px-4 py-4 text-xs text-zinc-600 leading-relaxed">
                  Ten projekt nie ma jeszcze zapisanej analizy AI. Kliknij „Uruchom darmową analizę
                  AI”, aby wygenerować strukturę projektu, propozycję materiałów i prompt do
                  przyszłej wizualizacji w ramach budżetu 0 zł.
                </div>
              )}

              <AnalysisResultPanel
                mode={project.mode}
                analysis={draftDisplay}
                loading={analyzing}
                error={analysisError}
                savingEdits={savingEdits}
                editsSaved={editsSaved}
                isPersistedProject={true}
                onChangeField={handleDraftFieldChange}
                onRetry={() => void handleRunProjectAnalysis()}
                onSaveEdits={handleSaveAnalysisEdits}
              />

              <ImageGenerationPanel
                mode={project.mode}
                hasSavedAnalysis={Boolean(draftDisplay)}
                previewImageUrl={project.preview_image_url}
                overview={imageProvidersOverview}
                onGenerate={(preferredProvider, aspectRatio) =>
                  onGenerateProjectImage(project.id, preferredProvider, aspectRatio)
                }
              />
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <label htmlFor="modal-project-status" className="text-xs font-medium text-zinc-600">
                Status projektu:
              </label>
              <select
                id="modal-project-status"
                value={project.status}
                disabled={updatingStatus || deleting}
                onChange={(e) => void handleStatusSelect(e.target.value as ProjectStatus)}
                className="px-3 py-1.5 text-sm border border-zinc-300 rounded-md bg-white text-zinc-900 disabled:opacity-60 min-w-0 max-w-full w-full sm:w-auto focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
              >
                <option value="draft">{formatStatusLabel('draft')}</option>
                <option value="awaiting_ai_pipeline">
                  {formatStatusLabel('awaiting_ai_pipeline')}
                </option>
                <option value="archived">{formatStatusLabel('archived')}</option>
              </select>
              {updatingStatus && (
                <span className="text-xs text-zinc-500">Zapisywanie statusu...</span>
              )}
            </div>

            {confirmDelete ? (
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-red-700 font-medium">
                  Usunąć projekt? (Referencje w bibliotece zostaną zachowane)
                </span>
                <button
                  type="button"
                  disabled={deleting}
                  onClick={() => void handleConfirmDelete()}
                  className="px-3 py-1.5 text-xs font-medium rounded-md bg-red-700 text-white hover:bg-red-800 disabled:opacity-50 transition-colors"
                >
                  {deleting ? 'Usuwanie...' : 'Potwierdź usunięcie'}
                </button>
                <button
                  type="button"
                  disabled={deleting}
                  onClick={() => setConfirmDelete(false)}
                  className="px-3 py-1.5 text-xs font-medium rounded-md border border-zinc-300 text-zinc-700 hover:bg-zinc-50 transition-colors"
                >
                  Anuluj
                </button>
              </div>
            ) : (
              <button
                type="button"
                disabled={updatingStatus || deleting}
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-red-700 border border-red-200 rounded-md hover:bg-red-50 disabled:opacity-50 transition-colors"
              >
                <Trash2 className="w-4 h-4" aria-hidden="true" />
                <span>Usuń projekt</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
