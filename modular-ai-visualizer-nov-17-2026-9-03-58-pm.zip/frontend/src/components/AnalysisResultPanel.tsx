import { useEffect, useState, type ReactNode } from 'react';
import {
  AlertTriangle,
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  Save,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import type {
  AnalysisEditableFields,
  AnalysisSource,
  ProjectMode,
  StructuredAnalysisSections,
} from '../types/domain';
import {
  formatAnalysisSourceLabel,
  formatConfidenceLabel,
  formatDimensionCheckStatusLabel,
  formatDimensionSourceTypeLabel,
  formatFullAnalysisForClipboard,
  formatProviderLabel,
  formatResponseTimeMs,
  getConfidenceToneClass,
  hasGeometryLockInPrompt,
} from '../utils/formatters';
import { StatusNotice } from './StatusNotice';

export interface AnalysisDisplayData
  extends AnalysisEditableFields,
    StructuredAnalysisSections {
  provider: string;
  model: string;
  is_free_tier: boolean;
  response_time_ms?: number | null;
  schema_version?: string;
  is_legacy_format?: boolean;
  analysis_source?: AnalysisSource;
  is_mock?: boolean;
}

interface AnalysisResultPanelProps {
  mode: ProjectMode;
  analysis: AnalysisDisplayData | null;
  loading: boolean;
  error: string | null;
  savingEdits?: boolean;
  editsSaved?: boolean;
  isPersistedProject?: boolean;
  onChangeField: (field: keyof AnalysisEditableFields, value: string) => void;
  onRetry?: () => void;
  onSaveEdits?: () => Promise<void> | void;
}

type SectionKey =
  | 'summary_layout'
  | 'epistemic'
  | 'geometry'
  | 'rooms'
  | 'openings'
  | 'requirements'
  | 'uncertainties'
  | 'geometry_protection'
  | 'materials_prompt';

interface CollapsibleSectionProps {
  id: string;
  title: string;
  subtitle?: string;
  isOpen: boolean;
  onToggle: () => void;
  children: ReactNode;
}

function CollapsibleSection({
  id,
  title,
  subtitle,
  isOpen,
  onToggle,
  children,
}: CollapsibleSectionProps) {
  const contentId = `${id}-content`;
  return (
    <div className="border border-zinc-200/90 rounded-md bg-white overflow-hidden min-w-0">
      <button
        type="button"
        id={`${id}-toggle`}
        aria-expanded={isOpen}
        aria-controls={contentId}
        onClick={onToggle}
        className="w-full px-4 py-3 flex items-center justify-between gap-3 text-left bg-zinc-50/60 hover:bg-zinc-100/70 transition-colors min-w-0"
      >
        <div className="min-w-0">
          <div className="text-xs font-semibold text-zinc-900 break-words">{title}</div>
          {subtitle && (
            <div className="text-[11px] text-zinc-500 mt-0.5 break-words">{subtitle}</div>
          )}
        </div>
        {isOpen ? (
          <ChevronDown className="w-4 h-4 text-zinc-500 shrink-0" aria-hidden="true" />
        ) : (
          <ChevronRight className="w-4 h-4 text-zinc-500 shrink-0" aria-hidden="true" />
        )}
      </button>
      {isOpen && (
        <div id={contentId} className="p-4 border-t border-zinc-200/80 space-y-4 min-w-0">
          {children}
        </div>
      )}
    </div>
  );
}

const DEFAULT_DISCLAIMER =
  'Analiza i koncepcja mają charakter pomocniczy i koncepcyjny — nie stanowią zatwierdzonego projektu budowlanego, dokumentacji wykonawczej ani weryfikacji konstrukcyjnej.';

export function AnalysisResultPanel({
  mode,
  analysis,
  loading,
  error,
  savingEdits = false,
  editsSaved = false,
  isPersistedProject = false,
  onChangeField,
  onRetry,
  onSaveEdits,
}: AnalysisResultPanelProps) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [openSections, setOpenSections] = useState<Record<SectionKey, boolean>>({
    summary_layout: true,
    epistemic: true,
    geometry: true,
    rooms: false,
    openings: false,
    requirements: false,
    uncertainties: true,
    geometry_protection: true,
    materials_prompt: true,
  });

  useEffect(() => {
    if (!analysis) return;
    const hasUncertainties =
      (analysis.uncertainties?.length ?? 0) > 0 ||
      (analysis.clarification_questions?.length ?? 0) > 0;
    const hasEpistemic =
      (analysis.observed_facts?.length ?? 0) > 0 ||
      (analysis.model_interpretations?.length ?? 0) > 0 ||
      (analysis.indeterminable_elements?.length ?? 0) > 0;
    setOpenSections({
      summary_layout: true,
      epistemic: hasEpistemic,
      geometry: Boolean(analysis.geometry),
      rooms: false,
      openings: false,
      requirements: false,
      uncertainties: hasUncertainties,
      geometry_protection: true,
      materials_prompt: true,
    });
  }, [analysis?.provider, analysis?.model, analysis?.schema_version, analysis?.analysis_source]);

  const toggleSection = (key: SectionKey) => {
    setOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const setAllSections = (expanded: boolean) => {
    setOpenSections({
      summary_layout: expanded,
      epistemic: expanded,
      geometry: expanded,
      rooms: expanded,
      openings: expanded,
      requirements: expanded,
      uncertainties: expanded,
      geometry_protection: expanded,
      materials_prompt: expanded,
    });
  };

  const copyText = async (key: string, value: string) => {
    if (!value.trim()) return;
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(key);
      window.setTimeout(() => {
        setCopiedKey((current) => (current === key ? null : current));
      }, 1800);
    } catch {
      // Clipboard API unavailable in restricted headless context; ignore silently
    }
  };

  if (loading) {
    return (
      <div
        className="bg-white border border-zinc-200/90 rounded-lg p-5 sm:p-6 space-y-4 animate-pulse"
        aria-busy="true"
      >
        <div className="flex items-center gap-2 text-sm font-medium text-zinc-900">
          <Sparkles className="w-4 h-4 text-zinc-700" aria-hidden="true" />
          <span>
            {mode === 'sketch_to_render'
              ? 'Trwa analiza geometrii szkicu przez darmowy model AI...'
              : 'Trwa przygotowanie koncepcji projektu przez darmowy model AI...'}
          </span>
        </div>
        <p className="text-xs text-zinc-500">
          Sprawdzanie polityki Zero Kosztów, limitów darmowego planu i strukturyzowanie wyniku.
        </p>
        <div className="space-y-2.5 pt-2">
          <div className="h-4 w-2/3 bg-zinc-200 rounded" />
          <div className="h-20 w-full bg-zinc-100 rounded" />
          <div className="h-16 w-full bg-zinc-100 rounded" />
        </div>
      </div>
    );
  }

  if (error && !analysis) {
    return (
      <StatusNotice
        tone="error"
        title="Nie udało się wykonać analizy AI"
        description={error}
        actionLabel={onRetry ? 'Ponów analizę' : undefined}
        onAction={onRetry}
      />
    );
  }

  if (!analysis) {
    return null;
  }

  const responseTimeLabel = formatResponseTimeMs(analysis.response_time_ms);
  const isLegacy = Boolean(
    analysis.is_legacy_format ||
      analysis.schema_version === '3.2_legacy' ||
      analysis.analysis_source === 'legacy'
  );
  const isMockResult = Boolean(analysis.is_mock || analysis.analysis_source === 'mock');
  const isFallbackResult = analysis.analysis_source === 'fallback';
  const sourceLabel = formatAnalysisSourceLabel(analysis.analysis_source, analysis.is_mock);
  const rooms = analysis.rooms ?? [];
  const openings = analysis.openings ?? [];
  const openingsCompletenessCheck = analysis.openings_completeness_check ?? '';
  const orientationSource = analysis.orientation_source ?? '';
  const unjustifiedDirections = analysis.unjustified_directions_detected ?? [];
  const dimensionObservations = analysis.dimension_observations ?? [];
  const dimensionChecks = analysis.dimension_checks ?? [];
  const dimensionConflicts = analysis.dimension_conflicts ?? [];
  const hasDimensionAudit =
    dimensionObservations.length > 0 ||
    dimensionChecks.length > 0 ||
    dimensionConflicts.length > 0;
  const uncertainties = analysis.uncertainties ?? [];
  const clarificationQuestions = analysis.clarification_questions ?? [];
  const userRequirements = analysis.user_requirements ?? [];
  const aiSuggestions = analysis.ai_suggestions ?? [];
  const observedFacts = analysis.observed_facts ?? [];
  const modelInterpretations = analysis.model_interpretations ?? [];
  const indeterminableElements = analysis.indeterminable_elements ?? [];
  const hasEpistemicBreakdown =
    observedFacts.length > 0 ||
    modelInterpretations.length > 0 ||
    aiSuggestions.length > 0 ||
    indeterminableElements.length > 0;
  const geometry = analysis.geometry ?? null;
  const geometryProtection = analysis.geometry_protection ?? null;
  const promptHasGeometryLock = hasGeometryLockInPrompt(analysis.visualization_prompt);
  const disclaimerText = analysis.disclaimer || DEFAULT_DISCLAIMER;

  const renderEditableTextarea = (
    key: keyof AnalysisEditableFields,
    label: string,
    rows: number
  ) => {
    const fieldId = `ai-field-${mode}-${key}`;
    const value = analysis[key] ?? '';
    return (
      <div key={key} className="space-y-1.5 min-w-0">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <label htmlFor={fieldId} className="text-xs font-medium text-zinc-800">
            {label}
          </label>
          <button
            type="button"
            onClick={() => void copyText(key, value)}
            disabled={!value.trim()}
            className="inline-flex items-center gap-1 text-[11px] font-medium text-zinc-600 hover:text-zinc-950 disabled:opacity-40"
          >
            {copiedKey === key ? (
              <>
                <Check className="w-3 h-3 text-emerald-700" aria-hidden="true" />
                <span>Skopiowano</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" aria-hidden="true" />
                <span>Kopiuj</span>
              </>
            )}
          </button>
        </div>
        <textarea
          id={fieldId}
          rows={rows}
          value={value}
          onChange={(e) => onChangeField(key, e.target.value)}
          className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-zinc-50/40 focus:bg-white leading-relaxed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
        />
      </div>
    );
  };

  return (
    <section
      aria-label="Wynik darmowej analizy AI"
      className="bg-white border border-zinc-200/90 rounded-lg p-4 sm:p-6 space-y-4 min-w-0"
    >
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-zinc-100 pb-4">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-500 font-mono-tabular">
            <span className="font-semibold text-zinc-900">
              {formatProviderLabel(analysis.provider)}
            </span>
            <span>·</span>
            <span className="break-all">{analysis.model}</span>
            <span>·</span>
            <span>Budżet 0 zł</span>
            {responseTimeLabel && (
              <>
                <span>·</span>
                <span>Czas: {responseTimeLabel}</span>
              </>
            )}
            {sourceLabel && (
              <>
                <span>·</span>
                <span className={isMockResult ? 'font-semibold text-amber-800' : 'text-zinc-600'}>
                  {sourceLabel}
                </span>
              </>
            )}
          </div>
          <h3 className="text-base font-semibold text-zinc-950 mt-1">
            Wynik analizy architektonicznej AI (możliwość edycji i kopiowania)
          </h3>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() =>
              void copyText('all', formatFullAnalysisForClipboard(mode, analysis))
            }
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50 transition-colors"
          >
            {copiedKey === 'all' ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                <span>Skopiowano całość</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Kopiuj całą analizę</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              const allExpanded = Object.values(openSections).every(Boolean);
              setAllSections(!allExpanded);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-200 text-xs font-medium text-zinc-700 hover:bg-zinc-50 transition-colors"
          >
            <span>
              {Object.values(openSections).every(Boolean)
                ? 'Zwiń sekcje'
                : 'Rozwiń wszystkie'}
            </span>
          </button>

          {onSaveEdits && (
            <button
              type="button"
              disabled={savingEdits}
              onClick={() => void onSaveEdits()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 disabled:opacity-50 transition-colors"
            >
              <Save className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{savingEdits ? 'Zapisywanie...' : 'Zapisz edycję w SQLite'}</span>
            </button>
          )}
        </div>
      </div>

      {error && (
        <StatusNotice
          tone="error"
          title="Ostatnia próba analizy lub zapisu zakończyła się błędem"
          description={`${error} Poniżej pozostaje wyłącznie poprzednia wersja robocza — nowa analiza nie została wygenerowana ani zapisana.`}
          actionLabel={onRetry ? 'Ponów analizę' : undefined}
          onAction={onRetry}
        />
      )}

      {editsSaved && !error && (
        <StatusNotice
          tone="success"
          title="Zapisano zmiany analizy w SQLite"
          description="Zmodyfikowana treść analizy została przypisana do tego projektu."
        />
      )}

      {!error && isMockResult && (
        <StatusNotice
          tone="warning"
          title="Wynik z trybu testowego / mock — nie pochodzi z rzeczywistego modelu AI"
          description="Wyświetlona odpowiedź została dostarczona przez warstwę testową/symulację. Generator obrazów pozostaje wyłączony w polityce Zero Kosztów."
        />
      )}

      {!error && !isMockResult && isFallbackResult && (
        <StatusNotice
          tone="warning"
          title="Odpowiedź opisowa dostawcy AI (tryb fallback bez ścisłego JSON)"
          description="Model zwrócił tekst opisowy zamiast pełnej struktury JSON. Sprawdź sekcje poniżej i uzupełnij brakujące dane ręcznie przed zapisem w SQLite."
        />
      )}

      {!error && !isMockResult && !isFallbackResult && (
        <StatusNotice
          tone="info"
          title="Analiza tekstowa gotowa — obraz nie został wygenerowany"
          description={
            isPersistedProject
              ? 'Treść analizy i prompt są zapisane w SQLite przy tym projekcie. Generator obrazów fotorealistycznych pozostaje zablokowany w polityce Zero Kosztów.'
              : 'Zapisz projekt przyciskiem formularza, aby trwale przypisać ten wynik analizy do projektu w bazie SQLite. Generator obrazów pozostaje niedostępny w wariancie 0 zł.'
          }
        />
      )}

      {isLegacy && (
        <div className="px-3.5 py-2.5 rounded-md border border-zinc-200 bg-zinc-50 text-xs text-zinc-700 leading-relaxed">
          Ten rekord pochodzi z wcześniejszej wersji schematu (3.2). Pola tekstowe są w pełni
          edytowalne i zgodne; ponowne uruchomienie analizy wygeneruje pełny podział strukturalny
          (pomieszczenia, stolarka, rozróżnienie A–D oraz reguły ochrony geometrii).
        </div>
      )}

      <div className="space-y-3 min-w-0">
        {/* 1. Podsumowanie i układ przestrzenny */}
        <CollapsibleSection
          id={`sec-${mode}-summary`}
          title="1. Podsumowanie i układ przestrzenny (edytowalne)"
          subtitle={
            mode === 'sketch_to_render'
              ? 'Opis rzutu, stref funkcjonalnych i proporcji wejściowych'
              : 'Koncepcja architektoniczna i organizacja modułów'
          }
          isOpen={openSections.summary_layout}
          onToggle={() => toggleSection('summary_layout')}
        >
          {renderEditableTextarea(
            'summary',
            mode === 'sketch_to_render' ? 'Podsumowanie szkicu' : 'Podsumowanie koncepcji',
            3
          )}
          {renderEditableTextarea(
            'spatial_layout',
            mode === 'sketch_to_render'
              ? 'Układ pomieszczeń, ścian, okien, drzwi i proporcji'
              : 'Struktura projektu i układ modułów',
            4
          )}
        </CollapsibleSection>

        {/* A–D. Rozróżnienie faktów, interpretacji, sugestii AI i braków */}
        {hasEpistemicBreakdown && (
          <CollapsibleSection
            id={`sec-${mode}-epistemic`}
            title="Rozróżnienie faktów, interpretacji, sugestii i braków (A–D)"
            subtitle="Co pochodzi z materiału (A), co model interpretuje (B), co proponuje AI (C), czego nie da się ustalić (D)"
            isOpen={openSections.epistemic}
            onToggle={() => toggleSection('epistemic')}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 rounded-md border border-emerald-200/80 bg-emerald-50/40 space-y-2 min-w-0">
                <h4 className="text-xs font-semibold text-emerald-950">
                  A. Odczytane ze szkicu / briefu
                </h4>
                {observedFacts.length === 0 ? (
                  <p className="text-xs text-zinc-600">
                    Brak wyodrębnionych faktów wejściowych.
                  </p>
                ) : (
                  <ul className="space-y-1.5 text-xs text-zinc-800 list-disc pl-4">
                    {observedFacts.map((item, idx) => (
                      <li key={idx} className="leading-relaxed break-words">
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="p-3 rounded-md border border-zinc-200 bg-zinc-50/70 space-y-2 min-w-0">
                <h4 className="text-xs font-semibold text-zinc-950">
                  B. Interpretacje modelu (do weryfikacji)
                </h4>
                {modelInterpretations.length === 0 ? (
                  <p className="text-xs text-zinc-600">Brak dodatkowych hipotez modelu.</p>
                ) : (
                  <ul className="space-y-1.5 text-xs text-zinc-700 list-disc pl-4">
                    {modelInterpretations.map((item, idx) => (
                      <li key={idx} className="leading-relaxed break-words">
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="p-3 rounded-md border border-zinc-200 bg-white space-y-2 min-w-0">
                <h4 className="text-xs font-semibold text-zinc-950">
                  C. Sugestie projektowe AI
                </h4>
                {aiSuggestions.length === 0 ? (
                  <p className="text-xs text-zinc-500">Brak dodatkowych sugestii AI.</p>
                ) : (
                  <ul className="space-y-1.5 text-xs text-zinc-700 list-disc pl-4">
                    {aiSuggestions.map((item, idx) => (
                      <li key={idx} className="leading-relaxed break-words">
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="p-3 rounded-md border border-red-200/80 bg-red-50/40 space-y-2 min-w-0">
                <h4 className="text-xs font-semibold text-red-950">
                  D. Niemożliwe do ustalenia z materiału
                </h4>
                {indeterminableElements.length === 0 ? (
                  <p className="text-xs text-zinc-600">Brak wykazanych braków danych.</p>
                ) : (
                  <ul className="space-y-1.5 text-xs text-red-950/90 list-disc pl-4">
                    {indeterminableElements.map((item, idx) => (
                      <li key={idx} className="leading-relaxed break-words">
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </CollapsibleSection>
        )}

        {/* 2. Geometria i układ konstrukcyjny */}
        {geometry && (
          <CollapsibleSection
            id={`sec-${mode}-geometry`}
            title="2. Geometria i układ konstrukcyjny"
            subtitle={`Poziom pewności: ${formatConfidenceLabel(geometry.confidence)}`}
            isOpen={openSections.geometry}
            onToggle={() => toggleSection('geometry')}
          >
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-zinc-100">
              <span className="text-xs font-medium text-zinc-700">
                Ocena czytelności geometrii
              </span>
              <span
                className={`text-[11px] font-medium px-2 py-0.5 rounded border ${getConfidenceToneClass(
                  geometry.confidence
                )}`}
              >
                {formatConfidenceLabel(geometry.confidence)}
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-md bg-zinc-50 border border-zinc-200/80 space-y-1 min-w-0">
                <span className="block font-semibold text-zinc-900">Obrys bryły</span>
                <p className="text-zinc-700 leading-relaxed break-words">
                  {geometry.building_footprint || 'Niemożliwe do ustalenia na podstawie materiału'}
                </p>
              </div>
              <div className="p-3 rounded-md bg-zinc-50 border border-zinc-200/80 space-y-1 min-w-0">
                <span className="block font-semibold text-zinc-900">Kondygnacje</span>
                <p className="text-zinc-700 leading-relaxed break-words">
                  {geometry.floors_count || 'Niemożliwe do ustalenia na podstawie materiału'}
                </p>
              </div>
              <div className="p-3 rounded-md bg-zinc-50 border border-zinc-200/80 space-y-1 min-w-0">
                <span className="block font-semibold text-zinc-900">
                  Ściany nośne vs działowe
                </span>
                <p className="text-zinc-700 leading-relaxed break-words">
                  {geometry.structural_vs_partition_walls ||
                    'Niemożliwe do ustalenia na podstawie materiału'}
                </p>
              </div>
              <div className="p-3 rounded-md bg-zinc-50 border border-zinc-200/80 space-y-1 min-w-0">
                <span className="block font-semibold text-zinc-900">Komunikacja wewnętrzna</span>
                <p className="text-zinc-700 leading-relaxed break-words">
                  {geometry.circulation || 'Niemożliwe do ustalenia na podstawie materiału'}
                </p>
              </div>
              <div className="md:col-span-2 p-3 rounded-md bg-zinc-50 border border-zinc-200/80 space-y-1 min-w-0">
                <span className="block font-semibold text-zinc-900">Proporcje i skala</span>
                <p className="text-zinc-700 leading-relaxed break-words">
                  {geometry.proportions_and_scale || 'Brak wymiarów na materiale'}
                </p>
              </div>
              {orientationSource && (
                <div className="md:col-span-2 p-3 rounded-md bg-zinc-50 border border-zinc-200/80 space-y-1 min-w-0">
                  <span className="block font-semibold text-zinc-900">Źródło orientacji</span>
                  <p className="text-zinc-700 leading-relaxed break-words">{orientationSource}</p>
                </div>
              )}
            </div>

            {unjustifiedDirections.length > 0 && (
              <div className="p-3 rounded-md border border-amber-200 bg-amber-50/60 space-y-1 text-xs text-amber-950 min-w-0">
                <div className="font-semibold flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>Wykryto nieuzasadnione kierunki geograficzne (brak róży wiatrów)</span>
                </div>
                <p className="leading-relaxed break-words">
                  {unjustifiedDirections.join(', ')}
                </p>
              </div>
            )}

            {hasDimensionAudit && (
              <div className="pt-2 border-t border-zinc-100 space-y-2.5 min-w-0">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-zinc-900">
                    Kontrola spójności wymiarowej (A–D)
                  </span>
                  {analysis.dimension_confidence && (
                    <span
                      className={`text-[11px] font-medium px-2 py-0.5 rounded border ${getConfidenceToneClass(
                        analysis.dimension_confidence
                      )}`}
                    >
                      {formatConfidenceLabel(analysis.dimension_confidence)}
                    </span>
                  )}
                </div>

                {dimensionConflicts.length > 0 && (
                  <div className="p-3 rounded-md border border-red-200 bg-red-50/60 space-y-1 text-xs text-red-950 min-w-0">
                    <div className="font-semibold">Wykryte sprzeczności wymiarowe</div>
                    <ul className="list-disc pl-4 space-y-1">
                      {dimensionConflicts.map((conflict, idx) => (
                        <li key={idx} className="leading-relaxed break-words">
                          {conflict}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {dimensionChecks.length > 0 && (
                  <div className="space-y-2">
                    {dimensionChecks.map((chk, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-md border border-zinc-200 bg-zinc-50/70 text-xs space-y-1 min-w-0"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-medium text-zinc-900 break-words">
                            {chk.description}
                          </span>
                          <span
                            className={`text-[11px] font-medium px-2 py-0.5 rounded border ${
                              chk.status === 'conflict'
                                ? 'text-red-800 border-red-200 bg-red-50/70'
                                : chk.status === 'consistent'
                                ? 'text-emerald-800 border-emerald-200 bg-emerald-50/70'
                                : 'text-zinc-700 border-zinc-200 bg-zinc-50'
                            }`}
                          >
                            {formatDimensionCheckStatusLabel(chk.status)}
                          </span>
                        </div>
                        {(chk.overall_dimension || chk.segment_sum || chk.difference) && (
                          <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-zinc-600 font-mono-tabular">
                            {chk.overall_dimension && (
                              <span>Całkowity: {chk.overall_dimension}</span>
                            )}
                            {chk.segment_sum && <span>Suma odcinków: {chk.segment_sum}</span>}
                            {chk.difference && <span>Różnica: {chk.difference}</span>}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {dimensionObservations.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {dimensionObservations.map((obs, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-md border border-zinc-200/80 bg-white text-xs space-y-1 min-w-0"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-1.5">
                          <span className="font-semibold text-zinc-900 break-words">
                            {obs.label}: <span className="font-mono-tabular">{obs.value}</span>
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-2 text-[11px] text-zinc-600">
                          <span>{formatDimensionSourceTypeLabel(obs.source_type)}</span>
                          <span>·</span>
                          <span>{formatConfidenceLabel(obs.confidence)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </CollapsibleSection>
        )}

        {/* 3. Lista pomieszczeń */}
        {rooms.length > 0 && (
          <CollapsibleSection
            id={`sec-${mode}-rooms`}
            title={`3. Lista pomieszczeń (${rooms.length})`}
            subtitle="Nazwa, strefa funkcjonalna, metraż orientacyjny i poziom pewności"
            isOpen={openSections.rooms}
            onToggle={() => toggleSection('rooms')}
          >
            <div className="space-y-2.5">
              {rooms.map((room, index) => (
                <div
                  key={`${room.name}-${index}`}
                  className="p-3 rounded-md border border-zinc-200/90 bg-zinc-50/60 space-y-1.5 min-w-0"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-zinc-950 break-words">
                      {room.name}
                    </span>
                    <span
                      className={`text-[11px] font-medium px-2 py-0.5 rounded border ${getConfidenceToneClass(
                        room.confidence
                      )}`}
                    >
                      {formatConfidenceLabel(room.confidence)}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-zinc-600 font-mono-tabular">
                    <span>Strefa: {room.zone || 'nieustalone'}</span>
                    <span>Metraż: {room.approximate_area || 'brak wymiarów na materiale'}</span>
                  </div>
                  {room.spatial_relations && (
                    <p className="text-xs text-zinc-700 leading-relaxed break-words">
                      {room.spatial_relations}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </CollapsibleSection>
        )}

        {/* 4. Stolarka i otwory */}
        {openings.length > 0 && (
          <CollapsibleSection
            id={`sec-${mode}-openings`}
            title={`4. Stolarka i otwory (${openings.length})`}
            subtitle="Drzwi wejściowe, wewnętrzne, przesuwne, tarasowe, przeszklenia HS i okna"
            isOpen={openSections.openings}
            onToggle={() => toggleSection('openings')}
          >
            {openingsCompletenessCheck && (
              <div className="p-3 rounded-md border border-zinc-200 bg-zinc-50 text-xs text-zinc-700 leading-relaxed break-words">
                <span className="font-semibold text-zinc-900">Kontrola kompletności otworów: </span>
                {openingsCompletenessCheck}
              </div>
            )}
            <div className="space-y-2.5">
              {openings.map((item, index) => (
                <div
                  key={`${item.opening_id || item.category}-${index}`}
                  className="p-3 rounded-md border border-zinc-200/90 bg-zinc-50/60 space-y-1.5 min-w-0"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-zinc-950 break-words">
                      {item.opening_id ? `[${item.opening_id}] ` : ''}
                      {item.category}
                    </span>
                    <span
                      className={`text-[11px] font-medium px-2 py-0.5 rounded border ${getConfidenceToneClass(
                        item.confidence
                      )}`}
                    >
                      {formatConfidenceLabel(item.confidence)}
                    </span>
                  </div>
                  <div className="text-xs text-zinc-700 space-y-0.5 break-words">
                    <div>
                      <span className="font-medium text-zinc-900">Lokalizacja: </span>
                      {item.location || 'nieustalona'}
                    </div>
                    <div>
                      <span className="font-medium text-zinc-900">Kierunek otwierania: </span>
                      {item.opening_direction || 'niemożliwe do ustalenia na podstawie materiału'}
                    </div>
                    {typeof item.has_swing_arc === 'boolean' && (
                      <div>
                        <span className="font-medium text-zinc-900">Łuk otwierania na szkicu: </span>
                        {item.has_swing_arc ? 'widoczny' : 'brak widocznego łuku (kierunek niepewny)'}
                      </div>
                    )}
                    {item.opening_completeness_note && (
                      <div className="text-amber-900">{item.opening_completeness_note}</div>
                    )}
                    {item.notes && <div className="text-zinc-600">{item.notes}</div>}
                  </div>
                </div>
              ))}
            </div>
          </CollapsibleSection>
        )}

        {/* 5. Wymagania użytkownika vs Sugestie AI */}
        {(userRequirements.length > 0 || aiSuggestions.length > 0) && (
          <CollapsibleSection
            id={`sec-${mode}-requirements`}
            title="5. Wymagania użytkownika vs Sugestie AI"
            subtitle={`Wymagania z briefu: ${userRequirements.length} · Propozycje AI: ${aiSuggestions.length}`}
            isOpen={openSections.requirements}
            onToggle={() => toggleSection('requirements')}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 rounded-md border border-zinc-200 bg-zinc-50/70 space-y-2 min-w-0">
                <h4 className="text-xs font-semibold text-zinc-950">
                  Wymagania użytkownika (ze szkicu / briefu)
                </h4>
                {userRequirements.length === 0 ? (
                  <p className="text-xs text-zinc-500">Brak wyodrębnionych wymagań.</p>
                ) : (
                  <ul className="space-y-1.5 text-xs text-zinc-800 list-disc pl-4">
                    {userRequirements.map((req, idx) => (
                      <li key={idx} className="leading-relaxed break-words">
                        {req}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="p-3 rounded-md border border-zinc-200 bg-white space-y-2 min-w-0">
                <h4 className="text-xs font-semibold text-zinc-950">
                  Sugestie architektoniczne AI
                </h4>
                {aiSuggestions.length === 0 ? (
                  <p className="text-xs text-zinc-500">Brak dodatkowych sugestii AI.</p>
                ) : (
                  <ul className="space-y-1.5 text-xs text-zinc-700 list-disc pl-4">
                    {aiSuggestions.map((sug, idx) => (
                      <li key={idx} className="leading-relaxed break-words">
                        {sug}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </CollapsibleSection>
        )}

        {/* 6. Niepewności i pytania wymagające wyjaśnienia */}
        {(uncertainties.length > 0 || clarificationQuestions.length > 0) && (
          <CollapsibleSection
            id={`sec-${mode}-uncertainties`}
            title={`6. Niepewności i pytania (${uncertainties.length + clarificationQuestions.length})`}
            subtitle="Elementy niejednoznaczne, brakujące wymiary oraz pytania do inwestora"
            isOpen={openSections.uncertainties}
            onToggle={() => toggleSection('uncertainties')}
          >
            {uncertainties.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-900">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>Wykryte niepewności i braki w materiale wejściowym</span>
                </div>
                <div className="space-y-2">
                  {uncertainties.map((item, idx) => (
                    <div
                      key={`${item.element}-${idx}`}
                      className="p-3 rounded-md border border-amber-200/80 bg-amber-50/40 space-y-1 min-w-0"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-zinc-950 break-words">
                          {item.element}
                        </span>
                        <span
                          className={`text-[11px] font-medium px-2 py-0.5 rounded border ${getConfidenceToneClass(
                            item.confidence
                          )}`}
                        >
                          {formatConfidenceLabel(item.confidence)}
                        </span>
                      </div>
                      {item.reason && (
                        <p className="text-xs text-zinc-700 leading-relaxed break-words">
                          {item.reason}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {clarificationQuestions.length > 0 && (
              <div className="space-y-2 p-3 rounded-md border border-zinc-200 bg-zinc-50/60">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-xs font-semibold text-zinc-950">
                    Pytania wymagające doprecyzowania
                  </h4>
                  <span className="text-[11px] font-medium text-amber-900">
                    Wymaga potwierdzenia inwestora
                  </span>
                </div>
                <ul className="space-y-1.5 text-xs text-zinc-700 list-disc pl-4">
                  {clarificationQuestions.map((question, idx) => (
                    <li key={idx} className="leading-relaxed break-words">
                      {question}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CollapsibleSection>
        )}

        {/* 7. Ochrona geometrii (3 części + pole edytowalne) */}
        <CollapsibleSection
          id={`sec-${mode}-protection`}
          title="7. Ochrona geometrii i wytyczne dla wizualizacji"
          subtitle="Co zachować, co można modyfikować oraz zmiany zabronione"
          isOpen={openSections.geometry_protection}
          onToggle={() => toggleSection('geometry_protection')}
        >
          {geometryProtection && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3 rounded-md border border-emerald-200/80 bg-emerald-50/40 space-y-1.5 min-w-0">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-950">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>Do bezwzględnego zachowania</span>
                </div>
                <ul className="text-xs text-zinc-800 space-y-1 list-disc pl-4">
                  {(geometryProtection.must_preserve ?? []).map((item, idx) => (
                    <li key={idx} className="break-words">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 rounded-md border border-zinc-200 bg-zinc-50/70 space-y-1.5 min-w-0">
                <h4 className="text-xs font-semibold text-zinc-900">
                  Co można zmienić (styl / wykończenie)
                </h4>
                <ul className="text-xs text-zinc-700 space-y-1 list-disc pl-4">
                  {(geometryProtection.can_change ?? []).map((item, idx) => (
                    <li key={idx} className="break-words">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 rounded-md border border-red-200/80 bg-red-50/40 space-y-1.5 min-w-0">
                <h4 className="text-xs font-semibold text-red-950">Zmiany zabronione</h4>
                <ul className="text-xs text-red-950/90 space-y-1 list-disc pl-4">
                  {(geometryProtection.forbidden_changes ?? []).map((item, idx) => (
                    <li key={idx} className="break-words">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {renderEditableTextarea(
            'geometry_preservation_note',
            mode === 'sketch_to_render'
              ? 'Wytyczne ochrony oryginalnej geometrii szkicu (edytowalne)'
              : 'Założenia wymiarowe i bryłowe do szkicu (edytowalne)',
            2
          )}
        </CollapsibleSection>

        {/* 8. Materiały, oświetlenie i prompt wizualizacyjny */}
        <CollapsibleSection
          id={`sec-${mode}-materials`}
          title="8. Materiały, oświetlenie i prompt do wizualizacji (edytowalne)"
          subtitle="Spójny zestaw wykończeń, światła i prompt końcowy"
          isOpen={openSections.materials_prompt}
          onToggle={() => toggleSection('materials_prompt')}
        >
          {renderEditableTextarea(
            'materials_proposal',
            'Propozycja materiałów i kolorystyki',
            3
          )}
          {renderEditableTextarea('lighting_proposal', 'Propozycja oświetlenia', 2)}
          {mode === 'sketch_to_render' && analysis.visualization_prompt.trim() && (
            <div
              className={`px-3 py-2 rounded-md border text-xs flex items-center gap-2 ${
                promptHasGeometryLock
                  ? 'border-emerald-200 bg-emerald-50/50 text-emerald-950'
                  : 'border-amber-200 bg-amber-50/60 text-amber-950'
              }`}
            >
              {promptHasGeometryLock ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>
                    Geometry Lock aktywny w prompcie (ochrona obrysu, ścian, okien, drzwi i pomieszczeń).
                  </span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>
                    Prompt nie zawiera pełnej sekcji GEOMETRY LOCK (zapis historyczny lub brak twardego zakazu zmian).
                  </span>
                </>
              )}
            </div>
          )}
          {renderEditableTextarea(
            'visualization_prompt',
            'Prompt do przyszłej wizualizacji',
            4
          )}
        </CollapsibleSection>
      </div>

      <p className="text-[11px] text-zinc-500 border-t border-zinc-100 pt-3 leading-relaxed break-words">
        {disclaimerText}
      </p>
    </section>
  );
}
