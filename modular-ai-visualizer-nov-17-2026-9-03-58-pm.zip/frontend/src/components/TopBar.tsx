import { Menu, Plus } from 'lucide-react';
import type { NavSection } from '../types/domain';

interface TopBarProps {
  activeSection: NavSection;
  onOpenMobileMenu: () => void;
  onStartNewProject: () => void;
}

const SECTION_TITLES: Record<NavSection, string> = {
  dashboard: 'Dashboard',
  new_project: 'Nowy projekt',
  sketch_mode: 'Szkic → Wizualizacja',
  idea_mode: 'Pomysł → Projekt',
  references: 'Biblioteka referencji',
  history: 'Historia projektów',
  settings: 'Ustawienia',
};

export function TopBar({ activeSection, onOpenMobileMenu, onStartNewProject }: TopBarProps) {
  return (
    <header className="h-16 bg-white/95 backdrop-blur-xs border-b border-zinc-200/90 px-4 sm:px-8 flex items-center justify-between gap-4 sticky top-0 z-30">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          aria-label="Otwórz menu boczne"
          className="lg:hidden p-2 -ml-2 text-zinc-700 hover:text-zinc-950 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-sm min-w-0">
          <span className="text-zinc-500 whitespace-nowrap hidden sm:inline">
            Modular AI Visualizer
          </span>
          <span className="text-zinc-300 hidden sm:inline" aria-hidden="true">
            /
          </span>
          <span className="text-[15px] font-semibold text-zinc-950 truncate">
            {SECTION_TITLES[activeSection]}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3 shrink-0">
        {activeSection !== 'new_project' && (
          <button
            type="button"
            onClick={onStartNewProject}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900 focus-visible:ring-offset-2"
          >
            <Plus className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Utwórz nowy projekt</span>
          </button>
        )}
      </div>
    </header>
  );
}
