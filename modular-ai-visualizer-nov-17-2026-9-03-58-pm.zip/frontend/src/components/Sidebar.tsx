import {
  BookOpen,
  Clock,
  FolderPlus,
  LayoutDashboard,
  PenTool,
  Settings,
  Sparkles,
  X,
} from 'lucide-react';
import type { NavSection } from '../types/domain';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'new_project', label: 'Nowy projekt', icon: FolderPlus },
  { id: 'sketch_mode', label: 'Szkic → Wizualizacja', icon: PenTool },
  { id: 'idea_mode', label: 'Pomysł → Projekt', icon: Sparkles },
  { id: 'references', label: 'Biblioteka referencji', icon: BookOpen },
  { id: 'history', label: 'Historia projektów', icon: Clock },
  { id: 'settings', label: 'Ustawienia', icon: Settings },
];

function ArchitecturalLogoMark() {
  return (
    <svg
      width="26"
      height="26"
      viewBox="0 0 28 28"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className="shrink-0"
    >
      <rect x="3" y="8" width="14" height="16" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
      <path d="M10 8V4.5H25V20H17" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="7" y1="13" x2="13" y2="13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="7" y1="17" x2="13" y2="17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export function Sidebar({
  activeSection,
  onSelectSection,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const renderNavContent = () => (
    <div className="flex flex-col h-full bg-[#141518] text-zinc-100 select-none">
      <div className="px-5 py-4 flex items-center justify-between border-b border-zinc-800/80 shrink-0">
        <button
          type="button"
          onClick={() => {
            onSelectSection('dashboard');
            onCloseMobile();
          }}
          className="flex items-center gap-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-400 rounded-md py-1"
        >
          <span className="w-9 h-9 rounded-md bg-zinc-900 border border-zinc-700/80 flex items-center justify-center text-white">
            <ArchitecturalLogoMark />
          </span>
          <span className="min-w-0">
            <span className="block text-sm font-semibold tracking-tight text-white whitespace-nowrap">
              Modular AI Visualizer
            </span>
            <span className="block text-[11px] text-zinc-400 whitespace-nowrap">
              Studio projektowe
            </span>
          </span>
        </button>

        <button
          type="button"
          onClick={onCloseMobile}
          aria-label="Zamknij menu nawigacji"
          className="lg:hidden p-2 text-zinc-400 hover:text-white rounded-md"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav aria-label="Główna nawigacja" className="flex-1 px-3 py-6 space-y-1.5 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onSelectSection(item.id);
                onCloseMobile();
              }}
              aria-current={isActive ? 'page' : undefined}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 min-h-[42px] rounded-md text-sm font-medium transition-colors duration-150 whitespace-nowrap text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-400 ${
                isActive
                  ? 'bg-white text-zinc-950 shadow-xs'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/70'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 ${isActive ? 'text-zinc-950' : 'text-zinc-400'}`}
                aria-hidden="true"
              />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="px-5 py-4 border-t border-zinc-800/80 text-xs text-zinc-400">
        <p className="text-zinc-200 font-medium">Etap 2.5 · Zero Kosztów</p>
        <p className="mt-0.5 text-zinc-500">Baza SQLite · Twardy budżet 0 zł</p>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block w-[264px] shrink-0 border-r border-zinc-800 bg-[#141518]">
        <div className="sticky top-0 h-screen">{renderNavContent()}</div>
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/50 transition-opacity"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative w-[280px] max-w-[85vw] h-full shadow-2xl">
            {renderNavContent()}
          </div>
        </div>
      )}
    </>
  );
}
