import { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Image as ImageIcon,
  Lock,
  RefreshCw,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import type {
  ImageGenerationResponse,
  ImageProvidersOverviewRead,
  ProjectMode,
  RenderLifecycleState,
} from '../types/domain';
import {
  canTriggerFreeImageGeneration,
  formatImageEngineStatusLabel,
  formatPolishDate,
  formatRenderLifecycleLabel,
  formatResponseTimeMs,
} from '../utils/formatters';
import { ImageFrame } from './ImageFrame';
import { StatusNotice } from './StatusNotice';

interface ImageGenerationPanelProps {
  mode: ProjectMode;
  hasSavedAnalysis: boolean;
  previewImageUrl: string | null;
  overview: ImageProvidersOverviewRead | null;
  onGenerate?: (preferredProvider: string, aspectRatio: string) => Promise<ImageGenerationResponse>;
  compact?: boolean;
}

export function ImageGenerationPanel({
  mode,
  hasSavedAnalysis,
  previewImageUrl,
  overview,
  onGenerate,
  compact = false,
}: ImageGenerationPanelProps) {
  const [selectedEngine, setSelectedEngine] = useState<string>('auto');
  const [aspectRatio, setAspectRatio] = useState<string>('16:9');
  const [lifecycleState, setLifecycleState] = useState<RenderLifecycleState>(
    previewImageUrl ? 'completed' : 'not_requested'
  );
  const [lastResult, setLastResult] = useState<ImageGenerationResponse | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showEnginesTable, setShowEnginesTable] = useState<boolean>(!compact);

  const canGenerateFree = canTriggerFreeImageGeneration(overview);
  const freeProviders = (overview?.providers ?? []).filter(
    (p) =>
      p.available &&
      p.is_truly_free &&
      p.is_verified &&
      !p.is_paid_endpoint &&
      !p.blocked_by_cost_policy
  );

  const effectiveImageUrl = lastResult?.generated_image_url ?? previewImageUrl;
  const effectiveRenderState: RenderLifecycleState =
    lifecycleState === 'queued' || lifecycleState === 'generating' || lifecycleState === 'error'
      ? lifecycleState
      : effectiveImageUrl
        ? 'completed'
        : lastResult?.render_status ?? (canGenerateFree ? 'not_requested' : 'unavailable_free');

  const handleTriggerGenerate = async () => {
    if (!onGenerate || !canGenerateFree) return;
    setErrorMessage(null);
    setLifecycleState('queued');
    try {
      // Transition cleanly from queued to generating
      await new Promise((resolve) => setTimeout(resolve, 60));
      setLifecycleState('generating');
      const response = await onGenerate(selectedEngine, aspectRatio);
      setLastResult(response);
      setLifecycleState(response.render_status);
    } catch (err) {
      setLifecycleState('error');
      setErrorMessage(
        err instanceof Error ? err.message : 'Nie udało się wygenerować obrazu w darmowym silniku.'
      );
    }
  };

  return (
    <section
      aria-label="Warstwa generowania obrazów Multi-Engine (Zero Kosztów)"
      className="bg-white border border-zinc-200/90 rounded-lg p-5 sm:p-6 space-y-5"
    >
      {/* Nagłówek i wyraźne rozdzielenie statusu analizy AI od statusu renderowania obrazu */}
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-zinc-100 pb-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-zinc-900 shrink-0" aria-hidden="true" />
            <h3 className="text-sm sm:text-base font-semibold text-zinc-950">
              Generowanie wizualizacji (Multi-Engine · Strict Zero Cost)
            </h3>
          </div>
          <p className="text-xs text-zinc-600 mt-1 leading-relaxed">
            {mode === 'sketch_to_render'
              ? 'Tryb A: Wykorzystuje szkic wejściowy, zapisaną analizę architektoniczną oraz pełny Geometry Lock (image-to-image, jeśli silnik obsługuje).'
              : 'Tryb B: Wykorzystuje opis koncepcji i analizę AI do wygenerowania obrazu oznaczonego jako wizualizacja koncepcyjna.'}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowEnginesTable((prev) => !prev)}
          aria-expanded={showEnginesTable}
          className="px-3 py-1.5 rounded-md border border-zinc-300 bg-zinc-50 text-xs font-medium text-zinc-800 hover:bg-zinc-100 transition-colors shrink-0"
        >
          {showEnginesTable
            ? 'Ukryj matrycę silników'
            : `Pokaż silniki obrazów (${overview?.providers.length ?? 0})`}
        </button>
      </div>

      {/* Wyraźna separacja: Status analizy AI vs Status generowania obrazu */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-3.5 rounded-md border border-zinc-200 bg-zinc-50/70 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <span className="block text-[11px] font-medium text-zinc-500">
              Etap 1 · Status analizy architektonicznej AI
            </span>
            <p className="text-xs font-semibold text-zinc-950 mt-0.5">
              {hasSavedAnalysis
                ? 'Zakończona (analiza i prompt zapisane)'
                : 'Oczekuje na uruchomienie analizy'}
            </p>
            <p className="text-[11px] text-zinc-600 mt-0.5">
              Sukces analizy tekstowej/wizyjnej nie oznacza wygenerowania obrazu.
            </p>
          </div>
          <span
            className={`px-2 py-0.5 rounded text-[11px] font-mono-tabular border shrink-0 ${
              hasSavedAnalysis
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                : 'border-zinc-200 bg-white text-zinc-600'
            }`}
          >
            {hasSavedAnalysis ? 'ANALIZA: OK' : 'ANALIZA: BRAK'}
          </span>
        </div>

        <div className="p-3.5 rounded-md border border-zinc-200 bg-zinc-50/70 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <span className="block text-[11px] font-medium text-zinc-500">
              Etap 2 · Status generowania obrazu (Render)
            </span>
            <p className="text-xs font-semibold text-zinc-950 mt-0.5">
              {formatRenderLifecycleLabel(effectiveRenderState)}
            </p>
            <p className="text-[11px] text-zinc-600 mt-0.5">
              {canGenerateFree
                ? `Aktywny darmowy silnik: ${overview?.active_free_engine_name}`
                : 'Brak aktywnego darmowego silnika generowania obrazów (0 zł).'}
            </p>
          </div>
          <span
            className={`px-2 py-0.5 rounded text-[11px] font-mono-tabular border shrink-0 ${
              effectiveRenderState === 'completed'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                : effectiveRenderState === 'error'
                  ? 'border-red-200 bg-red-50 text-red-900'
                  : effectiveRenderState === 'queued' || effectiveRenderState === 'generating'
                    ? 'border-amber-200 bg-amber-50 text-amber-900'
                    : 'border-zinc-300 bg-white text-zinc-700'
            }`}
          >
            {effectiveRenderState === 'completed'
              ? 'RENDER: GOTOWY'
              : effectiveRenderState === 'queued'
                ? 'W KOLEJCE'
                : effectiveRenderState === 'generating'
                  ? 'GENEROWANIE'
                  : effectiveRenderState === 'error'
                    ? 'BŁĄD'
                    : 'NIEDOSTĘPNY (0 ZŁ)'}
          </span>
        </div>
      </div>

      {/* Czytelny komunikat, gdy żaden darmowy silnik nie jest dostępny */}
      {!canGenerateFree && (
        <div className="p-3.5 rounded-md border border-amber-300/90 bg-amber-50/70 flex items-start gap-3 text-xs text-amber-950">
          <AlertTriangle className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" aria-hidden="true" />
          <div className="space-y-1 min-w-0">
            <p className="font-semibold">
              Brak aktywnego darmowego silnika generowania obrazów — przycisk generowania pozostaje
              nieaktywny
            </p>
            <p className="text-amber-900 leading-relaxed">
              {overview?.summary_message ??
                'Lokalne silniki Open-Source (Stable Diffusion WebUI :7860, ComfyUI :8188) są wyłączone (brak GPU/VRAM w środowisku), a chmurowe API obrazów są zablokowane przez CostGuard w ramach polityki Zero Kosztów (0 zł). Aplikacja nie symuluje renderów ani nie zwraca zaślepek.'}
            </p>
          </div>
        </div>
      )}

      {errorMessage && (
        <StatusNotice tone="error" title="Błąd generowania obrazu" description={errorMessage} />
      )}

      {lastResult && lastResult.render_status === 'completed' && (
        <div className="p-3.5 rounded-md border border-emerald-200 bg-emerald-50/70 flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-950">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-800 shrink-0" aria-hidden="true" />
            <span>
              {lastResult.message}
              {lastResult.response_time_ms
                ? ` (${formatResponseTimeMs(lastResult.response_time_ms)})`
                : ''}
            </span>
          </div>
          {lastResult.is_conceptual && (
            <span className="px-2 py-0.5 rounded border border-amber-300 bg-amber-50 text-amber-950 font-medium">
              {lastResult.conceptual_label ?? 'Obraz koncepcyjny (Tryb B)'}
            </span>
          )}
        </div>
      )}

      {/* Pasek sterowania generowaniem — przycisk aktywny WYŁĄCZNIE gdy darmowy silnik jest dostępny */}
      {onGenerate && (
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2 min-w-0">
            <label
              htmlFor={`img-engine-select-${mode}`}
              className="text-xs font-medium text-zinc-700 whitespace-nowrap"
            >
              Silnik obrazu:
            </label>
            <select
              id={`img-engine-select-${mode}`}
              value={selectedEngine}
              onChange={(e) => setSelectedEngine(e.target.value)}
              disabled={
                !canGenerateFree ||
                lifecycleState === 'queued' ||
                lifecycleState === 'generating'
              }
              className="px-3 py-1.5 text-xs font-medium bg-white border border-zinc-300 rounded-md text-zinc-900 disabled:opacity-60 min-w-0 max-w-full"
            >
              <option value="auto">
                {canGenerateFree
                  ? `Automatyczny darmowy (${overview?.active_free_engine_name})`
                  : 'Automatyczny (brak aktywnego darmowego silnika)'}
              </option>
              {freeProviders.map((prov) => (
                <option key={prov.key} value={prov.key}>
                  {prov.name} ({prov.model})
                </option>
              ))}
            </select>

            <label
              htmlFor={`img-aspect-select-${mode}`}
              className="text-xs font-medium text-zinc-700 whitespace-nowrap ml-1"
            >
              Proporcje:
            </label>
            <select
              id={`img-aspect-select-${mode}`}
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value)}
              disabled={
                !canGenerateFree ||
                lifecycleState === 'queued' ||
                lifecycleState === 'generating'
              }
              className="px-2.5 py-1.5 text-xs font-mono-tabular bg-white border border-zinc-300 rounded-md text-zinc-900 disabled:opacity-60"
            >
              <option value="16:9">16:9 (1024×768)</option>
              <option value="4:3">4:3 (1024×768)</option>
              <option value="3:2">3:2 (1152×768)</option>
              <option value="1:1">1:1 (1024×1024)</option>
            </select>
          </div>

          <button
            type="button"
            disabled={
              !canGenerateFree ||
              lifecycleState === 'queued' ||
              lifecycleState === 'generating'
            }
            onClick={() => void handleTriggerGenerate()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 disabled:opacity-45 disabled:cursor-not-allowed transition-colors"
          >
            {lifecycleState === 'queued' || lifecycleState === 'generating' ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
            )}
            <span>
              {lifecycleState === 'queued'
                ? 'W kolejce...'
                : lifecycleState === 'generating'
                  ? 'Generowanie obrazu...'
                  : canGenerateFree
                    ? 'Generuj wizualizację (0 zł)'
                    : 'Generowanie niedostępne (brak darmowego silnika)'}
            </span>
          </button>
        </div>
      )}

      {/* Podgląd rzeczywiście wygenerowanego obrazu (jeśli istnieje) */}
      {effectiveImageUrl && (
        <div className="space-y-2 pt-2 border-t border-zinc-100">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="font-semibold text-zinc-900">
              Wygenerowany i zapisany obraz projektu
            </span>
            {mode === 'idea_to_project' ? (
              <span className="px-2 py-0.5 rounded border border-amber-300 bg-amber-50 text-amber-950 font-medium">
                Wizualizacja koncepcyjna (Tryb B)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded border border-emerald-200 bg-emerald-50 text-emerald-900 font-medium">
                <Lock className="w-3 h-3" aria-hidden="true" />
                <span>Zachowana geometria szkicu (Tryb A)</span>
              </span>
            )}
          </div>
          <ImageFrame
            src={effectiveImageUrl}
            alt="Wygenerowana wizualizacja architektoniczna"
            aspectClass="aspect-[4/3]"
            fit="contain"
          />
        </div>
      )}

      {/* Matryca dostępnych, niedostępnych i zablokowanych silników obrazów */}
      {showEnginesTable && (
        <div className="space-y-3 pt-3 border-t border-zinc-200">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-900">
              <Cpu className="w-3.5 h-3.5 text-zinc-700" aria-hidden="true" />
              <span>Audyt silników generowania obrazów (ImageProviderRouter & CostGuard)</span>
            </div>
            <span className="text-[11px] text-zinc-500 font-mono-tabular">
              Tylko zweryfikowane silniki 0 zł mogą zostać wybrane
            </span>
          </div>

          <div className="divide-y divide-zinc-200 border border-zinc-200 rounded-md bg-zinc-50/40">
            {(overview?.providers ?? []).map((prov) => (
              <div key={prov.key} className="p-3.5 space-y-2 text-xs">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-zinc-950">{prov.name}</span>
                      <span className="font-mono-tabular text-[11px] px-1.5 py-0.5 rounded bg-zinc-100 border border-zinc-200 text-zinc-700">
                        {prov.model}
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-600 mt-0.5">{prov.role}</p>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded text-[11px] font-medium border shrink-0 ${
                      prov.available
                        ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                        : prov.blocked_by_cost_policy
                          ? 'border-red-200 bg-red-50 text-red-900'
                          : 'border-zinc-300 bg-white text-zinc-700'
                    }`}
                  >
                    {formatImageEngineStatusLabel(prov.availability_status)}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 pt-1.5 border-t border-zinc-200/70 text-[11px]">
                  <div>
                    <span className="text-zinc-500 block">Status kosztowy / weryfikacja</span>
                    <span className="font-medium text-zinc-900">
                      {prov.is_truly_free
                        ? '100% darmowy (zweryfikowany)'
                        : prov.verification_status === 'unverified'
                          ? 'Niezweryfikowany (zablokowany)'
                          : prov.verification_status === 'verified_micro_credits'
                            ? 'Mikro-kredyt (zablokowany)'
                            : 'Płatny (zablokowany)'}
                    </span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block">Image-to-Image / Geometry Lock</span>
                    <span className="font-medium text-zinc-900 font-mono-tabular">
                      img2img: {prov.supports_image_to_image ? 'TAK' : 'NIE'} · Geometria:{' '}
                      {prov.supports_geometry_preservation ? 'TAK' : 'NIE'}
                    </span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block">Obsługiwane rozdzielczości</span>
                    <span className="font-medium text-zinc-900 font-mono-tabular">
                      {(prov.supported_resolutions ?? []).join(', ') || '—'}
                    </span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block">Limity / Wymagania sprzętowe</span>
                    <span className="font-medium text-zinc-900">
                      {prov.hardware_requirements || prov.known_limits}
                    </span>
                  </div>
                </div>

                {prov.unavailability_reason && (
                  <div className="flex items-start gap-1.5 text-[11px] text-zinc-700 bg-white border border-zinc-200/80 rounded px-2.5 py-1.5">
                    <ShieldAlert
                      className="w-3.5 h-3.5 text-zinc-500 shrink-0 mt-0.5"
                      aria-hidden="true"
                    />
                    <span>
                      <strong>Powód niedostępności / blokady:</strong> {prov.unavailability_reason}
                      {prov.cooldown_until
                        ? ` (Cooldown do: ${formatPolishDate(prov.cooldown_until)})`
                        : ''}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
