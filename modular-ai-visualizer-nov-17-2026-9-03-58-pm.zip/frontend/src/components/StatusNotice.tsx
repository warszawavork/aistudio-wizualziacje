import { AlertCircle, AlertTriangle, CheckCircle2, Info } from 'lucide-react';

interface StatusNoticeProps {
  tone: 'info' | 'success' | 'warning' | 'error';
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function StatusNotice({
  tone,
  title,
  description,
  actionLabel,
  onAction,
}: StatusNoticeProps) {
  const styles =
    tone === 'error'
      ? 'bg-red-50/70 border-red-200 text-red-950'
      : tone === 'warning'
      ? 'bg-amber-50/80 border-amber-200 text-amber-950'
      : tone === 'success'
      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
      : 'bg-zinc-50 border-zinc-200 text-zinc-900';

  const Icon =
    tone === 'error'
      ? AlertCircle
      : tone === 'warning'
      ? AlertTriangle
      : tone === 'success'
      ? CheckCircle2
      : Info;

  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={`border rounded-md px-4 py-3 flex flex-wrap items-center justify-between gap-3 ${styles}`}
    >
      <div className="flex items-start gap-3 min-w-0 flex-1">
        <Icon className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
        <div className="min-w-0">
          <p className="text-sm font-medium">{title}</p>
          <p className="text-xs opacity-85 mt-0.5 leading-relaxed">{description}</p>
        </div>
      </div>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="px-3 py-1.5 rounded-md border border-current/25 bg-white/80 text-xs font-medium hover:bg-white transition-colors shrink-0"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
