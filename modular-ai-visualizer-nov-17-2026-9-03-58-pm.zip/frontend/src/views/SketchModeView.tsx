import { useState, type ChangeEvent, type DragEvent, type FormEvent } from 'react';
import { Compass, Lock, Sparkles, SunMedium, Upload } from 'lucide-react';
import { motion } from 'motion/react';
import { apiClient } from '../api/client';
import type {
  AnalysisEditableFields,
  AnalysisPreviewResponse,
  ImageProvidersOverviewRead,
  NavSection,
  ProjectCreatePayload,
  ProviderPreference,
  ReferenceItem,
} from '../types/domain';
import { validateProjectDraft } from '../utils/formatters';
import { AnalysisResultPanel } from '../components/AnalysisResultPanel';
import { ImageFrame } from '../components/ImageFrame';
import { ImageGenerationPanel } from '../components/ImageGenerationPanel';
import { ReferenceSelectorPanel } from '../components/ReferenceSelectorPanel';
import { StatusNotice } from '../components/StatusNotice';

interface SketchModeViewProps {
  defaultStyle: string;
  references: ReferenceItem[];
  imageProvidersOverview?: ImageProvidersOverviewRead | null;
  onCreateProject: (payload: ProjectCreatePayload) => Promise<void>;
  onNavigate: (section: NavSection) => void;
  onAfterAiCall?: () => Promise<void>;
}

const LIGHTING_PRESETS = [
  'Światło dzienne rozproszone (overcast)',
  'Poranne słońce wschodnie',
  'Złota godzina przed zachodem',
  'Niebieska godzina + ciepłe wnętrze 2700K',
];

const MATERIAL_PRESETS = [
  'Blacha na rąbek grafit + modrzew naturalny',
  'Drewno opalane Shou Sugi Ban + czarne aluminium',
  'Beton architektoniczny + ciepły dąb',
  'Sklejka brzozowa + posadzka z mikrocementu',
];

const SAMPLE_SKETCH_URL = '/src/assets/images/architectural_hand_sketch_1794908154196.jpg';

export function SketchModeView({
  defaultStyle,
  references,
  imageProvidersOverview,
  onCreateProject,
  onNavigate,
  onAfterAiCall,
}: SketchModeViewProps) {
  const [title, setTitle] = useState('');
  const [buildingType, setBuildingType] = useState('Dom modułowy parterowy');
  const [areaSqm, setAreaSqm] = useState('68');
  const [modulesCount, setModulesCount] = useState('2');
  const [stylePreset, setStylePreset] = useState(defaultStyle);
  const [lightingPreset, setLightingPreset] = useState(LIGHTING_PRESETS[0]);
  const [materialPreset, setMaterialPreset] = useState(MATERIAL_PRESETS[0]);
  const [preserveGeometry, setPreserveGeometry] = useState(true);
  const [lockOpenings, setLockOpenings] = useState(true);
  const [promptBrief, setPromptBrief] = useState('');
  const [geometryNotes, setGeometryNotes] = useState('');
  const [sketchUrl, setSketchUrl] = useState<string | null>(null);
  const [generatedRenderUrl, setGeneratedRenderUrl] = useState<string | null>(null);
  const [isSampleSketch, setIsSampleSketch] = useState(false);
  const [selectedRefIds, setSelectedRefIds] = useState<number[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [preferredProvider, setPreferredProvider] = useState<ProviderPreference>('auto');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisPreviewResponse | null>(null);

  const uploadFile = async (file: File) => {
    setError(null);
    setUploading(true);
    try {
      const res = await apiClient.uploadSketch(file);
      setSketchUrl(res.url);
      setIsSampleSketch(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Błąd przesyłania pliku szkicu.');
    } finally {
      setUploading(false);
    }
  };

  const handleLoadSampleSketch = () => {
    setError(null);
    setSketchUrl(SAMPLE_SKETCH_URL);
    setIsSampleSketch(true);
  };

  const handleClearSketch = () => {
    setSketchUrl(null);
    setIsSampleSketch(false);
  };

  const handleFileInput = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) await uploadFile(file);
  };

  const handleDrop = async (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) await uploadFile(file);
  };

  const handleRunAiAnalysis = async () => {
    setAnalysisError(null);
    if (!sketchUrl) {
      setAnalysisError(
        'Najpierw prześlij plik szkicu (PNG, JPG, WEBP) lub załaduj wzór demonstracyjny.'
      );
      return;
    }

    const parsedArea = areaSqm.trim() ? Number(areaSqm) : null;
    if (parsedArea !== null && (Number.isNaN(parsedArea) || parsedArea <= 0)) {
      setAnalysisError('Powierzchnia zabudowy musi być liczbą większą od zera.');
      return;
    }

    const composedBrief = [
      promptBrief.trim(),
      `Materiały docelowe: ${materialPreset}`,
      `Oświetlenie: ${lightingPreset}`,
      lockOpenings ? 'Blokada osi okien, drzwi i proporcji ścian.' : '',
    ]
      .filter(Boolean)
      .join(' | ');

    setAnalyzing(true);
    try {
      const result = await apiClient.analyzeDraft({
        mode: 'sketch_to_render',
        title: title.trim() || 'Szkic roboczy projektu',
        building_type: buildingType,
        area_sqm: parsedArea,
        modules_count: Number(modulesCount) || 1,
        style_preset: stylePreset,
        preserve_geometry: preserveGeometry,
        prompt_brief: composedBrief,
        geometry_notes: geometryNotes.trim(),
        sketch_image_url: sketchUrl,
        reference_ids: selectedRefIds,
        preferred_provider: preferredProvider,
      });
      setAnalysisResult(result);
    } catch (err) {
      setAnalysisError(
        err instanceof Error ? err.message : 'Nie udało się wykonać darmowej analizy szkicu.'
      );
    } finally {
      setAnalyzing(false);
      if (onAfterAiCall) {
        void onAfterAiCall();
      }
    }
  };

  const handleAnalysisFieldChange = (field: keyof AnalysisEditableFields, value: string) => {
    setAnalysisResult((prev) => (prev ? { ...prev, [field]: value } : prev));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedSuccess(false);

    const parsedArea = areaSqm.trim() ? Number(areaSqm) : null;
    const validationError = validateProjectDraft({
      title,
      mode: 'sketch_to_render',
      prompt_brief: promptBrief,
      area_sqm: parsedArea,
    });
    if (validationError) {
      setError(validationError);
      return;
    }

    const composedBrief = [
      promptBrief.trim(),
      `Materiały docelowe: ${materialPreset}`,
      `Oświetlenie: ${lightingPreset}`,
      lockOpenings ? 'Blokada osi okien, drzwi i proporcji ścian.' : '',
    ]
      .filter(Boolean)
      .join(' | ');

    setSaving(true);
    try {
      await onCreateProject({
        title: title.trim(),
        mode: 'sketch_to_render',
        status: 'awaiting_ai_pipeline',
        building_type: buildingType,
        area_sqm: parsedArea,
        modules_count: Number(modulesCount) || 1,
        style_preset: stylePreset,
        preserve_geometry: preserveGeometry,
        prompt_brief: composedBrief,
        geometry_notes: geometryNotes.trim(),
        sketch_image_url: sketchUrl,
        reference_ids: selectedRefIds,
        initial_analysis: analysisResult
          ? {
              mode: 'sketch_to_render',
              provider: analysisResult.provider,
              model: analysisResult.model,
              is_free_tier: analysisResult.is_free_tier,
              response_time_ms: analysisResult.response_time_ms,
              schema_version: analysisResult.schema_version,
              analysis_source: analysisResult.is_mock
                ? 'mock'
                : analysisResult.analysis_source,
              summary: analysisResult.summary,
              spatial_layout: analysisResult.spatial_layout,
              materials_proposal: analysisResult.materials_proposal,
              lighting_proposal: analysisResult.lighting_proposal,
              geometry_preservation_note: analysisResult.geometry_preservation_note,
              visualization_prompt: analysisResult.visualization_prompt,
              rooms: analysisResult.rooms,
              geometry: analysisResult.geometry,
              openings: analysisResult.openings,
              openings_completeness_check: analysisResult.openings_completeness_check,
              orientation_source: analysisResult.orientation_source,
              unjustified_directions_detected: analysisResult.unjustified_directions_detected,
              dimension_observations: analysisResult.dimension_observations,
              dimension_checks: analysisResult.dimension_checks,
              dimension_conflicts: analysisResult.dimension_conflicts,
              dimension_confidence: analysisResult.dimension_confidence,
              geometry_protection: analysisResult.geometry_protection,
              uncertainties: analysisResult.uncertainties,
              user_requirements: analysisResult.user_requirements,
              ai_suggestions: analysisResult.ai_suggestions,
              observed_facts: analysisResult.observed_facts,
              model_interpretations: analysisResult.model_interpretations,
              indeterminable_elements: analysisResult.indeterminable_elements,
              clarification_questions: analysisResult.clarification_questions,
              disclaimer: analysisResult.disclaimer,
              raw_response_text: analysisResult.raw_response_text,
            }
          : null,
      });
      setSavedSuccess(true);
      setTitle('');
      setPromptBrief('');
      setGeometryNotes('');
      setSketchUrl(null);
      setIsSampleSketch(false);
      setSelectedRefIds([]);
      setAnalysisResult(null);
      setAnalysisError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zapisać projektu.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="min-w-0">
          <p className="text-xs font-medium text-zinc-500">Tryb A · Studio wiernego odwzorowania</p>
          <h1 className="text-2xl sm:text-3xl font-semibold text-zinc-950 mt-0.5">
            Szkic → Wizualizacja
          </h1>
        </div>
        <div className="flex items-center gap-2 text-xs font-medium text-zinc-700 bg-white border border-zinc-200 px-3.5 py-2 rounded-md max-w-full">
          <Lock className="w-3.5 h-3.5 text-zinc-900 shrink-0" aria-hidden="true" />
          <span>Priorytet: wierne zachowanie układu ścian, okien i proporcji</span>
        </div>
      </div>

      {error && <StatusNotice tone="error" title="Błąd formularza" description={error} />}
      {savedSuccess && (
        <div className="bg-emerald-50/80 border border-emerald-200 rounded-lg px-4 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="min-w-0">
            <p className="text-sm font-medium text-emerald-950">
              Projekt ze szkicu został zapisany w bazie pracowni
            </p>
            <p className="text-xs text-emerald-800 mt-0.5">
              Szkic, wytyczne geometrii oraz preferencje materiałów zostały trwale zapisane w SQLite.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('history')}
            className="px-3.5 py-2 rounded-md bg-emerald-900 text-white text-xs font-medium hover:bg-emerald-800 whitespace-nowrap"
          >
            Otwórz historię projektów
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Lewa kolumna: duża strefa przesyłania i podglądu szkicu */}
        <div className="xl:col-span-7 space-y-6 min-w-0">
          <div className="bg-white border border-zinc-200/90 rounded-lg p-5 sm:p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="min-w-0">
                <h2 className="text-base font-semibold text-zinc-950">
                  Przestrzeń robocza szkicu wejściowego
                </h2>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Przeciągnij plik na strefę poniżej lub wybierz rysunek (PNG, JPG, WEBP, SVG do 15 MB)
                </p>
              </div>
              <label className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 cursor-pointer transition-colors whitespace-nowrap">
                <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{uploading ? 'Przesyłanie...' : 'Wybierz plik szkicu'}</span>
                <input
                  type="file"
                  accept=".png,.jpg,.jpeg,.webp,.svg"
                  onChange={handleFileInput}
                  className="sr-only"
                />
              </label>
            </div>

            {isSampleSketch && sketchUrl && (
              <div className="px-3.5 py-2.5 rounded-md border border-amber-300/80 bg-amber-50/70 text-xs text-amber-950 flex flex-wrap items-center justify-between gap-2">
                <span>
                  Załadowano <strong>przykładowy szkic pracowni</strong> (materiał poglądowy — nie
                  jest to plik przesłany przez użytkownika).
                </span>
              </div>
            )}

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`rounded-lg transition-colors ${
                isDragging ? 'ring-2 ring-zinc-900 bg-zinc-50' : ''
              }`}
            >
              {sketchUrl ? (
                <ImageFrame
                  src={sketchUrl}
                  alt={
                    isSampleSketch
                      ? 'Przykładowy szkic architektoniczny pracowni'
                      : 'Podgląd przesłanego szkicu architektonicznego'
                  }
                  aspectClass="aspect-[4/3]"
                  fit="contain"
                  fallbackLabel="Nie udało się wyświetlić szkicu"
                  className="rounded-md"
                />
              ) : (
                <div className="aspect-[4/3] w-full rounded-md border-2 border-dashed border-zinc-300 bg-zinc-50/70 p-6 flex flex-col items-center justify-center text-center">
                  <div className="w-11 h-11 rounded-md border border-zinc-300 bg-white flex items-center justify-center text-zinc-700 mb-3">
                    <Compass className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <p className="text-sm font-medium text-zinc-900">
                    Upuść szkic architektoniczny tutaj
                  </p>
                  <p className="text-xs text-zinc-500 mt-1 max-w-sm leading-relaxed">
                    Rzut lub szkic odręczny wyświetli się w pełnej skali bez przycinania krawędzi i
                    linii wymiarowych.
                  </p>
                  <button
                    type="button"
                    onClick={handleLoadSampleSketch}
                    className="mt-4 px-3.5 py-2 rounded-md border border-zinc-300 bg-white text-xs font-medium text-zinc-900 hover:bg-zinc-100 transition-colors"
                  >
                    Załaduj przykładowy szkic
                  </button>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-zinc-500 pt-1">
              <span className="font-mono-tabular min-w-0 break-all">
                {sketchUrl
                  ? isSampleSketch
                    ? `Wzór demonstracyjny: ${sketchUrl.split('/').pop()}`
                    : `Plik użytkownika: ${sketchUrl.split('/').pop()}`
                  : 'Aktywny szkic: brak (oczekuje na plik użytkownika)'}
              </span>
              <div className="flex flex-wrap items-center gap-4 shrink-0">
                {!isSampleSketch && (
                  <button
                    type="button"
                    onClick={handleLoadSampleSketch}
                    className="text-zinc-700 hover:text-zinc-950 underline underline-offset-4"
                  >
                    Załaduj przykładowy szkic
                  </button>
                )}
                {sketchUrl && (
                  <button
                    type="button"
                    onClick={handleClearSketch}
                    className="text-zinc-500 hover:text-red-700 underline underline-offset-4"
                  >
                    Wyczyść podgląd
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Sterowanie darmową analizą szkicu + wyniki */}
          <div className="bg-white border border-zinc-200/90 rounded-lg p-5 sm:p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-sm font-semibold text-zinc-950">
                  Darmowa analiza szkicu AI (Zero Kosztów)
                </h2>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Analiza układu pomieszczeń, ścian, okien i materiałów z zachowaniem geometrii
                  szkicu.
                </p>
              </div>
              <span className="text-xs text-zinc-500 font-mono-tabular">Budżet zewnętrzny: 0 zł</span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex flex-wrap items-center gap-2 min-w-0 max-w-full">
                <label
                  htmlFor="sketch-ai-provider"
                  className="text-xs font-medium text-zinc-700 whitespace-nowrap"
                >
                  Dostawca AI:
                </label>
                <select
                  id="sketch-ai-provider"
                  value={preferredProvider}
                  onChange={(e) => setPreferredProvider(e.target.value as ProviderPreference)}
                  disabled={analyzing}
                  className="px-3 py-2 text-xs font-medium bg-white border border-zinc-300 rounded-md text-zinc-900 min-w-0 max-w-full w-full sm:w-auto"
                >
                  <option value="auto">Automatyczny (darmowy wg ustawień)</option>
                  <option value="gemini">Google Gemini (Free Tier)</option>
                  <option value="groq">GroqCloud (Free Tier)</option>
                </select>
              </div>

              <button
                type="button"
                disabled={analyzing}
                onClick={() => void handleRunAiAnalysis()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 disabled:opacity-50 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{analyzing ? 'Analizowanie szkicu...' : 'Uruchom darmową analizę AI'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-zinc-100">
              <div className="border border-dashed border-zinc-300 rounded-md p-4 bg-zinc-50/70">
                <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900">
                  <Compass className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>01. Analiza szkicu (Gemini / Groq Free Tier)</span>
                </div>
                <p className="mt-1.5 text-xs text-zinc-600 leading-relaxed">
                  Przygotowuje opis pomieszczeń, stolarki, proporcji i prompt przy zachowaniu
                  geometrii. Brak limitu nigdy nie przełącza na płatne API.
                </p>
              </div>
              <div className="border border-dashed border-zinc-300 rounded-md p-4 bg-zinc-50/70">
                <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900">
                  <SunMedium className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>02. Generowanie obrazu (niedostępne w wersji 0 zł)</span>
                </div>
                <p className="mt-1.5 text-xs text-zinc-600 leading-relaxed">
                  Generowanie fotorealistycznego obrazu pozostaje zablokowane w wariancie 0 zł.
                  Szkic, analiza AI i parametry są zapisywane w SQLite.
                </p>
              </div>
            </div>
          </div>

          <AnalysisResultPanel
            mode="sketch_to_render"
            analysis={analysisResult}
            loading={analyzing}
            error={analysisError}
            onChangeField={handleAnalysisFieldChange}
            onRetry={() => void handleRunAiAnalysis()}
          />

          <ImageGenerationPanel
            mode="sketch_to_render"
            hasSavedAnalysis={Boolean(analysisResult)}
            previewImageUrl={generatedRenderUrl}
            overview={imageProvidersOverview ?? null}
            onGenerate={async (preferredProvider, aspectRatio) => {
              const res = await apiClient.generateDraftImage({
                mode: 'sketch_to_render',
                title: title.trim() || 'Szkic roboczy projektu',
                building_type: buildingType,
                style_preset: stylePreset,
                preserve_geometry: preserveGeometry,
                prompt:
                  analysisResult?.visualization_prompt ||
                  promptBrief.trim() ||
                  `${buildingType}, ${stylePreset}`,
                sketch_image_url: sketchUrl,
                preferred_provider: preferredProvider,
                aspect_ratio: aspectRatio,
              });
              if (res.generated_image_url) {
                setGeneratedRenderUrl(res.generated_image_url);
              }
              if (onAfterAiCall) {
                void onAfterAiCall();
              }
              return res;
            }}
            compact={true}
          />
        </div>

        {/* Prawa kolumna: parametry, geometria, materiały i światło */}
        <div className="xl:col-span-5 min-w-0 bg-white border border-zinc-200/90 rounded-lg p-5 sm:p-6 space-y-6">
          <div>
            <h2 className="text-base font-semibold text-zinc-950">Parametry projektu</h2>
            <p className="text-xs text-zinc-500 mt-0.5">
              Wszystkie pola zapisywane są bezpośrednio w lokalnej bazie SQLite.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label
                htmlFor="sketch-title"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Nazwa projektu
              </label>
              <input
                id="sketch-title"
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="np. Dom Sosnowy — Elewacja Wschodnia"
                className="w-full px-3.5 py-2.5 text-sm border border-zinc-300 rounded-md bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="sketch-area"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Powierzchnia (m²)
                </label>
                <input
                  id="sketch-area"
                  type="number"
                  step="0.5"
                  min="1"
                  value={areaSqm}
                  onChange={(e) => setAreaSqm(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md font-mono-tabular focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
                />
              </div>
              <div>
                <label
                  htmlFor="sketch-modules"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Liczba modułów
                </label>
                <input
                  id="sketch-modules"
                  type="number"
                  min="1"
                  max="24"
                  value={modulesCount}
                  onChange={(e) => setModulesCount(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md font-mono-tabular focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="sketch-type"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Typ obiektu
              </label>
              <select
                id="sketch-type"
                value={buildingType}
                onChange={(e) => setBuildingType(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
              >
                <option value="Dom modułowy parterowy">Dom modułowy parterowy</option>
                <option value="Pawilon dwumodułowy">Pawilon dwumodułowy</option>
                <option value="Wnętrze dzienne">Wnętrze dzienne</option>
                <option value="Domek rekreacyjny">Domek rekreacyjny</option>
              </select>
            </div>
          </div>

          {/* Opcje zachowania geometrii i proporcji */}
          <div className="pt-4 border-t border-zinc-100 space-y-3">
            <h3 className="text-xs font-semibold text-zinc-900">
              Ochrona geometrii i proporcji szkicu
            </h3>

            <label className="p-3 rounded-md border border-zinc-200 bg-zinc-50/70 flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={preserveGeometry}
                onChange={(e) => setPreserveGeometry(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-zinc-300"
              />
              <span className="text-xs text-zinc-700 leading-relaxed">
                <strong className="block text-zinc-950 font-medium">
                  Ścisłe zachowanie obrysu bryły i geometrii dachu
                </strong>
                Zabrania AI zmiany proporcji oraz dodawania samowolnych wykuszy.
              </span>
            </label>

            <label className="p-3 rounded-md border border-zinc-200 bg-zinc-50/70 flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={lockOpenings}
                onChange={(e) => setLockOpenings(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-zinc-300"
              />
              <span className="text-xs text-zinc-700 leading-relaxed">
                <strong className="block text-zinc-950 font-medium">
                  Blokada położenia okien, drzwi i tarasu
                </strong>
                Zachowuje układ otworów stolarki dokładnie według przesłanego rysunku.
              </span>
            </label>

            <div>
              <label
                htmlFor="sketch-notes"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Uwagi wymiarowe do stolarki i ścian
              </label>
              <textarea
                id="sketch-notes"
                rows={2}
                value={geometryNotes}
                onChange={(e) => setGeometryNotes(e.target.value)}
                placeholder="np. Okno tarasowe HS 3.5 m na osi głównej, podcień szerokości 2.2 m"
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
              />
            </div>
          </div>

          {/* Miejsce na przyszłe ustawienia materiałów, światła i stylu */}
          <div className="pt-4 border-t border-zinc-100 space-y-4">
            <h3 className="text-xs font-semibold text-zinc-900">
              Ustawienia stylu, materiałów i światła (dla generatora AI)
            </h3>

            <div>
              <label
                htmlFor="sketch-style"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Kierunek stylistyczny
              </label>
              <select
                id="sketch-style"
                value={stylePreset}
                onChange={(e) => setStylePreset(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
              >
                <option value="Nordic Graphite">Nordic Graphite</option>
                <option value="Raw Steel & Cedar">Raw Steel & Cedar</option>
                <option value="Birch & Microcement">Birch & Microcement</option>
                <option value="Shou Sugi Ban Minimal">Shou Sugi Ban Minimal</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="sketch-materials"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Zestaw materiałów i elewacji
              </label>
              <select
                id="sketch-materials"
                value={materialPreset}
                onChange={(e) => setMaterialPreset(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
              >
                {MATERIAL_PRESETS.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="sketch-lighting"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Scenariusz oświetlenia i pory dnia
              </label>
              <select
                id="sketch-lighting"
                value={lightingPreset}
                onChange={(e) => setLightingPreset(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
              >
                {LIGHTING_PRESETS.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="sketch-brief"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Dodatkowe wytyczne otoczenia i detalu
              </label>
              <textarea
                id="sketch-brief"
                rows={3}
                value={promptBrief}
                onChange={(e) => setPromptBrief(e.target.value)}
                placeholder="np. Otoczenie lasu sosnowego, ścieżka ze żwiru bazaltowego, subtelne oprawy elewacyjne"
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
              />
            </div>

            {references.length > 0 && (
              <div className="pt-2 border-t border-zinc-100">
                <ReferenceSelectorPanel
                  references={references}
                  selectedIds={selectedRefIds}
                  onChangeSelectedIds={setSelectedRefIds}
                  projectTitle={title.trim() || 'Szkic roboczy projektu'}
                />
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="text-xs font-medium text-zinc-600 hover:text-zinc-950 underline underline-offset-4"
            >
              Historia projektów
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 disabled:opacity-50 transition-colors text-center"
            >
              {saving ? 'Zapisywanie...' : 'Zapisz projekt i przygotuj wizualizację'}
            </button>
          </div>
        </div>
      </form>
    </motion.div>
  );
}
