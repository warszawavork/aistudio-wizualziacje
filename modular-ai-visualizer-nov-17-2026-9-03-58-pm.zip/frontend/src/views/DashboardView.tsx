import { ArrowRight, BookOpen, PenTool, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import type { DashboardSummary, NavSection, Project, ReferenceItem } from '../types/domain';
import {
  formatAreaSqm,
  formatCategoryLabel,
  formatModeLabel,
  formatModeShortLabel,
  formatModulesCount,
  formatPolishDate,
} from '../utils/formatters';
import { ImageFrame } from '../components/ImageFrame';

interface DashboardViewProps {
  studioName?: string;
  summary: DashboardSummary | null;
  references: ReferenceItem[];
  loading: boolean;
  onNavigate: (section: NavSection) => void;
  onInspectProject: (project: Project) => void;
}

export function DashboardView({
  studioName,
  summary,
  references,
  loading,
  onNavigate,
  onInspectProject,
}: DashboardViewProps) {
  if (loading && !summary) {
    return (
      <div className="space-y-10 animate-pulse" aria-busy="true">
        <div className="h-44 bg-white border border-zinc-200/80 rounded-lg" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-72 bg-white border border-zinc-200/80 rounded-lg" />
          <div className="h-72 bg-white border border-zinc-200/80 rounded-lg" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-64 bg-white border border-zinc-200/80 rounded-lg" />
          <div className="h-64 bg-white border border-zinc-200/80 rounded-lg" />
          <div className="h-64 bg-white border border-zinc-200/80 rounded-lg" />
        </div>
      </div>
    );
  }

  const totalProjects = summary?.total_projects ?? 0;
  const sketchCount = summary?.sketch_mode_count ?? 0;
  const ideaCount = summary?.idea_mode_count ?? 0;
  const totalRefs = summary?.total_references ?? references.length;
  const recentProjects = summary?.recent_projects ?? [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-12"
    >
      {/* Elegancki nagłówek pracowni + główne działanie */}
      <section className="bg-white border border-zinc-200/90 rounded-lg p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-zinc-500 tracking-wide">
              {studioName || 'Pracownia projektowania modułowego'}
            </p>
            <h1 className="mt-2 text-3xl sm:text-4xl font-semibold tracking-tight text-zinc-950">
              Modular AI Visualizer
            </h1>
            <p className="mt-3 text-base text-zinc-600 leading-relaxed">
              Cyfrowe studio architektoniczne do przygotowania projektów domów modułowych i wnętrz.
              Zarządzaj szkicami wejściowymi, geometrią bryły oraz biblioteką materiałów przed
              wizualizacją.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end gap-3 shrink-0">
            <div className="flex flex-wrap items-center gap-4 text-xs text-zinc-500 font-mono-tabular bg-zinc-50 border border-zinc-200/80 rounded-md px-4 py-2.5">
              <span>
                <strong className="text-zinc-950 font-semibold">{totalProjects}</strong> zapisanych
                projektów
              </span>
              <span aria-hidden="true">·</span>
              <span>
                <strong className="text-zinc-950 font-semibold">{totalRefs}</strong> referencji w
                bibliotece
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Dwa wyraźne kafle głównych trybów */}
      <section aria-labelledby="workflows-heading">
        <div className="flex flex-wrap items-baseline justify-between gap-2 mb-5">
          <h2 id="workflows-heading" className="text-xl font-semibold text-zinc-950">
            Główne tryby pracy projektowej
          </h2>
          <span className="text-xs text-zinc-500 font-mono-tabular">
            Tryb A: {sketchCount} · Tryb B: {ideaCount}
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Tryb A */}
          <div className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden flex flex-col justify-between group">
            <div className="grid grid-cols-2 border-b border-zinc-200/80 bg-zinc-50">
              <div className="relative">
                <ImageFrame
                  src="/src/assets/images/architectural_hand_sketch_1794908154196.jpg"
                  alt="Przykładowy szkic architektoniczny trybu A"
                  aspectClass="aspect-[16/10]"
                  fit="contain"
                  fallbackLabel="Szkic wejściowy"
                  className="border-0 border-r border-zinc-200/80"
                />
              </div>
              <div className="relative">
                <ImageFrame
                  src="/src/assets/images/modular_cabin_exterior_1794908155648.jpg"
                  alt="Docelowa wizualizacja zewnętrzna trybu A"
                  aspectClass="aspect-[16/10]"
                  fallbackLabel="Wizualizacja docelowa"
                  className="border-0"
                />
              </div>
            </div>

            <div className="p-6 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
                  <PenTool className="w-3.5 h-3.5 text-zinc-800" aria-hidden="true" />
                  <span>Tryb A · Wierność geometrii i proporcji</span>
                </div>
                <h3 className="mt-2 text-xl font-semibold text-zinc-950">
                  1. Szkic → Wizualizacja
                </h3>
                <p className="mt-2 text-sm text-zinc-600 leading-relaxed">
                  Prześlij rysunek odręczny lub rzut techniczny. Określ blokadę położenia ścian,
                  okien i drzwi, dobierz materiały z biblioteki oraz wytyczne światła.
                </p>
              </div>

              <div className="mt-6 pt-5 border-t border-zinc-100 flex items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('sketch_mode')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 transition-colors whitespace-nowrap"
                >
                  <span>Otwórz studio Szkic → Wizualizacja</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>

          {/* Tryb B */}
          <div className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden flex flex-col justify-between group">
            <div className="border-b border-zinc-200/80 bg-zinc-50">
              <ImageFrame
                src="/src/assets/images/modular_pavilion_concept_1794908154441.jpg"
                alt="Przykładowa koncepcja pawilonu dwumodułowego"
                aspectClass="aspect-[32/10]"
                fallbackLabel="Koncepcja architektoniczna"
                className="border-0"
              />
            </div>

            <div className="p-6 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
                  <Sparkles className="w-3.5 h-3.5 text-zinc-800" aria-hidden="true" />
                  <span>Tryb B · Od opisu koncepcji do szkicu i wizualizacji</span>
                </div>
                <h3 className="mt-2 text-xl font-semibold text-zinc-950">
                  2. Pomysł → Projekt
                </h3>
                <p className="mt-2 text-sm text-zinc-600 leading-relaxed">
                  Opisz układ funkcjonalny domu modułowego lub wnętrza. Zdefiniuj liczbę modułów,
                  metraż oraz inspiracje materiałowe jako bazę do szkicu koncepcyjnego.
                </p>
              </div>

              <div className="mt-6 pt-5 border-t border-zinc-100 flex items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('idea_mode')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-white text-zinc-950 border border-zinc-300 text-sm font-medium hover:bg-zinc-50 transition-colors whitespace-nowrap"
                >
                  <span>Otwórz studio Pomysł → Projekt</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ostatnie projekty — duże miniatury */}
      <section aria-labelledby="recent-projects-heading">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 id="recent-projects-heading" className="text-xl font-semibold text-zinc-950">
              Ostatnie projekty
            </h2>
            <p className="text-xs text-zinc-500 mt-0.5">
              Kliknij kartę, aby obejrzeć parametry geometrii, szkic wejściowy i opis projektu.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('history')}
            className="text-sm font-medium text-zinc-700 hover:text-zinc-950 underline underline-offset-4 whitespace-nowrap"
          >
            Wszystkie projekty ({totalProjects})
          </button>
        </div>

        {recentProjects.length === 0 ? (
          <div className="bg-white border border-zinc-200 rounded-lg p-12 text-center">
            <p className="text-base font-medium text-zinc-900">Pracownia jest pusta</p>
            <p className="text-sm text-zinc-500 mt-1 mb-5 max-w-md mx-auto">
              Rozpocznij pierwszy projekt ze szkicu lub opisu tekstowego, aby zapisać dokumentację
              w bazie pracowni.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('new_project')}
              className="px-5 py-2.5 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 transition-colors"
            >
              Utwórz nowy projekt
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {recentProjects.map((project) => (
              <article
                key={project.id}
                className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden flex flex-col hover:border-zinc-300 transition-colors"
              >
                <button
                  type="button"
                  onClick={() => onInspectProject(project)}
                  aria-label={`Otwórz podgląd projektu ${project.title}`}
                  className="text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-zinc-900"
                >
                  <div className="overflow-hidden">
                    <ImageFrame
                      src={project.preview_image_url || project.sketch_image_url}
                      alt={`Podgląd projektu ${project.title}`}
                      aspectClass="aspect-[16/10]"
                      fallbackLabel="Karta projektowa oczekuje na wizualizację"
                      className="border-0 border-b border-zinc-200/80 group-hover:scale-[1.015] transition-transform duration-200"
                    />
                  </div>
                </button>

                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-xs text-zinc-500 font-mono-tabular">
                      {formatModeShortLabel(project.mode)} · {formatModeLabel(project.mode)} ·{' '}
                      {formatAreaSqm(project.area_sqm)}
                    </p>
                    <h3 className="mt-1.5 text-base font-semibold text-zinc-950">
                      <button
                        type="button"
                        onClick={() => onInspectProject(project)}
                        className="text-left hover:underline underline-offset-4"
                      >
                        {project.title}
                      </button>
                    </h3>
                    <p className="mt-1.5 text-sm text-zinc-600 line-clamp-2 leading-relaxed">
                      {project.prompt_brief || project.building_type}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-zinc-100 flex items-center justify-between text-xs text-zinc-500 font-mono-tabular">
                    <span>
                      {formatModulesCount(project.modules_count)} · {project.style_preset}
                    </span>
                    <span>{formatPolishDate(project.updated_at)}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* Biblioteka referencji */}
      <section aria-labelledby="ref-preview-heading">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-4 h-4 text-zinc-700" aria-hidden="true" />
            <h2 id="ref-preview-heading" className="text-xl font-semibold text-zinc-950">
              Biblioteka referencji
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('references')}
            className="text-sm font-medium text-zinc-700 hover:text-zinc-950 underline underline-offset-4 whitespace-nowrap"
          >
            Otwórz całą bibliotekę ({totalRefs})
          </button>
        </div>

        {references.length === 0 ? (
          <div className="bg-white border border-zinc-200 rounded-lg p-10 text-center">
            <p className="text-sm font-medium text-zinc-900">Brak zapisanych materiałów referencyjnych</p>
            <p className="text-xs text-zinc-500 mt-1 mb-4">
              Dodaj zdjęcia realizacji, wzorniki materiałów oraz przykłady oświetlenia.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('references')}
              className="px-4 py-2 rounded-md border border-zinc-300 text-sm font-medium text-zinc-900 hover:bg-zinc-50"
            >
              Dodaj pierwszą referencję
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
            {references.slice(0, 4).map((ref) => (
              <button
                key={ref.id}
                type="button"
                onClick={() => onNavigate('references')}
                className="text-left bg-white border border-zinc-200/90 rounded-lg overflow-hidden hover:border-zinc-300 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
              >
                <ImageFrame
                  src={ref.image_url}
                  alt={ref.title}
                  aspectClass="aspect-[4/3]"
                  fallbackLabel={formatCategoryLabel(ref.category)}
                  className="border-0 border-b border-zinc-200/80"
                />
                <div className="p-4">
                  <p className="text-xs text-zinc-500">{formatCategoryLabel(ref.category)}</p>
                  <h3 className="mt-1 text-sm font-semibold text-zinc-950 line-clamp-1">
                    {ref.title}
                  </h3>
                  <p className="mt-1 text-xs text-zinc-600 line-clamp-2">
                    {ref.materials_note || ref.description}
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>
    </motion.div>
  );
}
