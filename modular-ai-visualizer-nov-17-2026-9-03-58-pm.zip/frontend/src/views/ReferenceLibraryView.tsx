import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import {
  AlertTriangle,
  Check,
  Edit3,
  FolderKanban,
  Maximize2,
  Plus,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { apiClient } from '../api/client';
import type {
  Project,
  ReferenceCategory,
  ReferenceCreatePayload,
  ReferenceItem,
  ReferenceUpdatePayload,
} from '../types/domain';
import {
  formatCategoryLabel,
  formatPolishDate,
  formatReferenceRoleLabel,
  parseReferenceTags,
  validateReferenceDraft,
} from '../utils/formatters';
import { ImageFrame } from '../components/ImageFrame';
import { StatusNotice } from '../components/StatusNotice';

interface ReferenceLibraryViewProps {
  references: ReferenceItem[];
  projects: Project[];
  loading: boolean;
  onAddReference: (payload: ReferenceCreatePayload) => Promise<void>;
  onUpdateReference: (id: number, payload: ReferenceUpdatePayload) => Promise<void>;
  onDeleteReference: (id: number, force?: boolean) => Promise<void>;
}

const REFERENCE_PAGE_SIZE = 12;

const CATEGORIES: Array<{ id: 'all' | ReferenceCategory; label: string }> = [
  { id: 'all', label: 'Wszystkie' },
  { id: 'sketch_pair', label: 'Szkice i rzuty' },
  { id: 'visualization', label: 'Wizualizacje' },
  { id: 'realization', label: 'Realizacje' },
  { id: 'material', label: 'Materiały i faktury' },
  { id: 'color', label: 'Kolory' },
  { id: 'lighting', label: 'Oświetlenie' },
  { id: 'style', label: 'Style architektoniczne' },
  { id: 'interior', label: 'Aranżacje wnętrz' },
];

const CATEGORY_SELECT_OPTIONS: Array<{ value: ReferenceCategory; label: string }> = [
  { value: 'sketch_pair', label: 'Szkice i rzuty (lub para szkic + wizualizacja)' },
  { value: 'visualization', label: 'Wizualizacje' },
  { value: 'realization', label: 'Zdjęcia ukończonych realizacji' },
  { value: 'material', label: 'Materiały i faktury' },
  { value: 'color', label: 'Kolory i palety barwne' },
  { value: 'lighting', label: 'Oświetlenie' },
  { value: 'style', label: 'Style architektoniczne' },
  { value: 'interior', label: 'Aranżacje wnętrz' },
];

export function ReferenceLibraryView({
  references,
  projects,
  loading,
  onAddReference,
  onUpdateReference,
  onDeleteReference,
}: ReferenceLibraryViewProps) {
  const [categoryFilter, setCategoryFilter] = useState<'all' | ReferenceCategory>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [visibleCount, setVisibleCount] = useState(REFERENCE_PAGE_SIZE);
  const [showAddForm, setShowAddForm] = useState(false);
  const [pairViewMode, setPairViewMode] = useState<Record<number, 'split' | 'sketch' | 'render'>>(
    {}
  );
  const [inspectedRef, setInspectedRef] = useState<ReferenceItem | null>(null);
  const [editingRef, setEditingRef] = useState<ReferenceItem | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Add form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ReferenceCategory>('material');
  const [description, setDescription] = useState('');
  const [materialsNote, setMaterialsNote] = useState('');
  const [lightingNote, setLightingNote] = useState('');
  const [styleTags, setStyleTags] = useState('');
  const [selectedProjectIds, setSelectedProjectIds] = useState<number[]>([]);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [pairedSketchUrl, setPairedSketchUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedBanner, setSavedBanner] = useState<string | null>(null);

  // Edit form state
  const [editTitle, setEditTitle] = useState('');
  const [editCategory, setEditCategory] = useState<ReferenceCategory>('material');
  const [editDescription, setEditDescription] = useState('');
  const [editMaterialsNote, setEditMaterialsNote] = useState('');
  const [editLightingNote, setEditLightingNote] = useState('');
  const [editStyleTags, setEditStyleTags] = useState('');
  const [editProjectIds, setEditProjectIds] = useState<number[]>([]);
  const [editImageUrl, setEditImageUrl] = useState<string | null>(null);
  const [editPairedSketchUrl, setEditPairedSketchUrl] = useState<string | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  useEffect(() => {
    setVisibleCount(REFERENCE_PAGE_SIZE);
  }, [categoryFilter, projectFilter, searchQuery]);

  useEffect(() => {
    if (!inspectedRef && !editingRef) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setInspectedRef(null);
        setEditingRef(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [inspectedRef, editingRef]);

  // Keep inspectedRef in sync when references list updates
  useEffect(() => {
    if (!inspectedRef) return;
    const updated = references.find((item) => item.id === inspectedRef.id);
    if (updated) {
      setInspectedRef(updated);
    }
  }, [references, inspectedRef?.id]);

  const startEditingReference = (item: ReferenceItem) => {
    setError(null);
    setSavedBanner(null);
    setEditingRef(item);
    setEditTitle(item.title);
    setEditCategory(item.category === 'sketch_plan' ? 'sketch_pair' : item.category);
    setEditDescription(item.description || '');
    setEditMaterialsNote(item.materials_note || '');
    setEditLightingNote(item.lighting_note || '');
    setEditStyleTags(item.style_tags || '');
    setEditProjectIds(
      item.linked_project_ids ?? (item.project_id ? [item.project_id] : [])
    );
    setEditImageUrl(item.image_url);
    setEditPairedSketchUrl(item.paired_sketch_url);
  };

  const filteredReferences = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return references.filter((item) => {
      const matchesCategory =
        categoryFilter === 'all' ||
        (categoryFilter === 'sketch_pair'
          ? item.category === 'sketch_pair' || item.category === 'sketch_plan'
          : item.category === categoryFilter);

      const linkedIds = item.linked_project_ids ?? (item.project_id ? [item.project_id] : []);
      const matchesProject =
        projectFilter === 'all' ||
        (projectFilter === 'unassigned'
          ? linkedIds.length === 0
          : linkedIds.includes(Number(projectFilter)));

      const matchesSearch =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.materials_note.toLowerCase().includes(q) ||
        item.lighting_note.toLowerCase().includes(q) ||
        item.style_tags.toLowerCase().includes(q) ||
        (item.linked_project_titles ?? []).some((pt) => pt.toLowerCase().includes(q));

      return matchesCategory && matchesProject && matchesSearch;
    });
  }, [references, categoryFilter, projectFilter, searchQuery]);

  const visibleReferences = useMemo(
    () => filteredReferences.slice(0, visibleCount),
    [filteredReferences, visibleCount]
  );

  const handleUploadImage = async (
    e: ChangeEvent<HTMLInputElement>,
    target: 'main' | 'paired' | 'edit_main' | 'edit_paired'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setUploading(true);
    try {
      const res = await apiClient.uploadReferenceImage(file);
      if (target === 'main') {
        setImageUrl(res.url);
      } else if (target === 'paired') {
        setPairedSketchUrl(res.url);
      } else if (target === 'edit_main') {
        setEditImageUrl(res.url);
      } else {
        setEditPairedSketchUrl(res.url);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Błąd przesyłania pliku.');
    } finally {
      setUploading(false);
    }
  };

  const toggleCreateProjectLink = (projId: number) => {
    setSelectedProjectIds((prev) =>
      prev.includes(projId) ? prev.filter((id) => id !== projId) : [...prev, projId]
    );
  };

  const toggleEditProjectLink = (projId: number) => {
    setEditProjectIds((prev) =>
      prev.includes(projId) ? prev.filter((id) => id !== projId) : [...prev, projId]
    );
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedBanner(null);

    const validationError = validateReferenceDraft({ title });
    if (validationError) {
      setError(validationError);
      return;
    }

    setSaving(true);
    try {
      await onAddReference({
        title: title.trim(),
        category,
        description: description.trim(),
        materials_note: materialsNote.trim(),
        lighting_note: lightingNote.trim(),
        style_tags: styleTags.trim(),
        image_url: imageUrl,
        paired_sketch_url:
          category === 'sketch_pair' || category === 'sketch_plan' ? pairedSketchUrl : null,
        project_id: selectedProjectIds[0] ?? null,
        linked_project_ids: selectedProjectIds,
      });
      setTitle('');
      setDescription('');
      setMaterialsNote('');
      setLightingNote('');
      setStyleTags('');
      setSelectedProjectIds([]);
      setImageUrl(null);
      setPairedSketchUrl(null);
      setShowAddForm(false);
      setSavedBanner('Dodano nową referencję do biblioteki pracowni i zapisano w SQLite.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zapisać referencji.');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveEdit = async (e: FormEvent) => {
    e.preventDefault();
    if (!editingRef) return;
    setError(null);
    setSavedBanner(null);

    const validationError = validateReferenceDraft({ title: editTitle });
    if (validationError) {
      setError(validationError);
      return;
    }

    setSavingEdit(true);
    try {
      await onUpdateReference(editingRef.id, {
        title: editTitle.trim(),
        category: editCategory,
        description: editDescription.trim(),
        materials_note: editMaterialsNote.trim(),
        lighting_note: editLightingNote.trim(),
        style_tags: editStyleTags.trim(),
        image_url: editImageUrl,
        paired_sketch_url:
          editCategory === 'sketch_pair' || editCategory === 'sketch_plan'
            ? editPairedSketchUrl
            : null,
        project_id: editProjectIds[0] ?? null,
        linked_project_ids: editProjectIds,
      });
      setEditingRef(null);
      setSavedBanner('Zaktualizowano metadane i powiązania referencji w bazie SQLite.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zapisać zmian w referencji.');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleConfirmDelete = async (id: number, force: boolean) => {
    setError(null);
    setSavedBanner(null);
    setDeletingId(id);
    try {
      await onDeleteReference(id, force);
      setConfirmDeleteId(null);
      if (inspectedRef?.id === id) {
        setInspectedRef(null);
      }
      if (editingRef?.id === id) {
        setEditingRef(null);
      }
      setSavedBanner(
        force
          ? 'Referencja została odłączona od projektów i usunięta z biblioteki (plik źródłowy na dysku został zachowany).'
          : 'Referencja została usunięta z biblioteki pracowni.'
      );
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Nie udało się usunąć referencji z biblioteki pracowni.'
      );
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-zinc-950">
            Biblioteka referencji
          </h1>
          <p className="text-sm text-zinc-600 mt-1">
            Trwała baza szkiców, wizualizacji, realizacji, materiałów, kolorów, oświetlenia, stylów i
            wnętrz powiązana z projektami pracowni.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setShowAddForm((prev) => !prev);
            setSavedBanner(null);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 transition-colors whitespace-nowrap"
        >
          {showAddForm ? (
            <>
              <X className="w-4 h-4" aria-hidden="true" />
              <span>Zamknij formularz</span>
            </>
          ) : (
            <>
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Dodaj referencję</span>
            </>
          )}
        </button>
      </div>

      {error && <StatusNotice tone="error" title="Błąd operacji" description={error} />}
      {savedBanner && (
        <StatusNotice
          tone="success"
          title="Zapisano zmiany w bibliotece referencji"
          description={savedBanner}
        />
      )}

      {showAddForm && (
        <form
          onSubmit={handleSubmit}
          className="bg-white border border-zinc-200 rounded-lg p-6 space-y-5"
        >
          <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
            <h2 className="text-base font-semibold text-zinc-950">
              Nowy wpis w bibliotece referencji
            </h2>
            <span className="text-xs text-zinc-500 font-mono-tabular">
              Rola dla AI: {formatReferenceRoleLabel(category)}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="ref-title"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Nazwa referencji
                  </label>
                  <input
                    id="ref-title"
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="np. Elewacja z opalanego modrzewia"
                    className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>

                <div>
                  <label
                    htmlFor="ref-category"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Kategoria (8 kategorii architektonicznych)
                  </label>
                  <select
                    id="ref-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ReferenceCategory)}
                    className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  >
                    {CATEGORY_SELECT_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="ref-desc"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Opis architektoniczny i zastosowanie
                </label>
                <textarea
                  id="ref-desc"
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Kiedy i w jakich projektach stosować tę referencję..."
                  className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label
                    htmlFor="ref-materials"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Materiały i kolory
                  </label>
                  <input
                    id="ref-materials"
                    type="text"
                    value={materialsNote}
                    onChange={(e) => setMaterialsNote(e.target.value)}
                    placeholder="np. Modrzew, RAL 7016"
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>
                <div>
                  <label
                    htmlFor="ref-lighting"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Oświetlenie
                  </label>
                  <input
                    id="ref-lighting"
                    type="text"
                    value={lightingNote}
                    onChange={(e) => setLightingNote(e.target.value)}
                    placeholder="np. Miękkie dzienne / 2700K"
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>
                <div>
                  <label
                    htmlFor="ref-tags"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Tagi (po przecinku)
                  </label>
                  <input
                    id="ref-tags"
                    type="text"
                    value={styleTags}
                    onChange={(e) => setStyleTags(e.target.value)}
                    placeholder="np. nordic, taras, drewno"
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>
              </div>

              {projects.length > 0 && (
                <div>
                  <span className="block text-xs font-medium text-zinc-700 mb-1.5">
                    Opcjonalne powiązanie z projektami ({selectedProjectIds.length} wybrano)
                  </span>
                  <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-2 border border-zinc-200 rounded-md bg-zinc-50/60">
                    {projects.map((proj) => {
                      const active = selectedProjectIds.includes(proj.id);
                      return (
                        <button
                          key={proj.id}
                          type="button"
                          onClick={() => toggleCreateProjectLink(proj.id)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs transition-colors ${
                            active
                              ? 'border-zinc-950 bg-zinc-900 text-white font-medium'
                              : 'border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-100'
                          }`}
                        >
                          {active && <Check className="w-3 h-3" aria-hidden="true" />}
                          <span>{proj.title}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>
                    {uploading
                      ? 'Przesyłanie...'
                      : imageUrl
                        ? 'Zmień główne zdjęcie'
                        : 'Prześlij zdjęcie / wizualizację'}
                  </span>
                  <input
                    type="file"
                    accept=".png,.jpg,.jpeg,.webp,.svg"
                    onChange={(e) => handleUploadImage(e, 'main')}
                    className="sr-only"
                  />
                </label>

                {(category === 'sketch_pair' || category === 'sketch_plan') && (
                  <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>
                      {pairedSketchUrl ? 'Zmień powiązany szkic' : 'Prześlij powiązany szkic'}
                    </span>
                    <input
                      type="file"
                      accept=".png,.jpg,.jpeg,.webp,.svg"
                      onChange={(e) => handleUploadImage(e, 'paired')}
                      className="sr-only"
                    />
                  </label>
                )}
              </div>
            </div>

            <div className="lg:col-span-4 space-y-2">
              <span className="block text-xs font-medium text-zinc-700">Podgląd obrazu</span>
              <ImageFrame
                src={imageUrl}
                alt="Podgląd dodawanej referencji"
                aspectClass="aspect-[4/3]"
                fallbackLabel="Podgląd pojawi się po przesłaniu pliku"
                className="rounded-md"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-zinc-200 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-sm font-medium text-zinc-700 hover:text-zinc-950"
            >
              Anuluj
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 disabled:opacity-50"
            >
              {saving ? 'Zapisywanie...' : 'Zapisz w bibliotece'}
            </button>
          </div>
        </form>
      )}

      {/* Pasek wyszukiwania, filtrów kategorii i filtru projektów */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-zinc-200/75 rounded-md w-full max-w-full">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                categoryFilter === cat.id
                  ? 'bg-white text-zinc-950 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <select
              aria-label="Filtruj referencje według powiązanego projektu"
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="px-3 py-2 text-xs font-medium bg-white border border-zinc-300 rounded-md text-zinc-800 max-w-full"
            >
              <option value="all">Wszystkie projekty ({references.length})</option>
              <option value="unassigned">Nieprzypisane do projektu</option>
              {projects.map((proj) => (
                <option key={proj.id} value={String(proj.id)}>
                  Projekt: {proj.title}
                </option>
              ))}
            </select>

            <p className="text-xs text-zinc-500 font-mono-tabular">
              Wyświetlono <strong>{filteredReferences.length}</strong> z{' '}
              <strong>{references.length}</strong> referencji
            </p>
          </div>

          <div className="relative w-full sm:w-80">
            <Search
              className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Szukaj po nazwie, materiale, projekcie lub tagu..."
              aria-label="Szukaj w bibliotece referencji"
              className="w-full pl-9 pr-3.5 py-2 text-sm bg-white border border-zinc-300 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
            />
          </div>
        </div>
      </div>

      {/* Galeria referencji */}
      {loading && references.length === 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[0, 1, 2].map((idx) => (
            <div
              key={idx}
              className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden animate-pulse"
            >
              <div className="aspect-[4/3] bg-zinc-200" />
              <div className="p-5 space-y-3">
                <div className="h-3 w-1/3 bg-zinc-200 rounded" />
                <div className="h-5 w-2/3 bg-zinc-200 rounded" />
                <div className="h-3 w-full bg-zinc-100 rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : references.length === 0 ? (
        <div className="bg-white border border-zinc-200 rounded-lg p-8 sm:p-12 text-center">
          <p className="text-sm font-medium text-zinc-900">Brak zapisanych referencji</p>
          <p className="text-xs text-zinc-500 mt-1 mb-4">
            Biblioteka pracowni jest obecnie pusta. Dodaj pierwszy szkic, realizację lub wzornik
            materiału.
          </p>
          <button
            type="button"
            onClick={() => setShowAddForm(true)}
            className="px-4 py-2 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 transition-colors"
          >
            Dodaj pierwszą referencję
          </button>
        </div>
      ) : filteredReferences.length === 0 ? (
        <div className="bg-white border border-zinc-200 rounded-lg p-8 sm:p-12 text-center">
          <p className="text-sm font-medium text-zinc-900">Brak pasujących referencji</p>
          <p className="text-xs text-zinc-500 mt-1 mb-4">
            Żaden materiał nie spełnia bieżących kryteriów wyszukiwania, kategorii lub projektu.
          </p>
          <button
            type="button"
            onClick={() => {
              setCategoryFilter('all');
              setProjectFilter('all');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50"
          >
            Pokaż wszystkie referencje
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {visibleReferences.map((item) => {
              const mode = pairViewMode[item.id] || 'split';
              const tags = parseReferenceTags(item.style_tags, item.tags);
              const linkedTitles = item.linked_project_titles ?? [];
              const isInUse = Boolean(item.is_in_use || linkedTitles.length > 0);
              const filePath = item.original_file_path || item.image_url || item.paired_sketch_url;

              return (
                <article
                  key={item.id}
                  className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden flex flex-col min-w-0"
                >
                  <div className="relative border-b border-zinc-200/80">
                    <button
                      type="button"
                      onClick={() => setInspectedRef(item)}
                      aria-label={`Powiększ podgląd: ${item.title}`}
                      className="block w-full text-left group relative cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-zinc-900"
                    >
                      {item.paired_sketch_url ? (
                        <>
                          {mode === 'split' && (
                            <div className="grid grid-cols-2">
                              <ImageFrame
                                src={item.paired_sketch_url}
                                alt={`Szkic dla ${item.title}`}
                                aspectClass="aspect-[4/3]"
                                fit="contain"
                                fallbackLabel="Szkic"
                                className="border-0 border-r border-zinc-200/80"
                              />
                              <ImageFrame
                                src={item.image_url}
                                alt={`Wizualizacja dla ${item.title}`}
                                aspectClass="aspect-[4/3]"
                                fallbackLabel="Wizualizacja"
                                className="border-0"
                              />
                            </div>
                          )}
                          {mode === 'sketch' && (
                            <ImageFrame
                              src={item.paired_sketch_url}
                              alt={`Szkic dla ${item.title}`}
                              aspectClass="aspect-[4/3]"
                              fit="contain"
                              fallbackLabel="Szkic"
                              className="border-0"
                            />
                          )}
                          {mode === 'render' && (
                            <ImageFrame
                              src={item.image_url}
                              alt={`Wizualizacja dla ${item.title}`}
                              aspectClass="aspect-[4/3]"
                              fallbackLabel="Wizualizacja"
                              className="border-0"
                            />
                          )}
                        </>
                      ) : (
                        <ImageFrame
                          src={item.image_url}
                          alt={item.title}
                          aspectClass="aspect-[4/3]"
                          fallbackLabel={formatCategoryLabel(item.category)}
                          className="border-0"
                        />
                      )}

                      <span className="absolute top-2.5 right-2.5 inline-flex items-center gap-1 px-2 py-1 rounded bg-zinc-950/75 text-white text-[11px] font-medium opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-opacity">
                        <Maximize2 className="w-3 h-3" aria-hidden="true" />
                        <span>Szczegóły</span>
                      </span>
                    </button>

                    {item.paired_sketch_url && (
                      <div className="px-4 py-2 bg-zinc-50 border-t border-zinc-200/70 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <span className="text-zinc-500">Widok pary:</span>
                        <div className="flex items-center gap-1">
                          {(
                            [
                              ['split', 'Porównanie'],
                              ['sketch', 'Szkic'],
                              ['render', 'Wizualizacja'],
                            ] as const
                          ).map(([key, label]) => (
                            <button
                              key={key}
                              type="button"
                              onClick={() =>
                                setPairViewMode((prev) => ({ ...prev, [item.id]: key }))
                              }
                              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                                mode === key
                                  ? 'bg-zinc-900 text-white'
                                  : 'text-zinc-600 hover:text-zinc-950'
                              }`}
                            >
                              {label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-xs text-zinc-500 font-mono-tabular">
                        {formatCategoryLabel(item.category)} · {formatPolishDate(item.created_at)}
                      </p>
                      <h3 className="mt-1.5 text-base font-semibold text-zinc-950">{item.title}</h3>
                      {item.description && (
                        <p className="mt-1.5 text-sm text-zinc-600 leading-relaxed line-clamp-2">
                          {item.description}
                        </p>
                      )}

                      <dl className="mt-3 space-y-1 text-xs text-zinc-600">
                        <div>
                          <dt className="inline font-medium text-zinc-800">Rola AI: </dt>
                          <dd className="inline">
                            {item.role || formatReferenceRoleLabel(item.category)}
                          </dd>
                        </div>
                        {item.materials_note && (
                          <div>
                            <dt className="inline font-medium text-zinc-800">Materiały: </dt>
                            <dd className="inline">{item.materials_note}</dd>
                          </div>
                        )}
                        {item.lighting_note && (
                          <div>
                            <dt className="inline font-medium text-zinc-800">Oświetlenie: </dt>
                            <dd className="inline">{item.lighting_note}</dd>
                          </div>
                        )}
                        {filePath && (
                          <div className="truncate">
                            <dt className="inline font-medium text-zinc-800">Plik: </dt>
                            <dd className="inline font-mono-tabular text-[11px] text-zinc-500">
                              {filePath}
                            </dd>
                          </div>
                        )}
                        {linkedTitles.length > 0 && (
                          <div className="pt-1 flex items-start gap-1.5 text-zinc-700">
                            <FolderKanban
                              className="w-3.5 h-3.5 text-zinc-500 shrink-0 mt-0.5"
                              aria-hidden="true"
                            />
                            <span>
                              <strong className="font-medium text-zinc-900">Projekty:</strong>{' '}
                              {linkedTitles.join(', ')}
                            </span>
                          </div>
                        )}
                      </dl>
                    </div>

                    <div className="mt-4 pt-3 border-t border-zinc-100 space-y-2.5">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-500 min-w-0">
                        {tags.length > 0 ? (
                          tags.map((tag, idx) => (
                            <button
                              key={tag}
                              type="button"
                              onClick={() => setSearchQuery(tag)}
                              className="hover:text-zinc-950 hover:underline underline-offset-2"
                            >
                              {idx > 0 ? '· ' : ''}#{tag}
                            </button>
                          ))
                        ) : (
                          <span>Brak tagów</span>
                        )}
                      </div>

                      {confirmDeleteId === item.id ? (
                        <div className="p-2.5 rounded-md border border-red-200 bg-red-50/70 space-y-2 text-xs">
                          {isInUse ? (
                            <div className="flex items-start gap-2 text-red-900">
                              <AlertTriangle
                                className="w-4 h-4 text-red-700 shrink-0 mt-0.5"
                                aria-hidden="true"
                              />
                              <p className="leading-relaxed">
                                Ta referencja jest powiązana z projektami:{' '}
                                <strong>{linkedTitles.join(', ')}</strong>. Plik źródłowy jest
                                chroniony — potwierdzenie odłączy referencję od projektów i usunie
                                wpis z biblioteki bez kasowania pliku na dysku.
                              </p>
                            </div>
                          ) : (
                            <p className="text-zinc-700 font-medium">
                              Czy na pewno chcesz usunąć referencję „{item.title}”?
                            </p>
                          )}
                          <div className="flex flex-wrap items-center justify-end gap-2">
                            <button
                              type="button"
                              disabled={deletingId === item.id}
                              onClick={() => void handleConfirmDelete(item.id, isInUse)}
                              aria-label={`Potwierdź usunięcie referencji ${item.title}`}
                              className="px-2.5 py-1 rounded bg-red-700 text-white font-medium hover:bg-red-800 disabled:opacity-50"
                            >
                              {deletingId === item.id
                                ? 'Usuwanie...'
                                : isInUse
                                  ? 'Odłącz od projektów i usuń'
                                  : 'Potwierdź usunięcie'}
                            </button>
                            <button
                              type="button"
                              disabled={deletingId === item.id}
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-2.5 py-1 rounded border border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-50 disabled:opacity-50"
                            >
                              Anuluj
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => startEditingReference(item)}
                            aria-label={`Edytuj referencję ${item.title}`}
                            className="inline-flex items-center gap-1 text-xs font-medium text-zinc-700 hover:text-zinc-950 transition-colors"
                          >
                            <Edit3 className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Edytuj metadane</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setError(null);
                              setConfirmDeleteId(item.id);
                            }}
                            aria-label={`Usuń referencję ${item.title}`}
                            className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-red-700 transition-colors shrink-0"
                          >
                            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Usuń</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>

          {filteredReferences.length > visibleCount && (
            <div className="flex justify-center">
              <button
                type="button"
                onClick={() => setVisibleCount((prev) => prev + REFERENCE_PAGE_SIZE)}
                className="px-4 py-2 text-xs font-medium text-zinc-800 hover:text-zinc-950 border border-zinc-300 rounded-md bg-white hover:bg-zinc-50 transition-colors"
              >
                Pokaż kolejne referencje ({filteredReferences.length - visibleCount} pozostało)
              </button>
            </div>
          )}
        </div>
      )}

      {/* Modal edycji metadanych i powiązań referencji */}
      {editingRef && (
        <div
          className="fixed inset-0 z-50 bg-zinc-950/75 backdrop-blur-[2px] flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="ref-edit-modal-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setEditingRef(null);
            }
          }}
        >
          <form
            onSubmit={handleSaveEdit}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-lg border border-zinc-200 max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-xl"
          >
            <div className="px-5 sm:px-6 py-4 border-b border-zinc-200 flex items-center justify-between gap-4 sticky top-0 bg-white z-10">
              <div>
                <p className="text-xs text-zinc-500 font-mono-tabular">
                  Edycja metadanych · ID #{editingRef.id}
                </p>
                <h2 id="ref-edit-modal-title" className="text-lg font-semibold text-zinc-950">
                  {editingRef.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setEditingRef(null)}
                aria-label="Zamknij edycję referencji"
                className="p-2 text-zinc-500 hover:text-zinc-950 rounded-md hover:bg-zinc-100"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            <div className="p-5 sm:p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="edit-ref-title"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Nazwa referencji
                  </label>
                  <input
                    id="edit-ref-title"
                    type="text"
                    required
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>

                <div>
                  <label
                    htmlFor="edit-ref-category"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Kategoria
                  </label>
                  <select
                    id="edit-ref-category"
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value as ReferenceCategory)}
                    className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  >
                    {CATEGORY_SELECT_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="edit-ref-desc"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Opis architektoniczny i zastosowanie
                </label>
                <textarea
                  id="edit-ref-desc"
                  rows={3}
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label
                    htmlFor="edit-ref-materials"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Materiały i kolory
                  </label>
                  <input
                    id="edit-ref-materials"
                    type="text"
                    value={editMaterialsNote}
                    onChange={(e) => setEditMaterialsNote(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>

                <div>
                  <label
                    htmlFor="edit-ref-lighting"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Oświetlenie
                  </label>
                  <input
                    id="edit-ref-lighting"
                    type="text"
                    value={editLightingNote}
                    onChange={(e) => setEditLightingNote(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>

                <div>
                  <label
                    htmlFor="edit-ref-tags"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Tagi (po przecinku)
                  </label>
                  <input
                    id="edit-ref-tags"
                    type="text"
                    value={editStyleTags}
                    onChange={(e) => setEditStyleTags(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
                  />
                </div>
              </div>

              {projects.length > 0 && (
                <div>
                  <span className="block text-xs font-medium text-zinc-700 mb-1.5">
                    Powiązane projekty ({editProjectIds.length})
                  </span>
                  <div className="flex flex-wrap gap-1.5 p-2.5 border border-zinc-200 rounded-md bg-zinc-50/70">
                    {projects.map((proj) => {
                      const active = editProjectIds.includes(proj.id);
                      return (
                        <button
                          key={proj.id}
                          type="button"
                          onClick={() => toggleEditProjectLink(proj.id)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs transition-colors ${
                            active
                              ? 'border-zinc-950 bg-zinc-900 text-white font-medium'
                              : 'border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-100'
                          }`}
                        >
                          {active && <Check className="w-3 h-3" aria-hidden="true" />}
                          <span>{proj.title}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{uploading ? 'Przesyłanie...' : 'Zmień plik obrazu'}</span>
                  <input
                    type="file"
                    accept=".png,.jpg,.jpeg,.webp,.svg"
                    onChange={(e) => handleUploadImage(e, 'edit_main')}
                    className="sr-only"
                  />
                </label>

                <span className="text-xs text-zinc-500 font-mono-tabular break-all">
                  Ścieżka: {editImageUrl || editingRef.original_file_path || 'brak'}
                </span>
              </div>
            </div>

            <div className="px-5 sm:px-6 py-4 border-t border-zinc-200 flex items-center justify-end gap-3 bg-zinc-50/60">
              <button
                type="button"
                onClick={() => setEditingRef(null)}
                className="px-4 py-2 text-sm font-medium text-zinc-700 hover:text-zinc-950"
              >
                Anuluj
              </button>
              <button
                type="submit"
                disabled={savingEdit}
                className="px-4 py-2 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 disabled:opacity-50"
              >
                {savingEdit ? 'Zapisywanie...' : 'Zapisz zmiany'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal szczegółowego podglądu referencji */}
      {inspectedRef && (
        <div
          className="fixed inset-0 z-50 bg-zinc-950/75 backdrop-blur-[2px] flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="ref-lightbox-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setInspectedRef(null);
            }
          }}
        >
          <div
            className="bg-white rounded-lg border border-zinc-200 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 sm:px-6 py-4 border-b border-zinc-200 flex items-start justify-between gap-4 sticky top-0 bg-white z-10">
              <div className="min-w-0">
                <p className="text-xs text-zinc-500 font-mono-tabular">
                  {formatCategoryLabel(inspectedRef.category)} · Rola AI:{' '}
                  {inspectedRef.role || formatReferenceRoleLabel(inspectedRef.category)} · Dodano:{' '}
                  {formatPolishDate(inspectedRef.created_at)}
                </p>
                <h2
                  id="ref-lightbox-title"
                  className="text-lg sm:text-xl font-semibold text-zinc-950 mt-0.5 break-words"
                >
                  {inspectedRef.title}
                </h2>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    const target = inspectedRef;
                    setInspectedRef(null);
                    startEditingReference(target);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50"
                >
                  <Edit3 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Edytuj</span>
                </button>
                <button
                  type="button"
                  onClick={() => setInspectedRef(null)}
                  aria-label="Zamknij podgląd referencji"
                  className="p-2 text-zinc-500 hover:text-zinc-950 rounded-md hover:bg-zinc-100"
                >
                  <X className="w-5 h-5" aria-hidden="true" />
                </button>
              </div>
            </div>

            <div className="p-5 sm:p-6 space-y-5">
              {inspectedRef.paired_sketch_url ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <span className="block text-xs font-medium text-zinc-600">
                      Powiązany szkic koncepcyjny
                    </span>
                    <ImageFrame
                      src={inspectedRef.paired_sketch_url}
                      alt={`Szkic dla ${inspectedRef.title}`}
                      aspectClass="aspect-[4/3]"
                      fit="contain"
                      fallbackLabel="Brak szkicu"
                      className="rounded-md"
                    />
                  </div>
                  <div className="space-y-2">
                    <span className="block text-xs font-medium text-zinc-600">
                      Wizualizacja / Realizacja
                    </span>
                    <ImageFrame
                      src={inspectedRef.image_url}
                      alt={`Wizualizacja dla ${inspectedRef.title}`}
                      aspectClass="aspect-[4/3]"
                      fit="contain"
                      fallbackLabel="Brak obrazu"
                      className="rounded-md"
                    />
                  </div>
                </div>
              ) : (
                <ImageFrame
                  src={inspectedRef.image_url}
                  alt={inspectedRef.title}
                  aspectClass="aspect-[16/10]"
                  fit="contain"
                  fallbackLabel={formatCategoryLabel(inspectedRef.category)}
                  className="rounded-md"
                />
              )}

              <div className="space-y-3 text-sm text-zinc-700">
                {inspectedRef.description && (
                  <p className="leading-relaxed">{inspectedRef.description}</p>
                )}

                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-zinc-50 border border-zinc-200 rounded-md p-4">
                  <div>
                    <dt className="text-zinc-500">Materiały i kolory</dt>
                    <dd className="text-zinc-900 font-medium mt-0.5">
                      {inspectedRef.materials_note || 'Nie określono'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-zinc-500">Oświetlenie</dt>
                    <dd className="text-zinc-900 font-medium mt-0.5">
                      {inspectedRef.lighting_note || 'Nie określono'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-zinc-500">Tagi stylistyczne</dt>
                    <dd className="text-zinc-900 font-medium mt-0.5">
                      {inspectedRef.style_tags || 'Brak tagów'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-zinc-500">Ścieżka do oryginalnego pliku</dt>
                    <dd className="text-zinc-900 font-mono-tabular mt-0.5 break-all">
                      {inspectedRef.original_file_path ||
                        inspectedRef.image_url ||
                        inspectedRef.paired_sketch_url ||
                        'Brak pliku'}
                    </dd>
                  </div>
                  <div className="sm:col-span-2">
                    <dt className="text-zinc-500">Powiązane projekty w bazie SQLite</dt>
                    <dd className="text-zinc-900 font-medium mt-0.5">
                      {(inspectedRef.linked_project_titles ?? []).length > 0
                        ? inspectedRef.linked_project_titles?.join(' · ')
                        : 'Brak przypisanych projektów'}
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
