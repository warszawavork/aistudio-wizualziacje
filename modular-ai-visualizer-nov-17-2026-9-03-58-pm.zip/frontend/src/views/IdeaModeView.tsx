import { useState, type FormEvent } from 'react';
import { Home, Layers, PenTool, Sofa, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { apiClient } from '../api/client';
import type {
  AnalysisEditableFields,
  AnalysisPreviewResponse,
  ImageProvidersOverviewRead,
  NavSection,
  ProjectCreatePayload,
  ProviderPreference,
  ReferenceItem,
} from '../types/domain';
import { validateProjectDraft } from '../utils/formatters';
import { AnalysisResultPanel } from '../components/AnalysisResultPanel';
import { ImageGenerationPanel } from '../components/ImageGenerationPanel';
import { ReferenceSelectorPanel } from '../components/ReferenceSelectorPanel';
import { StatusNotice } from '../components/StatusNotice';

interface IdeaModeViewProps {
  defaultStyle: string;
  references: ReferenceItem[];
  imageProvidersOverview?: ImageProvidersOverviewRead | null;
  onCreateProject: (payload: ProjectCreatePayload) => Promise<void>;
  onNavigate: (section: NavSection) => void;
  onAfterAiCall?: () => Promise<void>;
}

const SAMPLE_IDEAS = {
  modular_house:
    'Nowoczesny parterowy dom modułowy złożony z trzech połączonych brył o łącznej powierzchni 94 m² na leśnej działce. Część dzienna z dużym narożnym przeszkleniem HS otwartym na zadaszony taras modrzewiowy, strefa sypialniana oddzielona łącznikiem. Elewacja z grafitowej blachy na rąbek i opalanego modrzewia, oświetlenie zmierzchowe podbitki.',
  interior:
    'Przestronne wnętrze strefy dziennej domu modułowego (42 m²) z otwartym widokiem na sosnowy ogród przez trzy wysokie okna w czarnych ramach aluminiowych. Sufit ze sklejki brzozowej z widocznymi belkami, gładka posadzka z jasnego mikrocementu, zabudowa kuchenna w matowym graficie oraz miękkie światło poranne.',
};

export function IdeaModeView({
  defaultStyle,
  references,
  imageProvidersOverview,
  onCreateProject,
  onNavigate,
  onAfterAiCall,
}: IdeaModeViewProps) {
  const [projectCategory, setProjectCategory] = useState<'modular_house' | 'interior'>(
    'modular_house'
  );
  const [title, setTitle] = useState('');
  const [buildingType, setBuildingType] = useState('Pawilon dwumodułowy');
  const [areaSqm, setAreaSqm] = useState('92');
  const [modulesCount, setModulesCount] = useState('3');
  const [stylePreset, setStylePreset] = useState(defaultStyle);
  const [promptBrief, setPromptBrief] = useState('');
  const [geometryNotes, setGeometryNotes] = useState('');
  const [generatedRenderUrl, setGeneratedRenderUrl] = useState<string | null>(null);
  const [selectedRefIds, setSelectedRefIds] = useState<number[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [preferredProvider, setPreferredProvider] = useState<ProviderPreference>('auto');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisPreviewResponse | null>(null);

  const handleSelectCategory = (category: 'modular_house' | 'interior') => {
    setProjectCategory(category);
    if (category === 'interior') {
      setBuildingType('Wnętrze dzienne');
      setAreaSqm('42');
      setModulesCount('1');
    } else {
      setBuildingType('Pawilon dwumodułowy');
      setAreaSqm('92');
      setModulesCount('3');
    }
  };

  const applySampleIdea = () => {
    if (projectCategory === 'interior') {
      if (!title.trim()) setTitle('Wnętrze Modułu Dziennego — Strefa Relaksu');
      setPromptBrief(SAMPLE_IDEAS.interior);
      setGeometryNotes('Wysokość w świetle 2.95 m, okna od podłogi do sufitu w osi południowej.');
    } else {
      if (!title.trim()) setTitle('Rezydencja Modułowa Sosnowa 94 m²');
      setPromptBrief(SAMPLE_IDEAS.modular_house);
      setGeometryNotes('Szerokość transportowa modułu 3.45 m, dach płaski z attyką grafitową.');
    }
  };

  const handleRunIdeaAnalysis = async () => {
    setAnalysisError(null);
    if (promptBrief.trim().length < 10) {
      setAnalysisError(
        'Wpisz opis pomysłu architektonicznego o długości co najmniej 10 znaków (lub wstaw przykład).'
      );
      return;
    }

    const parsedArea = areaSqm.trim() ? Number(areaSqm) : null;
    if (parsedArea !== null && (Number.isNaN(parsedArea) || parsedArea <= 0)) {
      setAnalysisError('Metraż musi być liczbą większą od zera.');
      return;
    }

    setAnalyzing(true);
    try {
      const result = await apiClient.analyzeDraft({
        mode: 'idea_to_project',
        title: title.trim() || 'Nowa koncepcja modułowa',
        building_type: buildingType,
        area_sqm: parsedArea,
        modules_count: Number(modulesCount) || 1,
        style_preset: stylePreset,
        preserve_geometry: true,
        prompt_brief: promptBrief.trim(),
        geometry_notes: geometryNotes.trim(),
        sketch_image_url: null,
        reference_ids: selectedRefIds,
        preferred_provider: preferredProvider,
      });
      setAnalysisResult(result);
    } catch (err) {
      setAnalysisError(
        err instanceof Error ? err.message : 'Nie udało się wygenerować koncepcji AI.'
      );
    } finally {
      setAnalyzing(false);
      if (onAfterAiCall) {
        void onAfterAiCall();
      }
    }
  };

  const handleAnalysisFieldChange = (field: keyof AnalysisEditableFields, value: string) => {
    setAnalysisResult((prev) => (prev ? { ...prev, [field]: value } : prev));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedSuccess(false);

    const parsedArea = areaSqm.trim() ? Number(areaSqm) : null;
    const validationError = validateProjectDraft({
      title,
      mode: 'idea_to_project',
      prompt_brief: promptBrief,
      area_sqm: parsedArea,
    });
    if (validationError) {
      setError(validationError);
      return;
    }

    setSaving(true);
    try {
      await onCreateProject({
        title: title.trim(),
        mode: 'idea_to_project',
        status: 'awaiting_ai_pipeline',
        building_type: buildingType,
        area_sqm: parsedArea,
        modules_count: Number(modulesCount) || 1,
        style_preset: stylePreset,
        preserve_geometry: true,
        prompt_brief: promptBrief.trim(),
        geometry_notes: geometryNotes.trim(),
        sketch_image_url: null,
        reference_ids: selectedRefIds,
        initial_analysis: analysisResult
          ? {
              mode: 'idea_to_project',
              provider: analysisResult.provider,
              model: analysisResult.model,
              is_free_tier: analysisResult.is_free_tier,
              response_time_ms: analysisResult.response_time_ms,
              schema_version: analysisResult.schema_version,
              analysis_source: analysisResult.is_mock
                ? 'mock'
                : analysisResult.analysis_source,
              summary: analysisResult.summary,
              spatial_layout: analysisResult.spatial_layout,
              materials_proposal: analysisResult.materials_proposal,
              lighting_proposal: analysisResult.lighting_proposal,
              geometry_preservation_note: analysisResult.geometry_preservation_note,
              visualization_prompt: analysisResult.visualization_prompt,
              rooms: analysisResult.rooms,
              geometry: analysisResult.geometry,
              openings: analysisResult.openings,
              openings_completeness_check: analysisResult.openings_completeness_check,
              orientation_source: analysisResult.orientation_source,
              unjustified_directions_detected: analysisResult.unjustified_directions_detected,
              dimension_observations: analysisResult.dimension_observations,
              dimension_checks: analysisResult.dimension_checks,
              dimension_conflicts: analysisResult.dimension_conflicts,
              dimension_confidence: analysisResult.dimension_confidence,
              geometry_protection: analysisResult.geometry_protection,
              uncertainties: analysisResult.uncertainties,
              user_requirements: analysisResult.user_requirements,
              ai_suggestions: analysisResult.ai_suggestions,
              observed_facts: analysisResult.observed_facts,
              model_interpretations: analysisResult.model_interpretations,
              indeterminable_elements: analysisResult.indeterminable_elements,
              clarification_questions: analysisResult.clarification_questions,
              disclaimer: analysisResult.disclaimer,
              raw_response_text: analysisResult.raw_response_text,
            }
          : null,
      });
      setSavedSuccess(true);
      setTitle('');
      setPromptBrief('');
      setGeometryNotes('');
      setSelectedRefIds([]);
      setAnalysisResult(null);
      setAnalysisError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zapisać koncepcji.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-zinc-500">Tryb B · Koncepcja tekstowa</p>
          <h1 className="text-2xl sm:text-3xl font-semibold text-zinc-950 mt-0.5">
            Pomysł → Projekt
          </h1>
        </div>
        <div className="flex items-center gap-2 text-xs font-medium text-zinc-700 bg-white border border-zinc-200 px-3.5 py-2 rounded-md">
          <Layers className="w-3.5 h-3.5 text-zinc-900" aria-hidden="true" />
          <span>Ścieżka: Opis idei → Szkic koncepcyjny → Wizualizacja</span>
        </div>
      </div>

      {error && <StatusNotice tone="error" title="Błąd formularza" description={error} />}
      {savedSuccess && (
        <div className="bg-emerald-50/80 border border-emerald-200 rounded-lg px-4 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-emerald-950">
              Koncepcja projektu została zapisana w SQLite
            </p>
            <p className="text-xs text-emerald-800 mt-0.5">
              Opis wraz z konfiguracją modułów oczekuje w historii na wygenerowanie szkicu i
              wizualizacji.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('history')}
            className="px-3.5 py-2 rounded-md bg-emerald-900 text-white text-xs font-medium hover:bg-emerald-800 whitespace-nowrap"
          >
            Otwórz historię projektów
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Lewa kolumna: wybór typu projektu i duże pole opisu pomysłu */}
        <div className="xl:col-span-7 bg-white border border-zinc-200/90 rounded-lg p-6 space-y-6">
          <div>
            <span className="block text-xs font-semibold text-zinc-900 mb-3">
              Wybierz typ projektu
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <button
                type="button"
                onClick={() => handleSelectCategory('modular_house')}
                className={`p-4 rounded-md border text-left transition-colors ${
                  projectCategory === 'modular_house'
                    ? 'border-zinc-950 bg-zinc-50'
                    : 'border-zinc-200 hover:border-zinc-300'
                }`}
              >
                <div className="flex items-center gap-2 text-sm font-semibold text-zinc-950">
                  <Home className="w-4 h-4" aria-hidden="true" />
                  <span>Dom modułowy</span>
                </div>
                <p className="mt-1 text-xs text-zinc-600">
                  Bryła zewnętrzna, układ modułów, dach, elewacja i otoczenie działki.
                </p>
              </button>

              <button
                type="button"
                onClick={() => handleSelectCategory('interior')}
                className={`p-4 rounded-md border text-left transition-colors ${
                  projectCategory === 'interior'
                    ? 'border-zinc-950 bg-zinc-50'
                    : 'border-zinc-200 hover:border-zinc-300'
                }`}
              >
                <div className="flex items-center gap-2 text-sm font-semibold text-zinc-950">
                  <Sofa className="w-4 h-4" aria-hidden="true" />
                  <span>Wnętrze</span>
                </div>
                <p className="mt-1 text-xs text-zinc-600">
                  Strefa dzienna, kuchnia, sypialnia, materiały ścian i oświetlenie wewnętrzne.
                </p>
              </button>
            </div>
          </div>

          <div>
            <label htmlFor="idea-title" className="block text-xs font-medium text-zinc-700 mb-1.5">
              Nazwa koncepcji projektu
            </label>
            <input
              id="idea-title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                projectCategory === 'interior'
                  ? 'np. Salon z aneksem w module 42 m²'
                  : 'np. Rezydencja Modułowa Jeziorna 92 m²'
              }
              className="w-full px-3.5 py-2.5 text-sm border border-zinc-300 rounded-md bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
            />
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
              <label htmlFor="idea-brief" className="block text-xs font-medium text-zinc-700">
                Opis pomysłu architektonicznego
              </label>
              <button
                type="button"
                onClick={applySampleIdea}
                className="text-xs font-medium text-zinc-700 hover:text-zinc-950 underline underline-offset-4"
              >
                Wstaw przykładowy opis koncepcji
              </button>
            </div>
            <textarea
              id="idea-brief"
              rows={7}
              required
              value={promptBrief}
              onChange={(e) => setPromptBrief(e.target.value)}
              placeholder="Opisz układ modułów, liczbę pomieszczeń, orientację przeszkleń względem stron świata, preferowane materiały wykończeniowe, porę dnia oraz charakter działki lub wnętrza..."
              className="w-full px-4 py-3 text-sm border border-zinc-300 rounded-md bg-white leading-relaxed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
            />
            <p className="mt-2 text-xs text-zinc-500 leading-relaxed">
              Podpowiedź: {SAMPLE_IDEAS[projectCategory]}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="idea-area" className="block text-xs font-medium text-zinc-700 mb-1.5">
                Metraż (m²)
              </label>
              <input
                id="idea-area"
                type="number"
                step="0.5"
                min="1"
                value={areaSqm}
                onChange={(e) => setAreaSqm(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md font-mono-tabular"
              />
            </div>

            <div>
              <label
                htmlFor="idea-modules"
                className="block text-xs font-medium text-zinc-700 mb-1.5"
              >
                Liczba modułów
              </label>
              <input
                id="idea-modules"
                type="number"
                min="1"
                max="24"
                value={modulesCount}
                onChange={(e) => setModulesCount(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md font-mono-tabular"
              />
            </div>

            <div>
              <label htmlFor="idea-style" className="block text-xs font-medium text-zinc-700 mb-1.5">
                Styl bazowy
              </label>
              <select
                id="idea-style"
                value={stylePreset}
                onChange={(e) => setStylePreset(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white"
              >
                <option value="Nordic Graphite">Nordic Graphite</option>
                <option value="Raw Steel & Cedar">Raw Steel & Cedar</option>
                <option value="Birch & Microcement">Birch & Microcement</option>
                <option value="Shou Sugi Ban Minimal">Shou Sugi Ban Minimal</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="idea-notes" className="block text-xs font-medium text-zinc-700 mb-1.5">
              Parametry konstrukcyjne i stolarka (opcjonalnie)
            </label>
            <textarea
              id="idea-notes"
              rows={2}
              value={geometryNotes}
              onChange={(e) => setGeometryNotes(e.target.value)}
              placeholder="np. Szerokość transportowa modułu 3.45 m, wysokość pomieszczeń 2.95 m"
              className="w-full px-3 py-2 text-sm border border-zinc-300 rounded-md bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
            />
          </div>
        </div>

        {/* Prawa kolumna: uruchomienie darmowej analizy AI + wyniki + referencje */}
        <div className="xl:col-span-5 space-y-6 min-w-0">
          <div className="bg-white border border-zinc-200/90 rounded-lg p-5 sm:p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-semibold text-zinc-950">
                  Koncepcja AI i struktura projektu (0 zł)
                </h2>
                <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">
                  Darmowy model AI opracowuje układ modułów, materiały, oświetlenie i prompt do
                  wizualizacji.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2 min-w-0 max-w-full">
                <label
                  htmlFor="idea-ai-provider"
                  className="text-xs font-medium text-zinc-700 whitespace-nowrap"
                >
                  Dostawca:
                </label>
                <select
                  id="idea-ai-provider"
                  value={preferredProvider}
                  onChange={(e) => setPreferredProvider(e.target.value as ProviderPreference)}
                  disabled={analyzing}
                  className="px-3 py-2 text-xs font-medium bg-white border border-zinc-300 rounded-md text-zinc-900 min-w-0 max-w-full w-full sm:w-auto"
                >
                  <option value="auto">Automatyczny (wg ustawień)</option>
                  <option value="gemini">Google Gemini (Free Tier)</option>
                  <option value="groq">GroqCloud (Free Tier)</option>
                </select>
              </div>

              <button
                type="button"
                disabled={analyzing}
                onClick={() => void handleRunIdeaAnalysis()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 disabled:opacity-50 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{analyzing ? 'Generowanie koncepcji...' : 'Generuj koncepcję AI (0 zł)'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-zinc-100">
              <div className="rounded-md border border-dashed border-zinc-300 bg-zinc-50/70 p-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900">
                  <PenTool className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>01. Koncepcja tekstowa AI</span>
                </div>
                <p className="text-xs text-zinc-600 mt-1.5 leading-relaxed">
                  Korzysta wyłącznie z darmowego planu Gemini lub Groq bez płatnego fallbacku.
                </p>
              </div>

              <div className="rounded-md border border-dashed border-zinc-300 bg-zinc-50/70 p-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900">
                  <Sparkles className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>02. Generowanie obrazu</span>
                </div>
                <p className="text-xs text-zinc-600 mt-1.5 leading-relaxed">
                  Niedostępne w wariancie 0 zł. Opis, analiza i prompt zapisywane są w SQLite.
                </p>
              </div>
            </div>
          </div>

          <AnalysisResultPanel
            mode="idea_to_project"
            analysis={analysisResult}
            loading={analyzing}
            error={analysisError}
            onChangeField={handleAnalysisFieldChange}
            onRetry={() => void handleRunIdeaAnalysis()}
          />

          <ImageGenerationPanel
            mode="idea_to_project"
            hasSavedAnalysis={Boolean(analysisResult)}
            previewImageUrl={generatedRenderUrl}
            overview={imageProvidersOverview ?? null}
            onGenerate={async (preferredProvider, aspectRatio) => {
              const res = await apiClient.generateDraftImage({
                mode: 'idea_to_project',
                title: title.trim() || 'Nowa koncepcja modułowa',
                building_type: buildingType,
                style_preset: stylePreset,
                preserve_geometry: true,
                prompt:
                  analysisResult?.visualization_prompt ||
                  promptBrief.trim() ||
                  `${buildingType}, ${stylePreset}`,
                sketch_image_url: null,
                preferred_provider: preferredProvider,
                aspect_ratio: aspectRatio,
              });
              if (res.generated_image_url) {
                setGeneratedRenderUrl(res.generated_image_url);
              }
              if (onAfterAiCall) {
                void onAfterAiCall();
              }
              return res;
            }}
            compact={true}
          />

          <div className="bg-white border border-zinc-200/90 rounded-lg p-6 space-y-4">
            {references.length > 0 && (
              <ReferenceSelectorPanel
                references={references}
                selectedIds={selectedRefIds}
                onChangeSelectedIds={setSelectedRefIds}
                projectTitle={title.trim() || 'Nowa koncepcja modułowa'}
              />
            )}

            <div className="pt-2 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => onNavigate('history')}
                className="text-xs font-medium text-zinc-600 hover:text-zinc-950 underline underline-offset-4"
              >
                Historia projektów
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2.5 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 disabled:opacity-50 transition-colors"
              >
                {saving ? 'Zapisywanie...' : 'Zapisz koncepcję projektu'}
              </button>
            </div>
          </div>
        </div>
      </form>
    </motion.div>
  );
}
