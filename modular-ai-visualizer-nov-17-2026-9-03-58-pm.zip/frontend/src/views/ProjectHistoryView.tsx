import { useEffect, useMemo, useState } from 'react';
import { Eye, Search, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import type { NavSection, Project, ProjectMode, ProjectStatus } from '../types/domain';
import {
  formatAreaSqm,
  formatModeLabel,
  formatModeShortLabel,
  formatModulesCount,
  formatPolishDate,
  formatStatusLabel,
  sortProjects,
  type ProjectSortOption,
} from '../utils/formatters';
import { ImageFrame } from '../components/ImageFrame';
import { StatusNotice } from '../components/StatusNotice';

interface ProjectHistoryViewProps {
  projects: Project[];
  loading: boolean;
  onInspectProject: (project: Project) => void;
  onDeleteProject: (projectId: number) => Promise<void>;
  onNavigate: (section: NavSection) => void;
}

const PROJECT_PAGE_SIZE = 12;

export function ProjectHistoryView({
  projects,
  loading,
  onInspectProject,
  onDeleteProject,
  onNavigate,
}: ProjectHistoryViewProps) {
  const [modeFilter, setModeFilter] = useState<'all' | ProjectMode>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | ProjectStatus>('all');
  const [sortBy, setSortBy] = useState<ProjectSortOption>('date_desc');
  const [searchQuery, setSearchQuery] = useState('');
  const [visibleCount, setVisibleCount] = useState(PROJECT_PAGE_SIZE);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    setVisibleCount(PROJECT_PAGE_SIZE);
  }, [modeFilter, statusFilter, sortBy, searchQuery]);

  const filteredProjects = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return projects.filter((project) => {
      const matchesMode = modeFilter === 'all' || project.mode === modeFilter;
      const matchesStatus = statusFilter === 'all' || project.status === statusFilter;
      const matchesSearch =
        !q ||
        project.title.toLowerCase().includes(q) ||
        project.prompt_brief.toLowerCase().includes(q) ||
        (project.geometry_notes || '').toLowerCase().includes(q) ||
        project.building_type.toLowerCase().includes(q) ||
        project.style_preset.toLowerCase().includes(q);
      return matchesMode && matchesStatus && matchesSearch;
    });
  }, [projects, modeFilter, statusFilter, searchQuery]);

  const sortedProjects = useMemo(
    () => sortProjects(filteredProjects, sortBy),
    [filteredProjects, sortBy]
  );

  const visibleProjects = useMemo(
    () => sortedProjects.slice(0, visibleCount),
    [sortedProjects, visibleCount]
  );

  const handleConfirmDelete = async (projectId: number) => {
    setActionError(null);
    setDeletingId(projectId);
    try {
      await onDeleteProject(projectId);
      setConfirmDeleteId(null);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Nie udało się usunąć projektu.');
    } finally {
      setDeletingId(null);
    }
  };

  if (loading && projects.length === 0) {
    return (
      <div className="space-y-6 animate-pulse" aria-busy="true">
        <div className="h-14 bg-white border border-zinc-200/80 rounded-lg" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          <div className="h-72 bg-white border border-zinc-200/80 rounded-lg" />
          <div className="h-72 bg-white border border-zinc-200/80 rounded-lg" />
          <div className="h-72 bg-white border border-zinc-200/80 rounded-lg" />
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-2xl sm:text-3xl font-semibold text-zinc-950">Historia projektów</h1>
          <p className="text-sm text-zinc-600 mt-1">
            Galeria zapisanych projektów z możliwością filtrowania, sortowania, podglądu szczegółów
            i zmiany statusu.
          </p>
        </div>

        <p className="text-xs font-mono-tabular text-zinc-600 bg-white border border-zinc-200 px-3 py-1.5 rounded-md shrink-0">
          Wyświetlono <strong className="text-zinc-950">{sortedProjects.length}</strong> z{' '}
          <strong className="text-zinc-950">{projects.length}</strong> projektów
        </p>
      </div>

      {actionError && (
        <StatusNotice tone="error" title="Błąd operacji na projekcie" description={actionError} />
      )}

      {/* Pasek filtrów trybu, statusu, sortowania i wyszukiwarki */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 min-w-0">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-zinc-200/75 rounded-md max-w-full">
            <button
              type="button"
              onClick={() => setModeFilter('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                modeFilter === 'all'
                  ? 'bg-white text-zinc-950 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              Wszystkie ({projects.length})
            </button>
            <button
              type="button"
              onClick={() => setModeFilter('sketch_to_render')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                modeFilter === 'sketch_to_render'
                  ? 'bg-white text-zinc-950 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              Szkic → Wizualizacja
            </button>
            <button
              type="button"
              onClick={() => setModeFilter('idea_to_project')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                modeFilter === 'idea_to_project'
                  ? 'bg-white text-zinc-950 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              Pomysł → Projekt
            </button>
          </div>

          <select
            aria-label="Filtruj według statusu projektu"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as 'all' | ProjectStatus)}
            className="px-3 py-2 text-xs font-medium bg-white border border-zinc-300 rounded-md text-zinc-800 max-w-full"
          >
            <option value="all">Wszystkie statusy</option>
            <option value="draft">{formatStatusLabel('draft')}</option>
            <option value="awaiting_ai_pipeline">{formatStatusLabel('awaiting_ai_pipeline')}</option>
            <option value="archived">{formatStatusLabel('archived')}</option>
          </select>

          <select
            aria-label="Sortuj projekty"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as ProjectSortOption)}
            className="px-3 py-2 text-xs font-medium bg-white border border-zinc-300 rounded-md text-zinc-800 max-w-full"
          >
            <option value="date_desc">Data: najnowsze</option>
            <option value="date_asc">Data: najstarsze</option>
            <option value="name_asc">Nazwa (A–Z)</option>
            <option value="name_desc">Nazwa (Z–A)</option>
            <option value="area_desc">Metraż (malejąco)</option>
            <option value="area_asc">Metraż (rosnąco)</option>
          </select>
        </div>

        <div className="relative w-full xl:w-72 shrink-0">
          <Search
            className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Szukaj projektu..."
            aria-label="Szukaj w historii projektów"
            className="w-full pl-9 pr-3.5 py-2 text-sm bg-white border border-zinc-300 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
          />
        </div>
      </div>

      {/* Puste stany vs Galeria projektów */}
      {projects.length === 0 ? (
        <div className="bg-white border border-zinc-200 rounded-lg p-12 text-center">
          <p className="text-base font-medium text-zinc-900">Pracownia nie ma jeszcze projektów</p>
          <p className="text-xs text-zinc-500 mt-1 mb-5 max-w-md mx-auto leading-relaxed">
            Baza projektów jest obecnie pusta. Rozpocznij od przesłania szkicu w Trybie A lub
            opisania koncepcji w Trybie B.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('new_project')}
            className="px-4 py-2 rounded-md bg-[#141518] text-white text-xs font-medium hover:bg-zinc-800 transition-colors"
          >
            Wybierz tryb nowego projektu
          </button>
        </div>
      ) : sortedProjects.length === 0 ? (
        <div className="bg-white border border-zinc-200 rounded-lg p-12 text-center">
          <p className="text-sm font-medium text-zinc-900">Brak projektów dla wybranych filtrów</p>
          <p className="text-xs text-zinc-500 mt-1 mb-4">
            Żaden z {projects.length} zapisanych projektów nie spełnia bieżących kryteriów.
          </p>
          <button
            type="button"
            onClick={() => {
              setModeFilter('all');
              setStatusFilter('all');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-md border border-zinc-300 text-xs font-medium text-zinc-800 hover:bg-zinc-50"
          >
            Resetuj filtry
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {visibleProjects.map((project) => {
              const isConfirming = confirmDeleteId === project.id;
              const isDeleting = deletingId === project.id;

              return (
                <article
                  key={project.id}
                  className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden flex flex-col hover:border-zinc-300 transition-colors min-w-0"
                >
                  <button
                    type="button"
                    onClick={() => onInspectProject(project)}
                    aria-label={`Otwórz szczegóły projektu ${project.title}`}
                    className="text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-zinc-900"
                  >
                    <div className="overflow-hidden">
                      <ImageFrame
                        src={project.preview_image_url || project.sketch_image_url}
                        alt={`Podgląd ${project.title}`}
                        aspectClass="aspect-[16/10]"
                        fit={
                          !project.preview_image_url && project.sketch_image_url
                            ? 'contain'
                            : 'cover'
                        }
                        fallbackLabel="Karta projektowa oczekuje na wizualizację"
                        className="border-0 border-b border-zinc-200/80 group-hover:scale-[1.015] transition-transform duration-200"
                      />
                    </div>
                  </button>

                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-xs text-zinc-500 font-mono-tabular">
                        {formatModeShortLabel(project.mode)} · {formatModeLabel(project.mode)} ·{' '}
                        {formatStatusLabel(project.status)}
                      </p>
                      <h2 className="mt-1.5 text-base font-semibold text-zinc-950">
                        <button
                          type="button"
                          onClick={() => onInspectProject(project)}
                          className="text-left hover:underline underline-offset-4"
                        >
                          {project.title}
                        </button>
                      </h2>
                      <p className="mt-1.5 text-sm text-zinc-600 line-clamp-2 leading-relaxed">
                        {project.prompt_brief || project.building_type}
                      </p>
                      <p className="mt-3 text-xs text-zinc-500 font-mono-tabular">
                        {project.building_type} · {formatAreaSqm(project.area_sqm)} ·{' '}
                        {formatModulesCount(project.modules_count)} · Referencje:{' '}
                        {(project.reference_ids ?? []).length}
                        {(project.analyses_count ?? (project.latest_analysis ? 1 : 0)) > 0
                          ? ` · Analizy AI: ${project.analyses_count ?? 1}`
                          : ''}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-zinc-100 flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs text-zinc-500 font-mono-tabular">
                        {formatPolishDate(project.updated_at)}
                      </span>

                      {isConfirming ? (
                        <div className="flex flex-wrap items-center gap-1.5">
                          <button
                            type="button"
                            disabled={isDeleting}
                            onClick={() => void handleConfirmDelete(project.id)}
                            className="px-2.5 py-1.5 text-xs font-medium rounded bg-red-700 text-white hover:bg-red-800 disabled:opacity-50"
                          >
                            {isDeleting ? 'Usuwanie...' : 'Potwierdź'}
                          </button>
                          <button
                            type="button"
                            disabled={isDeleting}
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2.5 py-1.5 text-xs font-medium rounded border border-zinc-300 text-zinc-700 hover:bg-zinc-50"
                          >
                            Anuluj
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onInspectProject(project)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded border border-zinc-300 text-zinc-900 hover:bg-zinc-50 transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Szczegóły</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(project.id)}
                            aria-label={`Usuń projekt ${project.title}`}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded border border-red-200 text-red-700 hover:bg-red-50 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>

          {sortedProjects.length > visibleCount && (
            <div className="flex justify-center">
              <button
                type="button"
                onClick={() => setVisibleCount((prev) => prev + PROJECT_PAGE_SIZE)}
                className="px-4 py-2 text-xs font-medium text-zinc-800 hover:text-zinc-950 border border-zinc-300 rounded-md bg-white hover:bg-zinc-50 transition-colors"
              >
                Pokaż kolejne projekty ({sortedProjects.length - visibleCount} pozostało)
              </button>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
