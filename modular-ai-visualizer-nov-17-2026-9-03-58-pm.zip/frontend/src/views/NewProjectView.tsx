import { ArrowRight, BookOpen, Lock, PenTool, ShieldCheck, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import type { NavSection } from '../types/domain';
import { ImageFrame } from '../components/ImageFrame';

interface NewProjectViewProps {
  onNavigate: (section: NavSection) => void;
}

export function NewProjectView({ onNavigate }: NewProjectViewProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="max-w-5xl space-y-8"
    >
      <div>
        <p className="text-xs font-medium text-zinc-500">Wybór ścieżki projektowej</p>
        <h1 className="text-2xl sm:text-3xl font-semibold text-zinc-950 mt-0.5">
          Rozpocznij nowy projekt
        </h1>
        <p className="text-sm text-zinc-600 mt-1.5 max-w-2xl leading-relaxed">
          Wybierz właściwy tryb pracy w studiu. Wszystkie założenia, szkice i powiązane materiały są
          zapisywane bezpośrednio w bazie SQLite bez opłat zewnętrznych.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <article className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden flex flex-col justify-between">
          <div className="grid grid-cols-2 border-b border-zinc-200/80 bg-zinc-50">
            <ImageFrame
              src="/src/assets/images/architectural_hand_sketch_1794908154196.jpg"
              alt="Przykładowy rzut i szkic dla trybu A"
              aspectClass="aspect-[16/10]"
              fit="contain"
              className="border-0 border-r border-zinc-200/80"
            />
            <ImageFrame
              src="/src/assets/images/modular_cabin_exterior_1794908155648.jpg"
              alt="Docelowa realizacja domu modułowego"
              aspectClass="aspect-[16/10]"
              className="border-0"
            />
          </div>

          <div className="p-6 flex-1 flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
                <PenTool className="w-3.5 h-3.5 text-zinc-900" aria-hidden="true" />
                <span>Tryb A · Z gotowego rysunku lub rzutu</span>
              </div>
              <h2 className="text-xl font-semibold text-zinc-950">Szkic → Wizualizacja</h2>
              <p className="text-sm text-zinc-600 leading-relaxed">
                Prześlij własny szkic odręczny albo rzut techniczny. Określ blokadę położenia ścian,
                okien i drzwi, dobierz materiały elewacyjne oraz oświetlenie.
              </p>
              <div className="flex items-start gap-2 text-xs text-zinc-600 pt-1">
                <Lock className="w-3.5 h-3.5 text-zinc-800 mt-0.5 shrink-0" aria-hidden="true" />
                <span>
                  Priorytet wiernego zachowania proporcji i osi otworów oryginalnego rysunku.
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('sketch_mode')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 transition-colors"
            >
              <span>Przejdź do: Szkic → Wizualizacja</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </article>

        <article className="bg-white border border-zinc-200/90 rounded-lg overflow-hidden flex flex-col justify-between">
          <div className="border-b border-zinc-200/80 bg-zinc-50">
            <ImageFrame
              src="/src/assets/images/modular_pavilion_concept_1794908154441.jpg"
              alt="Koncepcja pawilonu modułowego"
              aspectClass="aspect-[32/10]"
              className="border-0"
            />
          </div>

          <div className="p-6 flex-1 flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
                <Sparkles className="w-3.5 h-3.5 text-zinc-900" aria-hidden="true" />
                <span>Tryb B · Od opisu słownego do koncepcji</span>
              </div>
              <h2 className="text-xl font-semibold text-zinc-950">Pomysł → Projekt</h2>
              <p className="text-sm text-zinc-600 leading-relaxed">
                Opisz funkcję pomieszczeń, liczbę modułów, metraż i charakter działki lub wnętrza.
                Przygotuj uporządkowaną kartę koncepcyjną powiązaną z biblioteką referencji.
              </p>
              <div className="flex items-start gap-2 text-xs text-zinc-600 pt-1">
                <BookOpen
                  className="w-3.5 h-3.5 text-zinc-800 mt-0.5 shrink-0"
                  aria-hidden="true"
                />
                <span>
                  Obsługa zarówno pełnych domów modułowych, jak i aranżacji pojedynczych wnętrz.
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('idea_mode')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-md bg-white text-zinc-950 border border-zinc-300 text-sm font-medium hover:bg-zinc-50 transition-colors"
            >
              <span>Przejdź do: Pomysł → Projekt</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </article>
      </div>

      <div className="bg-white border border-zinc-200/90 rounded-lg px-5 py-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3 min-w-0 flex-1">
          <ShieldCheck className="w-4 h-4 text-zinc-900 mt-0.5 shrink-0" aria-hidden="true" />
          <p className="text-xs text-zinc-600 leading-relaxed">
            Aktywna polityka <strong className="text-zinc-900">Zero Kosztów (0 zł)</strong>:
            analiza opisów i szkiców może korzystać z darmowego planu Gemini lub Groq, natomiast
            płatne API do generowania obrazów pozostają zablokowane.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className="text-xs font-medium text-zinc-800 hover:text-zinc-950 underline underline-offset-4 shrink-0"
        >
          Sprawdź limity w Ustawieniach
        </button>
      </div>
    </motion.div>
  );
}
