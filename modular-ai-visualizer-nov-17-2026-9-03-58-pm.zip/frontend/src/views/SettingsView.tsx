import { useEffect, useState, type FormEvent } from 'react';
import { Database, RefreshCw, ShieldCheck } from 'lucide-react';
import type { HealthResponse, ProvidersOverview, StudioSettings } from '../types/domain';
import { formatPolishDate } from '../utils/formatters';
import { StatusNotice } from '../components/StatusNotice';

interface SettingsViewProps {
  settings: StudioSettings | null;
  providers: ProvidersOverview | null;
  health: HealthResponse | null;
  onSaveSettings: (payload: Partial<StudioSettings>) => Promise<void>;
  onRefreshHealth: () => Promise<void>;
}

function formatAvailabilityLabel(status: string): string {
  switch (status) {
    case 'available_free':
      return 'Dostępny (darmowy plan)';
    case 'disabled_by_cost_policy':
      return 'Zablokowany (polityka Zero Kosztów)';
    case 'unverified_blocked':
      return 'Zablokowany (niezweryfikowany dostawca)';
    case 'unavailable_free':
      return 'Brak potwierdzonego darmowego API / lokalny serwer wyłączony';
    case 'missing_api_key':
      return 'Brak klucza w .env backendu';
    case 'cooldown':
      return 'Cooldown po limicie 429';
    case 'local_limit_reached':
      return 'Osiągnięto lokalny limit dzienny';
    default:
      return status;
  }
}

export function SettingsView({
  settings,
  providers,
  health,
  onSaveSettings,
  onRefreshHealth,
}: SettingsViewProps) {
  const [studioName, setStudioName] = useState(
    settings?.studio_name ?? 'Modular AI Visualizer Studio'
  );
  const [defaultStyle, setDefaultStyle] = useState(settings?.default_style ?? 'Nordic Graphite');
  const [defaultPreserveGeometry, setDefaultPreserveGeometry] = useState(
    settings?.default_preserve_geometry ?? true
  );
  const [aspectRatio, setAspectRatio] = useState(settings?.preferred_aspect_ratio ?? '16:9');
  const [saving, setSaving] = useState(false);
  const [checkingHealth, setCheckingHealth] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (settings) {
      setStudioName(settings.studio_name);
      setDefaultStyle(settings.default_style);
      setDefaultPreserveGeometry(settings.default_preserve_geometry);
      setAspectRatio(settings.preferred_aspect_ratio);
    }
  }, [settings]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedNotice(false);
    setSaving(true);
    try {
      await onSaveSettings({
        studio_name: studioName.trim(),
        default_style: defaultStyle,
        default_preserve_geometry: defaultPreserveGeometry,
        preferred_aspect_ratio: aspectRatio,
      });
      setSavedNotice(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zapisać ustawień.');
    } finally {
      setSaving(false);
    }
  };

  const handleHealthRefresh = async () => {
    setCheckingHealth(true);
    try {
      await onRefreshHealth();
    } finally {
      setCheckingHealth(false);
    }
  };

  const costPolicy = providers?.cost_policy;
  const imageGen = providers?.image_generator;

  return (
    <div className="max-w-5xl space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-semibold text-zinc-950">
          Ustawienia pracowni i kontrola kosztów
        </h1>
        <p className="text-sm text-zinc-600 mt-1">
          Domyślne parametry projektowe w SQLite oraz panel „Darmowe AI i limity” z twardą blokadą
          płatnych usług.
        </p>
      </div>

      {error && <StatusNotice tone="error" title="Błąd zapisu" description={error} />}
      {savedNotice && (
        <StatusNotice
          tone="success"
          title="Zapisano ustawienia"
          description="Preferencje pracowni zostały zaktualizowane w bazie SQLite."
        />
      )}

      {/* Sekcja: Darmowe AI i limity */}
      <section
        aria-labelledby="free-ai-limits-heading"
        className="bg-white border border-zinc-200/90 rounded-lg p-6 space-y-5"
      >
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-zinc-100 pb-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-zinc-900 shrink-0" aria-hidden="true" />
              <h2 id="free-ai-limits-heading" className="text-lg font-semibold text-zinc-950">
                Darmowe AI i limity
              </h2>
            </div>
            <p className="text-xs text-zinc-600 mt-1 leading-relaxed max-w-xl">
              Klucze API są odczytywane wyłącznie po stronie backendu z pliku .env i nigdy nie są
              przesyłane do przeglądarki.
            </p>
          </div>

          <div className="rounded-md bg-zinc-50 border border-zinc-200 px-3.5 py-2 text-left xl:text-right text-xs font-mono-tabular shrink-0">
            <p className="font-semibold text-zinc-950">
              {costPolicy?.paid_services_blocked
                ? 'Blokada płatnych usług: AKTYWNA'
                : 'Blokada płatnych usług: WYŁĄCZONA'}
            </p>
            <p className="text-zinc-600 mt-0.5">
              FREE_ONLY={String(costPolicy?.free_only ?? true)} · ALLOW_PAID_APIS=
              {String(costPolicy?.allow_paid_apis ?? false)} · BUDGET=
              {costPolicy?.monthly_budget ?? 0} zł
            </p>
          </div>
        </div>

        {/* Zastrzeżenie dotyczące lokalnego licznika */}
        <StatusNotice
          tone="info"
          title="Uwaga o lokalnym liczniku wywołań"
          description="Lokalna liczba wywołań zlicza wyłącznie zapytania wykonane przez naszą aplikację i NIE jest oficjalnym saldem konta dostawcy. Google Gemini i GroqCloud nie udostępniają publicznego API do odczytu bieżącego salda limitów."
        />

        {/* Status darmowego generatora obrazów (Multi-Engine Audit) */}
        {imageGen && (
          <div className="p-4 rounded-md border border-zinc-200 bg-zinc-50/70 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-zinc-950">
                Warstwa generowania obrazów (Multi-Engine ImageProviderRouter): {imageGen.provider_name}
              </span>
              <span className="font-mono-tabular text-zinc-700">
                Status: {formatAvailabilityLabel(imageGen.status)}
              </span>
            </div>
            <p className="text-xs text-zinc-600 leading-relaxed">{imageGen.message}</p>

            {(providers?.image_providers_overview?.providers?.length ?? 0) > 0 && (
              <div className="pt-2 border-t border-zinc-200/80 space-y-2">
                <p className="text-xs font-semibold text-zinc-900">
                  Zarejestrowane silniki generowania obrazów (
                  {providers?.image_providers_overview?.providers.length})
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {providers?.image_providers_overview?.providers.map((imgProv) => (
                    <div
                      key={imgProv.key}
                      className="p-3 rounded border border-zinc-200 bg-white text-xs space-y-1.5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-1.5">
                        <span className="font-semibold text-zinc-950">{imgProv.name}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[11px] font-medium border ${
                            imgProv.available
                              ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                              : imgProv.blocked_by_cost_policy
                                ? 'border-red-200 bg-red-50 text-red-900'
                                : 'border-zinc-300 bg-zinc-50 text-zinc-700'
                          }`}
                        >
                          {formatAvailabilityLabel(imgProv.availability_status)}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-600 font-mono-tabular">
                        Model: {imgProv.model} · img2img:{' '}
                        {imgProv.supports_image_to_image ? 'TAK' : 'NIE'} · Geometria:{' '}
                        {imgProv.supports_geometry_preservation ? 'TAK' : 'NIE'} · Rozdzielczości:{' '}
                        {(imgProv.supported_resolutions ?? []).join(', ')}
                      </p>
                      {imgProv.unavailability_reason && (
                        <p className="text-[11px] text-zinc-700 leading-relaxed">
                          {imgProv.unavailability_reason}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Lista dostawców */}
        <div className="divide-y divide-zinc-200 border border-zinc-200 rounded-md">
          {(providers?.providers ?? []).map((provider) => (
            <div key={provider.key} className="p-4 sm:p-5 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold text-zinc-950">{provider.name}</h3>
                  <p className="text-xs text-zinc-600 mt-0.5">{provider.role}</p>
                </div>
                <div className="text-left sm:text-right shrink-0">
                  <p className="text-xs font-semibold text-zinc-900">
                    {formatAvailabilityLabel(provider.availability_status)}
                  </p>
                  <p className="text-xs text-zinc-500 font-mono-tabular mt-0.5">
                    Klucz w backendzie: {provider.api_key_configured ? 'skonfigurowany' : 'brak'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-zinc-100 text-xs">
                <div>
                  <span className="text-zinc-500 block">Model</span>
                  <span className="font-medium text-zinc-900 font-mono-tabular break-all">
                    {provider.model}
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block">Rodzaj planu</span>
                  <span className="font-medium text-zinc-900">{provider.plan_type}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block">Lokalna liczba wywołań</span>
                  <span className="font-medium text-zinc-900 font-mono-tabular">
                    Dziś: {provider.local_calls_today} · Łącznie: {provider.local_calls_total}
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block">Cooldown po limicie</span>
                  <span className="font-medium text-zinc-900 font-mono-tabular">
                    {provider.cooldown_until
                      ? `Do ${formatPolishDate(provider.cooldown_until)}`
                      : 'Brak aktywnego cooldownu'}
                  </span>
                </div>
              </div>

              <div className="text-xs text-zinc-600 space-y-1">
                <p>{provider.configured_limits}</p>
                {provider.last_error && (
                  <p className="text-red-700 font-medium">
                    Ostatni błąd: {provider.last_error}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Preferencje pracowni */}
      <form
        onSubmit={handleSubmit}
        className="bg-white border border-zinc-200/90 rounded-lg p-6 space-y-5"
      >
        <h2 className="text-base font-semibold text-zinc-950">Preferencje domyślne pracowni</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label htmlFor="set-studio" className="block text-xs font-medium text-zinc-700 mb-1.5">
              Nazwa pracowni / zespołu
            </label>
            <input
              id="set-studio"
              type="text"
              required
              value={studioName}
              onChange={(e) => setStudioName(e.target.value)}
              className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
            />
          </div>

          <div>
            <label htmlFor="set-style" className="block text-xs font-medium text-zinc-700 mb-1.5">
              Domyślny styl architektoniczny
            </label>
            <select
              id="set-style"
              value={defaultStyle}
              onChange={(e) => setDefaultStyle(e.target.value)}
              className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white"
            >
              <option value="Nordic Graphite">Nordic Graphite</option>
              <option value="Raw Steel & Cedar">Raw Steel & Cedar</option>
              <option value="Birch & Microcement">Birch & Microcement</option>
              <option value="Shou Sugi Ban Minimal">Shou Sugi Ban Minimal</option>
            </select>
          </div>

          <div>
            <label htmlFor="set-ratio" className="block text-xs font-medium text-zinc-700 mb-1.5">
              Domyślne proporcje kadrów wizualizacji
            </label>
            <select
              id="set-ratio"
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value)}
              className="w-full px-3.5 py-2 text-sm border border-zinc-300 rounded-md bg-white font-mono-tabular"
            >
              <option value="16:9">16:9 (Panorama architektoniczna)</option>
              <option value="4:3">4:3 (Karta projektowa)</option>
              <option value="3:2">3:2 (Obiektyw 24mm)</option>
            </select>
          </div>

          <div className="flex items-center pt-5">
            <label className="flex items-center gap-3 text-sm text-zinc-800 cursor-pointer">
              <input
                type="checkbox"
                checked={defaultPreserveGeometry}
                onChange={(e) => setDefaultPreserveGeometry(e.target.checked)}
                className="h-4 w-4 rounded border-zinc-300"
              />
              <span>Domyślnie blokuj geometrię w Trybie A</span>
            </label>
          </div>
        </div>

        <div className="pt-3 border-t border-zinc-100 flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-4 py-2 rounded-md bg-[#141518] text-white text-sm font-medium hover:bg-zinc-800 disabled:opacity-50 transition-colors"
          >
            {saving ? 'Zapisywanie...' : 'Zapisz ustawienia'}
          </button>
        </div>
      </form>

      {/* Weryfikacja połączenia z bazą SQLite i backendem */}
      <section className="bg-white border border-zinc-200/90 rounded-lg p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Database className="w-4 h-4 text-zinc-800" aria-hidden="true" />
            <h2 className="text-base font-semibold text-zinc-950">
              Połączenie z backendem FastAPI i SQLite
            </h2>
          </div>
          <button
            type="button"
            onClick={handleHealthRefresh}
            disabled={checkingHealth}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-md border border-zinc-300 text-xs font-medium text-zinc-900 hover:bg-zinc-50 transition-colors"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${checkingHealth ? 'animate-spin' : ''}`}
              aria-hidden="true"
            />
            <span>Sprawdź /api/health</span>
          </button>
        </div>

        {health ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-2 border-t border-zinc-100">
            <div>
              <span className="text-zinc-500 block">Status API</span>
              <span className="font-semibold text-zinc-950 font-mono-tabular">{health.status}</span>
            </div>
            <div>
              <span className="text-zinc-500 block">Połączenie SQLite</span>
              <span className="font-semibold text-zinc-950 font-mono-tabular">
                {health.database_connected ? 'Połączono (SELECT 1 OK)' : 'Błąd połączenia'}
              </span>
            </div>
            <div>
              <span className="text-zinc-500 block">Katalog storage/</span>
              <span className="font-semibold text-zinc-950 font-mono-tabular">
                {health.storage_ready ? 'Gotowy do zapisu' : 'Niedostępny'}
              </span>
            </div>
          </div>
        ) : (
          <p className="text-xs text-zinc-500">Brak odpowiedzi z endpointu /api/health.</p>
        )}
      </section>
    </div>
  );
}
